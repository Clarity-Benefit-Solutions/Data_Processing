CREATE PROCEDURE [dbo].[insert_to_auto_ftp_list]

AS
BEGIN




INSERT INTO [dbo].[ftp_autofile_list]
           ([find_autoftp_file])
   SELECT distinct replace(replace(f.[folder_name],right(f.[folder_name],charindex('.',reverse(f.[folder_name]))),''),'G:\FTP\AutomatedHeaderv1_Files\','')
     FROM [dbo].[alegeus_file_final] as f
	 join [dbo].[Automated_Header_list] as l
	   on charindex(l.[BENCODE],[file_row]) > 1
    where file_row like '%,BEN%' and len(f.folder_name) > 3
	  and l.to_FTP = 1

END
go

