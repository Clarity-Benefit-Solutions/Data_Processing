

CREATE   PROCEDURE spFB_GetBillingInvoice_sel	@Year int = null, 
											@Month int = null,
											@SearchText nvarchar(250) = null 

as

begin
set nocount on;
set transaction isolation level read uncommitted;
	
select	[Year]				= [Year],
		[Month]				= [Month],
		[Employer Name]		= [Employer Name],
		[Invoice Total]		= sum([pepm_amount]),
		[Service]			= count(1)

from	[dbo].[TBL_QB_IMPORTS_PRO]
where	[Year] = iif(@Year is null, year(Getdate()), @Year) and 
		[Month] = iif(@Month is null, [Month], @Month) and 
		[Employer Name] like iif(@SearchText is null, [Employer Name], '%'+ @SearchText +'%')

group	by [Year],
		   [Month],
		   [Employer Name]

end
go

