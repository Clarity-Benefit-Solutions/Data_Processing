-- =============================================
-- Author:		<JASWAL, MANOJ>
-- Create date: <03/04/2022>
-- Description:	<Create view from QB Unique Row>
-- =============================================

CREATE  VIEW [dbo].[VW_QB_UNIQUE_ROW] AS (

	SELECT
		[dbo].[TBL_STAGING_QBDETAIL].clientname
		, [dbo].[TBL_STAGING_QBDETAIL].[Alternate ER ID]
		, [dbo].[TBL_STAGING_QBDETAIL].ssn
		, [dbo].[TBL_STAGING_QBDETAIL].status
	FROM
		[dbo].[TBL_STAGING_QBDETAIL]
	WHERE
		((([dbo].[TBL_STAGING_QBDETAIL].relationshipname) = 'SELF'))
	GROUP BY
		[dbo].[TBL_STAGING_QBDETAIL].clientname
		,[dbo].[TBL_STAGING_QBDETAIL].[Alternate ER ID]
		,[dbo].[TBL_STAGING_QBDETAIL].ssn
		,[dbo].[TBL_STAGING_QBDETAIL].status
	HAVING
		((([dbo].[TBL_STAGING_QBDETAIL].status) = 'TE'))
)
go

