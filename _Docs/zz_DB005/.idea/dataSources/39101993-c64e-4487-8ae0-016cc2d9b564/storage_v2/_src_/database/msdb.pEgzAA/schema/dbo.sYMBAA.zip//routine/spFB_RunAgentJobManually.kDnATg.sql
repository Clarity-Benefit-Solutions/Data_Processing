
CREATE   PROCEDURE dbo.spFB_RunAgentJobManually
as
Begin 
  
EXEC dbo.sp_start_job N'TestJob' ;  

end
go

