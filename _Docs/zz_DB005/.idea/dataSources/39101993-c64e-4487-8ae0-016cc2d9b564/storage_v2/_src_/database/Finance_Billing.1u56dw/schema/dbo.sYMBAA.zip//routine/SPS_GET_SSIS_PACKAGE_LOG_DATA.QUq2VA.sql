
/*-- =============================================
-- Author:		<Manoj, Jaswal>
-- Create date: <25/03/2022>
-- Description:	<Get all error>
-- =============================================

COMMENTS:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
EXAMPLE:		EXEC SPS_GET_SSIS_PACKAGE_LOG_DATA 


OUTPUT:	
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

RETURN VALUES:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

MODIFICATIONS:

DATE        DEVELOPER                  DESCRIPTION
----------  -------------------------  ------------------------------------------------------------------------------------------------------------
*/
CREATE PROCEDURE [dbo].[SPS_GET_SSIS_PACKAGE_LOG_DATA] 
	@GUID varchar(50)
AS

SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

BEGIN
    SET NOCOUNT ON;  
	--get data from Logging db table
	SELECT Id,PackageName,PackageId,[Guid],MachineName,UserName,DataSource,StartDateTime,EndDateTime,NumRowsInserted,NumRowsUpdated,NumRowsDeleted,NumRowsTotal,IsSuccess,IsFailed,IsCompleted
	FROM [dbo].[TBL_LOGGINGDB] WHERE [Guid]=@GUID order by Id ASC


	--Get data form error logging db table
	SELECT eLogs.ID,eLogs.MachineName,eLogs.PackageName,eLogs.TaskName,eLogs.ErrorCode,eLogs.ErrorDescription,Dated,LoggingDbID
	FROM [dbo].[TBL_LOGGINGDB] ldb
		LEFT JOIN [dbo].[TBL_ERROR_LOGS] eLogs on ldb.Id=eLogs.LoggingDbID
	WHERE [Guid]=@GUID 
	AND ldb.Id IS NOT null
	order by ldb.Id ASC

	--First File

	Select f1.[Error Code],f1.[Error Column],f1.[Error Row No],f1.[Logging Db Id]  
	FROM [dbo].[TBL_LOGGINGDB] tldb      
		LEFT JOIN TBL_STAGING_EDI_5_PLAN_DOC_REPORT_ERROR f1 on tldb.Id=f1.[Logging Db Id]
	WHERE [Guid]=@GUID order by Id ASC
	
	
END;
go

