




CREATE   VIEW [dbo].[VW_NEW_CLIENT] AS (
SELECT  NEW_CLIENT.*, SERVICE_DETAIL.[TPA Code], SERVICE_DETAIL.[Line type], [Account Type Code], [Plan ID]
FROM [dbo].[TBL_STAGING_CLIENTS_MASTER]  AS NEW_CLIENT
LEFT JOIN [dbo].[TBL_STAGING_EDI_5_PLAN_DOC_REPORT]  AS SERVICE_DETAIL
ON NEW_CLIENT.ClientAlternate = SERVICE_DETAIL.Bencode
WHERE
iif(isnumeric((BillingStartDate)) = 1 , MONTH(BillingStartDate), 0)  = MONTH(GETDATE())
AND iif(isnumeric( (BillingStartDate)) =1, YEAR(BillingStartDate), 0) = YEAR(GETDATE())
AND
NEW_CLIENT.Active = 'Active'
AND NEW_CLIENT.ClientAlternate NOT IN (	SELECT BENCODE FROM TBL_EXCLUDE_CLIENT )
)
go

