/*-- =============================================
-- Author:		<JASWAL, MANOJ>
-- Create date: <03/03/2022>
-- Description: <UPDATE [Is Paylocity] TO [dbo].[TBL_STAGING_NPM]}>
-- =============================================

COMMENTS:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
EXAMPLE:		EXEC PSP_UPDATE_STAGING_NPM_PAYLOCITY 


OUTPUT:	
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

RETURN VALUES:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

MODIFICATIONS:

DATE        DEVELOPER                  DESCRIPTION
----------  -------------------------  ------------------------------------------------------------------------------------------------------------
*/
CREATE PROCEDURE [dbo].[PSP_UPDATE_STAGING_NPM_PAYLOCITY] 
AS

SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;


BEGIN
BEGIN TRY
	DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +QUOTENAME( OBJECT_NAME( @@PROCID ) );

    EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
    --
    
    -- ALTER PROCEDURE [qry_Update NPN With Client List EDI] AS
    UPDATE	[dbo].[TBL_STAGING_NPM]
    SET		[Is Paylocity] = 'EDI'
    FROM	[dbo].[TBL_STAGING_NPM]
            INNER JOIN [dbo].[TBL_STAGING_CLIENTS_MASTER] ON [dbo].[TBL_STAGING_NPM].[Alternate ER ID] = [dbo].[TBL_STAGING_CLIENTS_MASTER].clientalternate;;
    --
    EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;

END TRY 
BEGIN CATCH
    EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
    --
    DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
    EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
    -- reraise error
    THROW @errno, @errmessage, @errseverity;
END CATCH;
END;
go

