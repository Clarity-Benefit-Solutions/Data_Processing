
/*
Title:			SPS_EXECUTE_FINANCEBILLING
Creator:		kundan kumar

Purpose: 		Finance Billing Support
Functionality:	Execute SSIS

Created:		09/02/2022

Applications:	MRCS

Comments:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Example:		exec SPS_EXECUTE_FINANCEBILLING		@inputParameter = 1,
													@output_execution_id =


Output:	
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Return Values:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Modifications:

Date        Developer                  Description
----------  -------------------------  ------------------------------------------------------------------------------------------------------------
*/

CREATE   procedure [dbo].[SPS_EXECUTE_FINANCEBILLING]( 	@inputParameter nvarchar(300),
																@output_execution_id bigint output
 )
as

set nocount on;
set transaction isolation level read uncommitted;


begin

declare @execution_id bigint

exec	ssisdb.catalog.create_execution 
		@folder_name	= 'Finance_Billing',
		@project_name	= 'FinanceBilling',
		@package_name	= 'ParentFinanceBilling.dtsx',
		@execution_id	= @execution_id output
 
exec	ssisdb.catalog.set_execution_parameter_value
		@execution_id,
		@object_type		= 30,
		@parameter_name		= 'Parameter',
		@parameter_value	= @inputParameter;

exec ssisdb.catalog.start_execution @execution_id

set @output_execution_id = @execution_id

end



go

