
/* -- =============================================
-- Author:		<Manoj Jaswal>
-- Create date: <16 March 20222>
-- Description:	<Get Logging detail by GUID>
-- ============================================= 
-- =============================================

COMMENTS:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
EXAMPLE:		EXEC [SPS_GET_TBL_LOGGING_GUID] @GUID = '12345'


OUTPUT:	
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

RETURN VALUES:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

MODIFICATIONS:

DATE        DEVELOPER                  DESCRIPTION
----------  -------------------------  ------------------------------------------------------------------------------------------------------------
*/
CREATE PROCEDURE [dbo].[SPS_GET_TBL_LOGGING_GUID]		@GUID nvarchar(255)
AS
BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

    select	Id,
			PackageName,
			PackageId,
			[Guid],
			MachineName,
			UserName,
			DataSource,
			StartDateTime,
			EndDateTime,
			NumRowsInserted,
			NumRowsUpdated,
			NumRowsDeleted,
			NumRowsTotal,
			IsSuccess,
			IsFailed,
			IsCompleted
	from	[dbo].[TBL_LOGGINGDB] 
	where	[guid] = @GUID
END
go

