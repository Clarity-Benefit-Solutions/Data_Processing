-- =============================================
-- Author:		<Kundan Kumar>
-- Create date: <17/02/2022>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SPS_INVOKEK_FINANCEBILLING_PACAKGE] AS

BEGIN
    set nocount on;  
 
	declare @JobID binary(16)
	select @JobID = job_id from msdb.dbo.sysjobs where (name = 'Finance_Billing')

	if (@JobID IS NOT NULL)
	begin
		exec msdb.dbo.sp_start_job @job_id = @JobID;
	end 
	
END;

go

