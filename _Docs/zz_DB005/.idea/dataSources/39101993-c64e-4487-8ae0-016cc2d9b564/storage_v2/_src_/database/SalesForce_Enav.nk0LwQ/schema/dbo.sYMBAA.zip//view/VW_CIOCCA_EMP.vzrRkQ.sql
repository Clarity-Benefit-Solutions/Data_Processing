


















 

CREATE VIEW [dbo].[VW_CIOCCA_EMP] AS 
(


SELECT  
  A.[SSN]
 ,A.[DealerNumber]
,'' AS [DependentSSN]
,A.[FirstName] AS Fname
,CASE WHEN A.[MiddleName] = ''  THEN '' ELSE LEFT(A.[MiddleName],1) END AS Mname
,A.[LastName] AS Lname
,A.[Suffix] AS Suffix
,A.[DOB] AS BirthDate
,A.[Gender] AS Gender
,A.[Street1] AS Street1
,A.[Street2] AS Street2
,A.[city] AS City
,A.[State] AS  [State]
,A.[ZIP]
,A.[ZIP4]
,A.[Email]
--,A.[Phone]
,REPLACE(A.[Phone],'+','') AS [Phone]
,'' AS MedicareClaimNum
,'' AS MedicareDisabled
, CASE 
	WHEN A.[MaritalStatus] IS NULL OR A.[MaritalStatus] = '' OR A.[MaritalStatus]='Unknown' THEN 'K' 
	WHEN A.[MaritalStatus] = 'Single' THEN 'I'
	ELSE UPPER(LEFT(A.[MaritalStatus],1)) 
  END AS [MaritalStatus]  
,CASE WHEN A.[TerminationDate] != '' 
	THEN CAST(MONTH(DATEADD(MONTH,1,A.[TerminationDate])) AS nvarchar(2)) + '/01/' + CAST( YEAR(DATEADD(MONTH,1,A.[TerminationDate])) AS nvarchar) 
	ELSE ''
	END AS [TerminationDate]

,A.[TerminationCodeID]


--,A.[Benefit]
--,A.[Plan]
--,A.[CoverageLevel]

,'1' IsSubscriber
, CASE WHEN A.[TerminationDate] = '' THEN 'ACTI' ELSE '' END AS CBCClassID
, G.CBCMedPlanID AS CBCMedPlanID
, G.GroupNumber AS GroupNum--B.[GroupNumber] AS GroupNum
, FORMAT (CONVERT(DATETIME,A.[PlanStarts]),  'MM/dd/yyyy') AS EffectiveDate
, '' AS RelationshipID
,A.[Salary]
,A.[HireDate]
--,B.*

FROM [dbo].[CIOCCA_ENROLLMENT] AS A
LEFT JOIN [dbo].[Ciocca_Groups] AS G ON G.[DealerNumber] = A.[DealerNumber] AND UPPER(LEFT(G.[PLAN],25)) = UPPER(LEFT(A.[Plan],25)) 
WHERE [CoverageLevel] LIKE '%Employee%'

--ORDER BY [SSN]




)


go

