

CREATE PROCEDURE [dbo].[QBAEI_Create_filesandInsertintoRunLog_notunknown] AS
BEGIN
   
   ----create subsidy csv file
   


IF OBJECT_ID('[dbo].[QBAEI_Subsidy_csv_notunknown]', 'U') IS NOT NULL 
   DROP TABLE QBAEI_Subsidy_csv_notunknown;
   
   
   Select clientid,clientAlternate,
       d.[Last Name]
      ,d.[First Name]
      ,d.[MID]
      ,[AEI 2021 Status]
      ,d.[SSN]
      ,[QE Date]
      ,[FDOC]
      ,[LDOC]
      ,[Event Type]
      ,[Client Name]
      ,[Client Division Name]
      ,[Member Status]
      ,[Medical Plan Status]
      ,[Dental Plan Status]
      ,[Vision Plan Status]
      ,[EAP Plan Status]
      ,[HRA Plan Status] 
     into QBAEI_Subsidy_csv_notunknown
	 from [dbo].[QBAEI_dailyreport] as d
	 left
	 join [SalesForce_COBRA].[dbo].[Client] as c
	   on d.[Client Name] = c.[ClientName]
     left
	 join [dbo].[QBAEI_RecordRptRunlog_notunknown] as l
	   on l.[MID] = d.[mid]
      and l.[SSN] = l.[ssn]
	 where l.mid is null  and [AEI 2021 Status] <> 'UNKNOWN'

---delete from [dbo].[QBAEI_RecordRptRunlog_notunknown]
	
     ----Add to run log
INSERT INTO [dbo].[QBAEI_RecordRptRunlog_notunknown]
           ([Last Name]
           ,[First Name]
           ,[Mid]
           ,[SSN]
           ,[timestamp])
 Select distinct
       [Last Name]
       ,[First Name]
       ,[MID]
       ,[SSN]
       ,getdate()
   from QBAEI_Subsidy_csv_notunknown




END;

GO

