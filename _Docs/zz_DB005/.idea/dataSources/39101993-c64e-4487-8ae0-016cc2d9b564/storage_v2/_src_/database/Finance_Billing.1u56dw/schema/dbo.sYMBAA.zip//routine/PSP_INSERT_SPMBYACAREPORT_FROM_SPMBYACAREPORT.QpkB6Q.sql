/*
-- Author:		<JASWAL, MANOJ>
-- Create date: <03/03/2022>
-- Description:	<Insert Into [dbo].[TBL_STAGING_SPMBYACAREPORT_DIST] from [dbo].[TBL_STAGING_SPMBYACAREPORT}>

COMMENTS:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
EXAMPLE:		EXEC PSP_INSERT_SPMBYACAREPORT_FROM_SPMBYACAREPORT


OUTPUT:	
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

RETURN VALUES:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

MODIFICATIONS:

DATE        DEVELOPER                  DESCRIPTION
----------  -------------------------  ------------------------------------------------------------------------------------------------------------
*/

CREATE PROCEDURE [dbo].[PSP_INSERT_SPMBYACAREPORT_FROM_SPMBYACAREPORT] 
AS

BEGIN
SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

BEGIN TRY
	DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +QUOTENAME( OBJECT_NAME( @@PROCID ) );

    EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN'; 
    INSERT	INTO [dbo].[TBL_STAGING_SPMBYACAREPORT_DIST] (	  clientalternate,
															  clientname,
															  [First Name],
															  [Last Name],
															  memberid,
															  uniquekey,
															  [Account Type] )
    SELECT	[dbo].[TBL_STAGING_SPMBYACAREPORT].clientalternate,
			[dbo].[TBL_STAGING_SPMBYACAREPORT].clientname,
			[dbo].[TBL_STAGING_SPMBYACAREPORT].firstname,
			[dbo].[TBL_STAGING_SPMBYACAREPORT].lastname,
			[dbo].[TBL_STAGING_SPMBYACAREPORT].memberid,
			[dbo].[TBL_STAGING_SPMBYACAREPORT].uniquekey,
			' Special PLAN MEMBER ' [Account Type]
    FROM    [dbo].[TBL_STAGING_SPMBYACAREPORT]
    GROUP	BY [dbo].[TBL_STAGING_SPMBYACAREPORT].clientalternate,
			[dbo].[TBL_STAGING_SPMBYACAREPORT].clientname,
			[dbo].[TBL_STAGING_SPMBYACAREPORT].firstname,
			[dbo].[TBL_STAGING_SPMBYACAREPORT].lastname,
			[dbo].[TBL_STAGING_SPMBYACAREPORT].memberid,
			[dbo].[TBL_STAGING_SPMBYACAREPORT].uniquekey,
			[dbo].[TBL_STAGING_SPMBYACAREPORT].status
    HAVING	[dbo].[TBL_STAGING_SPMBYACAREPORT].status = 'ACTIVE'
    ORDER	BY [dbo].[TBL_STAGING_SPMBYACAREPORT].firstname;

    EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;

END TRY 
BEGIN CATCH
    EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
    --
    DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
    EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
    -- reraise error
    THROW @errno, @errmessage, @errseverity;
END CATCH;
END;
go

