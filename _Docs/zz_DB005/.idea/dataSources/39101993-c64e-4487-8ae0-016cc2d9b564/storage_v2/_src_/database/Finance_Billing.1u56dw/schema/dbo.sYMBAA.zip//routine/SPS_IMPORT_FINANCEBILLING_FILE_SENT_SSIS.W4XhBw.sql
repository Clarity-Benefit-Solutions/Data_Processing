-- =============================================
-- Author:		<Kundan Kumar>
-- Create date: <17/02/2022>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SPS_IMPORT_FINANCEBILLING_FILE_SENT_SSIS] AS

begin
	set nocount on;
 
	declare @JobID binary(16)

	select @JobID = job_id FROM msdb.dbo.sysjobs WHERE (name = 'Finance_Billing')

	if (@JobID is not null)
	begin
		exec msdb.dbo.sp_start_job @job_id = @JobID;
	end

	
end;

go

