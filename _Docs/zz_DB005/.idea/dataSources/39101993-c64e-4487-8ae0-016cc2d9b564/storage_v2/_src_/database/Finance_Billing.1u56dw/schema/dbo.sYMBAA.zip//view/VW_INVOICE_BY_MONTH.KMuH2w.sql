CREATE VIEW VW_INVOICE_BY_MONTH AS (

SELECT  
[Year]
,[Month]
,[Employer Name]
 
 ,SUM([pepm_amount]) AS [INVOICE TOTAL]
 ,COUNT ([BILLING CODE]) AS [INVOICE COUNT]
FROM 
[dbo].[TBL_QB_IMPORTS_PRO]
 GROUP BY [Year]
,[Month]
,[Employer Name]
 
 --ORDER BY[Month], [Year],[Employer Name]

 )
go

