/*
-- Author:		<ALFRED ZHU>
-- Create date: <Create Date,,>
-- Description:	<Description,,>

COMMENTS:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
EXAMPLE:		EXEC [SPS_UPDATE_NPM_ALTID]


OUTPUT:	
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

RETURN VALUES:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

MODIFICATIONS:

DATE        DEVELOPER                  DESCRIPTION
----------  -------------------------  ------------------------------------------------------------------------------------------------------------
*/

CREATE PROCEDURE [dbo].[SPS_UPDATE_NPM_ALTID] 
AS

BEGIN
	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' + QUOTENAME( OBJECT_NAME( @@PROCID ) );
        
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';

        UPDATE  [dbo].[TBL_STAGING_NPM]
        SET		[dbo].[TBL_STAGING_NPM].[Alternate ER ID] = [dbo].[TBL_STAGING_BROKERCLIENTLIST].[ClientAlternate]
        FROM	[dbo].[TBL_STAGING_BROKERCLIENTLIST]
                INNER JOIN [dbo].[TBL_STAGING_NPM] ON [dbo].[TBL_STAGING_BROKERCLIENTLIST].clientname = [dbo].[TBL_STAGING_NPM].clientname;

        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;

    END TRY BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW @errno, @errmessage, @errseverity;
    END CATCH;
END;
go

