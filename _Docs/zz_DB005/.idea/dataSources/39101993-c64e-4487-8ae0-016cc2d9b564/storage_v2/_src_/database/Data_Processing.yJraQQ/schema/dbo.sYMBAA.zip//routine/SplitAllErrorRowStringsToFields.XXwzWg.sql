CREATE procedure dbo.SplitAllErrorRowStringsToFields( @tableName nvarchar(250) ) as
begin
    
    --
    declare @row_num int;
    declare @error_row nvarchar(max);
    --
    declare @row_type nvarchar(100);
    declare @bencode nvarchar(100);
    declare @employee_id nvarchar(100);
    declare @plan_id nvarchar(100);
    declare @start_date nvarchar(100);
    declare @end_date nvarchar(100);
    declare @error_code nvarchar(100);
    declare @error_message nvarchar(500);
    declare @dummy nvarchar(100);
    
    --
    DECLARE db_cursor CURSOR FOR
        SELECT /*top 3*/
            row_num
          , error_row
        FROM
            dbo.res_file_table_stage
        order by
            res_file_table_stage.row_num;
    
    OPEN db_cursor
    FETCH NEXT FROM db_cursor INTO @row_num, @error_row;
    
    WHILE @@FETCH_STATUS = 0
        BEGIN
            ;
            with
                T( row_num, row_type, bencode, employee_id, plan_id, start_date, end_date, error_code
                 , error_message, dummy)
                    as (
                           select top 1
                               @row_num row_num
                             , row_type
                             , bencode
                             , employee_id
                             , plan_id
                             , start_date
                             , end_date
                             , error_code
                             , error_message
                             , dummy
                           from
                               dbo.SplitErrorRowStringToFields( @error_row )
                       )
            update dbo.res_file_table_stage
            set
                row_type      = T.row_type
              , bencode       = T.bencode
              , employee_id   = T.employee_id
              , plan_id       = T.plan_id
              , start_date    = T.start_date
              , end_date      = T.end_date
              , error_code    = T.error_code
              , error_message = T.error_message
                --               , dummy         = @dummy
            from
                dbo.res_file_table_stage r
                    inner join T on r.row_num = T.row_num
            
            where
                r.row_num = @row_num;
            /**/
            FETCH NEXT FROM db_cursor INTO @row_num, @error_row;
        END
    
    CLOSE db_cursor
    DEALLOCATE db_cursor
    
    RETURN

end;
go

