/*
-- Author:		<JASWAL, MANOJ>
-- Create date: <03/0407/2022>
-- Description:	<Insert Into [dbo].[TBL_STATING_QB_TE_COUNT] from VW_QB_UNIQUE_ROW>

COMMENTS:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
EXAMPLE:		EXEC [PSP_INSERT_QB_TE_COUNT_VW_QB_UNIQUE]


OUTPUT:	
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

RETURN VALUES:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

MODIFICATIONS:

DATE        DEVELOPER                  DESCRIPTION
----------  -------------------------  ------------------------------------------------------------------------------------------------------------
*/
CREATE PROCEDURE [dbo].[PSP_INSERT_QB_TE_COUNT_VW_QB_UNIQUE] 
AS

BEGIN
SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

BEGIN TRY
	DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' + QUOTENAME( OBJECT_NAME( @@PROCID ) );

    EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';

    INSERT	INTO [dbo].[TBL_STATING_QB_TE_COUNT] (	[Alternate ER ID],
													[status],
													[TE  Count] ) 
	SELECT	V2.[Alternate ER ID],
			V2.status,
			COUNT( V2.ssn ) countofssn
    FROM	[VW_QB_UNIQUE_ROW] AS V1
            INNER JOIN  [dbo].[VW_QB_UNIQUE_ROW] AS V2 ON   V1.[Alternate ER ID] = V2.[Alternate ER ID]
    GROUP	BY V2.[Alternate ER ID],
			V2.[status]
    HAVING	V2.[status] = 'TE';

    EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;

END TRY 
BEGIN CATCH
    EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
    --
    DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
    EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
    -- reraise error
    THROW @errno, @errmessage, @errseverity;
END CATCH;
END;
go

