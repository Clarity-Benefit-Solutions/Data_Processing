/*-- =============================================
-- Author:		<SUSHIL S.>
-- Create date: <03/16/2022>
-- Description:	<UPDATE ClientAlternate of [dbo].[TBL_STAGING_CLIENTS_MASTER] from [dbo].[TBL_ALL_ACCOUNTS]>
-- =============================================

COMMENTS:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
EXAMPLE:		EXEC [PSP_UPDATE_CLIENTMASTER_CLIENTALTID_FROM_ALLACCOUNTS] 


OUTPUT:	
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

RETURN VALUES:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

MODIFICATIONS:

DATE        DEVELOPER                  DESCRIPTION
----------  -------------------------  ------------------------------------------------------------------------------------------------------------
*/
CREATE   PROCEDURE [dbo].[PSP_UPDATE_CLIENTMASTER_CLIENTALTID_FROM_ALLACCOUNTS] 
AS
BEGIN
SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

BEGIN TRY
	DECLARE		@this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +QUOTENAME( OBJECT_NAME( @@PROCID ) );

    EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';  

	-- UPDATE BEGINS HERE 
    UPDATE  [dbo].[TBL_STAGING_CLIENTS_MASTER]
    SET		[dbo].[TBL_STAGING_CLIENTS_MASTER].[ClientAlternate] = [dbo].[TBL_ALL_ACCOUNTS].[clientcode]
    FROM	[dbo].[TBL_STAGING_CLIENTS_MASTER]
            INNER JOIN [dbo].[TBL_ALL_ACCOUNTS] ON  [dbo].[TBL_ALL_ACCOUNTS].clientname = [dbo].[TBL_STAGING_CLIENTS_MASTER].clientname;;
    -- UPDATE ENDS HERE

    EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
END TRY 

BEGIN CATCH
    EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
    
	--
    DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
    EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
    
	-- RERAISE ERROR
    THROW @errno, @errmessage, @errseverity;
END CATCH;
END;
go

