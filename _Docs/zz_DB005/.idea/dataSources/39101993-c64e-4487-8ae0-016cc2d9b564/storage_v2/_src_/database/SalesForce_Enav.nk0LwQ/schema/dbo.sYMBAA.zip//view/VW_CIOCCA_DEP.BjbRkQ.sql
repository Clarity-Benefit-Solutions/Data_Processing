

















 

CREATE VIEW [dbo].[VW_CIOCCA_DEP] AS 
(

     SELECT  
 A.[SSN]
,A.[DealerNumber]
,A.[DependentSSN]
,A.[DependentFname] AS Fname
--,A.[DependentMname] AS Mname
,CASE WHEN A.[DependentMname] = ''  THEN '' ELSE LEFT(A.[DependentMname],1) END AS Mname
,A.[DependentLname] AS Lname
,A.[DependentSuffix] AS Suffix
,A.[DependentBirthDate] AS BirthDate
,A.[DependentGender] AS Gender
,A.[DependentStreet1] AS Street1
,A.[DependentStreet2] AS Street2
,A.[Dependentcity] AS City
,A.[DependentState] AS  [State]
,A.[ZIP]
,A.[ZIP4]
,A.[Email]
,REPLACE(A.[Phone],'+','') AS [Phone]
,'' AS MedicareClaimNum
,'' AS MedicareDisabled
--,A.[MaritalStatus]  
, CASE 
	WHEN A.[MaritalStatus] IS NULL OR A.[MaritalStatus] = '' OR A.[MaritalStatus]='Unknown' THEN 'K' 
	WHEN A.[MaritalStatus] = 'Single' THEN 'I'
	ELSE UPPER(LEFT(A.[MaritalStatus],1)) 
  END AS [MaritalStatus]
,CASE WHEN A.[TerminationDate] != '' 
	THEN CAST(MONTH(DATEADD(MONTH,1,A.[TerminationDate])) AS nvarchar(2)) + '/01/' + CAST( YEAR(DATEADD(MONTH,1,A.[TerminationDate])) AS nvarchar) 
	ELSE ''
	END AS [TerminationDate]
,A.[TerminationCodeID]

--,B.[Benefit]
--,B.[Plan]
--,B.[CoverageLevel]

,'0' IsSubscriber
, CASE WHEN A.[TerminationDate] = '' THEN 'ACTI' ELSE '' END AS CBCClassID
, G.CBCMedPlanID AS CBCMedPlanID
, G.GroupNumber AS GroupNum--B.[GroupNumber] AS GroupNum
--, B.[PlanStarts] AS EffectiveDate
, FORMAT (CONVERT(DATETIME,B.[PlanStarts]),  'MM/dd/yyyy') AS EffectiveDate
, CASE 
		WHEN A.[Relationship] LIKE '%Natural Child%' THEN '1'
		WHEN A.[Relationship] LIKE '%Child%' THEN '1' 
		WHEN A.[Relationship] LIKE '%Step Child%' THEN '2' 
		WHEN A.[Relationship] LIKE '%Common Law Spouse%' THEN '3' 
		WHEN A.[Relationship] LIKE '%Spouse%' THEN '6' 
		WHEN A.[Relationship] LIKE '%Domestic Partner%' THEN '4' 
		WHEN A.[Relationship] LIKE '%Grandchild%' THEN '5' 
		WHEN A.[Relationship] LIKE '%Legal Guardian%' THEN '7'  
		ELSE ''
	END  AS RelationshipID
, A.[Salary]
, A.[HireDate]
FROM [dbo].[CIOCCA_DEPENDENT] AS A
LEFT JOIN [dbo].[CIOCCA_ENROLLMENT]  AS B ON A.SSN = B.SSN
LEFT JOIN [dbo].[Ciocca_Groups] AS G ON G.[DealerNumber] = A.[DealerNumber] AND UPPER(LEFT(G.[PLAN],25)) = UPPER(LEFT(B.[Plan],25))
WHERE B.CoverageLevel != 'Employee'
--ORDER BY [SSN]

)











go

