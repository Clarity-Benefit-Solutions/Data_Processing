/*-- =============================================
-- Author:		<Sushil S.>
-- Create date: <28/02/2022>
-- Description:	<Get Exclude Client List for GridView>
-- =============================================

COMMENTS:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
EXAMPLE:		EXEC SPS_GET_EXCLUDECLIENTDATA 


OUTPUT:	
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

RETURN VALUES:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

MODIFICATIONS:

DATE        DEVELOPER                  DESCRIPTION
----------  -------------------------  ------------------------------------------------------------------------------------------------------------
*/
CREATE   PROCEDURE [dbo].[SPS_GET_EXCLUDECLIENTDATA]		--@Page INT = 1,
														--@Size INT = 10
AS
BEGIN

	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

	SELECT	EXCLUDE_CLIENT.Id,
			EXCLUDE_CLIENT.ClientID, 
			EXCLUDE_CLIENT.ClientName, 
			EXCLUDE_CLIENT.Bencode,
			EXCLUDE_CLIENT.Description,
			EXCLUDE_CLIENT.UserID,
			EXCLUDE_CLIENT.UserName,
			EXCLUDE_CLIENT.CreateDate,
			EXCLUDE_CLIENT.isDeleted
	FROM	[dbo].[TBL_EXCLUDE_CLIENT]  AS EXCLUDE_CLIENT 
	WHERE	EXCLUDE_CLIENT.isDeleted is  null
	--ORDER BY EXCLUDE_CLIENT.ClientID ASC OFFSET (@Page -1) * @Size ROWS
	--FETCH NEXT @Size ROWS ONLY
	
END;
go

