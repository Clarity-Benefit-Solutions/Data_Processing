














 
 
CREATE VIEW [dbo].[VW_CIOCCA_Enrollment] AS 
(

   SELECT  DISTINCT
	pref.value('(SSN)[1]', 'varchar(9)') as SSN, --Employee SSN
	ISNULL(LEFT(pref.value('(Office)[1]', 'varchar(250)'),6),'')  AS DealerNumber, 
	ISNULL(pref.value('(CompanyIdentifier)[1]', 'varchar(250)'),'')  AS CompanyIdentifier,
	ISNULL(pref.value('(FirstName)[1]', 'varchar(250)'),'')  AS FirstName, 
	ISNULL(pref.value('(MiddleName)[1]', 'varchar(250)'),'')  AS MiddleName, 
	ISNULL(pref.value('(LastName)[1]', 'varchar(250)'),'')  AS LastName, 
	ISNULL(pref.value('(Suffix)[1]', 'varchar(250)'),'') as  Suffix, 
	ISNULL(pref.value('(Gender)[1]', 'varchar(250)'),'')  AS Gender, 
	FORMAT (CONVERT(DATETIME,pref.value('(DOB)[1]', 'varchar(250)')),  'MM/dd/yyyy ') AS  DOB, 
	--CASE 
	--	WHEN pref.value('(MaritalStatus)[1]', 'varchar(250)')='Married' THEN 'M'
	--	WHEN pref.value('(MaritalStatus)[1]', 'varchar(250)')='Single' THEN 'I' 
	--	ELSE 'K'
	--END  AS MaritalStatus,
	pref.value('(MaritalStatus)[1]', 'varchar(250)') AS MaritalStatus,
	 
	pref.value('(Address1)[1]', 'varchar(250)') as Street1,
	pref.value('(Address2)[1]', 'varchar(250)') as Street2,
	pref.value('(City)[1]', 'varchar(250)') as city,
    pref.value('(State)[1]', 'varchar(250)') as [State],
	Case when len(pref.value('(ZIP)[1]', 'varchar(250)')) = 5 THEN Right('00000' + pref.value('(ZIP)[1]', 'varchar(250)'), 5) else LEFT( pref.value('(ZIP)[1]', 'varchar(250)'), 5) END as ZIP, 
	Case when len(pref.value('(ZIP)[1]', 'varchar(250)')) = 5 THEN '' else RIGHT( pref.value('(ZIP)[1]', 'varchar(250)'), 4) END as ZIP4, 
	pref.value('(Email)[1]', 'varchar(250)') as Email,
	RTRIM(LTRIM(REPLACE(REPLACE(REPLACE(REPLACE(pref.value('(Phone)[1]', 'varchar(250)'),'(',''),')',''),'-',''),' ',''))) as Phone, 
	'' AS MedicareClaimNum,
	'' AS MedicareDisabled,
	--RTRIM(LTRIM(UPPER(EN.value('Plan[1]','varchar(150)') ))) AS PLAN_ENROLLED, 
	CASE
		WHEN pref.value('(TerminationDate)[1]', 'varchar(250)') = '' THEN '' ELSE
		FORMAT (CONVERT(DATETIME, pref.value('(TerminationDate)[1]', 'varchar(250)')),  'MM/dd/yyyy') 
	END AS  TerminationDate, 
		CASE 
		WHEN RTRIM(LTRIM(LOWER(pref.value('(TerminationReason)[1]', 'varchar(250)')))) LIKE '%voluntary%' THEN '1'
		WHEN RTRIM(LTRIM(LOWER(pref.value('(TerminationReason)[1]', 'varchar(250)')))) LIKE '%deceased%' THEN '6' 
		WHEN RTRIM(LTRIM(LOWER(pref.value('(TerminationReason)[1]', 'varchar(250)')))) LIKE '%divorced%' THEN '9' 
		WHEN RTRIM(LTRIM(LOWER(pref.value('(TerminationReason)[1]', 'varchar(250)')))) LIKE '%transfer%' THEN '12' 
		WHEN RTRIM(LTRIM(LOWER(pref.value('(TerminationReason)[1]', 'varchar(250)')))) LIKE '%deceased with living dependents%' THEN '22' 
		ELSE ''
	END  AS TerminationCodeID,
	pref.value('(Salary)[1]', 'varchar(250)')  as Salary, 
	FORMAT (CONVERT(DATETIME,pref.value('(HireDate)[1]', 'varchar(250)')),  'MM/dd/yyyy') AS HireDate,
	-------------------------------------- Enrollment -----------------------------------------------------------------------
 
	ISNULL(EN.value('EnrollmentType[1]','varchar(30)'),'') AS EnrollmentType,
	ISNULL(EN.value('Plan[1]','varchar(30)'),'') AS [Plan],
	ISNULL(EN.value('GroupNumber[1]','varchar(30)'),'') AS GroupNumber,
	ISNULL(EN.value('PolicyNumber[1]','varchar(30)'),'') AS PolicyNumber,
 
	ISNULL(EN.value('Benefit[1]','varchar(30)'),'') AS Benefit,
	ISNULL(EN.value('Type[1]','varchar(30)'),'') AS [Type],
	ISNULL(EN.value('PlanStarts[1]','varchar(30)'),'') AS [PlanStarts],
	ISNULL(EN.value('PlanEnds[1]','varchar(30)'),'') AS [PlanEnds],
	ISNULL(EN.value('CoverageLevel[1]','varchar(30)'),'') AS [CoverageLevel]  

FROM  XmlSourceTable CROSS APPLY 
      XmlData.nodes('/Data/Companies/Company/Employees/Employee') AS People(pref)
	  OUTER APPLY pref.nodes('Enrollments/Enrollment') AS Enrollment(EN) 
	  --OUTER APPLY pref.nodes('Dependents/Dependent') AS Dependents(Dep) 
--LEFT JOIN [dbo].[Ciocca_Groups] AS G ON RTRIM(LTRIM(UPPER(EN.value('Plan[1]','varchar(150)') ))) = RTRIM(LTRIM(UPPER(G.[PLAN])))
WHERE 
pref.value('(CompanyIdentifier)[1]', 'varchar(50)')  like '%BENCIOCCA%' 
--AND (EN.value('DependentEnrollees[1]','varchar(150)') IS NOT NULL 
--AND EN.value('DependentEnrollees[1]','varchar(150)') != '')
    
)







go

