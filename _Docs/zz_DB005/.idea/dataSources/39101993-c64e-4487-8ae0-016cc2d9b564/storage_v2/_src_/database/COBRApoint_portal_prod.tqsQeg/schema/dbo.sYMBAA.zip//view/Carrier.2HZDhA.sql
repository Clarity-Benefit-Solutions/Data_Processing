create VIEW [dbo].[Carrier]
AS
SELECT       *
FROM            [SalesForce_COBRA].dbo.Carrier
GO

