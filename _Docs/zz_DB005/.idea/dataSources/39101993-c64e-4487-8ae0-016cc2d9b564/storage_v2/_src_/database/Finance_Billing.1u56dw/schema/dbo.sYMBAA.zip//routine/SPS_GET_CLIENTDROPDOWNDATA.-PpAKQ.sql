/*-- =============================================
-- Author:		<Sushil S.>
-- Create date: <28/02/2022>
-- Description:	<Get Client List for Dropdown>
-- =============================================

COMMENTS:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
EXAMPLE:		EXEC SPS_GET_CLIENTDROPDOWNDATA 


OUTPUT:	
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

RETURN VALUES:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

MODIFICATIONS:

DATE        DEVELOPER                  DESCRIPTION
----------  -------------------------  ------------------------------------------------------------------------------------------------------------
*/
CREATE   PROCEDURE [dbo].[SPS_GET_CLIENTDROPDOWNDATA] 
AS

SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

BEGIN
    SET NOCOUNT ON;  

	SELECT	NEW_CLIENT.ClientID, 
			NEW_CLIENT.ClientName 
	FROM	[dbo].[TBL_STAGING_CLIENTS_MASTER]  AS NEW_CLIENT 
	WHERE	NEW_CLIENT.Active = 'Active' AND 
			NEW_CLIENT.ClientAlternate NOT IN (	SELECT BENCODE FROM TBL_EXCLUDE_CLIENT )
	GROUP	BY NEW_CLIENT.ClientID, 
			NEW_CLIENT.ClientName 
	
END;
go

