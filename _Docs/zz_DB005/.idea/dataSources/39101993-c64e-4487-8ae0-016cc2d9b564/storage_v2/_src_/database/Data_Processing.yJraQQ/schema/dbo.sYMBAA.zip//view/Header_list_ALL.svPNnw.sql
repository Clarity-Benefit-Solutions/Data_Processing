CREATE VIEW dbo.Header_list_ALL
    AS
        SELECT
            'G:\FTP\' + Folder_name folder_name
          , template_type
          , IC_type
          , BENCODE
          , to_FTP
        FROM
            dbo.Automated_Header_list
go

