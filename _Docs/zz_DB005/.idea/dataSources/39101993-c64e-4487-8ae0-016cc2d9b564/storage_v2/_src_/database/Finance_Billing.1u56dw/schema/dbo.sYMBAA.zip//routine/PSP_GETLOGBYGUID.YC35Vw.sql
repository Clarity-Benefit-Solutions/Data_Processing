
CREATE PROCEDURE PSP_GETLOGBYGUID	@GUID NVARCHAR(50) 

as

BEGIN 
SET NOCOUNT ON;

SELECT	ID, PackageName , PackageID, GUID, MachineName, UserName, DataSource, StartDateTime , 
		EndDatetime, NumRowsTotal, NumRowsInserted, NumRowsNotInserted
from	TBL_LOGGINGDB 
WHERE	[GUID] = @GUID
order	BY StartDateTime asc

END
go

