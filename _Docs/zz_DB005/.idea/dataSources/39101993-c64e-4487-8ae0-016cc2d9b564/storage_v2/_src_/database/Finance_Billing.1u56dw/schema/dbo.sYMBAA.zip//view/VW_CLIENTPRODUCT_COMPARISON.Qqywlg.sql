
 
CREATE   VIEW [dbo].[VW_CLIENTPRODUCT_COMPARISON] AS (
SELECT	DISTINCT  SOURCEFILE_BENCODE	= [TBL_STAGING_CLIENTS_MASTER].ClientAlternate  ,
		SOURCEFILE_CLIENTNAME			= [TBL_STAGING_CLIENTS_MASTER].ClientName,
		SOURCEFILE_PRODUCTS				= CONVERT(NVARCHAR(50), null), 
		BILLINGAPP_BENCODE				= tmpStagingClientList.BENCODE,
		BILLINGAPP_CLIENTNAME			= tmpStagingClientList.CLIENTNAME,
		START_BILLING_DATE				= CONVERT(DATE, NULL) ,
		END_BILLING_DATE				= CONVERT(DATE, NULL) ,
		NOTEXIST_IN_BILLINGAPPTABLE		= IIF(tmpStagingClientList.BENCODE = [TBL_STAGING_CLIENTS_MASTER].ClientAlternate, 0, 1) 

FROM	(	SELECT	DISTINCT ClientAlternate		= tmpClientList.BENCODE , 
					ClientName	= tmpClientList.ClientName 
			FROM	(	SELECT DISTINCT [Alternate ER ID] BENCODE, ClientName from [dbo].[TBL_STAGING_NPM]
						UNION ALL
						SELECT DISTINCT [Alternate ER ID] BENCODE, ClientName from [dbo].[TBL_STAGING_QBDETAIL]
						UNION ALL
						SELECT DISTINCT ClientAlternate BENCODE, ClientName from [dbo].[TBL_STAGING_BROKERCLIENTLIST]
						UNION ALL
						SELECT DISTINCT ClientAlternate BENCODE, ClientName from [dbo].[TBL_STAGING_CLIENTS_MASTER]
						UNION ALL
						SELECT DISTINCT ClientAlternate BENCODE, ClientName from [dbo].[TBL_STAGING_SPMBYACAREPORT] ) tmpClientList

			WHERE	(tmpClientList.ClientName  NOT LIKE '%Do Not Use%' AND 
					 tmpClientList.ClientName  NOT LIKE '%Test Company%' AND 
					 tmpClientList.ClientName  NOT LIKE '%Demo%' AND 
					 tmpClientList.ClientName  NOT LIKE '%DoNotUse%' ) 		)TBL_STAGING_CLIENTS_MASTER  

		OUTER APPLY	(	SELECT	DISTINCT BENCODE		= [TBL_ALL_ACCOUNTS].CLIENTCODE,
								CLIENTNAME				= [TBL_ALL_ACCOUNTS].CLIENTNAME
						FROM	[dbo].[TBL_ALL_ACCOUNTS]   
						WHERE	[TBL_ALL_ACCOUNTS].CLIENTCODE = [TBL_STAGING_CLIENTS_MASTER].ClientAlternate -- and 
								--[TBL_ALL_ACCOUNTS].Products  is NULL 
								) tmpStagingClientList

WHERE	[TBL_STAGING_CLIENTS_MASTER].ClientAlternate NOT IN (	SELECT	BENCODE 
																FROM	TBL_EXCLUDE_CLIENT )  )


go

