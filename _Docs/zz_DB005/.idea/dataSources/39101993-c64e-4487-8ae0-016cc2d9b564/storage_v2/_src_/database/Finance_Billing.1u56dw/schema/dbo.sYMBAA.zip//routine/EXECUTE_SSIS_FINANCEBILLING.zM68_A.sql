CREATE procedure dbo.EXECUTE_SSIS_FINANCEBILLING(
 @inputParameter nvarchar(300),
 @output_execution_id bigint output
 )
as
begin
 declare @execution_id bigint
 exec ssisdb.catalog.create_execution 
  @folder_name = 'Finance_Billing'
 ,@project_name = 'FinanceBilling'
 ,@package_name = 'ParentFinanceBilling.dtsx'
 ,@execution_id = @execution_id output
 
 EXEC ssisdb.catalog.set_execution_parameter_value
	@execution_id,
	@object_type = 30,
	@parameter_name = 'Parameter',
	@parameter_value = @inputParameter;

 exec ssisdb.catalog.start_execution @execution_id
 set @output_execution_id = @execution_id
end



go

