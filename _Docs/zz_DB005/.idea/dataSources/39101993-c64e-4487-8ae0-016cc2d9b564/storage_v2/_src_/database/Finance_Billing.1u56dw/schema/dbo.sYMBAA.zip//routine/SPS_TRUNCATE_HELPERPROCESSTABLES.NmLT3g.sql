/*
-- Author:		<Sushil S.>
-- Create date: <01/03/2022>
-- Description:	<SP to Truncate helper and Process tables >

COMMENTS:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
EXAMPLE:		EXEC [SPS_TRUNCATE_HELPERPROCESSTABLES]


OUTPUT:	
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

RETURN VALUES:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

MODIFICATIONS:

DATE        DEVELOPER                  DESCRIPTION
----------  -------------------------  ------------------------------------------------------------------------------------------------------------
*/
CREATE   PROCEDURE [dbo].[SPS_TRUNCATE_HELPERPROCESSTABLES] AS

BEGIN
SET NOCOUNT ON; 


    BEGIN TRY
        DECLARE @this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' + QUOTENAME( OBJECT_NAME( @@PROCID ) );
        
        EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
         
		/* Truncate Helper and Process Tables  */
		Truncate Table [dbo].[TBL_STATING_QB_TE_COUNT];
		Truncate Table [dbo].[TBL_STATING_QB_TP_COUNT];
		Truncate Table [dbo].[TBL_STAGING_NPM_DIST];
		Truncate Table [dbo].[TBL_STAGING_NPN_COUNT]; 
		Truncate Table [dbo].[TBL_EDI_BILLING_GROUP_COUNT];
		Truncate Table [dbo].[TBL_STAGING_SPMBYACAREPORT_DIST];
		Truncate Table [dbo].[TBL_STAGING_COBRA_CLIENT_LIST];
		Truncate Table [dbo].[TBL_STAGING_COBRA_LETTERS_SUMMARY];
		Truncate Table [dbo].[TBL_STAGING_EDI_3_SOURCE_DATA];
		Truncate Table [dbo].[TBL_STAGING_ACCOUNTS];
		Truncate Table [dbo].[TBL_PROCESS];
		Truncate Table [dbo].[TBL_PROCESS_BK];
		Truncate Table [dbo].[TBL_BILLING INVOICE EXPORT];
		Truncate Table [dbo].[TBL_BK_RPT_EXPORT];
		Truncate Table [dbo].[TBL_BILLING_INVOICE_EXPORT_QB];
		Truncate Table [dbo].[TBL_MONTH_MIN_CONVERSION];
		Truncate Table [dbo].[TBL_MONTH_MIN_CONVERSION_INVOICE];

        EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;
    END TRY 
	BEGIN CATCH
        EXEC db_log_message @this_proc_name , 'ERROR' , 'ERROR';
        --
        DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
        EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
        -- reraise error
        THROW @errno, @errmessage, @errseverity;
    END CATCH;	
END;
go

