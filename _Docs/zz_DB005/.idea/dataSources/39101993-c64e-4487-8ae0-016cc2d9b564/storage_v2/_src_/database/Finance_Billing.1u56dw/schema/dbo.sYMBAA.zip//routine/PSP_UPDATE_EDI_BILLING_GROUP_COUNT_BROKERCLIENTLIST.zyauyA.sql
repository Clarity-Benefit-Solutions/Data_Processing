
/*-- =============================================
-- Author:		<JASWAL, MANOJ>
-- Create date: <03/03/2022>
-- Description:	<Insert Into [dbo].[TBL_EDI_BILLING_GROUP_COUNT] from [dbo].[TBL_STAGING_BROKERCLIENTLIST>
-- =============================================

COMMENTS:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
EXAMPLE:		EXEC [PSP_UPDATE_EDI_BILLING_GROUP_COUNT_BROKERCLIENTLIST] 


OUTPUT:	
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

RETURN VALUES:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

MODIFICATIONS:

DATE        DEVELOPER                  DESCRIPTION
----------  -------------------------  ------------------------------------------------------------------------------------------------------------
*/
CREATE PROCEDURE [dbo].[PSP_UPDATE_EDI_BILLING_GROUP_COUNT_BROKERCLIENTLIST] 
AS

BEGIN
SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

BEGIN TRY
	DECLARE		@this_proc_name nvarchar(max) = QUOTENAME( OBJECT_SCHEMA_NAME( @@PROCID ) ) + '.' +QUOTENAME( OBJECT_NAME( @@PROCID ) );

    EXEC dbo.db_log_message @this_proc_name , ' Starting' , 'WARN';
    --
    
    --
    INSERT INTO [dbo].[TBL_EDI_BILLING_GROUP_COUNT] (	clientname,
														[Alternate ER ID] )
    SELECT	[dbo].[TBL_STAGING_BROKERCLIENTLIST].clientname,
			[dbo].[TBL_STAGING_BROKERCLIENTLIST].clientalternate
    FROM	[dbo].[TBL_STAGING_BROKERCLIENTLIST]
    GROUP	BY [dbo].[TBL_STAGING_BROKERCLIENTLIST].clientname,
			[dbo].[TBL_STAGING_BROKERCLIENTLIST].clientalternate;;
    --

    EXEC db_log_message @this_proc_name , 'FINISHED' , 'WARN' , @@ROWCOUNT;

END TRY 
BEGIN CATCH
    EXEC	db_log_message	@this_proc_name , 'ERROR' , 'ERROR';
    --
    DECLARE @errno int = 50001 , @errmessage varchar(max) = CONCAT( 'ErrNo: ' , ERROR_NUMBER( ) , ' - ' , ERROR_MESSAGE( ) ), @errseverity int = ERROR_SEVERITY( );
    EXEC db_log_error @errno , @this_proc_name , @errmessage , @errseverity;
    -- reraise error
    THROW @errno, @errmessage, @errseverity;
END CATCH;
END;


go

