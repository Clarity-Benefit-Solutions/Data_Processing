CREATE VIEW dbo.[mbi_errors]
    AS
        SELECT distinct
            e.mbi_file_name --, m.data_row AS mbi_line
        FROM
            dbo.error_log_results e
go

