create procedure check_imports_file as
    begin
        select 1;
    end
go

