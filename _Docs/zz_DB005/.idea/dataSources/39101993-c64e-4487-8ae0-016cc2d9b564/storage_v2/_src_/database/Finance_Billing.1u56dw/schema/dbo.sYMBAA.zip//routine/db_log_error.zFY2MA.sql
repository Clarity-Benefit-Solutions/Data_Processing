-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[db_log_error](
                                @err_no varchar(50),
                                @err_source varchar(200),
                                @err_msg text,
                                @sqlstate varchar(200) ) AS
BEGIN
    PRINT CONCAT( '****ERROR**** ' , ', SQLSTATE: ' , @sqlstate , ', ERRNO: ' , @err_no , ', FROM: ' , @err_source ,
                  ', MESSAGE: ' , @err_msg );
    /**/
    INSERT
        INTO [dbo].[TBL_ERROR_LOG]  (
                          sql_state,
                          err_no,
                          err_source,
                          err_msg,
						  created_at
    )
    VALUES (
           @sqlstate,
           @err_no,
           @err_source,
           @err_msg,
		   getdate()
           );
END;
go

