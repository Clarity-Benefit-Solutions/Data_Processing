










 


 

CREATE VIEW [dbo].[VW_CIOCCA] AS 
(

 
SELECT * FROM [dbo].[VW_CIOCCA_EMP]
UNION ALL
SELECT * FROM [dbo].[VW_CIOCCA_DEP]
 
    
	)



go

