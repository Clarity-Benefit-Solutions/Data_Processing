CREATE function buildsqlforparam( @value nvarchar(max), @isnumber int ) returns nvarchar(max) as begin
    if @value is null
        return 'null';
    
    if @isnumber > 0
        return @value;
    
    return concat( char( 39 ) , replace( @value , '''' , '''''' ) , char( 39 ) );
end
GO

