CREATE
    DEFINER = root@`%` PROCEDURE upsert_wc_employers(
                                                    IN p_employer_id varchar(30),
                                                    IN p_employer_name varchar(200),
                                                    IN p_active_first_use varchar(20),
                                                    IN p_bucket_split varchar(20),
                                                    IN p_city varchar(75),
                                                    IN p_email_address varchar(200),
                                                    IN p_copay_auto_renew varchar(20),
                                                    IN p_employer_status varchar(15),
                                                    IN p_recurring_expense_auto_renew varchar(20),
                                                    IN p_state varchar(75),
                                                    IN p_tpa_id varchar(75) )
BEGIN
    
    -- handle error that may happen as the table has a few unique keys which may conflict
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO,
                @text = MESSAGE_TEXT;
            SET @text = CONCAT( @text , CONCAT( '
Called With Params: ' , ', employer_id: ' , api.api_nz( `p_employer_id` , '' ) , ', employer_name: ' ,
                                                api.api_nz( `p_employer_name` , '' ) , ', active_first_use: ' ,
                                                api.api_nz( `p_active_first_use` , '' ) , ', bucket_split: ' ,
                                                api.api_nz( `p_bucket_split` , '' ) , ', city: ' ,
                                                api.api_nz( `p_city` , '' ) , ', email_address: ' ,
                                                api.api_nz( `p_email_address` , '' ) , ', copay_auto_renew: ' ,
                                                api.api_nz( `p_copay_auto_renew` , '' ) , ', employer_status: ' ,
                                                api.api_nz( `p_employer_status` , '' ) ,
                                                ', recurring_expense_auto_renew: ' ,
                                                api.api_nz( `p_recurring_expense_auto_renew` , '' ) , ', state: ' ,
                                                api.api_nz( `p_state` , '' ) , ', tpa_id: ' ,
                                                api.api_nz( `p_tpa_id` , '' ) ) );
            CALL api.db_log_message( 'upsert_wc_employers' , @text , 'ERROR' );
        END;
    
    CALL api.db_log_message( 'upsert_wc_employers' ,
                             CONCAT( 'Called With Params: ' , ', employer_id: ' , api.api_nz( `p_employer_id` , '' ) ,
                                     ', employer_name: ' , api.api_nz( `p_employer_name` , '' ) ,
                                     ', active_first_use: ' , api.api_nz( `p_active_first_use` , '' ) ,
                                     ', bucket_split: ' , api.api_nz( `p_bucket_split` , '' ) , ', city: ' ,
                                     api.api_nz( `p_city` , '' ) , ', email_address: ' ,
                                     api.api_nz( `p_email_address` , '' ) , ', copay_auto_renew: ' ,
                                     api.api_nz( `p_copay_auto_renew` , '' ) , ', employer_status: ' ,
                                     api.api_nz( `p_employer_status` , '' ) , ', recurring_expense_auto_renew: ' ,
                                     api.api_nz( `p_recurring_expense_auto_renew` , '' ) , ', state: ' ,
                                     api.api_nz( `p_state` , '' ) , ', tpa_id: ' , api.api_nz( `p_tpa_id` , '' ) ) ,
                             'WARN' );
    
    INSERT INTO `wc`.`wc_employers` (
                                    `employer_id`,
                                    `employer_name`,
                                    `active_first_use`,
                                    `bucket_split`,
                                    `city`,
                                    `email_address`,
                                    `copay_auto_renew`,
                                    `employer_status`,
                                    `recurring_expense_auto_renew`,
                                    `state`,
                                    `tpa_id`
    )
    VALUES (
           `p_employer_id`,
           `p_employer_name`,
           `p_active_first_use`,
           `p_bucket_split`,
           `p_city`,
           `p_email_address`,
           `p_copay_auto_renew`,
           `p_employer_status`,
           `p_recurring_expense_auto_renew`,
           `p_state`,
           `p_tpa_id`
           )
        
        /* use api_nz to avoid replacing previous value if new value is null or blank */
    ON DUPLICATE KEY
        UPDATE
            `employer_id`                  = api.api_nz( `p_employer_id` , `employer_id` ),
            `employer_name`                = api.api_nz( `p_employer_name` , `employer_name` ),
            `active_first_use`             = api.api_nz( `p_active_first_use` , `active_first_use` ),
            `bucket_split`                 = api.api_nz( `p_bucket_split` , `bucket_split` ),
            `city`                         = api.api_nz( `p_city` , `city` ),
            `email_address`                = api.api_nz( `p_email_address` , `email_address` ),
            `copay_auto_renew`             = api.api_nz( `p_copay_auto_renew` , `copay_auto_renew` ),
            `employer_status`              = api.api_nz( `p_employer_status` , `employer_status` ),
            `recurring_expense_auto_renew` = api.api_nz( `p_recurring_expense_auto_renew` ,
                                                         `recurring_expense_auto_renew` ),
            `state`                        = api.api_nz( `p_state` , `state` ),
            `tpa_id`                       = api.api_nz( `p_tpa_id` , `tpa_id` );

END;

