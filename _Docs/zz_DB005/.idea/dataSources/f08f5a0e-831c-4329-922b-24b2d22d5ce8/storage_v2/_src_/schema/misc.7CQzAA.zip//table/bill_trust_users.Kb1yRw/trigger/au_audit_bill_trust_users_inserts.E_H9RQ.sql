CREATE DEFINER = root@`%` TRIGGER au_audit_bill_trust_users_inserts
    AFTER INSERT
    ON bill_trust_users
    FOR EACH ROW
    INSERT INTO `misc`.`bill_trust_users_audit`
     (`auditAction`,`row_id`,`email`,`line_of_business`,`account_number`,`branch_name`,`account_name`,`status`,`enrolled_date`,`send_paper_bill`,`created_at`,`created_by`,`updated_at`,`updated_by`)
  VALUES
     ('INSERT',NEW.`row_id`,NEW.`email`,NEW.`line_of_business`,NEW.`account_number`,NEW.`branch_name`,NEW.`account_name`,NEW.`status`,NEW.`enrolled_date`,NEW.`send_paper_bill`,NEW.`created_at`,NEW.`created_by`,NEW.`updated_at`,NEW.`updated_by`);

