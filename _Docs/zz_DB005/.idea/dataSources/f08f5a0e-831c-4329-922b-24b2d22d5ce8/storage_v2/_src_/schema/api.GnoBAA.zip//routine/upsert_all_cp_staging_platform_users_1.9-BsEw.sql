CREATE
    DEFINER = root@`%` PROCEDURE upsert_all_cp_staging_platform_users_1(
    IN p_only_emails_like varchar(200) )
full_proc:

BEGIN
    DECLARE v_email varchar(200) DEFAULT NULL;
    
    DECLARE v_finished int;
    DECLARE v_values_cursor CURSOR FOR
        SELECT DISTINCT
            email
        FROM
            cp.cp_all_sso_users_staging t
        WHERE
            email LIKE p_only_emails_like
        ORDER BY
            email;
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND
        BEGIN
            SET v_finished = 1;
        END;
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
            CALL db_throw_error( @errno , 'upsert_all_cp_platform_staging_users_1' , @text );
        END;
    
    SET @@max_sp_recursion_depth = 12;
    
    CALL api.db_log_message( 'upsert_all_cp_platform_staging_users_1' ,
                             CONCAT(
                                     'Processing for Emails like : ' ,
                                     p_only_emails_like
                                 ) , 'WARN' );
    
    SET p_only_emails_like = api.api_nz( p_only_emails_like , '%' );
    
    OPEN v_values_cursor;
    
    getvalues
        :
    LOOP
        
        FETCH v_values_cursor INTO v_email;
        
        IF v_finished = 1 THEN
            LEAVE getvalues;
        END IF;
        
        IF !api.api_is_blank( v_email ) THEN
            /* sumeet - insert for each order seq so we take highest active record in each category of user*/
            /* do not upsert parts pending changes*/
            CALL api.upsert_all_cp_staging_platform_users_2( v_email , 10 );
            CALL api.upsert_all_cp_staging_platform_users_2( v_email , 20 );
            CALL api.upsert_all_cp_staging_platform_users_2( v_email , 30 );
            CALL api.upsert_all_cp_staging_platform_users_2( v_email , 40 );
            CALL api.upsert_all_cp_staging_platform_users_2( v_email , 50 );
            CALL api.upsert_all_cp_staging_platform_users_2( v_email , 60 );
        
        END IF;
    END LOOP getvalues;
END;

