CREATE DEFINER = root@`%` TRIGGER util_bu_cp__all_sso_users_set_updated_at_and_by
    BEFORE UPDATE
    ON cp_all_sso_users
    FOR EACH ROW
BEGIN
    SET new.updated_at = CURRENT_TIMESTAMP;
    SET new.updated_by = CURRENT_USER;
    
    SET new.entitytype = api.api_nz( new.entitytype , '' );
    SET new.ssoidentifier = api.api_nz( new.ssoidentifier , '' );
    SET new.email = api.api_nz( new.email , '' );
    SET new.userid = api.api_nz( new.userid , '' );
    
    SET new.dob = api.api_fix_date( new.dob );
    SET new.registrationdate = api.api_fix_date( new.registrationdate );
    SET new.qualeventdate = api.api_fix_date( new.qualeventdate );
    

END;

