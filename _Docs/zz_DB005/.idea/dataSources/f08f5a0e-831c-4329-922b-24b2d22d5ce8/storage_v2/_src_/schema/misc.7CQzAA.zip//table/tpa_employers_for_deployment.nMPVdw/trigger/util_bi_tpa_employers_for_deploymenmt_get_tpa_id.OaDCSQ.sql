CREATE DEFINER = root@`%` TRIGGER util_bi_tpa_employers_for_deploymenmt_get_tpa_id
    BEFORE INSERT
    ON tpa_employers_for_deployment
    FOR EACH ROW
BEGIN
    DECLARE v_tpa_id int DEFAULT NULL;
    IF new.tpa_id IS NULL OR new.tpa_id <= 0 THEN
        SELECT
            tpa_id
        INTO v_tpa_id
        FROM
            misc.tpa_employers
        WHERE
            alegeus_key = new.alegeus_key;
        
        SET new.tpa_id = v_tpa_id;
    END IF;
END;

