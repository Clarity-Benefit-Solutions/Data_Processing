CREATE DEFINER = root@`%` TRIGGER au_audit_case_owner_master_deletes
    AFTER DELETE
    ON case_owner_master
    FOR EACH ROW
    INSERT INTO `sf`.`case_owner_master_audit`
                 (
                 `auditAction`,
                 `sf_case_owner_user_id`,
                 `sf_case_owner_full_name`,
                 `created_at`,
                 `created_by`,
                 `updated_at`,
                 `updated_by`
                 )
                 VALUES (
                        'DELETE',
                        OLD.`sf_case_owner_user_id`,
                        OLD.`sf_case_owner_full_name`,
                        OLD.`created_at`,
                        OLD.`created_by`,
                        OLD.`updated_at`,
                        OLD.`updated_by`
                        );

