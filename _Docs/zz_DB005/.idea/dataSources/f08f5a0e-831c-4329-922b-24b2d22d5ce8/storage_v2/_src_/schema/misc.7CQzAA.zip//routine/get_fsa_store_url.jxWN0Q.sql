CREATE
    DEFINER = root@`%` FUNCTION get_fsa_store_url(
                                                 shoppinglinkurl varchar(250),
                                                 learnmorelinkurl varchar(250),
                                                 shoppinglinktext varchar(250),
                                                 learnmorelinktext varchar(250),
                                                 shoppinglinktype varchar(250),
                                                 label varchar(250),
                                                 p_benefittype varchar(50) ) RETURNS longtext
BEGIN
    DECLARE url longtext DEFAULT '';
    DECLARE urllabel varchar(250) DEFAULT '';
    DECLARE urlutm varchar(250) DEFAULT '&utm_source=Clarity&utm_medium=TPA+Portal+Proprietary+EL&utm_campaign=TPA+Partner&a_aid=57b6176e09c7a';
    
    IF shoppinglinktype = 'Category' THEN
        SET urllabel = 'Shop at FSA Store';
        SET url = shoppinglinkurl;
    ELSEIF shoppinglinktype = 'Search' THEN
        SET urllabel = 'Learn More at FSA Store';
        SET url = shoppinglinkurl;
    ELSE
        SET urllabel = 'Learn More at FSA Store';
        SET url = learnmorelinkurl;
    END IF;
    
    IF SUBSTR( url , 1 , 1 ) = '/' THEN
        SET url = CONCAT( 'https://fsastore.com' , url );
    ELSEIF api.api_is_blank( url ) THEN
        SET url = CONCAT( 'https://fsastore.com/SearchProducts.aspx?q=' , CASE
                                                                              WHEN NOT api.api_is_blank( learnmorelinktext )
                                                                                  THEN learnmorelinktext
                                                                              ELSE label
                                                                          END );
    END IF;
    
    IF POSITION( '?' IN url ) = 0 THEN
        SET url = CONCAT( url , '?' );
    END IF;
    
    SET url = CONCAT( url , urlutm );
    
    /*
    <option value="fsaeligibilitytype" selected="selected">Clarity FSA</option>
    <option value="limitedcarefsaeligibilitytype">Clarity LPFSA</option>
    <option value="hraeligibilitytype">Clarity HRA</option>
    <option value="hsaeligibilitytype">Clarity HSA</option>
    <option value="dependentcarefsaeligibilitytype">Clarity Dependent Care</option>
    */
#     IF p_benefittype IN ('hsaeligibilitytype') THEN
#         SET urllabel = REPLACE( urllabel , 'FSA' , 'HSA' );
#         SET url = REPLACE( url , 'fsastore.com' , 'hsastore.com' );
#     END IF;
    
    IF NOT api.api_is_blank( url ) THEN
        SET url = CONCAT( '<a target="_blank" href="' , url , '">' , urllabel , '</a>' );
    END IF;
    
    RETURN url;
END;

