CREATE DEFINER = root@`%` TRIGGER au_audit_case_owner_master_updates
    AFTER UPDATE
    ON case_owner_master
    FOR EACH ROW
    INSERT INTO `sf`.`case_owner_master_audit`
                 (
                 `auditAction`,
                 `sf_case_owner_user_id`,
                 `sf_case_owner_full_name`,
                 `created_at`,
                 `created_by`,
                 `updated_at`,
                 `updated_by`
                 )
                 VALUES (
                        'UPDATE',
                        NEW.`sf_case_owner_user_id`,
                        NEW.`sf_case_owner_full_name`,
                        NEW.`created_at`,
                        NEW.`created_by`,
                        NEW.`updated_at`,
                        NEW.`updated_by`
                        );

