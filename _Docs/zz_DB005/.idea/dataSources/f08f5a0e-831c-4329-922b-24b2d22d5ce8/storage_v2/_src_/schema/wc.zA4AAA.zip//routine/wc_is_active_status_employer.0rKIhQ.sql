CREATE
    DEFINER = root@`%` FUNCTION wc_is_active_status_employer(
    p_employer_id varchar(200) ) RETURNS float
BEGIN
    DECLARE v_ret float DEFAULT 0;
    DECLARE p_status varchar(100) DEFAULT '';
    
    SELECT
        api.api_nz( employer_status , '' )
    INTO p_status
    FROM
        wc.wc_employers
    WHERE
        employer_id = p_employer_id
    LIMIT 1;
    #
    CASE
        WHEN p_status IS NULL
            THEN
                SET v_ret = 0;
        WHEN p_status IN (
                          '',
                          '1',
                          'ACTIVE',
                          'NEW'
            )
            THEN
                SET v_ret = 1;
        WHEN p_status IN (
                          'TEMPORARILY INACTIVE',
                          'TI', 'TEMPINACTIVE',
                          'TI'
            )
            THEN
                SET v_ret = 0.0;
        WHEN p_status IN (
                          'PERMANENTLY INACTIVE', 'PERMINACTIVE',
                          'PI'
            )
            THEN
                SET v_ret = 0.0;
        ELSE SET v_ret = 0.0;
    END CASE;
    
    RETURN v_ret;

END;

