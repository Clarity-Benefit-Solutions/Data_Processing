CREATE
    DEFINER = admin@`%` FUNCTION api_nz_float(
                                             value varchar(200),
                                             valueifnullorempty varchar(200) ) RETURNS float
BEGIN
    IF ifnull(value, '') = '' THEN
        RETURN api_cfloat(valueifnullorempty);
        /* sumeet: allow force setting a value to null by passing '<NULL>'*/
    ELSEIF ifnull(
                   value
               , '') = '<NULL>' THEN
        RETURN NULL;
    ELSE
        RETURN api_cfloat(value);
    END IF;
END;

