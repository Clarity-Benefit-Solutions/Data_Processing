CREATE
    DEFINER = root@`%` FUNCTION get_registration_invite_count_prv(
    p_email varchar(200) ) RETURNS text
BEGIN
    
    DECLARE v_count int(11);
    
    SELECT
        COUNT( * )
    INTO v_count
    
    FROM
        api.api_notification_logs
    WHERE
          destination_address = p_email
      AND notification_type LIKE 'email'
      AND notification_category = 'Registration';
    
    RETURN api.api_nz_int( v_count , 0 );
END;

