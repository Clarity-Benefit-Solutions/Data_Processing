CREATE DEFINER = root@`%` TRIGGER au_audit_wc_employers_deletes
    AFTER DELETE
    ON wc_employers
    FOR EACH ROW
    INSERT INTO `wc`.`wc_employers_audit`
                 (
                 `auditAction`,
                 `employer_id`,
                 `employer_name`,
                 `active_first_use`,
                 `bucket_split`,
                 `city`,
                 `email_address`,
                 `copay_auto_renew`,
                 `employer_status`,
                 `recurring_expense_auto_renew`,
                 `state`,
                 `tpa_id`,
                 `created_at`,
                 `created_by`,
                 `updated_at`,
                 `updated_by`
                 )
                 VALUES (
                        'DELETE',
                        OLD.`employer_id`,
                        OLD.`employer_name`,
                        OLD.`active_first_use`,
                        OLD.`bucket_split`,
                        OLD.`city`,
                        OLD.`email_address`,
                        OLD.`copay_auto_renew`,
                        OLD.`employer_status`,
                        OLD.`recurring_expense_auto_renew`,
                        OLD.`state`,
                        OLD.`tpa_id`,
                        OLD.`created_at`,
                        OLD.`created_by`,
                        OLD.`updated_at`,
                        OLD.`updated_by`
                        );

