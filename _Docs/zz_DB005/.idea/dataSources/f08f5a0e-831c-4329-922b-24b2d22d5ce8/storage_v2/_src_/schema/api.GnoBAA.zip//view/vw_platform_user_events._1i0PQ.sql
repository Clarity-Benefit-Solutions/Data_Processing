CREATE VIEW vw_platform_user_events
AS
    SELECT
        `e`.`user_event_id` `UserEventId`
      , `e`.`user_id` `UserId`
      , `api`.`cap_first`( `e`.`user_event_type` ) `UserEventType`
      , `api`.`cap_first`( `e`.`user_event_status` ) `UserEventStatus`
      , `u`.`email` `Email`
      , `u`.`first_name` `FirstName`
      , `u`.`last_name` `LastName`
      , `u`.`mobile_number` `MobileNumber`
      , `u`.`is_tpa_admin` `IsTpaAdmin`
      , `u`.`is_broker` `IsBroker`
      , `u`.`is_client` `IsClient`
      , `u`.`is_particpant` `IsParticpant`
      , `u`.`is_verified` `IsVerified`
      , `e`.`user_event_notes` `UserEventNotes`
      , `e`.`created_at` `CreatedAt`
      , `e`.`created_by` `CreatedBy`
      , `e`.`updated_at` `UpdatedAt`
      , `e`.`updated_by` `UpdatedBy`
    FROM
        (`api`.`platform_user_events` `e`
            LEFT JOIN `api`.`vw_platform_sso_users` `u` ON (`e`.`user_id` = `u`.`user_id`));

