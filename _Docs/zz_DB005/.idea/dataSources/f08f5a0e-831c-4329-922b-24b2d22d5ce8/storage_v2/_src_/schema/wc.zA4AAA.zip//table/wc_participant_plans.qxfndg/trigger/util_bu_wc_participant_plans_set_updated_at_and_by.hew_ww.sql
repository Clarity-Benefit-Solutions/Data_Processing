CREATE DEFINER = root@`%` TRIGGER util_bu_wc_participant_plans_set_updated_at_and_by
    BEFORE UPDATE
    ON wc_participant_plans
    FOR EACH ROW
BEGIN
    SET new.updated_at = CURRENT_TIMESTAMP;
    SET new.updated_by = CURRENT_USER;
    
    
     /* columns used in unique key*/
    SET new.tpaid = api.api_nz( new.tpaid , '' );
    SET new.employerid = api.api_nz( new.employerid , '' );
    SET new.employeeid = api.api_nz( new.employeeid , '' );
    SET new.plandesc = api.api_nz( new.plandesc , '' );
    SET new.plancode = api.api_nz( new.plancode , '' );

END;

