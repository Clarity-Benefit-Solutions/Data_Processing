CREATE
    DEFINER = root@`%` FUNCTION if_is_active_status(
                                                   p_employee_status varchar(200),
                                                   p_employee_id varchar(200),
                                                   p_employer_id varchar(200) ) RETURNS float
BEGIN
    DECLARE v_ret float DEFAULT 0;
    DECLARE v_ret_employer float DEFAULT 0;
    DECLARE v_ret_ic_plan float DEFAULT 0;
    DECLARE v_ret_employer_ic_plan float DEFAULT 0;
    
    IF api.api_is_blank( p_employee_status ) THEN
        SET v_ret = 0;
    END IF;
    
    SET p_employee_status = TRIM( UPPER( api.api_nz( p_employee_status , '' ) ) );
    
    CASE
        WHEN p_employee_status IN (
                                   '',
                                   '1',
                                   'ACTIVE',
                                   'NEW'
            )
            THEN
                SET v_ret = 1.0;
        WHEN p_employee_status IN (
                                   'TEMPORARILY INACTIVE',
                                   'TI', 'TEMPINACTIVE',
                                   'TI'
            )
            THEN
                SET v_ret = 0.5;
        WHEN p_employee_status IN (
                                   '0',
                                   'PERMANENTLY INACTIVE', 'PERMINACTIVE',
                                   'PI'
            )
            THEN
                SET v_ret = 0.0;
        ELSE SET v_ret = 0.0;
    END CASE;
    
    #      if active, check employer is also active
    IF v_ret > 0 AND NOT api.api_is_blank( p_employer_id ) THEN
        SET v_ret_employer = wc.wc_is_active_status_employer( p_employer_id );
        
        /* return the elast of the 2*/
        IF v_ret < v_ret_employer THEN
            SET v_ret = v_ret;
        ELSE
            SET v_ret = v_ret_employer;
        END IF;
    
    END IF;
    #      if a tive, check has relevant plan for employye
    IF v_ret > 0 AND NOT api.api_is_blank( p_employer_id ) THEN
        SET v_ret_employer_ic_plan = wc.if_is_active_status_employer( p_employer_id );
        SET v_ret_ic_plan = wc.wc_has_ic_plan( p_employee_id , p_employer_id );
        
        IF v_ret_ic_plan > 0 THEN
            /* active*/
            SET v_ret_ic_plan = 1;
        ELSEIF v_ret_employer_ic_plan > 0 THEN
            /*unregistered - has not elected in IF*/
            SET v_ret_ic_plan = 2;
        END IF;
        
        /* return the elast of the 2*/
        SET v_ret = v_ret_ic_plan;
    
    END IF;
    
    RETURN v_ret;

END;

