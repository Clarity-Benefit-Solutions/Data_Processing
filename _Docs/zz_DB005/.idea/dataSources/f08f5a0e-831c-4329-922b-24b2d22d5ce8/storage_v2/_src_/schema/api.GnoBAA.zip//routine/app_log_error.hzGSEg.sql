CREATE
    DEFINER = admin@`%` PROCEDURE app_log_error(
                                               IN p_ip_address varchar(50),
                                               IN p_err_source varchar(200),
                                               IN p_file_path varchar(200),
                                               IN p_err_type varchar(200),
                                               IN p_msg varchar(500),
                                               IN p_json_dump text )
BEGIN
	
 DECLARE EXIT HANDLER FOR SQLEXCEPTION 
 BEGIN
     GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
     CALL db_log_error( @errno , 'app_log_error' , @text , @sqlstate );
 END; 
 INSERT INTO logs.app_error_logs (
		ip_address,
		error_source,
		file_path,
		err_type,
		err_msg,
        json_dump
	) VALUES (
		p_ip_address,
		p_err_source,
		p_file_path,
		p_err_type,
		p_msg,
        p_json_dump
	);
END;

