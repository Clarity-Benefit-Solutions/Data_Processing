CREATE
    DEFINER = root@`%` FUNCTION el_is_active_status(
                                                   p_employee_status varchar(200),
                                                   p_employee_id varchar(200),
                                                   p_employer_id varchar(200) ) RETURNS float
BEGIN
    DECLARE v_ret float DEFAULT 0;
    DECLARE v_ret_employer float DEFAULT 0;
    DECLARE v_ret_ic_plan float DEFAULT 0;
    DECLARE v_ret_el_plan float DEFAULT 0;
    
    IF api.api_is_blank( p_employee_status ) THEN
        SET v_ret = 0.0;
    END IF;
    
    SET p_employee_status = TRIM( UPPER( api.api_nz( p_employee_status , '' ) ) );
    
    CASE
        WHEN p_employee_status IN (
                                   '',
                                   '1',
                                   'ACTIVE',
                                   'NEW'
            )
            THEN
                SET v_ret = 1.0;
        WHEN p_employee_status IN (
                                   'TEMPORARILY INACTIVE',
                                   'TI', 'TEMPINACTIVE',
                                   'TI'
            )
            THEN
                SET v_ret = 0.5;
        WHEN p_employee_status IN (
                                   '0',
                                   'PERMANENTLY INACTIVE', 'PERMINACTIVE',
                                   'PI'
            )
            THEN
                SET v_ret = 0.0;
        ELSE SET v_ret = 0.0;
    END CASE;
    
    #      if active, check employer is also active
    IF v_ret > 0 AND NOT api.api_is_blank( p_employer_id ) THEN
        SET v_ret_employer = el.el_is_active_status_employer( p_employer_id );
        
        /* return the elast of the 2*/
        IF v_ret < v_ret_employer THEN
            SET v_ret = v_ret;
        ELSE
            SET v_ret = v_ret_employer;
        END IF;
    
    END IF;
    #      sumeet - skip this check till we are sure we are aggregating all old wc plans or till IF goes live
    #     IF v_ret > 0 AND NOT api.api_is_blank( p_employer_id ) THEN
    #         SET v_ret_ic_plan = el.el_has_ic_plan( p_employee_id , p_employer_id );
    #         SET v_ret_el_plan = el.el_has_el_plan( p_employee_id , p_employer_id );
    #
    #         /* if there is a WC plan OR (there is no ic plan, then it is an active employee for whcih we have not aggregated old wc plans) */
    #         IF v_ret_el_plan OR (NOT v_ret_ic_plan AND v_ret > 0) THEN
    #             SET v_ret_el_plan = 1;
    #         END IF;
    #
    #         /* return the elast of the 2*/
    #         IF v_ret < v_ret_el_plan THEN
    #             SET v_ret = v_ret;
    #         ELSE
    #             SET v_ret = v_ret_el_plan;
    #         END IF;
    #
    #     END IF;
    
    RETURN v_ret;

END;

