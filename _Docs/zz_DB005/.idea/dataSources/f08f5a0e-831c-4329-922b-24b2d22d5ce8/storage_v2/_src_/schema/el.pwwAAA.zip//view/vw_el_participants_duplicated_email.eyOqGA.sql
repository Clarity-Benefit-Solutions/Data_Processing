CREATE VIEW vw_el_participants_duplicated_email
AS
    SELECT
        `el`.`el_participants`.`email` `email`
    FROM
        `el`.`el_participants`
    WHERE
        !`api`.`api_is_blank`( `el`.`el_participants`.`email` )
    GROUP BY
        `el`.`el_participants`.`email`
    HAVING
        COUNT( 0 ) > 1;

