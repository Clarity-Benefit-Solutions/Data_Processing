CREATE
    DEFINER = root@`%` PROCEDURE upsert_el_participant_plans(
                                                            IN p_recordid varchar(75),
                                                            IN p_tpaid varchar(75),
                                                            IN p_employerid varchar(75),
                                                            IN p_employeeid varchar(75),
                                                            IN p_firstname varchar(75),
                                                            IN p_lastname varchar(75),
                                                            IN p_plandesc varchar(75),
                                                            IN p_plancode varchar(75),
                                                            IN p_alegusacctstatus varchar(75),
                                                            IN p_planstart date,
                                                            IN p_planend date,
                                                            IN p_annualelection float,
                                                            IN p_overrideelection float,
                                                            IN p_employeeppd float,
                                                            IN p_employerppd float,
                                                            IN p_eligibilitydate date,
                                                            IN p_dummy1 varchar(75) )
BEGIN
    
    -- handle error that may happen as the table has a few unique keys which may conflict
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO,
                @text = MESSAGE_TEXT;
            SET @text = CONCAT( @text , CONCAT( '
Called With Params: ' , ', recordid: ' , api.api_nz( `p_recordid` , '' ) , ', tpaid: ' , api.api_nz( `p_tpaid` , '' ) ,
                                                ', employerid: ' , api.api_nz( `p_employerid` , '' ) ,
                                                ', employeeid: ' , api.api_nz( `p_employeeid` , '' ) , ', firstname: ' ,
                                                api.api_nz( `p_firstname` , '' ) , ', lastname: ' ,
                                                api.api_nz( `p_lastname` , '' ) , ', plandesc: ' ,
                                                api.api_nz( `p_plandesc` , '' ) , ', plancode: ' ,
                                                api.api_nz( `p_plancode` , '' ) , ', alegusacctstatus: ' ,
                                                api.api_nz( `p_alegusacctstatus` , '' ) , ', planstart: ' ,
                                                api.api_nz( `p_planstart` , '' ) , ', planend: ' ,
                                                api.api_nz( `p_planend` , '' ) , ', annualelection: ' ,
                                                api.api_nz( `p_annualelection` , '' ) , ', overrideelection: ' ,
                                                api.api_nz( `p_overrideelection` , '' ) , ', employeeppd: ' ,
                                                api.api_nz( `p_employeeppd` , '' ) , ', employerppd: ' ,
                                                api.api_nz( `p_employerppd` , '' ) , ', eligibilitydate: ' ,
                                                api.api_nz( `p_eligibilitydate` , '' ) , ', dummy1: ' ,
                                                api.api_nz( `p_dummy1` , '' ) ) );
            CALL api.db_log_message( 'upsert_el_participant_plans' , @text , 'ERROR' );
        END;
    
    CALL api.db_log_message( 'upsert_el_participant_plans' ,
                             CONCAT( 'Called With Params: ' , ', recordid: ' , api.api_nz( `p_recordid` , '' ) ,
                                     ', tpaid: ' , api.api_nz( `p_tpaid` , '' ) , ', employerid: ' ,
                                     api.api_nz( `p_employerid` , '' ) , ', employeeid: ' ,
                                     api.api_nz( `p_employeeid` , '' ) , ', firstname: ' ,
                                     api.api_nz( `p_firstname` , '' ) , ', lastname: ' ,
                                     api.api_nz( `p_lastname` , '' ) , ', plandesc: ' ,
                                     api.api_nz( `p_plandesc` , '' ) , ', plancode: ' ,
                                     api.api_nz( `p_plancode` , '' ) , ', alegusacctstatus: ' ,
                                     api.api_nz( `p_alegusacctstatus` , '' ) , ', planstart: ' ,
                                     api.api_nz( `p_planstart` , '' ) , ', planend: ' , api.api_nz( `p_planend` , '' ) ,
                                     ', annualelection: ' , api.api_nz( `p_annualelection` , '' ) ,
                                     ', overrideelection: ' , api.api_nz( `p_overrideelection` , '' ) ,
                                     ', employeeppd: ' , api.api_nz( `p_employeeppd` , '' ) , ', employerppd: ' ,
                                     api.api_nz( `p_employerppd` , '' ) , ', eligibilitydate: ' ,
                                     api.api_nz( `p_eligibilitydate` , '' ) , ', dummy1: ' ,
                                     api.api_nz( `p_dummy1` , '' ) ) , 'WARN' );
    
    INSERT INTO `el`.`el_participant_plans` (
                                            `recordid`,
                                            `tpaid`,
                                            `employerid`,
                                            `employeeid`,
                                            `firstname`,
                                            `lastname`,
                                            `plandesc`,
                                            `plancode`,
                                            `alegusacctstatus`,
                                            `planstart`,
                                            `planend`,
                                            `annualelection`,
                                            `overrideelection`,
                                            `employeeppd`,
                                            `employerppd`,
                                            `eligibilitydate`,
                                            `dummy1`
    )
    
    VALUES (
           `p_recordid`,
           `p_tpaid`,
           `p_employerid`,
           `p_employeeid`,
           `p_firstname`,
           `p_lastname`,
           `p_plandesc`,
           `p_plancode`,
           `p_alegusacctstatus`,
           `p_planstart`,
           `p_planend`,
           `p_annualelection`,
           `p_overrideelection`,
           `p_employeeppd`,
           `p_employerppd`,
           `p_eligibilitydate`,
           `p_dummy1`
           )
        
        /* use api_nz to avoid replacing previous value if new value is null or blank */
    ON DUPLICATE KEY
        UPDATE
            `recordid`         = api.api_nz( `p_recordid` , `recordid` ),
            `tpaid`            = api.api_nz( `p_tpaid` , `tpaid` ),
            `employerid`       = api.api_nz( `p_employerid` , `employerid` ),
            `employeeid`       = api.api_nz( `p_employeeid` , `employeeid` ),
            `firstname`        = api.api_nz( `p_firstname` , `firstname` ),
            `lastname`         = api.api_nz( `p_lastname` , `lastname` ),
            `plandesc`         = api.api_nz( `p_plandesc` , `plandesc` ),
            `plancode`         = api.api_nz( `p_plancode` , `plancode` ),
            `alegusacctstatus` = api.api_nz( `p_alegusacctstatus` , `alegusacctstatus` ),
            `planstart`        = api.api_nz_date( `p_planstart` , `planstart` ),
            `planend`          = api.api_nz_date( `p_planend` , `planend` ),
            `annualelection`   = api.api_nz_float( `p_annualelection` , `annualelection` ),
            `overrideelection` = api.api_nz_float( `p_overrideelection` , `overrideelection` ),
            `employeeppd`      = api.api_nz_float( `p_employeeppd` , `employeeppd` ),
            `employerppd`      = api.api_nz_float( `p_employerppd` , `employerppd` ),
            `eligibilitydate`  = api.api_nz_date( `p_eligibilitydate` , `eligibilitydate` ),
            `dummy1`           = api.api_nz( `p_dummy1` , `dummy1` );

END;

