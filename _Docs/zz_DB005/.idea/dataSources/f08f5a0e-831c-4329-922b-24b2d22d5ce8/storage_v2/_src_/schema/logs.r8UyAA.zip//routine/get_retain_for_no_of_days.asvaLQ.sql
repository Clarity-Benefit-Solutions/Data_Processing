CREATE
    DEFINER = root@`%` FUNCTION get_retain_for_no_of_days(
                                                         event_source varchar(100),
                                                         event_type varchar(100),
                                                         event_status varchar(100) ) RETURNS int
begin
    declare v_days int default 30;
    case when event_type = 'modified' then set v_days = 1095; /*WPpost modified*/
        when event_type = 'viewed' then set v_days = 1095; /*WPpost viewed*/
        when event_type = 'login' then set v_days = 1095; /*WPlogin*/
        when event_type = 'opened' then set v_days = 1095; /*WPpost opened*/
        when event_type = 'SSO-click' then set v_days = 1095; /*WPsso tile clicked*/
        when event_type = 'logout' then set v_days = 1095; /*WPlogout*/
        when event_type = 'Email-status' then set v_days = 30; /*WPemail-status*/
        when event_type = 'RenewalPortal:C2' then set v_days = 30; /*CRONRenewal Reminder CRON*/
        when event_type = 'RenewalPortal:C4' then set v_days = 30; /*CRONRenewal mark cases to closed or Cancelled Hidden*/
        when event_type = 'Form:C2' then set v_days = 30; /*CRONForms reminder cron*/
        when event_type = 'RenewalPortal:FileUpload' then set v_days = 30; /*CRONRenewal File upload cron*/
        when event_type = 'Form:C1_Covid2021Info' then set v_days = 30; /*CRONForm Initiall rollout*/
        when event_type = 'Sync:User' then set v_days = 30; /*CRONSync users data to MO*/
        when event_type = 'RenewalPortal:C1' then set v_days = 30; /*CRONRenewal Initial rollout*/
        when event_type = 'Send:Invite' then set v_days = 30; /*CRONSend Invite to users*/
        when event_type = 'TPAStream:ETL2' then set v_days = 30; /*CRONParticiant data extraction from TPA stream*/
        when event_type = 'indexForms' then set v_days = 30; /*APIAPI which will return the list of forms*/
        when event_type = 'WpApi' then set v_days = 30; /*APIWord press API call from LARAVEL*/
        when event_type = 'index' then set v_days = 30; /*APILaravel API for validating renewal case token with the assigned email*/
        when event_type = 'logUserEvent' then set v_days = 30; /*APILaravel API for logging word press event*/
        when event_type = 'doChangeStatus' then set v_days = 30; /*APILaravel API for updating the case status*/
        when event_type = 'doRegister-GET' then set v_days = 30; /*APILaravel API to fetch the data tobe pre filled in the form when user tryign to register with token*/
        when event_type = 'MiniOrangeApi' then set v_days = 30; /*APIMiniOrange API call from LARAVEL*/
        when event_type = 'setAllowSSO' then set v_days = 30; /*APILaravel API for setting allow sso flag*/
        when event_type = 'BoomiAllowSSOApi' then set v_days = 30; /*APIAllow SSO boomi API call from LARAVEL*/
        when event_type = 'doRegister-POST' then set v_days = 30; /*APILaravel API for registering users*/
        when event_type = 'inviteUser' then set v_days = 30; /*APILaravel API for sending invitation mail to users*/
        when event_type = 'detail' then set v_days = 30; /*APILaravel API for list of renewal cases to be desplayed at wordpress side*/
        when event_type = 'resetPassword' then set v_days = 30; /*APILaravel API for reset password step 1*/
        when event_type = 'setPassword' then set v_days = 30; /*APILaravel API for reset password step 2*/
        when event_type = 'fileUpload' then set v_days = 30; /*APILaravel API for file upload*/
        when event_type = 'tpaAPI' then set v_days = 30; /*APITPAStream API call from LARAVEL*/
        else set v_days = 30;
    end case;
    
    if event_status in ('ERROR', 'FAILED', 'SKIPPED') then
        if v_days < 180 then
            set v_days = 180;
        end if;
    end if;
    
    return v_days;
end;

