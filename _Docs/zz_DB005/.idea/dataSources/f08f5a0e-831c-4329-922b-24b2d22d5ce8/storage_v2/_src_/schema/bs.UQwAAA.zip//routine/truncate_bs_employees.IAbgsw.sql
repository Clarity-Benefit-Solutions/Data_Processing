CREATE
    DEFINER = root@`%` PROCEDURE truncate_bs_employees(
    IN dummy int(1) )
BEGIN

    CALL api.db_show_message( 'truncate_bs_employees', 'STARTING' );
    CALL api.db_show_message( 'truncate_bs_employees', 'returning without any further action' );

#     TRUNCATE TABLE bs.bs_employees;
#
#
#     CALL api.db_show_message( 'truncate_bs_employees', 'FINISHED' );


END;

