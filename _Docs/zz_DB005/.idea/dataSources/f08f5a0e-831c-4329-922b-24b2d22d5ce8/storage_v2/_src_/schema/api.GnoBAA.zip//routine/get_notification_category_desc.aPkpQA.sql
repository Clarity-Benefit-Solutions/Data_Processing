CREATE
    DEFINER = root@`%` FUNCTION get_notification_category_desc(
    p_notification_category_id varchar(255) ) RETURNS varchar(255)
BEGIN
    DECLARE v_ret varchar(255);
    
    IF p_notification_category_id = '' THEN
        RETURN 'Invalid Notification Category ID';
    END IF;

    
    SELECT
        notification_category_desc
    INTO v_ret
    FROM
        api.notification_categories
    WHERE
        notification_category_id = p_notification_category_id
    LIMIT 1;
    
    if api.api_is_blank(v_ret) then
        set v_ret = concat('Invalid Notification Category ID: ', p_notification_category_id);
    END IF;
    
    RETURN
        v_ret;
END;

