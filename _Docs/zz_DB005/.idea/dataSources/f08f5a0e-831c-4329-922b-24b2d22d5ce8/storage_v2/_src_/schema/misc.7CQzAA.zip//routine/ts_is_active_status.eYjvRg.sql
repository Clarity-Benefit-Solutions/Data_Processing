CREATE
    DEFINER = root@`%` FUNCTION ts_is_active_status(
                                                   p_employee_id int,
                                                   p_employer_id int ) RETURNS float
BEGIN
    DECLARE v_ret float DEFAULT 0;
    DECLARE v_count_policies float DEFAULT 0;
    DECLARE v_count_active_employers float DEFAULT 0;
    DECLARE v_login_problem text DEFAULT '';
    
    IF api.api_is_blank( p_employee_id ) THEN
        SET v_ret = 0.0;
    END IF;
    
    SELECT
        COUNT( * )
      , GROUP_CONCAT( login_problem )
    INTO v_count_policies, v_login_problem
    FROM
        misc.tpa_participant_policies
    WHERE
        tpa_employee_id = p_employee_id;
    
    SELECT
        COUNT( * )
    INTO v_count_active_employers
    FROM
        #         misc.tpa_employers_for_deployment
        misc.vw_tpa_employers_for_deployment
    WHERE
        tpa_id = p_employer_id;
    
    SET v_count_active_employers = api.api_nz_int( v_count_active_employers , 0 );
    SET v_count_policies = api.api_nz_int( v_count_policies , 0 );
    SET v_login_problem = api.api_nz( v_login_problem , '' );
    
    IF v_count_active_employers <= 0 THEN
        RETURN 0;
    END IF;
    
    CASE
        WHEN v_count_policies = 0
            THEN
                SET v_ret = 2;
        
        WHEN misc.ts_is_login_problem( v_login_problem ) THEN
            SET v_ret = 3;
        
        ELSE SET v_ret = 1;
    END CASE;
    
    RETURN v_ret;

END;

