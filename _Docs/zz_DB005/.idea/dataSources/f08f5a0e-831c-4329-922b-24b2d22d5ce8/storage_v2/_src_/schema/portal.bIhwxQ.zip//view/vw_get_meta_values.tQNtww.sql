CREATE VIEW vw_get_meta_values
AS
    SELECT
        `t`.`item_id` `item_id`
      , `t`.`form_name` `form_name`
      , `t`.`page_name` `page_name`
      , `t`.`field_name` `field_name`
      , `t`.`field_order` `field_order`
      , CASE
            WHEN `t`.`field_type` <> 'divider' THEN CASE
                                                        WHEN `t`.`original_value` = `t`.`current_value` THEN 0
                                                        ELSE 1
                                                    END
            ELSE 1
        END `value_has_changed`
      , `t`.`original_value` `original_value`
      , `t`.`current_value` `current_value`
      , `t`.`field_id` `field_id`
      , `t`.`form_id` `form_id`
      , `t`.`field_type` `field_type`
      , `t`.`field_key` `field_key`
      , `t`.`created_at` `created_at`
      , `t`.`updated_at` `updated_at`
    FROM
        (
            SELECT
                `m`.`item_id` `item_id`
              , `get_page_heading_for_field`( `f`.`form_id` , `f`.`field_order` ) `page_name`
              , `f`.`name` `field_name`
              , `api`.`api_nz`( `m`.`meta_value` , '' ) `current_value`
              , `api`.`api_nz`( `m`.`org_meta_value` , '' ) `original_value`
              , `m`.`field_id` `field_id`
              , `f`.`type` `field_type`
              , `fr`.`name` `form_name`
              , `f`.`field_order` `field_order`
              , `f`.`form_id` `form_id`
              , `f`.`field_key` `field_key`
              , `m`.`created_at` `created_at`
              , `m`.`updated_at` `updated_at`
            FROM
                ((`portal`.`cl_frm_item_metas` `m` JOIN `portal`.`cl_frm_fields` `f` ON (`m`.`field_id` = `f`.`id`))
                    JOIN `portal`.`cl_frm_forms` `fr` ON (`f`.`form_id` = `fr`.`id`))
        ) `t`;

