CREATE DEFINER = root@`%` TRIGGER au_audit_sf_contacts_deletes
    AFTER DELETE
    ON sf_contacts
    FOR EACH ROW
    INSERT INTO `sf`.`sf_contacts_audit`
                 (
                 `auditAction`,
                 `row_id`,
                 `entitytype`,
                 `clientcode`,
                 `clientname`,
                 `fullname`,
                 `ssn`,
                 `contactid`,
                 `contactstatus`,
                 `is_in_wc`,
                 `is_in_cp`,
                 `is_in_bs`,
                 `is_in_en`,
                 `phone`,
                 `email`,
                 `employeeid`,
                 `isprimarycontact`,
                 `created_at`,
                 `created_by`,
                 `updated_at`,
                 `updated_by`
                 )
                 VALUES (
                        'DELETE',
                        OLD.`row_id`,
                        OLD.`entitytype`,
                        OLD.`clientcode`,
                        OLD.`clientname`,
                        OLD.`fullname`,
                        OLD.`ssn`,
                        OLD.`contactid`,
                        OLD.`contactstatus`,
                        OLD.`is_in_wc`,
                        OLD.`is_in_cp`,
                        OLD.`is_in_bs`,
                        OLD.`is_in_en`,
                        OLD.`phone`,
                        OLD.`email`,
                        OLD.`employeeid`,
                        OLD.`isprimarycontact`,
                        OLD.`created_at`,
                        OLD.`created_by`,
                        OLD.`updated_at`,
                        OLD.`updated_by`
                        );

