CREATE
    DEFINER = root@`%` FUNCTION cp_is_active_status(
                                                   p_status varchar(200),
                                                   p_org_status varchar(200) ) RETURNS int
BEGIN
    DECLARE v_ret float DEFAULT 0;
    
    IF api.api_is_blank( p_status ) THEN
        SET v_ret = 0;
    END IF;
    
    SET p_status = upper( p_status );
    
    CASE
        WHEN p_status IN (
                          'ACTIVE',
                          '1')
            THEN
                SET v_ret = 1;
        WHEN p_status IN (
                          'INACTIVE',
                          '0'
            )
            THEN
                SET v_ret = 0;
        ELSE SET v_ret = 0;
    END CASE;
    
    #      if active, check employer is also active
    IF v_ret > 0 THEN
        CASE
            WHEN p_org_status IN (
                              'ACTIVE',
                              '1')
                THEN
                    SET v_ret = v_ret;
            WHEN p_org_status IN (
                              'INACTIVE',
                              '0'
                )
                THEN
                    SET v_ret = 0;
            ELSE SET v_ret = 0;
        END CASE;
    END IF;
    
    RETURN v_ret;

END;

