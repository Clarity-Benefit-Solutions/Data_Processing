CREATE
    DEFINER = sonammehta@`%` FUNCTION get_notification_sub_category_desc(
    p_notification_sub_category_id varchar(255) ) RETURNS varchar(255)
BEGIN
    DECLARE v_ret varchar(255);
    
    IF p_notification_sub_category_id = '' THEN
        RETURN '';
    END IF;

    
    SELECT
        notification_sub_category_desc
    INTO v_ret
    FROM
        api.notification_categories
    WHERE
        notification_sub_category_id = p_notification_sub_category_id
    LIMIT 1;
    
    if api.api_is_blank(v_ret) then
        set v_ret = concat('Invalid Notification Sub-Category ID: ', p_notification_sub_category_id);
    END IF;
    
    RETURN
        v_ret;
END;

