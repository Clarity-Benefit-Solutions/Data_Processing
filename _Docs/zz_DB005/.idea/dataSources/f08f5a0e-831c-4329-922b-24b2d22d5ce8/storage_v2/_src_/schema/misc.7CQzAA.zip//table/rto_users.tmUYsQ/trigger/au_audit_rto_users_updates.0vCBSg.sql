CREATE DEFINER = root@`%` TRIGGER au_audit_rto_users_updates
    AFTER UPDATE
    ON rto_users
    FOR EACH ROW
    INSERT INTO `misc`.`rto_users_audit`
     (`auditAction`,`row_id`,`email`,`role`,`first_name`,`last_name`,`company_name`,`created_date`,`group_id`,`external_id`,`created_at`,`created_by`,`updated_at`,`updated_by`)
  VALUES
     ('UPDATE',NEW.`row_id`,NEW.`email`,NEW.`role`,NEW.`first_name`,NEW.`last_name`,NEW.`company_name`,NEW.`created_date`,NEW.`group_id`,NEW.`external_id`,NEW.`created_at`,NEW.`created_by`,NEW.`updated_at`,NEW.`updated_by`);

