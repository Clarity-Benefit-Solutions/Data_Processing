CREATE
    DEFINER = root@`%` PROCEDURE upsert_case_owner_master(
                                                         IN p_sf_case_owner_user_id varchar(50),
                                                         IN p_sf_case_owner_full_name varchar(100) )
BEGIN
    
    -- handle error that may happen as the table has a few unique keys which may conflict
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO,
                @text = MESSAGE_TEXT;
            SET @text = CONCAT( @text , Concat( '
 Called With Params: ' , 'sf_case_owner_user_id: ' , api.api_nz( `p_sf_case_owner_user_id` , '' ) ,
                                                'sf_case_owner_full_name: ' ,
                                                api.api_nz( `p_sf_case_owner_full_name` , '' ) ) );
            CALL api.db_log_message( 'upsert_case_owner_master' , @text , 'ERROR');
        END;
    
    CALL api.db_log_message( 'upsert_case_owner_master' , Concat( 'Called With Params: ' , 'sf_case_owner_user_id: ' ,
                                                                  api.api_nz( `p_sf_case_owner_user_id` , '' ) ,
                                                                  'sf_case_owner_full_name: ' ,
                                                                  api.api_nz( `p_sf_case_owner_full_name` , '' ) ) ,
                             'WARN' );
    
    INSERT INTO `sf`.`case_owner_master` (
                                         `sf_case_owner_user_id`,
                                         `sf_case_owner_full_name`
    )
    
    VALUES (
           `p_sf_case_owner_user_id`,
           `p_sf_case_owner_full_name`
           )
        
        /* use api_nz to avoid replacing previous value if new value is null or blank */
    ON DUPLICATE KEY
        UPDATE
            `sf_case_owner_user_id`   = api.api_nz( `p_sf_case_owner_user_id` , `sf_case_owner_user_id` ),
            `sf_case_owner_full_name` = api.api_nz( `p_sf_case_owner_full_name` , `sf_case_owner_full_name` );

END;

