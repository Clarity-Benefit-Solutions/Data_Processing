CREATE
    DEFINER = root@`%` PROCEDURE upsert_all_rto_platform_contacts_2(
    IN p_email varchar(200) )
full_proc:

BEGIN
    DECLARE v_email varchar(200);
    DECLARE v_is_active varchar(200);
    DECLARE v_user_type varchar(200);
    
    DECLARE v_row_id varchar(200);
    
    DECLARE v_first_name varchar(200);
    DECLARE v_last_name varchar(200);
    DECLARE v_role varchar(200);
    DECLARE v_company_name varchar(200);
    DECLARE v_created_date varchar(200);
    DECLARE v_group_id varchar(200);
    DECLARE v_external_id varchar(200);
    
    DECLARE v_created_at varchar(200);
    DECLARE v_created_by varchar(200);
    DECLARE v_updated_at varchar(200);
    DECLARE v_updated_by varchar(200);
    
    DECLARE v_finished int;
    DECLARE v_values_cursor CURSOR FOR SELECT
                                           t.email
                                         , t.is_active
                                         , t.user_type
                                         , t.row_id
                                         , t.role
                                         , t.first_name
                                         , t.last_name
                                         , t.company_name
                                         , t.created_date
                                         , t.group_id
                                         , t.external_id
                                         , t.created_at
                                         , t.created_by
                                         , t.updated_at
                                         , t.updated_by
                                       FROM
                                           misc.vw_rto_users t
                                       WHERE
                                           email = p_email
                                       ORDER BY
                                           email
                                         , user_type DESC
                                         , is_active DESC
                                       LIMIT 1;
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND BEGIN
        SET v_finished = 1;
    END;
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN
        GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
        CALL db_throw_error( @errno , 'upsert_all_rto_platform_contacts_1' , @text );
    END;
    
    SET @@max_sp_recursion_depth = 12;
    
    OPEN v_values_cursor;
    
    getvalues
    :
    LOOP
        FETCH v_values_cursor INTO v_email , v_is_active , v_user_type , v_row_id , v_role , v_first_name , v_last_name , v_company_name , v_created_date , v_group_id , v_external_id , v_created_at , v_created_by , v_updated_at , v_updated_by;
        
        IF v_finished = 1 THEN
            LEAVE getvalues;
        END IF;
        
        IF !api.api_is_blank( v_email ) THEN
            CALL api.db_log_message( 'upsert_all_rto_platform_contacts_2' ,
                                     CONCAT( 'Processing RTO user for email: ' , p_email ,
                                             ' using record with row_id  ' , v_row_id , ' and user_type ' ,
                                             v_user_type ) , 'WARN' );
            
            CALL api.upsert_rto_platform_user( v_email , v_email , v_row_id , v_is_active , v_user_type );
        END IF;
    END LOOP getvalues;
END;

