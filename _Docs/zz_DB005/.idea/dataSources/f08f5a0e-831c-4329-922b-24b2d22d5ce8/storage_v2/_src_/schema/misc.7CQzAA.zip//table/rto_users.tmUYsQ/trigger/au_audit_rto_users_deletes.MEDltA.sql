CREATE DEFINER = root@`%` TRIGGER au_audit_rto_users_deletes
    AFTER DELETE
    ON rto_users
    FOR EACH ROW
    INSERT INTO `misc`.`rto_users_audit`
     (`auditAction`,`row_id`,`email`,`role`,`first_name`,`last_name`,`company_name`,`created_date`,`group_id`,`external_id`,`created_at`,`created_by`,`updated_at`,`updated_by`)
  VALUES
     ('DELETE',OLD.`row_id`,OLD.`email`,OLD.`role`,OLD.`first_name`,OLD.`last_name`,OLD.`company_name`,OLD.`created_date`,OLD.`group_id`,OLD.`external_id`,OLD.`created_at`,OLD.`created_by`,OLD.`updated_at`,OLD.`updated_by`);

