CREATE DEFINER = root@`%` TRIGGER util_bi_sf_account_plans_set_updated_at_and_by
    BEFORE INSERT
    ON sf_account_plans
    FOR EACH ROW
BEGIN
#
#     SET new.planstartdate = api.api_cdate( new.planstartdate );
#     SET new.planenddate = api.api_cdate( new.planenddate );
    /*
    IF POSITION( '-' IN new.planstartdate ) <= 0 AND NOT api.api_is_blank( new.planstartdate ) THEN
        SET new.planstartdate =
                CONCAT( SUBSTR( new.planstartdate , 1 , 4 ) , '-' , SUBSTR( new.planstartdate , 5 , 2 ) , '-' ,
                        SUBSTR( new.planstartdate , 7 , 2 ) );
    END IF;
    IF POSITION( '-' IN new.planenddate ) <= 0 AND NOT api.api_is_blank( new.planenddate ) THEN
        SET new.planenddate =
                CONCAT( SUBSTR( new.planenddate , 1 , 4 ) , '-' , SUBSTR( new.planenddate , 5 , 2 ) , '-' ,
                        SUBSTR( new.planenddate , 7 , 2 ) );
    END IF;*/
     SET new.clientcode = api.api_nz2( new.clientcode );
    SET new.platform = api.api_nz2( new.platform );
    SET new.planid = api.api_nz2( new.planid );
    SET new.planstartdate = api.api_nz2( new.planstartdate );
    SET new.planenddate = api.api_nz2( new.planenddate );
  
END;

