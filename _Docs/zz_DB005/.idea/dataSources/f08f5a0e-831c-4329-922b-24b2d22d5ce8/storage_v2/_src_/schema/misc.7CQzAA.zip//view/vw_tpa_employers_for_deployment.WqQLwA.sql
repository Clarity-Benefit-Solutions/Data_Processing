CREATE VIEW vw_tpa_employers_for_deployment
AS
    SELECT
        `misc`.`tpa_employers_for_deployment`.`row_id` `row_id`
      , `misc`.`tpa_employers_for_deployment`.`tpa_id` `tpa_id`
      , `misc`.`tpa_employers_for_deployment`.`name` `name`
      , `misc`.`tpa_employers_for_deployment`.`status` `status`
      , `misc`.`tpa_employers_for_deployment`.`import_name` `import_name`
      , `misc`.`tpa_employers_for_deployment`.`account_id` `account_id`
      , `misc`.`tpa_employers_for_deployment`.`start_date` `start_date`
      , `misc`.`tpa_employers_for_deployment`.`end_date` `end_date`
      , `misc`.`tpa_employers_for_deployment`.`alegeus_key` `alegeus_key`
      , `misc`.`tpa_employers_for_deployment`.`import_alegeus_key` `import_alegeus_key`
      , `misc`.`tpa_employers_for_deployment`.`updated_by` `updated_by`
      , `misc`.`tpa_employers_for_deployment`.`created_at` `created_at`
      , `misc`.`tpa_employers_for_deployment`.`created_by` `created_by`
      , `misc`.`tpa_employers_for_deployment`.`updated_at` `updated_at`
    FROM
        `misc`.`tpa_employers_for_deployment`
    WHERE
          !(`misc`.`tpa_employers_for_deployment`.`tpa_id` IN (
                                                                  SELECT
                                                                      `m`.`tpa_id`
                                                                  FROM
                                                                      ((`misc`.`tpa_participant_policies` `n` JOIN `misc`.`tpa_participants` `r` ON (`n`.`tpa_employee_id` = `r`.`tpa_employee_id`))
                                                                          JOIN `misc`.`tpa_employers` `m` ON (`m`.`tpa_id` = `r`.`tpa_employer_id`))
                                                                  WHERE
                                                                       `n`.`payer_name` LIKE 'UnitedHealthCare'
                                                                    OR `n`.`payer_name` LIKE 'oxford%'
                                                              ))
      AND `misc`.`tpa_employers_for_deployment`.`status` = 'active';

