CREATE DEFINER = admin@`%` TRIGGER util_bi_cl_frm_items_keep_save_draft_always
    BEFORE INSERT
    ON cl_frm_items
    FOR EACH ROW
BEGIN
    SET new.is_draft = 1;
END;

