CREATE VIEW vw_product_plans
AS
    SELECT
        `c`.`email` `email`
      , `c`.`isprimarycontact` `isprimarycontact`
      , `c`.`is_in_en` `is_in_en`
      , `c`.`is_in_bs` `is_in_bs`
      , `c`.`is_in_cp` `is_in_cp`
      , `c`.`is_in_wc` `is_in_wc`
      , `p`.`row_id` `row_id`
      , `p`.`clientcode` `clientcode`
      , `p`.`clientname` `clientname`
      , `p`.`planid` `planid`
      , `p`.`plantype` `plantype`
      , `p`.`planyear` `planyear`
      , `p`.`planstartdate` `planstartdate`
      , `p`.`planenddate` `planenddate`
      , `p`.`platform` `platform`
      , `p`.`uniquebenandplan` `uniquebenandplan`
      , `p`.`product2id` `product2id`
      , `p`.`productcode` `productcode`
      , `p`.`portaldesc` `portaldesc`
      , `p`.`productstatus` `productstatus`
      , `p`.`productdescription` `productdescription`
      , `p`.`graceperiodenddate` `graceperiodenddate`
      , `p`.`runoutenddate` `runoutenddate`
      , `p`.`mostfuturedate` `mostfuturedate`
      , `p`.`donotshowonportal` `donotshowonportal`
      , `p`.`enddateplusone` `enddateplusone`
      , `p`.`minimumelection` `minimumelection`
      , `p`.`maximumelection` `maximumelection`
      , `p`.`runoutdatefortermedemp` `runoutdatefortermedemp`
      , `p`.`created_at` `created_at`
      , `p`.`created_by` `created_by`
      , `p`.`updated_at` `updated_at`
      , `p`.`updated_by` `updated_by`
    FROM
        (`sf`.`sf_contacts` `c`
            JOIN `sf`.`sf_account_plans` `p` ON (`c`.`clientcode` = `p`.`clientcode`))
    WHERE
          `c`.`isprimarycontact` = 1
      AND `p`.`productstatus` = 'Current'
    ORDER BY
        `c`.`email`
      , `p`.`clientcode`
      , `p`.`planyear`
      , `p`.`productdescription`;

