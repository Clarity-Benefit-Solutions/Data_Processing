CREATE
    DEFINER = root@`%` PROCEDURE upsert_sf_account_plans(
                                                        IN p_clientcode varchar(75),
                                                        IN p_clientname varchar(75),
                                                        IN p_planid varchar(75),
                                                        IN p_plantype varchar(75),
                                                        IN p_planyear varchar(75),
                                                        IN p_planstartdate varchar(50),
                                                        IN p_planenddate varchar(50),
                                                        IN p_platform varchar(75),
                                                        IN p_uniquebenandplan varchar(75),
                                                        IN p_product2id varchar(75),
                                                        IN p_productcode varchar(75),
                                                        IN p_portaldesc varchar(75),
                                                        IN p_productstatus varchar(75),
                                                        IN p_productdescription varchar(75),
                                                        IN p_graceperiodenddate varchar(75),
                                                        IN p_runoutenddate varchar(75),
                                                        IN p_mostfuturedate varchar(75),
                                                        IN p_donotshowonportal varchar(75),
                                                        IN p_enddateplusone varchar(75),
                                                        IN p_minimumelection varchar(75),
                                                        IN p_maximumelection varchar(75),
                                                        IN p_runoutdatefortermedemp varchar(75),
                                                        IN p_rewardamount varchar(75) )
BEGIN
    
    -- handle error that may happen as the table has a few unique keys which may conflict
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            GET DIAGNOSTICS CONDITION 1 @SQLSTATE = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO,
                @TEXT = MESSAGE_TEXT;
            SET @TEXT = CONCAT( @TEXT , CONCAT( '
Called With Params: ' , ', clientcode: ' , api.api_nz( `p_clientcode` , '' ) , ', clientname: ' ,
                                                api.api_nz( `p_clientname` , '' ) , ', planid: ' ,
                                                api.api_nz( `p_planid` , '' ) , ', plantype: ' ,
                                                api.api_nz( `p_plantype` , '' ) , ', planyear: ' ,
                                                api.api_nz( `p_planyear` , '' ) , ', planstartdate: ' ,
                                                api.api_nz( `p_planstartdate` , '' ) , ', planenddate: ' ,
                                                api.api_nz( `p_planenddate` , '' ) , ', platform: ' ,
                                                api.api_nz( `p_platform` , '' ) , ', uniquebenandplan: ' ,
                                                api.api_nz( `p_uniquebenandplan` , '' ) , ', product2id: ' ,
                                                api.api_nz( `p_product2id` , '' ) , ', productcode: ' ,
                                                api.api_nz( `p_productcode` , '' ) , ', portaldesc: ' ,
                                                api.api_nz( `p_portaldesc` , '' ) , ', productstatus: ' ,
                                                api.api_nz( `p_productstatus` , '' ) , ', productdescription: ' ,
                                                api.api_nz( `p_productdescription` , '' ) , ', graceperiodenddate: ' ,
                                                api.api_nz( `p_graceperiodenddate` , '' ) , ', runoutenddate: ' ,
                                                api.api_nz( `p_runoutenddate` , '' ) , ', mostfuturedate: ' ,
                                                api.api_nz( `p_mostfuturedate` , '' ) , ', donotshowonportal: ' ,
                                                api.api_nz( `p_donotshowonportal` , '' ) , ', enddateplusone: ' ,
                                                api.api_nz( `p_enddateplusone` , '' ) , ', minimumelection: ' ,
                                                api.api_nz( `p_minimumelection` , '' ) , ', maximumelection: ' ,
                                                api.api_nz( `p_maximumelection` , '' ) , ', runoutdatefortermedemp: ' ,
                                                api.api_nz( `p_runoutdatefortermedemp` , '' ) ,
                                                ', rewardamount: ' , api.api_nz( `p_rewardamount` , '' )
                )
                );
            CALL api.db_log_message( 'upsert_sf_account_plans' , @TEXT , 'ERROR');
        END;
    
    CALL api.db_log_message( 'upsert_sf_account_plans' ,
                             CONCAT( 'Called With Params: ' , ', clientcode: ' , api.api_nz( `p_clientcode` , '' ) ,
                                     ', clientname: ' , api.api_nz( `p_clientname` , '' ) , ', planid: ' ,
                                     api.api_nz( `p_planid` , '' ) , ', plantype: ' , api.api_nz( `p_plantype` , '' ) ,
                                     ', planyear: ' , api.api_nz( `p_planyear` , '' ) , ', planstartdate: ' ,
                                     api.api_nz( `p_planstartdate` , '' ) , ', planenddate: ' ,
                                     api.api_nz( `p_planenddate` , '' ) , ', platform: ' ,
                                     api.api_nz( `p_platform` , '' ) , ', uniquebenandplan: ' ,
                                     api.api_nz( `p_uniquebenandplan` , '' ) , ', product2id: ' ,
                                     api.api_nz( `p_product2id` , '' ) , ', productcode: ' ,
                                     api.api_nz( `p_productcode` , '' ) , ', portaldesc: ' ,
                                     api.api_nz( `p_portaldesc` , '' ) , ', productstatus: ' ,
                                     api.api_nz( `p_productstatus` , '' ) , ', productdescription: ' ,
                                     api.api_nz( `p_productdescription` , '' ) , ', graceperiodenddate: ' ,
                                     api.api_nz( `p_graceperiodenddate` , '' ) , ', runoutenddate: ' ,
                                     api.api_nz( `p_runoutenddate` , '' ) , ', mostfuturedate: ' ,
                                     api.api_nz( `p_mostfuturedate` , '' ) , ', donotshowonportal: ' ,
                                     api.api_nz( `p_donotshowonportal` , '' ) , ', enddateplusone: ' ,
                                     api.api_nz( `p_enddateplusone` , '' ) , ', minimumelection: ' ,
                                     api.api_nz( `p_minimumelection` , '' ) , ', maximumelection: ' ,
                                     api.api_nz( `p_maximumelection` , '' ) , ', runoutdatefortermedemp: ' ,
                                     api.api_nz( `p_runoutdatefortermedemp` , '' ) , ', rewardamount: ' ,
                                     api.api_nz( `p_rewardamount` , '' ) ) , 'WARN' );
    
    SET p_planstartdate = api.api_cdate( p_planstartdate );
    SET p_planenddate = api.api_cdate( p_planenddate );
    SET p_rewardamount = api.api_cfloat( p_rewardamount );
    
    /* sumeet: update sf_account.if_* based on plan_type and start date*/
    IF p_plantype IN ('U21') THEN
        UPDATE sf.sf_accounts
        SET
            if_client_is_active         = 1,
            if_client_active_start_date = CASE
                                              WHEN if_client_active_start_date < p_planstartdate
                                                  THEN if_client_active_start_date
                                              ELSE p_planstartdate
                                          END,
            if_client_active_end_date   = CASE
                                              WHEN if_client_active_end_date > p_planenddate
                                                  THEN if_client_active_end_date
                                              ELSE p_planenddate
                                          END
        WHERE
            clientcode = p_clientcode;
    END IF;
    
    INSERT INTO `sf`.`sf_account_plans` (
                                        `clientcode`,
                                        `clientname`,
                                        `planid`,
                                        `plantype`,
                                        `planyear`,
                                        `planstartdate`,
                                        `planenddate`,
                                        `platform`,
                                        `uniquebenandplan`,
                                        `product2id`,
                                        `productcode`,
                                        `portaldesc`,
                                        `productstatus`,
                                        `productdescription`,
                                        `graceperiodenddate`,
                                        `runoutenddate`,
                                        `mostfuturedate`,
                                        `donotshowonportal`,
                                        `enddateplusone`,
                                        `minimumelection`,
                                        `maximumelection`,
                                        `runoutdatefortermedemp`,
                                        rewardamount
    )
    
    VALUES (
           `p_clientcode`,
           `p_clientname`,
           `p_planid`,
           `p_plantype`,
           `p_planyear`,
           `p_planstartdate`,
           `p_planenddate`,
           `p_platform`,
           `p_uniquebenandplan`,
           `p_product2id`,
           `p_productcode`,
           `p_portaldesc`,
           `p_productstatus`,
           `p_productdescription`,
           `p_graceperiodenddate`,
           `p_runoutenddate`,
           `p_mostfuturedate`,
           `p_donotshowonportal`,
           `p_enddateplusone`,
           `p_minimumelection`,
           `p_maximumelection`,
           `p_runoutdatefortermedemp`,
           p_rewardamount
           )
        
        /* use api_nz to avoid replacing previous value if new value is null or blank */
    ON DUPLICATE KEY
        UPDATE
            `clientcode`             = api.api_nz( `p_clientcode` , `clientcode` ),
            `clientname`             = api.api_nz( `p_clientname` , `clientname` ),
            `planid`                 = api.api_nz( `p_planid` , `planid` ),
            `plantype`               = api.api_nz( `p_plantype` , `plantype` ),
            `planyear`               = api.api_nz( `p_planyear` , `planyear` ),
            `planstartdate`          = api.api_nz( `p_planstartdate` , `planstartdate` ),
            `planenddate`            = api.api_nz( `p_planenddate` , `planenddate` ),
            `platform`               = api.api_nz( `p_platform` , `platform` ),
            `uniquebenandplan`       = api.api_nz( `p_uniquebenandplan` , `uniquebenandplan` ),
            `product2id`             = api.api_nz( `p_product2id` , `product2id` ),
            `productcode`            = api.api_nz( `p_productcode` , `productcode` ),
            `portaldesc`             = api.api_nz( `p_portaldesc` , `portaldesc` ),
            `productstatus`          = api.api_nz( `p_productstatus` , `productstatus` ),
            `productdescription`     = api.api_nz( `p_productdescription` , `productdescription` ),
            `graceperiodenddate`     = api.api_nz( `p_graceperiodenddate` , `graceperiodenddate` ),
            `runoutenddate`          = api.api_nz( `p_runoutenddate` , `runoutenddate` ),
            `mostfuturedate`         = api.api_nz( `p_mostfuturedate` , `mostfuturedate` ),
            `donotshowonportal`      = api.api_nz( `p_donotshowonportal` , `donotshowonportal` ),
            `enddateplusone`         = api.api_nz( `p_enddateplusone` , `enddateplusone` ),
            `minimumelection`        = api.api_nz( `p_minimumelection` , `minimumelection` ),
            `maximumelection`        = api.api_nz( `p_maximumelection` , `maximumelection` ),
            `runoutdatefortermedemp` = api.api_nz( `p_runoutdatefortermedemp` , `runoutdatefortermedemp` ),
            rewardamount             = api.api_nz( `p_rewardamount` , `rewardamount` );

END;

