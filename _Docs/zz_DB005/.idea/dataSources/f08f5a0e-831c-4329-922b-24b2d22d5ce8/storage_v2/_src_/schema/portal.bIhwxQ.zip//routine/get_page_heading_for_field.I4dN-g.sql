CREATE
    DEFINER = admin@`%` FUNCTION get_page_heading_for_field(
                                                           p_form_id int,
                                                           p_field_order int ) RETURNS varchar(1000)
BEGIN

    DECLARE v_page_heading varchar(1000);

    SELECT name
    INTO v_page_heading
    FROM portal.cl_frm_fields
    WHERE form_id = p_form_id
      AND field_order <= p_field_order
#       AND `type` LIKE 'html'
      AND (`description` LIKE '%page-heading%' OR `name` LIKE '%page-heading%')
      AND !api.api_is_blank(name)
    ORDER BY field_order DESC
    LIMIT 1;

    return v_page_heading;

    RETURN api.api_nz(v_page_heading, '');

END;

