CREATE VIEW vw_wc_participants
AS
    SELECT
        `wc`.`wc_participants`.`email` `email`
      , `wc_is_active_status`( `wc`.`wc_participants`.`employeestatus` , `wc`.`wc_participants`.`employeeid` ,
                               `wc`.`wc_participants`.`employerid` ) `is_active`
      , `wc_is_active_status_employer`( `wc`.`wc_participants`.`employerid` ) `is_active_employer`
      , `if_is_active_status`( `wc`.`wc_participants`.`employeestatus` , `wc`.`wc_participants`.`employeeid` ,
                               `wc`.`wc_participants`.`employerid` ) `if_is_active`
      , `if_is_active_status_employer`( `wc`.`wc_participants`.`employerid` ) `if_is_active_employer`
      , `if_reward_amount`( `wc`.`wc_participants`.`employerid` ) `if_reward_amount`
      , '00 EMPLOYEE ' `user_type`
      , `wc`.`wc_participants`.`row_id` `row_id`
      , `wc`.`wc_participants`.`employeeid` `employeeid`
      , `wc`.`wc_participants`.`recordid` `recordid`
      , `wc`.`wc_participants`.`tpaid` `tpaid`
      , `wc`.`wc_participants`.`employername` `employername`
      , `wc`.`wc_participants`.`employerid` `employerid`
      , `wc`.`wc_participants`.`lastname` `lastname`
      , `wc`.`wc_participants`.`firstname` `firstname`
      , `wc`.`wc_participants`.`phone` `phone`
      , `wc`.`wc_participants`.`addressline1` `addressline1`
      , `wc`.`wc_participants`.`addressline2` `addressline2`
      , `wc`.`wc_participants`.`city` `city`
      , `wc`.`wc_participants`.`state` `state`
      , `wc`.`wc_participants`.`zip` `zip`
      , `wc`.`wc_participants`.`country` `country`
      , `wc`.`wc_participants`.`employeestatus` `employeestatus`
      , `wc`.`wc_participants`.`reimbursementmethod` `reimbursementmethod`
      , `wc`.`wc_participants`.`birthdate` `birthdate`
      , `wc`.`wc_participants`.`employeessn` `employeessn`
      , `wc`.`wc_participants`.`cardnumber` `cardnumber`
      , `wc`.`wc_participants`.`mobilenumber` `mobilenumber`
      , `wc`.`wc_participants`.`created_at` `created_at`
      , `wc`.`wc_participants`.`created_by` `created_by`
      , `wc`.`wc_participants`.`updated_at` `updated_at`
      , `wc`.`wc_participants`.`updated_by` `updated_by`
      , `wc`.`wc_participants`.`is_used_for_registration` `is_used_for_registration`
    FROM
        `wc`.`wc_participants`
    WHERE
          !`api`.`upsert_ignore_this_email`( `wc`.`wc_participants`.`email` , 'wcp' )
      AND !`api`.`upsert_ignore_this_employer_id`( `wc`.`wc_participants`.`employerid` , 'wcp' );

