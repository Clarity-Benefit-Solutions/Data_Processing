CREATE
    DEFINER = root@`%` FUNCTION if_is_active_status_employer(
    p_employer_id varchar(200) ) RETURNS float
BEGIN
    DECLARE v_ret float DEFAULT 0;
    DECLARE v_status int DEFAULT 0;
    DECLARE v_active_start_date datetime DEFAULT NULL;
    DECLARE v_active_end_date datetime DEFAULT NULL;
    
    SELECT
        api.api_nz_int( if_client_is_active , 0 )
      , if_client_active_start_date
      , if_client_active_end_date
    INTO v_status, v_active_start_date, v_active_end_date
    FROM
        sf.sf_accounts
    WHERE
        clientcode = p_employer_id
    LIMIT 1;
    
    IF api.api_nz_int( v_status , 0 ) > 0 AND
       (v_active_start_date IS NULL OR DATEDIFF( DATE( SYSDATE( ) ) , v_active_start_date ) >= 2)
        /*AND
        (v_active_end_date IS NULL OR DATE( v_active_end_date ) >= SYSDATE( ) )*/
    THEN
        RETURN 1;
    ELSE
        RETURN 0;
    END IF;

END;

