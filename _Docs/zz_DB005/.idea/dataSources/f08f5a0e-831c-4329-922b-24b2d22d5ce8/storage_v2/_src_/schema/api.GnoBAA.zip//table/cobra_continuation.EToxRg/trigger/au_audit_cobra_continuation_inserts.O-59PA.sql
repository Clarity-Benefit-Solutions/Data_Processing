CREATE DEFINER = root@`%` TRIGGER au_audit_cobra_continuation_inserts
    AFTER INSERT
    ON cobra_continuation
    FOR EACH ROW
    INSERT INTO `api`.`cobra_continuation_audit`
                 (
                 `auditAction`,
                 `cobra_continuation_id`,
                 `status`,
                 `continuation_type`,
                 `memberid`,
                 `brokerid`,
                 `clientid`,
                 `employerid`,
                 `clientname`,
                 `salutation`,
                 `firstname`,
                 `lastname`,
                 `email`,
                 `ssn`,
                 `dob`,
                 `phone`,
                 `cobra_event_date`,
                 `cobra_last_day_of_coverage`,
                 `event_type`,
                 `ae_2021_is_eligible`,
                 `submitted_on`,
                 `submitted_by`,
                 `uploaded_on`,
                 `created_at`,
                 `created_by`,
                 `updated_at`,
                 `updated_by`
                 )
                 VALUES (
                        'INSERT',
                        NEW.`cobra_continuation_id`,
                        NEW.`status`,
                        NEW.`continuation_type`,
                        NEW.`memberid`,
                        NEW.`brokerid`,
                        NEW.`clientid`,
                        NEW.`employerid`,
                        NEW.`clientname`,
                        NEW.`salutation`,
                        NEW.`firstname`,
                        NEW.`lastname`,
                        NEW.`email`,
                        NEW.`ssn`,
                        NEW.`dob`,
                        NEW.`phone`,
                        NEW.`cobra_event_date`,
                        NEW.`cobra_last_day_of_coverage`,
                        NEW.`event_type`,
                        NEW.`ae_2021_is_eligible`,
                        NEW.`submitted_on`,
                        NEW.`submitted_by`,
                        NEW.`uploaded_on`,
                        NEW.`created_at`,
                        NEW.`created_by`,
                        NEW.`updated_at`,
                        NEW.`updated_by`
                        );

