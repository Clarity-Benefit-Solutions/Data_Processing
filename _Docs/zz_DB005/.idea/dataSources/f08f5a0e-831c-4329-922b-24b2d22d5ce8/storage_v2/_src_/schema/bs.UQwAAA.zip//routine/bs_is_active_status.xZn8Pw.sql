CREATE
    DEFINER = admin@`%` FUNCTION bs_is_active_status(
    p_status varchar(200) ) RETURNS int
BEGIN
    IF api.api_is_blank( p_status ) THEN
        RETURN 1;
    END IF;

    SET p_status = upper( p_status );

    CASE
        WHEN p_status IN (
                           'ACTIVE',
                           'NEW',
                           'TEMPORARILY INACTIVE',
                           'TI', '1' )
            THEN
                RETURN 1;
        WHEN p_status IN (
                           'PERMANENTLY INACTIVE',
                           'INACTIVE',
                           'PI', '0'
            )
            THEN
                RETURN 0;
        ELSE RETURN 0;
        END CASE;

END;

