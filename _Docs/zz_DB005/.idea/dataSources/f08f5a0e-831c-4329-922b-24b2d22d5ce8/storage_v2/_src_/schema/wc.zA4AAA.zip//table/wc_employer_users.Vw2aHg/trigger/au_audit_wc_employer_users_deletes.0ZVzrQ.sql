CREATE DEFINER = root@`%` TRIGGER au_audit_wc_employer_users_deletes
    AFTER DELETE
    ON wc_employer_users
    FOR EACH ROW
    INSERT INTO `wc`.`wc_employer_users_audit`
                 (
                 `auditAction`,
                 `row_id`,
                 `employer_id`,
                 `first_name`,
                 `last_name`,
                 `allow_get_current_sessions`,
                 `allow_to_uplod_a_payroll_file`,
                 `email`,
                 `middle_initial`,
                 `name_prefix`,
                 `phone`,
                 `profile_name`,
                 `status`,
                 `tpa_id`,
                 `user_id`,
                 `created_at`,
                 `created_by`,
                 `updated_at`,
                 `updated_by`
                 )
                 VALUES (
                        'DELETE',
                        OLD.`row_id`,
                        OLD.`employer_id`,
                        OLD.`first_name`,
                        OLD.`last_name`,
                        OLD.`allow_get_current_sessions`,
                        OLD.`allow_to_uplod_a_payroll_file`,
                        OLD.`email`,
                        OLD.`middle_initial`,
                        OLD.`name_prefix`,
                        OLD.`phone`,
                        OLD.`profile_name`,
                        OLD.`status`,
                        OLD.`tpa_id`,
                        OLD.`user_id`,
                        OLD.`created_at`,
                        OLD.`created_by`,
                        OLD.`updated_at`,
                        OLD.`updated_by`
                        );

