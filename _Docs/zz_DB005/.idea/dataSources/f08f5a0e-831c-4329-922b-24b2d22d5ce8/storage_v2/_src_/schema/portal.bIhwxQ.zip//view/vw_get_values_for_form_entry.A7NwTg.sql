CREATE VIEW vw_get_values_for_form_entry
AS
    SELECT
        `v`.`item_id` `item_id`
      , `f`.`form_id` `form_id`
      , `f`.`form_name` `form_name`
      , `v`.`page_name` `page_name`
      , `f`.`field_order` `field_order`
      , `f`.`field_name` `field_name`
      , `f`.`repeater_name` `repeater_name`
      , `v`.`value_has_changed` `value_has_changed`
      , `v`.`current_value` `current_value`
      , `v`.`original_value` `original_value`
      , `f`.`field_key` `field_key`
      , `f`.`field_id` `field_id`
      , `v`.`field_type` `field_type`
      , `v`.`created_at` `created_at`
      , `v`.`updated_at` `updated_at`
    FROM
        (`portal`.`vw_get_all_fields_for_form` `f`
            LEFT JOIN `portal`.`vw_get_meta_values` `v` ON (`f`.`field_id` = `v`.`field_id`))
    ORDER BY
        `f`.`form_id`
      , `f`.`field_order`;

