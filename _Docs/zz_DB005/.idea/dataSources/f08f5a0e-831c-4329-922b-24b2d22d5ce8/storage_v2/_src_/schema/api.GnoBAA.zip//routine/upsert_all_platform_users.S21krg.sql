CREATE
    DEFINER = root@`%` PROCEDURE upsert_all_platform_users(
    IN p_only_emails_like varchar(200) )
full_proc:

BEGIN
    DECLARE v_email varchar(200) DEFAULT NULL;
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN
        GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
        CALL db_throw_error( @errno , 'upsert_all_platform_users' , @text );
    END;
    
    SET @@max_sp_recursion_depth = 12;
    
    IF p_only_emails_like = 'xxx' THEN
        SET p_only_emails_like = '%';
    END IF;
    
    SET p_only_emails_like = api.api_nz( p_only_emails_like , '%' );
    #      sumeet: 2021-03-16: we are modifying upsert all logic so dont upsert to platform users till logic is changed
    
    CALL api.db_log_message( 'upsert_all_platform_users' ,
                             CONCAT( ' STARTING ------------------ ' , 'Processing for Emails like : ' ,
                                     p_only_emails_like , ' ------------------' ) , 'WARN' );
    
    /* BILLTRUST ALL users */
    CALL api.upsert_all_bt_platform_contacts_1( p_only_emails_like );
    
    /**/
    CALL api.db_log_message( 'upsert_all_platform_users' ,
                             CONCAT( 'FINISHED  upsert_all_bt_platform_contacts_1 ' , 'Processing for Emails like : ' ,
                                     p_only_emails_like , ' ------------------' ) , 'WARN' );
    /* RTO ALL users */
    CALL api.upsert_all_rto_platform_contacts_1( p_only_emails_like );
    
    /**/
    CALL api.db_log_message( 'upsert_all_platform_users' ,
                             CONCAT( 'FINISHED  upsert_all_rto_platform_contacts_1 ' , 'Processing for Emails like : ' ,
                                     p_only_emails_like , ' ------------------' ) , 'WARN' );
    /* EN All */
    CALL api.upsert_all_en_platform_contacts_1( p_only_emails_like );
    
    /**/
    CALL api.db_log_message( 'upsert_all_platform_users' ,
                             CONCAT( 'FINISHED  upsert_all_en_platform_contacts_1 ' , 'Processing for Emails like : ' ,
                                     p_only_emails_like , ' ------------------' ) , 'WARN' );
    /* wc employer users */
    CALL api.upsert_all_wc_platform_employer_users_1( p_only_emails_like );
    
    /**/
    CALL api.db_log_message( 'upsert_all_platform_users' ,
                             CONCAT( 'FINISHED  upsert_all_wc_platform_employer_users_1 ' ,
                                     'Processing for Emails like : ' ,
                                     p_only_emails_like , ' ------------------' ) , 'WARN' );
    /* cp ALL */
    CALL api.upsert_all_cp_platform_users_1( p_only_emails_like );
    
    /**/
    CALL api.db_log_message( 'upsert_all_platform_users' ,
                             CONCAT( 'FINISHED  upsert_all_cp_platform_users_1 ' , 'Processing for Emails like : ' ,
                                     p_only_emails_like , ' ------------------' ) , 'WARN' );
    /* bs ALL */
    CALL api.upsert_all_bs_platform_contacts_1( p_only_emails_like );
    
    /**/
    CALL api.db_log_message( 'upsert_all_platform_users' ,
                             CONCAT( 'FINISHED  upsert_all_bs_platform_contacts_1 ' , 'Processing for Emails like : ' ,
                                     p_only_emails_like , ' ------------------' ) , 'WARN' );
    /* sf ALL users */
    CALL api.upsert_all_sf_platform_contacts_1( p_only_emails_like );
    
    /**/
    CALL api.db_log_message( 'upsert_all_platform_users' ,
                             CONCAT( 'FINISHED  upsert_all_sf_platform_contacts_1 ' , 'Processing for Emails like : ' ,
                                     p_only_emails_like , ' ------------------' ) , 'WARN' );
    /* wc participants */
    CALL api.upsert_all_wc_platform_participant_users_1( p_only_emails_like );
    
    /**/
    CALL api.db_log_message( 'upsert_all_platform_users' ,
                             CONCAT( 'FINISHED  upsert_all_wc_platform_participant_users_1 ' ,
                                     'Processing for Emails like : ' ,
                                     p_only_emails_like , ' ------------------' ) , 'WARN' );
    
    # sumeet: 2021-08-11 commented as it is called by API after getting all users from TPAStream via Rest api
    #     /* tpa stream ALL users */
    #     CALL api.upsert_all_ts_platform_employees_1( p_only_emails_like );
    #     /**/
    #     CALL api.db_log_message( 'upsert_all_platform_users' ,
    #                              CONCAT( 'FINISHED  upsert_all_ts_platform_employees_1 ' , 'Processing for Emails like : ' ,
    #                                      p_only_emails_like , ' ------------------' ) , 'WARN' );
    #     /**/
    CALL api.db_log_message( 'upsert_all_platform_users' ,
                             CONCAT( 'FINISHED  ------------------ ' , 'Processing for Emails like : ' ,
                                     p_only_emails_like , ' ------------------' ) , 'WARN' );

END;

