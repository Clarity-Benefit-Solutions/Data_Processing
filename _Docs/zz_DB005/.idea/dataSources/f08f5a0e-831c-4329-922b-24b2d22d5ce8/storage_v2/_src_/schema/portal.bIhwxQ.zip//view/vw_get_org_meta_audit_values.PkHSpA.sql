CREATE VIEW vw_get_org_meta_audit_values
AS
    SELECT
        `m`.`item_id` `item_id`
      , `m`.`field_id` `field_id`
      , `api`.`api_nz`( `m`.`meta_value` , '' ) `current_value`
      , `api`.`api_nz`( `m`.`org_meta_value` , '' ) `original_value`
      , `m`.`created_at` `created_at`
      , `m`.`updated_at` `updated_at`
    FROM
        `portal`.`cl_frm_item_metas_audit` `m`
    WHERE
        `m`.`auditAction` = 'INSERT';

