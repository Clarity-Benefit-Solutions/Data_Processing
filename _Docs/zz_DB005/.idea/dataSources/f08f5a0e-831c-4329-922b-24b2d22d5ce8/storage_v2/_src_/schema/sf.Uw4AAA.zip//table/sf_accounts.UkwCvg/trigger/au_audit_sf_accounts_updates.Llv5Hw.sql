CREATE DEFINER = root@`%` TRIGGER au_audit_sf_accounts_updates
    AFTER UPDATE
    ON sf_accounts
    FOR EACH ROW
    INSERT INTO `sf`.`sf_accounts_audit`
                 (
                 `auditAction`,
                 `row_id`,
                 `clientcode`,
                 `clientname`,
                 `clientstatus`,
                 `clienttype`,
                 `created_at`,
                 `created_by`,
                 `updated_at`,
                 `updated_by`,
                 `if_client_is_active`,
                 `if_client_active_start_date`
                 )
                 VALUES (
                        'UPDATE',
                        NEW.`row_id`,
                        NEW.`clientcode`,
                        NEW.`clientname`,
                        NEW.`clientstatus`,
                        NEW.`clienttype`,
                        NEW.`created_at`,
                        NEW.`created_by`,
                        NEW.`updated_at`,
                        NEW.`updated_by`,
                        NEW.`if_client_is_active`,
                        NEW.`if_client_active_start_date`
                        );

