CREATE VIEW vw_get_all_current_and_original_form_values
AS
    SELECT
        `t`.`item_id` `item_id`
      , `t`.`page_name` `page_name`
      , CASE
            WHEN `t`.`field_type` = 'divider' THEN `t`.`field_name`
            ELSE ''
        END `repeater_name`
      , `t`.`field_name` `field_name`
      , CASE
            WHEN `t`.`field_type` <> 'divider' THEN CASE
                                                        WHEN `t`.`meta_value` = `t`.`org_meta_value` THEN 0
                                                        ELSE 1
                                                    END
            ELSE 1
        END `value_has_changed`
      , CASE
            WHEN `t`.`field_type` <> 'divider' THEN `t`.`meta_value`
            ELSE ''
        END `current_value`
      , CASE
            WHEN `t`.`field_type` <> 'divider' THEN `t`.`org_meta_value`
            ELSE ''
        END `original_value`
      , `t`.`field_id` `field_id`
      , `t`.`field_type` `field_type`
      , `t`.`form_name` `form_name`
      , `t`.`field_order` `field_order`
    FROM
        (
            SELECT
                `m`.`item_id` `item_id`
              , CASE
                    WHEN (`f`.`type` LIKE 'html' AND `f`.`description` LIKE '%heading%') THEN `f`.`name`
                    ELSE ''
                END `page_name`
              , `f`.`name` `field_name`
              , `api`.`api_nz`( `m`.`meta_value` , '' ) `meta_value`
              , `api`.`api_nz`( `m`.`org_meta_value` , '' ) `org_meta_value`
              , `m`.`field_id` `field_id`
              , `f`.`type` `field_type`
              , `fr`.`name` `form_name`
              , `f`.`field_order` `field_order`
            FROM
                ((`portal`.`cl_frm_item_metas` `m` LEFT JOIN `portal`.`cl_frm_fields` `f` ON (`m`.`field_id` = `f`.`id`))
                    LEFT JOIN `portal`.`cl_frm_forms` `fr` ON (`f`.`form_id` = `fr`.`id`))
            WHERE
                `f`.`type` <> 'hidden'
        ) `t`;

