CREATE DEFINER = root@`%` TRIGGER au_audit_bill_trust_users_deletes
    AFTER DELETE
    ON bill_trust_users
    FOR EACH ROW
    INSERT INTO `misc`.`bill_trust_users_audit`
     (`auditAction`,`row_id`,`email`,`line_of_business`,`account_number`,`branch_name`,`account_name`,`status`,`enrolled_date`,`send_paper_bill`,`created_at`,`created_by`,`updated_at`,`updated_by`)
  VALUES
     ('DELETE',OLD.`row_id`,OLD.`email`,OLD.`line_of_business`,OLD.`account_number`,OLD.`branch_name`,OLD.`account_name`,OLD.`status`,OLD.`enrolled_date`,OLD.`send_paper_bill`,OLD.`created_at`,OLD.`created_by`,OLD.`updated_at`,OLD.`updated_by`);

