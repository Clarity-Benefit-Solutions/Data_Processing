CREATE
    DEFINER = admin@`%` FUNCTION api_get_last_name_from_fullname(
    value varchar(500) ) RETURNS varchar(500)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;

            CALL api.db_log_error(@errno, 'api_get_last_name_from_fullname', @text, @`sqlstate`);

            RETURN 0;
        END;


    IF api.api_is_blank(value) THEN
        RETURN '';
    END IF;

    IF INSTR(value, ',') > 0 THEN
        RETURN TRIM(SUBSTRING_INDEX(value, ',', 1));
    END IF;

    IF INSTR(value, ' ') > 0 THEN
        RETURN TRIM(SUBSTRING_INDEX(value, ' ', -1));
    END IF;


    RETURN '';

END;

