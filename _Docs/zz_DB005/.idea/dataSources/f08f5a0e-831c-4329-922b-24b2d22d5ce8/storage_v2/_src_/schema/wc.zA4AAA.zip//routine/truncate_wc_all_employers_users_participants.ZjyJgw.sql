CREATE
    DEFINER = root@`%` PROCEDURE truncate_wc_all_employers_users_participants(
    IN dummy int(1) )
BEGIN
    CALL api.db_show_message( 'truncate_wc_employees_employers' , 'Returning without any action' );

    /*  CALL api.db_show_message( 'truncate_wc_employees_employers' , 'STARTING' );
      
      TRUNCATE TABLE wc.wc_employer_plans;
      TRUNCATE TABLE wc.wc_employers;
      TRUNCATE TABLE wc.wc_participants;
      
      #   do not remove TPA users as we move the file after each import....
      DELETE
      FROM
          wc.wc_employer_users
      WHERE
          NOT api.api_is_blank( employer_id );
      
      CALL api.db_show_message( 'truncate_wc_employees_employers' , 'FINISHED' );*/

END;

