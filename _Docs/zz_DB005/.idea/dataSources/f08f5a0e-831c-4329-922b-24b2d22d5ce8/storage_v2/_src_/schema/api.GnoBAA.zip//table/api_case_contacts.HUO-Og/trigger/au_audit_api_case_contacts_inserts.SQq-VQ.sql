CREATE DEFINER = root@`%` TRIGGER au_audit_api_case_contacts_inserts
    AFTER INSERT
    ON api_case_contacts
    FOR EACH ROW
    INSERT INTO `api`.`api_case_contacts_audit`
                 (
                 `auditAction`,
                 `case_contact_id`,
                 `case_id`,
                 `sf_contact_id`,
                 `status`,
                 `version_no`,
                 `contact_type`,
                 `organization_name`,
                 `organization_state`,
                 `organization_zip`,
                 `contact_sub_type`,
                 `contact_title`,
                 `contact_first_name`,
                 `contact_last_name`,
                 `contact_email`,
                 `contact_phone`,
                 `contact_is_cons_ben_contact`,
                 `contact_is_cobra_contact`,
                 `contact_is_ben_admin_contact`,
                 `created_at`,
                 `created_by`,
                 `updated_at`,
                 `updated_by`,
                 `contact_email_org`,
                 `benefit_plan_type`
                 )
                 VALUES (
                        'INSERT',
                        NEW.`case_contact_id`,
                        NEW.`case_id`,
                        NEW.`sf_contact_id`,
                        NEW.`status`,
                        NEW.`version_no`,
                        NEW.`contact_type`,
                        NEW.`organization_name`,
                        NEW.`organization_state`,
                        NEW.`organization_zip`,
                        NEW.`contact_sub_type`,
                        NEW.`contact_title`,
                        NEW.`contact_first_name`,
                        NEW.`contact_last_name`,
                        NEW.`contact_email`,
                        NEW.`contact_phone`,
                        NEW.`contact_is_cons_ben_contact`,
                        NEW.`contact_is_cobra_contact`,
                        NEW.`contact_is_ben_admin_contact`,
                        NEW.`created_at`,
                        NEW.`created_by`,
                        NEW.`updated_at`,
                        NEW.`updated_by`,
                        NEW.`contact_email_org`,
                        NEW.`benefit_plan_type`
                        );

