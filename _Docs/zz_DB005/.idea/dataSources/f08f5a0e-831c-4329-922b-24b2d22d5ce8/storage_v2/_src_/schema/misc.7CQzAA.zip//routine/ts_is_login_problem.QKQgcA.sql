CREATE
    DEFINER = root@`%` FUNCTION ts_is_login_problem(
    p_status text ) RETURNS int
BEGIN
    DECLARE v_ret int DEFAULT 0;
    #
    CASE
        WHEN p_status = ''
            THEN
                SET v_ret = 0; /* user on tpa stream but never registered*/
        WHEN
                p_status LIKE '%broken%' OR
                p_status LIKE '%wrong_secondary%' OR
                p_status LIKE '%incomplete%' OR
                p_status LIKE '%sec_question%' OR
                p_status LIKE '%invalid%' OR
                p_status LIKE '%locked%' OR
                p_status LIKE '%mfa_carrier%' OR
                p_status LIKE '%needs_two_factor%' THEN
            SET v_ret = 1; /* user is on tpa stream and registered but some policies are invalid*/
    #
        ELSE SET v_ret = 0; /* user is registered on tpa stream and all policies are fine */
    END CASE;
    
    RETURN v_ret;
END;

