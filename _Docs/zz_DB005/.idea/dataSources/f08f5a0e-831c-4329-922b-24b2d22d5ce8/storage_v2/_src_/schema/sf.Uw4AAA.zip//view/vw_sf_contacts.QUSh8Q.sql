CREATE VIEW vw_sf_contacts
AS
    SELECT
        `t`.`email` `email`
      , `sf`.`sf_is_active_status`( `t`.`contactstatus` ) `is_active`
      , CASE
            WHEN `t`.`entitytype` LIKE '%TPA%' THEN '3 TPA'
            WHEN `t`.`entitytype` LIKE '%BROKER%' THEN '2 BROKER'
            WHEN `t`.`entitytype` LIKE '%CLIENT%' THEN '1 CLIENT'
            WHEN `t`.`entitytype` LIKE '%EMPLOYEE%' THEN '0 EMPLOYEE'
            ELSE '00'
        END `user_type`
      , `t`.`row_id` `row_id`
      , `t`.`entitytype` `entitytype`
      , `t`.`clientcode` `clientcode`
      , `t`.`clientname` `clientname`
      , `t`.`fullname` `fullname`
      , `t`.`ssn` `ssn`
      , `t`.`contactid` `contactid`
      , `t`.`contactstatus` `contactstatus`
      , `t`.`is_in_wc` `is_in_wc`
      , `t`.`is_in_cp` `is_in_cp`
      , `t`.`is_in_bs` `is_in_bs`
      , `t`.`is_in_en` `is_in_en`
      , `t`.`phone` `phone`
      , `t`.`employeeid` `employeeid`
      , `t`.`isprimarycontact` `isprimarycontact`
      , `t`.`created_at` `created_at`
      , `t`.`created_by` `created_by`
      , `t`.`updated_at` `updated_at`
      , `t`.`updated_by` `updated_by`
    FROM
        `sf`.`sf_contacts` `t`
    WHERE
        !`api`.`upsert_ignore_this_email`( `t`.`email` , 'sf' );

