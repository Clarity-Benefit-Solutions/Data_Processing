CREATE VIEW vw_sso_platform_wc_parts
AS
    SELECT
        CASE
            WHEN `t`.`row_id` = `api`.`sso_get_record_for_wc`( `t`.`email` ) THEN 1
            ELSE 0
        END `is_sso_record`
      , `t`.`email` `email`
      , `t`.`is_active` `is_active`
      , `t`.`user_type` `user_type`
      , `t`.`row_id` `row_id`
      , `t`.`employeeid` `employeeid`
      , `t`.`recordid` `recordid`
      , `t`.`tpaid` `tpaid`
      , `t`.`employername` `employername`
      , `t`.`employerid` `employerid`
      , `t`.`lastname` `lastname`
      , `t`.`firstname` `firstname`
      , `t`.`phone` `phone`
      , `t`.`addressline1` `addressline1`
      , `t`.`addressline2` `addressline2`
      , `t`.`city` `city`
      , `t`.`state` `state`
      , `t`.`zip` `zip`
      , `t`.`country` `country`
      , `t`.`employeestatus` `employeestatus`
      , `t`.`reimbursementmethod` `reimbursementmethod`
      , `t`.`birthdate` `birthdate`
      , `t`.`employeessn` `employeessn`
      , `t`.`cardnumber` `cardnumber`
      , `t`.`mobilenumber` `mobilenumber`
      , `t`.`created_at` `created_at`
      , `t`.`created_by` `created_by`
      , `t`.`updated_at` `updated_at`
      , `t`.`updated_by` `updated_by`
    FROM
        `wc`.`vw_wc_participants` `t`;

