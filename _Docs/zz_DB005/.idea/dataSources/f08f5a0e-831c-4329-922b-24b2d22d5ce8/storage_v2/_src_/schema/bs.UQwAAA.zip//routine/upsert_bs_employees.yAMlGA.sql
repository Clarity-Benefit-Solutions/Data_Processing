CREATE
    DEFINER = root@`%` PROCEDURE upsert_bs_employees(
                                                    IN p_eeclientbencode varchar(200),
                                                    IN p_eedivision varchar(200),
                                                    IN p_eefirstname varchar(200),
                                                    IN p_eelastname varchar(200),
                                                    IN p_eeemployeeid varchar(200),
                                                    IN p_eessn varchar(200),
                                                    IN p_eestatus varchar(200),
                                                    IN p_eeaddress1 varchar(200),
                                                    IN p_eeaddress2 varchar(200),
                                                    IN p_eecity varchar(200),
                                                    IN p_eestate varchar(200),
                                                    IN p_eezip varchar(200),
                                                    IN p_eehomephone varchar(200),
                                                    IN p_eeemail varchar(200),
                                                    IN p_eedob varchar(200),
                                                    IN p_eebswiftparticipant varchar(200),
                                                    IN p_eealternateid varchar(200),
                                                    IN p_eeimportuserid varchar(200),
                                                    IN p_eepayrollid varchar(200),
                                                    IN p_eeuserid varchar(200),
                                                    IN p_eeusername varchar(200),
                                                    IN p_eeisemployee varchar(200),
                                                    IN p_eeismanager varchar(200),
                                                    IN p_eeistopdog varchar(200),
                                                    IN p_abbrevurl varchar(200) )
BEGIN
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO,
                @text = MESSAGE_TEXT;
            SET @text = CONCAT( @text , CONCAT( '
Called With Params: ' , ', eeclientbencode: ' , api.api_nz( `p_eeclientbencode` , '' ) , ', eedivision: ' ,
                                                api.api_nz( `p_eedivision` , '' ) , ', eefirstname: ' ,
                                                api.api_nz( `p_eefirstname` , '' ) , ', eelastname: ' ,
                                                api.api_nz( `p_eelastname` , '' ) , ', eeemployeeid: ' ,
                                                api.api_nz( `p_eeemployeeid` , '' ) , ', eessn: ' ,
                                                api.api_nz( `p_eessn` , '' ) , ', eestatus: ' ,
                                                api.api_nz( `p_eestatus` , '' ) , ', eeaddress1: ' ,
                                                api.api_nz( `p_eeaddress1` , '' ) , ', eeaddress2: ' ,
                                                api.api_nz( `p_eeaddress2` , '' ) , ', eecity: ' ,
                                                api.api_nz( `p_eecity` , '' ) , ', eestate: ' ,
                                                api.api_nz( `p_eestate` , '' ) , ', eezip: ' ,
                                                api.api_nz( `p_eezip` , '' ) , ', eehomephone: ' ,
                                                api.api_nz( `p_eehomephone` , '' ) , ', eeemail: ' ,
                                                api.api_nz( `p_eeemail` , '' ) , ', eedob: ' ,
                                                api.api_nz( `p_eedob` , '' ) , ', eebswiftparticipant: ' ,
                                                api.api_nz( `p_eebswiftparticipant` , '' ) , ', eealternateid: ' ,
                                                api.api_nz( `p_eealternateid` , '' ) , ', eeimportuserid: ' ,
                                                api.api_nz( `p_eeimportuserid` , '' ) , ', eepayrollid: ' ,
                                                api.api_nz( `p_eepayrollid` , '' ) , ', eeuserid: ' ,
                                                api.api_nz( `p_eeuserid` , '' ) , ', eeusername: ' ,
                                                api.api_nz( `p_eeusername` , '' ) , ', eeisemployee: ' ,
                                                api.api_nz( `p_eeisemployee` , '' ) , ', eeismanager: ' ,
                                                api.api_nz( `p_eeismanager` , '' ) , ', eeistopdog: ' ,
                                                api.api_nz( `p_eeistopdog` , '' ) , ', abbrevurl: ' ,
                                                api.api_nz( `p_abbrevurl` , '' ) ) );
            CALL api.db_log_message( 'upsert_bs_employees' , @text, 'ERROR' );
        END;
    
    CALL api.db_log_message( 'upsert_bs_employees' , CONCAT( 'Called With Params: ' , ', eeclientbencode: ' ,
                                                             api.api_nz( `p_eeclientbencode` , '' ) , ', eedivision: ' ,
                                                             api.api_nz( `p_eedivision` , '' ) , ', eefirstname: ' ,
                                                             api.api_nz( `p_eefirstname` , '' ) , ', eelastname: ' ,
                                                             api.api_nz( `p_eelastname` , '' ) , ', eeemployeeid: ' ,
                                                             api.api_nz( `p_eeemployeeid` , '' ) , ', eessn: ' ,
                                                             api.api_nz( `p_eessn` , '' ) , ', eestatus: ' ,
                                                             api.api_nz( `p_eestatus` , '' ) , ', eeaddress1: ' ,
                                                             api.api_nz( `p_eeaddress1` , '' ) , ', eeaddress2: ' ,
                                                             api.api_nz( `p_eeaddress2` , '' ) , ', eecity: ' ,
                                                             api.api_nz( `p_eecity` , '' ) , ', eestate: ' ,
                                                             api.api_nz( `p_eestate` , '' ) , ', eezip: ' ,
                                                             api.api_nz( `p_eezip` , '' ) , ', eehomephone: ' ,
                                                             api.api_nz( `p_eehomephone` , '' ) , ', eeemail: ' ,
                                                             api.api_nz( `p_eeemail` , '' ) , ', eedob: ' ,
                                                             api.api_nz( `p_eedob` , '' ) , ', eebswiftparticipant: ' ,
                                                             api.api_nz( `p_eebswiftparticipant` , '' ) ,
                                                             ', eealternateid: ' ,
                                                             api.api_nz( `p_eealternateid` , '' ) ,
                                                             ', eeimportuserid: ' ,
                                                             api.api_nz( `p_eeimportuserid` , '' ) , ', eepayrollid: ' ,
                                                             api.api_nz( `p_eepayrollid` , '' ) , ', eeuserid: ' ,
                                                             api.api_nz( `p_eeuserid` , '' ) , ', eeusername: ' ,
                                                             api.api_nz( `p_eeusername` , '' ) , ', eeisemployee: ' ,
                                                             api.api_nz( `p_eeisemployee` , '' ) , ', eeismanager: ' ,
                                                             api.api_nz( `p_eeismanager` , '' ) , ', eeistopdog: ' ,
                                                             api.api_nz( `p_eeistopdog` , '' ) , ', abbrevurl: ' ,
                                                             api.api_nz( `p_abbrevurl` , '' ) ) ,
                             'WARN' );
    
    SET p_eedob = api.api_fix_date_us_format( p_eedob );
    SET p_eestate = api.api_cbool( p_eestate );
    SET p_eeisemployee = api.api_cbool( p_eeisemployee );
    SET p_eeismanager = api.api_cbool( p_eeismanager );
    SET p_eeistopdog = api.api_cbool( p_eeistopdog );
    
    INSERT INTO bs.bs_employees(
                                 eeclientbencode
                               , eedivision
                               , eefirstname
                               , eelastname
                               , eeemployeeid
                               , eessn
                               , eestatus
                               , eeaddress1
                               , eeaddress2
                               , eecity
                               , eestate
                               , eezip
                               , eehomephone
                               , eeemail
                               , eedob
                               , eebswiftparticipant
                               , eealternateid
                               , eeimportuserid
                               , eepayrollid
                               , eeuserid
                               , eeusername
                               , eeisemployee
                               , eeismanager
                               , eeistopdog
                               , abbrevurl
    )
    VALUES (
               p_eeclientbencode
           ,   p_eedivision
           ,   p_eefirstname
           ,   p_eelastname
           ,   p_eeemployeeid
           ,   p_eessn
           ,   p_eestatus
           ,   p_eeaddress1
           ,   p_eeaddress2
           ,   p_eecity
           ,   p_eestate
           ,   p_eezip
           ,   p_eehomephone
           ,   p_eeemail
           ,   p_eedob
           ,   p_eebswiftparticipant
           ,   p_eealternateid
           ,   p_eeimportuserid
           ,   p_eepayrollid
           ,   p_eeuserid
           ,   p_eeusername
           ,   p_eeisemployee
           ,   p_eeismanager
           ,   p_eeistopdog
           ,   p_abbrevurl
           )
    ON DUPLICATE KEY UPDATE
                         eeclientbencode     = p_eeclientbencode
                       , eedivision          = p_eedivision
                       , eefirstname         = p_eefirstname
                       , eelastname          = p_eelastname
                       , eeemployeeid        = p_eeemployeeid
                       , eessn               = p_eessn
                       , eestatus            = p_eestatus
                       , eeaddress1          = p_eeaddress1
                       , eeaddress2          = p_eeaddress2
                       , eecity              = p_eecity
                       , eestate             = p_eestate
                       , eezip               = p_eezip
                       , eehomephone         = p_eehomephone
        /*            2021-03-16 - do not change email once that record (matched by employerid, employeeid has been used for registration by a participant - to ensure we can alwyas sync updated data for that part back to platform users
         if email has changed to become blank and is not yet is_used_for_registration, replace old email with new email even if new one blank */
        /*`email`               = api.api_nz( `p_email` , `email` ),*/
                       , `eeemail`           = api.api_if_true_else( is_used_for_registration , eeemail ,
                                                                     api.api_nz( p_eeemail , '' ) )
        /* end*/
       
                       , eedob               = p_eedob
                       , eebswiftparticipant = p_eebswiftparticipant
                       , eealternateid       = p_eealternateid
                       , eeimportuserid      = p_eeimportuserid
                       , eepayrollid         = p_eepayrollid
                       , eeuserid            = p_eeuserid
                       , eeusername          = p_eeusername
                       , eeisemployee        = p_eeisemployee
                       , eeismanager         = p_eeismanager
                       , eeistopdog          = p_eeistopdog
                       , abbrevurl           = p_abbrevurl;

END;

