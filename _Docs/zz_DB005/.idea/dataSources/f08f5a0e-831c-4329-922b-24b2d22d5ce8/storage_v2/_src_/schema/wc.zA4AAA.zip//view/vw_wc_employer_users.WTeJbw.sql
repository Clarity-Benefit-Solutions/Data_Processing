CREATE VIEW vw_wc_employer_users
AS
    SELECT
        `wc`.`wc_employer_users`.`email` `email`
      , `wc`.`wc_is_active_status`( `wc`.`wc_employer_users`.`status` , NULL ,
                                    `wc`.`wc_employer_users`.`employer_id` ) `is_active`
      , CASE
            WHEN `api`.`api_is_blank`( `wc`.`wc_employer_users`.`employer_id` ) THEN CASE
                                                                                         WHEN `wc`.`wc_employer_users`.`profile_name` IN
                                                                                              ('Clarity Admin Master', 'Clarity Employee Role')
                                                                                             THEN '3 TPA'
                                                                                         WHEN `wc`.`wc_employer_users`.`profile_name` IN
                                                                                              ('Broker Portal Standard', 'Group Broker Profile')
                                                                                             THEN '2 BROKER'
                                                                                         WHEN `wc`.`wc_employer_users`.`profile_name` IN ('Y', 'N')
                                                                                             THEN '000 INVALID'
                                                                                         ELSE '2 BROKER'
                                                                                     END
            ELSE '1 CLIENT'
        END `user_type`
      , `wc`.`wc_employer_users`.`tpa_id` `tpa_id`
      , `wc`.`wc_employer_users`.`user_id` `user_id`
      , `wc`.`wc_employer_users`.`profile_name` `profile_name`
      , `wc`.`wc_employer_users`.`middle_initial` `middle_initial`
      , `wc`.`wc_employer_users`.`name_prefix` `name_prefix`
      , `wc`.`wc_employer_users`.`phone` `phone`
      , `wc`.`wc_employer_users`.`row_id` `row_id`
      , `wc`.`wc_employer_users`.`employer_id` `employer_id`
      , `wc`.`wc_employer_users`.`first_name` `first_name`
      , `wc`.`wc_employer_users`.`last_name` `last_name`
      , `wc`.`wc_employer_users`.`allow_get_current_sessions` `allow_get_current_sessions`
      , `wc`.`wc_employer_users`.`allow_to_uplod_a_payroll_file` `allow_to_uplod_a_payroll_file`
      , `wc`.`wc_employer_users`.`status` `status`
      , `wc`.`wc_employer_users`.`created_at` `created_at`
      , `wc`.`wc_employer_users`.`created_by` `created_by`
      , `wc`.`wc_employer_users`.`updated_at` `updated_at`
      , `wc`.`wc_employer_users`.`updated_by` `updated_by`
    FROM
        `wc`.`wc_employer_users`;

