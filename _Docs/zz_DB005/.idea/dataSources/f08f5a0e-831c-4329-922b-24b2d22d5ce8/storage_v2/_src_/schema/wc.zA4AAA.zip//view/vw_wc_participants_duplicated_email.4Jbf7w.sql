CREATE VIEW vw_wc_participants_duplicated_email
AS
    SELECT
        `wc`.`wc_participants`.`email` `email`
    FROM
        `wc`.`wc_participants`
    WHERE
        !`api`.`api_is_blank`( `wc`.`wc_participants`.`email` )
    GROUP BY
        `wc`.`wc_participants`.`email`
    HAVING
        COUNT( 0 ) > 1;

