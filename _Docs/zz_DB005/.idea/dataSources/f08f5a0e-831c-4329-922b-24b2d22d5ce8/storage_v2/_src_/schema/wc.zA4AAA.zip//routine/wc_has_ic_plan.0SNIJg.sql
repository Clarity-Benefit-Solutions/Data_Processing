CREATE
    DEFINER = root@`%` FUNCTION wc_has_ic_plan(
                                              p_employee_id varchar(200),
                                              p_employer_id varchar(200) ) RETURNS float
BEGIN
    DECLARE v_ret float DEFAULT 0;
    
    #      if a tive, check has relevant plan for employee
    /* sumeet - dont check active plans till we are sure the table has all plans that need to be considered and can be loaded in a definite time */
    SELECT
        COUNT( * )
    INTO v_ret
    FROM
        wc.wc_participant_plans
    WHERE
          employeeid = p_employee_id
      AND (api.api_is_blank( employerid ) OR employerid = p_employer_id)
      AND plancode  IN ('U21'/*, 'CRA'*/)
      AND planstart <= DATE( SYSDATE( ) );
    #
    SET v_ret = api.api_nz_int( v_ret , 0 );
    
    RETURN v_ret;

END;

