CREATE DEFINER = root@`%` TRIGGER au_audit_en_employees_updates
    AFTER UPDATE
    ON en_employees
    FOR EACH ROW
    INSERT INTO `en`.`en_employees_audit`
                 (`auditAction`, `row_id`, `companyidentifier`, `firstname`, `lastname`, `ssn`, `employeeid`,
                  `employeestatus`, `address1`, `address2`, `city`, `state`, `zip`, `phone`, `email`, `dob`,
                  `terminationdate`, `enparticipant`, `created_at`, `created_by`, `updated_at`, `updated_by`,
                  `match_employeeid_last`, `match_ssn_last`, `match_dob_last`, `match_phone_last`, `matched_zip`,
                  `is_used_for_registration`, `matched_ssn_emp_id_last`)
                 VALUES ('UPDATE', NEW.`row_id`, NEW.`companyidentifier`, NEW.`firstname`, NEW.`lastname`, NEW.`ssn`,
                         NEW.`employeeid`, NEW.`employeestatus`, NEW.`address1`, NEW.`address2`, NEW.`city`,
                         NEW.`state`, NEW.`zip`, NEW.`phone`, NEW.`email`, NEW.`dob`, NEW.`terminationdate`,
                         NEW.`enparticipant`, NEW.`created_at`, NEW.`created_by`, NEW.`updated_at`, NEW.`updated_by`,
                         NEW.`match_employeeid_last`, NEW.`match_ssn_last`, NEW.`match_dob_last`,
                         NEW.`match_phone_last`, NEW.`matched_zip`, NEW.`is_used_for_registration`,
                         NEW.`matched_ssn_emp_id_last`);

