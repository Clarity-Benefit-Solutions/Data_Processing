CREATE DEFINER = admin@`%` TRIGGER util_bu_cl_options_set_updated_at_and_by
    BEFORE UPDATE
    ON cl_options
    FOR EACH ROW
BEGIN
    SET new.updated_at = CURRENT_TIMESTAMP;
    SET new.updated_by = current_user;
END;

