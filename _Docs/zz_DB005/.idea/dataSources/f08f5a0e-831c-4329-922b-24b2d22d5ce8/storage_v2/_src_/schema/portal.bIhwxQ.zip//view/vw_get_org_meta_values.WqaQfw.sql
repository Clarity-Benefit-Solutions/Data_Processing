CREATE VIEW vw_get_org_meta_values
AS
    SELECT
        `m`.`item_id` `item_id`
      , `get_page_heading_for_field`( `f`.`form_id` , `f`.`field_order` ) `page_name`
      , `m`.`field_id` `field_id`
      , `f`.`type` `field_type`
      , '' `form_name`
      , `f`.`field_order` `field_order`
      , `f`.`form_id` `form_id`
      , `f`.`field_key` `field_key`
      , `f`.`name` `field_name`
      , `api`.`api_nz`( `m`.`current_value` , '' ) `current_value`
      , `api`.`api_nz`( `m`.`original_value` , '' ) `original_value`
      , `m`.`created_at` `created_at`
      , `m`.`updated_at` `updated_at`
    FROM
        (`portal`.`vw_get_org_meta_audit_values` `m`
            JOIN `portal`.`cl_frm_fields` `f` ON (`m`.`field_id` = `f`.`id`));

