CREATE VIEW vw_cp_all_sso_users_staging
AS
    SELECT
        `cp`.`cp_all_sso_users_staging`.`email` `email`
      , `cp`.`cp_is_active_status`( `cp`.`cp_all_sso_users_staging`.`active` ,
                                    `cp`.`cp_all_sso_users_staging`.`organizationisactive` ) AND
        `cp`.`cp_all_sso_users_staging`.`organizationname` NOT LIKE '% TERM%' `is_active`
      , CASE
            WHEN `cp`.`cp_all_sso_users_staging`.`entitytype` LIKE '%QB%' THEN '01 QB'
            WHEN `cp`.`cp_all_sso_users_staging`.`entitytype` LIKE '%SPM%' THEN '00 SPM'
            WHEN `cp`.`cp_all_sso_users_staging`.`entitytype` LIKE '%BROKER%' THEN '2 BROKER'
            WHEN `cp`.`cp_all_sso_users_staging`.`entitytype` LIKE '%CLIENT%' THEN '1 CLIENT'
            WHEN `cp`.`cp_all_sso_users_staging`.`entitytype` LIKE '%TPA%' THEN '3 TPA'
            ELSE `cp`.`cp_all_sso_users_staging`.`entitytype`
        END `user_type`
      , `cp`.`cp_all_sso_users_staging`.`ROW_ID` `ROW_ID`
      , `cp`.`cp_all_sso_users_staging`.`orderseq` `orderseq`
      , `cp`.`cp_all_sso_users_staging`.`entitytype` `entitytype`
      , `cp`.`cp_all_sso_users_staging`.`memberid` `memberid`
      , `cp`.`cp_all_sso_users_staging`.`brokerid` `brokerid`
      , `cp`.`cp_all_sso_users_staging`.`clientcontactid` `clientcontactid`
      , `cp`.`cp_all_sso_users_staging`.`clientid` `clientid`
      , `cp`.`cp_all_sso_users_staging`.`clientdivisionid` `clientdivisionid`
      , `cp`.`cp_all_sso_users_staging`.`organizationname` `organizationname`
      , `cp`.`cp_all_sso_users_staging`.`divisionname` `divisionname`
      , `cp`.`cp_all_sso_users_staging`.`individualidentifier` `individualidentifier`
      , `cp`.`cp_all_sso_users_staging`.`contacttype` `contacttype`
      , `cp`.`cp_all_sso_users_staging`.`salutation` `salutation`
      , `cp`.`cp_all_sso_users_staging`.`firstname` `firstname`
      , `cp`.`cp_all_sso_users_staging`.`lastname` `lastname`
      , `cp`.`cp_all_sso_users_staging`.`title` `title`
      , `cp`.`cp_all_sso_users_staging`.`department` `department`
      , `cp`.`cp_all_sso_users_staging`.`phone` `phone`
      , `cp`.`cp_all_sso_users_staging`.`phone2` `phone2`
      , `cp`.`cp_all_sso_users_staging`.`city` `city`
      , `cp`.`cp_all_sso_users_staging`.`state` `state`
      , `cp`.`cp_all_sso_users_staging`.`postalcode` `postalcode`
      , `cp`.`cp_all_sso_users_staging`.`country` `country`
      , `cp`.`cp_all_sso_users_staging`.`active` `active`
      , `cp`.`cp_all_sso_users_staging`.`loginstatus` `loginstatus`
      , `cp`.`cp_all_sso_users_staging`.`registrationcode` `registrationcode`
      , `cp`.`cp_all_sso_users_staging`.`registrationdate` `registrationdate`
      , `cp`.`cp_all_sso_users_staging`.`userdisplayname` `userdisplayname`
      , `cp`.`cp_all_sso_users_staging`.`allowsso` `allowsso`
      , `cp`.`cp_all_sso_users_staging`.`ssoidentifier` `ssoidentifier`
      , `cp`.`cp_all_sso_users_staging`.`userid` `userid`
      , `cp`.`cp_all_sso_users_staging`.`ssn` `ssn`
      , `cp`.`cp_all_sso_users_staging`.`dob` `dob`
      , `cp`.`cp_all_sso_users_staging`.`employeeid` `employeeid`
      , `cp`.`cp_all_sso_users_staging`.`created_at` `created_at`
      , `cp`.`cp_all_sso_users_staging`.`created_by` `created_by`
      , `cp`.`cp_all_sso_users_staging`.`updated_at` `updated_at`
      , `cp`.`cp_all_sso_users_staging`.`updated_by` `updated_by`
      , `cp`.`cp_all_sso_users_staging`.`is_used_for_registration` `is_used_for_registration`
      , `cp`.`cp_all_sso_users_staging`.`qualeventdate` `qualeventdate`
    FROM
        `cp`.`cp_all_sso_users_staging`
    WHERE
        !`api`.`upsert_ignore_this_email`( `cp`.`cp_all_sso_users_staging`.`email` , 'cp' );

