CREATE VIEW vw_cp_all_sso_users
AS
    SELECT
        `cp`.`cp_all_sso_users`.`email` `email`
      , `cp`.`cp_is_active_status`( `cp`.`cp_all_sso_users`.`active` ,
                                    `cp`.`cp_all_sso_users`.`organizationisactive` ) AND
        `cp`.`cp_all_sso_users`.`organizationname` NOT LIKE '% TERM%' `is_active`
      , CASE
            WHEN `cp`.`cp_all_sso_users`.`entitytype` LIKE '%QB%' THEN '01 QB'
            WHEN `cp`.`cp_all_sso_users`.`entitytype` LIKE '%SPM%' THEN '00 SPM'
            WHEN `cp`.`cp_all_sso_users`.`entitytype` LIKE '%BROKER%' THEN '2 BROKER'
            WHEN `cp`.`cp_all_sso_users`.`entitytype` LIKE '%CLIENT%' THEN '1 CLIENT'
            WHEN `cp`.`cp_all_sso_users`.`entitytype` LIKE '%TPA%' THEN '3 TPA'
            ELSE `cp`.`cp_all_sso_users`.`entitytype`
        END `user_type`
      , `cp`.`cp_all_sso_users`.`ROW_ID` `ROW_ID`
      , `cp`.`cp_all_sso_users`.`orderseq` `orderseq`
      , `cp`.`cp_all_sso_users`.`entitytype` `entitytype`
      , `cp`.`cp_all_sso_users`.`memberid` `memberid`
      , `cp`.`cp_all_sso_users`.`brokerid` `brokerid`
      , `cp`.`cp_all_sso_users`.`clientcontactid` `clientcontactid`
      , `cp`.`cp_all_sso_users`.`clientid` `clientid`
      , `cp`.`cp_all_sso_users`.`clientdivisionid` `clientdivisionid`
      , `cp`.`cp_all_sso_users`.`organizationname` `organizationname`
      , `cp`.`cp_all_sso_users`.`divisionname` `divisionname`
      , `cp`.`cp_all_sso_users`.`individualidentifier` `individualidentifier`
      , `cp`.`cp_all_sso_users`.`contacttype` `contacttype`
      , `cp`.`cp_all_sso_users`.`salutation` `salutation`
      , `cp`.`cp_all_sso_users`.`firstname` `firstname`
      , `cp`.`cp_all_sso_users`.`lastname` `lastname`
      , `cp`.`cp_all_sso_users`.`title` `title`
      , `cp`.`cp_all_sso_users`.`department` `department`
      , `cp`.`cp_all_sso_users`.`phone` `phone`
      , `cp`.`cp_all_sso_users`.`phone2` `phone2`
      , `cp`.`cp_all_sso_users`.`city` `city`
      , `cp`.`cp_all_sso_users`.`state` `state`
      , `cp`.`cp_all_sso_users`.`postalcode` `postalcode`
      , `cp`.`cp_all_sso_users`.`country` `country`
      , `cp`.`cp_all_sso_users`.`active` `active`
      , `cp`.`cp_all_sso_users`.`loginstatus` `loginstatus`
      , `cp`.`cp_all_sso_users`.`registrationcode` `registrationcode`
      , `cp`.`cp_all_sso_users`.`registrationdate` `registrationdate`
      , `cp`.`cp_all_sso_users`.`userdisplayname` `userdisplayname`
      , `cp`.`cp_all_sso_users`.`allowsso` `allowsso`
      , `cp`.`cp_all_sso_users`.`ssoidentifier` `ssoidentifier`
      , `cp`.`cp_all_sso_users`.`userid` `userid`
      , `cp`.`cp_all_sso_users`.`ssn` `ssn`
      , `cp`.`cp_all_sso_users`.`dob` `dob`
      , `cp`.`cp_all_sso_users`.`employeeid` `employeeid`
      , `cp`.`cp_all_sso_users`.`created_at` `created_at`
      , `cp`.`cp_all_sso_users`.`created_by` `created_by`
      , `cp`.`cp_all_sso_users`.`updated_at` `updated_at`
      , `cp`.`cp_all_sso_users`.`updated_by` `updated_by`
      , `cp`.`cp_all_sso_users`.`is_used_for_registration` `is_used_for_registration`
      , `cp`.`cp_all_sso_users`.`qualeventdate` `qualeventdate`
    FROM
        `cp`.`cp_all_sso_users`
    WHERE
        !`api`.`upsert_ignore_this_email`( `cp`.`cp_all_sso_users`.`email` , 'cp' );

