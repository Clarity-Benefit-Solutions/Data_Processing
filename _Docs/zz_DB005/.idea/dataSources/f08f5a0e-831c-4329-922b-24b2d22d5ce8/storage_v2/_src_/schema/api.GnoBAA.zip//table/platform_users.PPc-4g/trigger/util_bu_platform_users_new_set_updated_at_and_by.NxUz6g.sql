CREATE DEFINER = root@`%` TRIGGER util_bu_platform_users_new_set_updated_at_and_by
    BEFORE UPDATE
    ON platform_users
    FOR EACH ROW
BEGIN
    -- if we are updating a record and changing value of user_synced_to_mini_orange, dont update the updated_at date
    IF old.user_synced_to_mini_orange <> new.user_synced_to_mini_orange THEN
        SET new.updated_at = old.updated_at;
        SET new.updated_by = old.updated_by;
    ELSE
        SET new.updated_at = CURRENT_TIMESTAMP;
        SET new.updated_by = current_user;
        SET new.user_synced_to_mini_orange = 0;
    END IF;
    
    set new.created_at = old.created_at;
    set new.created_by = old.created_by;
END;

