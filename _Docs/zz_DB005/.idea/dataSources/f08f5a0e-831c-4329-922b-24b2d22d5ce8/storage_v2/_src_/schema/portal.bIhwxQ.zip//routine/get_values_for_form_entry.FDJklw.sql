CREATE
    DEFINER = root@`%` FUNCTION get_values_for_form_entry(
                                                         p_entry_created_at timestamp,
                                                         p_form_item_id int,
                                                         p_add_header int,
                                                         p_page_name varchar(200),
                                                         p_repeater_field_name varchar(200),
                                                         p_only_for_field_key varchar(200),
                                                         p_only_field_current_value int ) RETURNS longtext
BEGIN
    
    DECLARE v_debug int DEFAULT 0;
    
    DECLARE v_csv longtext;
    
    DECLARE v_item_id varchar(100);
    DECLARE v_form_id varchar(100);
    DECLARE v_form_name varchar(200);
    DECLARE v_page_name varchar(500);
    DECLARE v_field_order int;
    DECLARE v_field_name varchar(500);
    DECLARE v_created_at timestamp;
    DECLARE v_updated_at timestamp;
    
    DECLARE v_value_has_changed varchar(10);
    DECLARE v_current_value longtext;
    DECLARE v_original_value longtext;
    DECLARE v_field_key varchar(500);
    DECLARE v_field_id varchar(100);
    DECLARE v_field_type varchar(100);
    
    DECLARE v_repeater_org_entry_id varchar(15);
    DECLARE v_repeater_entry_csv longtext;
    
    DECLARE v_repeater_curr_entry_id varchar(15);
    
    DECLARE v_finished int;
    
    DECLARE v_rowcsv longtext;
    
    DECLARE v_row_no int;
    DECLARE v_counter int;
    DECLARE v_only_field_current_value_format varchar(50) DEFAULT 'json';
    
    DECLARE v_values_cursor CURSOR FOR SELECT
                                           api.api_nz( item_id , '' )
                                         , api.api_nz( form_id , '' )
                                         , api.api_nz( form_name , '' )
                                         , api.api_nz( page_name , '' )
                                         , api.api_nz( field_order , '' )
                                         , api.api_nz( field_name , '' )
                                         , api.api_nz( value_has_changed , '' )
                                         , api.api_nz( current_value , '' )
                                         , api.api_nz( original_value , '' )
                                         , api.api_nz( field_key , '' )
                                         , api.api_nz( field_id , '' )
                                         , api.api_nz( field_type , '' )
                                         , created_at
                                         , updated_at
    
                                       FROM
                                           vw_get_values_for_form_entry
                                       WHERE
                                             item_id = p_form_item_id
                                         AND field_key LIKE p_only_for_field_key
                                       ORDER BY
                                           form_id
                                         , field_order;
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND BEGIN
        SET v_finished = 1;
    END;
    
    SET @@max_sp_recursion_depth = 12;
    
    SET v_csv = '';
    
    IF api.api_is_blank( TRIM( p_only_for_field_key ) ) THEN
        SET p_only_for_field_key = '%';
    ELSEIF POSITION( '%' IN p_only_for_field_key ) = 0 THEN
        SET p_only_for_field_key = CONCAT( p_only_for_field_key , '%' );
    END IF;
    
    IF p_only_field_current_value THEN
        SET p_add_header = 0;
    END IF;
    
    IF p_add_header THEN
        SET v_csv =
                CONCAT( api.qt( ) , 'Item Id' , api.qt( ) , ',' , api.qt( ) , 'Form Id' , api.qt( ) , ',' , api.qt( ) ,
                        'Form Name' , api.qt( ) , ',' , api.qt( ) , 'Page Name' , api.qt( ) , ',' , api.qt( ) ,
                        'Repeater Name' , api.qt( ) , ',' , api.qt( ) , 'Field Name' , api.qt( ) , ',' , api.qt( ) ,
                        'Is Repeater Field' , api.qt( ) , ',' , api.qt( ) , 'Field Id' , api.qt( ) , ',' , api.qt( ) ,
                        'Field Key' , api.qt( ) , ',' , api.qt( ) , 'Field Type' , api.qt( ) , ',' , api.qt( ) ,
                        'Has Changed' , api.qt( ) , ',' , api.qt( ) , 'Original Value' , api.qt( ) , ',' , api.qt( ) ,
                        'Current Value' , api.qt( ) , ',' , api.qt( ) , 'Org Item Id' , api.qt( ) , ',' , api.qt( ) ,
                        'Org Created At' , api.qt( ) , ',' , api.qt( ) , 'Curr Created At' , api.qt( ) , ',' ,
                        CHAR( 13 ) );
    END IF;
    
    IF p_only_field_current_value THEN
        IF v_only_field_current_value_format = 'csv' THEN
            SET v_csv = '';
        ELSEIF v_only_field_current_value_format = 'json' THEN
            SET v_csv = CONCAT( '['
                , CHAR( 13 ) );
        END IF;
    END IF;
    
    --
    OPEN v_values_cursor;
    #
    IF v_debug THEN
        CALL api.db_log_message( 'get_values_for_all_fields_for_form_entry' ,
                                 CONCAT( 'Processing Form Entry ID:  ' , p_form_item_id , ' created at: ' ,
                                         p_entry_created_at ) , 'INFO' );
    END IF;
    getvalues
    :
    LOOP
        SET v_rowcsv = '';
        --
        FETCH v_values_cursor INTO v_item_id, v_form_id, v_form_name, v_page_name, v_field_order, v_field_name, v_value_has_changed, v_current_value, v_original_value, v_field_key, v_field_id, v_field_type, v_created_at, v_updated_at;
        
        IF v_finished = 1 THEN
            LEAVE getvalues;
        END IF;
        
        SET v_page_name =
                api.api_nz( api.api_nz( p_page_name , portal.get_page_heading_for_field( v_form_id , v_field_order ) ) ,
                            '' );
        
        IF v_value_has_changed = '1' THEN
            SET v_value_has_changed = 'Yes';
        ELSE
            SET v_value_has_changed = 'No';
        END IF;
        
        IF v_current_value = 'undefined' THEN
            SET v_current_value = '';
        END IF;
        
        IF v_original_value = 'undefined' THEN
            SET v_original_value = '';
        END IF;
        
        IF v_field_type <> 'divider' THEN
            SET v_original_value = REPLACE( v_original_value , '"' , '""' );
            
            SET v_current_value = REPLACE( v_current_value , '"' , '""' );
            
            IF NOT p_only_field_current_value THEN
                SET v_rowcsv =
                        CONCAT( v_rowcsv , api.qt( ) , api.api_nz( v_item_id , '' ) , api.qt( ) , ',' , api.qt( ) ,
                                api.api_nz( v_form_id , '' ) , api.qt( ) , ',' , api.qt( ) ,
                                api.api_nz( v_form_name , '' ) , api.qt( ) , ',' , api.qt( ) ,
                                api.api_nz( v_page_name , '' ) , api.qt( ) , ',' , api.qt( ) ,
                                api.api_nz( p_repeater_field_name , '' ) , api.qt( ) , ',' , api.qt( ) ,
                                api.api_nz( v_field_name , '' ) , api.qt( ) , ',' , api.qt( ) ,
                                NOT api.api_is_blank( p_repeater_field_name ) , api.qt( ) , ',' , api.qt( ) ,
                                api.api_nz( v_field_id , '' ) , api.qt( ) , ',' , api.qt( ) ,
                                api.api_nz( v_field_key , '' ) , api.qt( ) , ',' , api.qt( ) ,
                                api.api_nz( v_field_type , '' ) , api.qt( ) , ',' , api.qt( ) ,
                                api.api_nz( v_value_has_changed , '' ) , api.qt( ) , ',' , api.qt( ) ,
                                api.api_nz( v_original_value , '' ) , api.qt( ) , ',' , api.qt( ) ,
                                api.api_nz( v_current_value , '' ) , api.qt( ) , ',' , api.qt( ) ,
                                api.api_nz( v_item_id , '' ) , api.qt( ) , ',' , api.qt( ) ,
                                api.api_nz( p_entry_created_at , '' ) , api.qt( ) , ',' , api.qt( ) ,
                                api.api_nz( v_created_at , '' ) , api.qt( ) , ','
                            , CHAR( 13 ) );
            
            ELSE
                IF v_only_field_current_value_format = 'csv' THEN
                    SET v_rowcsv =
                            CONCAT( v_rowcsv , api.qt( ) , api.api_nz( v_current_value , '' ) , api.qt( )
                                , CHAR( 13 ) );
                ELSEIF v_only_field_current_value_format = 'json' THEN
                    SET v_rowcsv =
                            CONCAT( v_rowcsv , '{' ,
                                    api.qt( ) , api.api_nz2( v_field_name ) , api.qt( ) , ':' ,
                                    api.qt( ) , api.api_nz( v_current_value , '' ) , api.qt( ) ,
                                    '}'
                                , ','
                                , CHAR( 13 ) );
                END IF;
            END IF;
        
        ELSE
            
            IF v_debug THEN
                CALL api.db_log_message( 'get_values_for_all_fields_for_form_entry' ,
                                         CONCAT( ' -- Processing Repeater Field: ' , v_field_name , ' , SubEntries: ' ,
                                                 v_current_value ) , 'INFO' );
            END IF;
            
            SET v_counter = 0;
            SET v_repeater_org_entry_id = 0;
            
            WHILE v_counter <= 20 AND (v_repeater_org_entry_id IS NOT NULL OR v_repeater_curr_entry_id IS NOT NULL) DO
                IF v_debug THEN
                    CALL api.db_log_message( 'get_values_for_all_fields_for_form_entry' ,
                                             CONCAT( ' -- Processing Repeater Field: ' , v_field_name , ', value: ' ,
                                                     v_current_value , ' , Entry AT index: ' , v_counter ) , 'INFO' );
                END IF;
                -- get current entry id at index
                SET v_repeater_curr_entry_id = api.api_getphpserializedarrayvaluebyindex( v_current_value , v_counter );
                
                -- get original entry id at index
                SET v_repeater_org_entry_id = api.api_getphpserializedarrayvaluebyindex( v_original_value , v_counter );
                
                IF v_debug THEN
                    CALL api.db_log_message( 'get_values_for_all_fields_for_form_entry' ,
                                             CONCAT( ' -- Processing Repeater Field: ' , v_field_name , ', value: ' ,
                                                     v_current_value , ' , Entry AT index: ' , v_counter , ' = ' ,
                                                     v_repeater_org_entry_id ) , 'INFO' );
                END IF;
                
                IF v_repeater_org_entry_id IS NOT NULL OR v_repeater_curr_entry_id IS NOT NULL THEN
                    
                    SET v_repeater_entry_csv = '';
                    
                    /*call get_values_for_repeater_form_entry_call_fn*/
                    SET v_repeater_entry_csv = portal.get_values_for_repeater_form_entry_cross_join(
                            p_entry_created_at ,
                            v_repeater_curr_entry_id ,
                            v_repeater_org_entry_id ,
                            v_page_name ,
                            v_field_name ,
                            p_only_field_current_value );
                    
                    IF p_only_field_current_value AND v_only_field_current_value_format = 'json' THEN
                        /* open bracket for nested object*/
                        SET v_rowcsv =
                                CONCAT( v_rowcsv
                                    , '{'
                                    , CHAR( 13 )
                                    , api.qt( ) , api.api_nz2( v_field_name ) , api.qt( ) , ':'
                                    , CHAR( 13 )
                                    #                                     , '{'
                                    #                                     , CHAR( 13 )
                                    , v_repeater_entry_csv
                                    , CHAR( 13 )
                                    , '}'
                                    #                                     , CHAR( 13 )
                                    , ','
                                    , CHAR( 13 ) );
                    ELSE
                        SET v_rowcsv = CONCAT( v_rowcsv , v_repeater_entry_csv , CHAR( 13 ) );
                    END IF;
                
                END IF;
                SET v_counter = v_counter + 1;
            END WHILE;
            --  SET v_rowCsv = concat(v_rowCsv, v_repeater_entry_csv);
        END IF;
        
        IF v_debug THEN
            CALL api.db_log_message( 'get_values_for_all_fields_for_form_entry' ,
                                     CONCAT( ' -- Field: ' , v_field_name , ' , FieldKey: ' , v_field_key , ', CSV:' ,
                                             CHAR( 13 ) , v_rowcsv ) , 'INFO' );
        END IF;
        
        IF api.api_nz( v_rowcsv , '' ) <> '' THEN
            SET v_csv = CONCAT( v_csv , v_rowcsv );
        END IF;
    
    END LOOP getvalues;
    
    IF p_only_field_current_value THEN
        IF v_only_field_current_value_format = 'csv' THEN
            SET v_csv = v_csv;
        ELSEIF v_only_field_current_value_format = 'json' THEN
            #              remove last comma
            SET v_csv = api.api_trim_last_n_chars( v_csv , 2 );
            # close array
            SET v_csv = CONCAT( v_csv , CHAR( 13 )
                , ']'
                );
        END IF;
    END IF;
    
    RETURN v_csv;

END;

