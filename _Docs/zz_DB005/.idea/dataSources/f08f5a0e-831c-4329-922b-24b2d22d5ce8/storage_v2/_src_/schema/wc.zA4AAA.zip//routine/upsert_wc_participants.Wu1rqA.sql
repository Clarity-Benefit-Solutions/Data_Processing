CREATE
    DEFINER = root@`%` PROCEDURE upsert_wc_participants(
                                                       IN p_employeeid varchar(50),
                                                       IN p_recordid varchar(50),
                                                       IN p_tpaid varchar(50),
                                                       IN p_employername varchar(50),
                                                       IN p_employerid varchar(50),
                                                       IN p_lastname varchar(50),
                                                       IN p_firstname varchar(50),
                                                       IN p_phone varchar(50),
                                                       IN p_addressline1 varchar(100),
                                                       IN p_addressline2 varchar(100),
                                                       IN p_city varchar(50),
                                                       IN p_state varchar(50),
                                                       IN p_zip varchar(50),
                                                       IN p_country varchar(50),
                                                       IN p_email varchar(200),
                                                       IN p_employeestatus varchar(50),
                                                       IN p_reimbursementmethod varchar(50),
                                                       IN p_birthdate varchar(50),
                                                       IN p_employeessn varchar(50),
                                                       IN p_cardnumber varchar(50),
                                                       IN p_mobilenumber varchar(50) )
BEGIN
    
    -- handle error that may happen as the table has a few unique keys which may conflict
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO,
                @text = MESSAGE_TEXT;
            SET @text = CONCAT( @text , CONCAT( '
Called With Params: ' , ', employeeid: ' , api.api_nz( `p_employeeid` , '' ) , ', recordid: ' ,
                                                api.api_nz( `p_recordid` , '' ) , ', tpaid: ' ,
                                                api.api_nz( `p_tpaid` , '' ) , ', employername: ' ,
                                                api.api_nz( `p_employername` , '' ) , ', employerid: ' ,
                                                api.api_nz( `p_employerid` , '' ) , ', lastname: ' ,
                                                api.api_nz( `p_lastname` , '' ) , ', firstname: ' ,
                                                api.api_nz( `p_firstname` , '' ) , ', phone: ' ,
                                                api.api_nz( `p_phone` , '' ) , ', addressline1: ' ,
                                                api.api_nz( `p_addressline1` , '' ) , ', addressline2: ' ,
                                                api.api_nz( `p_addressline2` , '' ) , ', city: ' ,
                                                api.api_nz( `p_city` , '' ) , ', state: ' ,
                                                api.api_nz( `p_state` , '' ) , ', zip: ' , api.api_nz( `p_zip` , '' ) ,
                                                ', country: ' , api.api_nz( `p_country` , '' ) , ', email: ' ,
                                                api.api_nz( `p_email` , '' ) , ', employeestatus: ' ,
                                                api.api_nz( `p_employeestatus` , '' ) , ', reimbursementmethod: ' ,
                                                api.api_nz( `p_reimbursementmethod` , '' ) , ', birthdate: ' ,
                                                api.api_nz( `p_birthdate` , '' ) , ', employeessn: ' ,
                                                api.api_nz( `p_employeessn` , '' ) , ', cardnumber: ' ,
                                                api.api_nz( `p_cardnumber` , '' ) , ', mobilenumber: ' ,
                                                api.api_nz( `p_mobilenumber` , '' ) ) );
            CALL api.db_log_message( 'upsert_wc_participants' , @text , 'ERROR' );
        END;
    
    CALL api.db_log_message( 'upsert_wc_participants' ,
                             CONCAT( 'Called With Params: ' , ', employeeid: ' , api.api_nz( `p_employeeid` , '' ) ,
                                     ', recordid: ' , api.api_nz( `p_recordid` , '' ) , ', tpaid: ' ,
                                     api.api_nz( `p_tpaid` , '' ) , ', employername: ' ,
                                     api.api_nz( `p_employername` , '' ) , ', employerid: ' ,
                                     api.api_nz( `p_employerid` , '' ) , ', lastname: ' ,
                                     api.api_nz( `p_lastname` , '' ) , ', firstname: ' ,
                                     api.api_nz( `p_firstname` , '' ) , ', phone: ' , api.api_nz( `p_phone` , '' ) ,
                                     ', addressline1: ' , api.api_nz( `p_addressline1` , '' ) , ', addressline2: ' ,
                                     api.api_nz( `p_addressline2` , '' ) , ', city: ' , api.api_nz( `p_city` , '' ) ,
                                     ', state: ' , api.api_nz( `p_state` , '' ) , ', zip: ' ,
                                     api.api_nz( `p_zip` , '' ) , ', country: ' , api.api_nz( `p_country` , '' ) ,
                                     ', email: ' , api.api_nz( `p_email` , '' ) , ', employeestatus: ' ,
                                     api.api_nz( `p_employeestatus` , '' ) , ', reimbursementmethod: ' ,
                                     api.api_nz( `p_reimbursementmethod` , '' ) , ', birthdate: ' ,
                                     api.api_nz( `p_birthdate` , '' ) , ', employeessn: ' ,
                                     api.api_nz( `p_employeessn` , '' ) , ', cardnumber: ' ,
                                     api.api_nz( `p_cardnumber` , '' ) , ', mobilenumber: ' ,
                                     api.api_nz( `p_mobilenumber` , '' ) ) , 'WARN' );
    
    INSERT INTO `wc`.`wc_participants` (
                                       `employeeid`,
                                       `recordid`,
                                       `tpaid`,
                                       `employername`,
                                       `employerid`,
                                       `lastname`,
                                       `firstname`,
                                       `phone`,
                                       `addressline1`,
                                       `addressline2`,
                                       `city`,
                                       `state`,
                                       `zip`,
                                       `country`,
                                       `email`,
                                       `employeestatus`,
                                       `reimbursementmethod`,
                                       `birthdate`,
                                       `employeessn`,
                                       `cardnumber`,
                                       `mobilenumber`
    )
    VALUES (
           `p_employeeid`,
           `p_recordid`,
           `p_tpaid`,
           `p_employername`,
           `p_employerid`,
           `p_lastname`,
           `p_firstname`,
           `p_phone`,
           `p_addressline1`,
           `p_addressline2`,
           `p_city`,
           `p_state`,
           `p_zip`,
           `p_country`,
           `p_email`,
           `p_employeestatus`,
           `p_reimbursementmethod`,
           `p_birthdate`,
           `p_employeessn`,
           `p_cardnumber`,
           `p_mobilenumber`
           )
        
        /* use api_nz to avoid replacing previous value if new value is null or blank */
    ON DUPLICATE KEY
        UPDATE
            `employeeid`          = api.api_nz( `p_employeeid` , `employeeid` ),
            `recordid`            = api.api_nz( `p_recordid` , `recordid` ),
            `tpaid`               = api.api_nz( `p_tpaid` , `tpaid` ),
            `employername`        = api.api_nz( `p_employername` , `employername` ),
            `employerid`          = api.api_nz( `p_employerid` , `employerid` ),
            `lastname`            = api.api_nz( `p_lastname` , `lastname` ),
            `firstname`           = api.api_nz( `p_firstname` , `firstname` ),
            `phone`               = api.api_nz( `p_phone` , `phone` ),
            `addressline1`        = api.api_nz( `p_addressline1` , `addressline1` ),
            `addressline2`        = api.api_nz( `p_addressline2` , `addressline2` ),
            `city`                = api.api_nz( `p_city` , `city` ),
            `state`               = api.api_nz( `p_state` , `state` ),
            `zip`                 = api.api_nz( `p_zip` , `zip` ),
            `country`             = api.api_nz( `p_country` , `country` ),
            /*            2021-03-16 - do not change email once that record (matched by employerid, employeeid has been used for registration by a participant - to ensure we can alwyas sync updated data for that part back to platform users
                         if email has changed to become blank and is not yet is_used_for_registration, replace old email with new email even if new one blank */
            /*`email`               = api.api_nz( `p_email` , `email` ),*/
            `email`               = api.api_if_true_else( is_used_for_registration , email ,
                                                          api.api_nz( p_email , '' ) ),
            /* end*/
            `employeestatus`      = api.api_nz( `p_employeestatus` , `employeestatus` ),
            `reimbursementmethod` = api.api_nz( `p_reimbursementmethod` , `reimbursementmethod` ),
            `birthdate`           = api.api_nz( `p_birthdate` , `birthdate` ),
            `employeessn`         = api.api_nz( `p_employeessn` , `employeessn` ),
            `cardnumber`          = api.api_nz( `p_cardnumber` , `cardnumber` ),
            `mobilenumber`        = api.api_nz( `p_mobilenumber` , `mobilenumber` );

END;

