CREATE
    DEFINER = root@`%` FUNCTION api_trim_last_n_chars(
                                                     p_value text,
                                                     p_trimCharsCount int ) RETURNS text
BEGIN
    IF api.api_is_blank( p_value ) THEN
        RETURN p_value;
    END IF;
    
    IF LENGTH( p_value ) < p_trimCharsCount THEN
        RETURN p_value;
    END IF;
    
    RETURN LEFT( p_value , LENGTH( p_value ) - p_trimCharsCount );

END;

