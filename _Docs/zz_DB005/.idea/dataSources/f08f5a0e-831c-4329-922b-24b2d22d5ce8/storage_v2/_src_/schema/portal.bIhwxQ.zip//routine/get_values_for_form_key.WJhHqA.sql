CREATE
    DEFINER = root@`%` FUNCTION get_values_for_form_key(
                                                       p_form_item_key varchar(50),
                                                       p_add_header int,
                                                       p_page_name varchar(200),
                                                       p_repeater_field_name varchar(200),
                                                       p_only_for_field_key varchar(200),
                                                       p_only_field_current_value int ) RETURNS longtext
BEGIN
    
    DECLARE v_csv longtext;
    
    DECLARE v_item_id integer;
    DECLARE v_item_created_at timestamp;
    DECLARE v_audit_item_created_at timestamp;
    DECLARE v_entry_created_at timestamp;
    DECLARE v_audit_item_id integer;
    
    DECLARE v_debug int DEFAULT 0;
    
    -- get id of item
    SELECT
        id
      , created_at
    INTO v_item_id , v_item_created_at
    FROM
        portal.cl_frm_items
    WHERE
        item_key = p_form_item_key;
    
    -- get time entry was first created from audit table
    SELECT
        id
      , created_at
    INTO v_audit_item_id, v_audit_item_created_at
    FROM
        portal.cl_frm_items_audit
    WHERE
        /*sumeet: added - ensure we take the same item_id that the current entry points casde entry was recreated and duplicate entry token fixed*/
                -- item_key = p_form_item_key
        /*AND */id = v_item_id
      AND       auditaction = 'INSERT'
    ORDER BY
        cl_frm_items_audit.created_at DESC
    LIMIT 1;
    
    --
    SET v_entry_created_at = v_audit_item_created_at;
    IF api.api_is_blank( v_entry_created_at ) THEN
        IF v_debug THEN
            CALL api.db_log_message( 'get_values_for_form_key' ,
                                     CONCAT( 'Could not get Audit Entry Created at for Item Id: ' ,
                                             api.api_nz2( v_item_id ) ,
                                             ' and   Item Key:  ' , api.api_nz2( p_form_item_key ) ) , 'WARN' );
        END IF;
        -- take a very early date so everything will show as Changes
        SET v_entry_created_at = v_item_created_at;
    END IF;
    
    IF v_debug THEN
        CALL api.db_log_message( 'get_values_for_form_key' ,
                                 CONCAT( 'Using ' , ' Entry Created Time:  ' , api.api_nz2( v_entry_created_at ) ,
                                         ' for ' 'Entry Item ID ' , v_item_id , 'Item Created at ' ,
                                         api.api_nz2( v_item_created_at ) ,
                                         'Audit Entry Item ID ' , api.api_nz2( v_audit_item_id ) ,
                                         'Audit Item Created at ' ,
                                         api.api_nz2( v_entry_created_at ) ) , 'WARN' );
    END IF;
    -- add one minute
    SET v_entry_created_at = TIMESTAMPADD( MINUTE , 1 , v_entry_created_at );
    
    SET v_csv = portal.get_values_for_form_entry( v_entry_created_at , v_item_id , p_add_header , p_page_name ,
                                                  p_repeater_field_name , p_only_for_field_key ,
                                                  p_only_field_current_value );
    
    RETURN v_csv;

END;

