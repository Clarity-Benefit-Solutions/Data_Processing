CREATE
    DEFINER = root@`%` PROCEDURE upsert_el_employer_users(
                                                         IN p_employer_id varchar(30),
                                                         IN p_first_name varchar(200),
                                                         IN p_last_name varchar(200),
                                                         IN p_allow_get_current_sessions varchar(5),
                                                         IN p_allow_to_uplod_a_payroll_file varchar(5),
                                                         IN p_email varchar(200),
                                                         IN p_middle_initial varchar(50),
                                                         IN p_name_prefix varchar(50),
                                                         IN p_phone varchar(50),
                                                         IN p_profile_name varchar(75),
                                                         IN p_status varchar(50),
                                                         IN p_tpa_id varchar(50),
                                                         IN p_user_id varchar(200) )
BEGIN
    
    -- handle error that may happen as the table has a few unique keys which may conflict
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO,
                @text = MESSAGE_TEXT;
            SET @text = CONCAT( @text , CONCAT( '
Called With Params: ' , ', employer_id: ' , api.api_nz( `p_employer_id` , '' ) , ', first_name: ' ,
                                                api.api_nz( `p_first_name` , '' ) , ', last_name: ' ,
                                                api.api_nz( `p_last_name` , '' ) , ', allow_get_current_sessions: ' ,
                                                api.api_nz( `p_allow_get_current_sessions` , '' ) ,
                                                ', allow_to_uplod_a_payroll_file: ' ,
                                                api.api_nz( `p_allow_to_uplod_a_payroll_file` , '' ) , ', email: ' ,
                                                api.api_nz( `p_email` , '' ) , ', middle_initial: ' ,
                                                api.api_nz( `p_middle_initial` , '' ) , ', name_prefix: ' ,
                                                api.api_nz( `p_name_prefix` , '' ) , ', phone: ' ,
                                                api.api_nz( `p_phone` , '' ) , ', profile_name: ' ,
                                                api.api_nz( `p_profile_name` , '' ) , ', status: ' ,
                                                api.api_nz( `p_status` , '' ) , ', tpa_id: ' ,
                                                api.api_nz( `p_tpa_id` , '' ) , ', user_id: ' ,
                                                api.api_nz( `p_user_id` , '' ) ) );
            CALL api.db_log_message( 'upsert_el_employer_users' , @text , 'ERROR' );
        END;
    
    CALL api.db_log_message( 'upsert_el_employer_users' ,
                             CONCAT( 'Called With Params: ' , ', employer_id: ' , api.api_nz( `p_employer_id` , '' ) ,
                                     ', first_name: ' , api.api_nz( `p_first_name` , '' ) , ', last_name: ' ,
                                     api.api_nz( `p_last_name` , '' ) , ', allow_get_current_sessions: ' ,
                                     api.api_nz( `p_allow_get_current_sessions` , '' ) ,
                                     ', allow_to_uplod_a_payroll_file: ' ,
                                     api.api_nz( `p_allow_to_uplod_a_payroll_file` , '' ) , ', email: ' ,
                                     api.api_nz( `p_email` , '' ) , ', middle_initial: ' ,
                                     api.api_nz( `p_middle_initial` , '' ) , ', name_prefix: ' ,
                                     api.api_nz( `p_name_prefix` , '' ) , ', phone: ' , api.api_nz( `p_phone` , '' ) ,
                                     ', profile_name: ' , api.api_nz( `p_profile_name` , '' ) , ', status: ' ,
                                     api.api_nz( `p_status` , '' ) , ', tpa_id: ' , api.api_nz( `p_tpa_id` , '' ) ,
                                     ', user_id: ' , api.api_nz( `p_user_id` , '' ) ) , 'WARN' );
    
    INSERT INTO `el`.`el_employer_users` (
                                         `employer_id`,
                                         `first_name`,
                                         `last_name`,
                                         `allow_get_current_sessions`,
                                         `allow_to_uplod_a_payroll_file`,
                                         `email`,
                                         `middle_initial`,
                                         `name_prefix`,
                                         `phone`,
                                         `profile_name`,
                                         `status`,
                                         `tpa_id`,
                                         `user_id`
    )
    
    VALUES (
           `p_employer_id`,
           `p_first_name`,
           `p_last_name`,
           `p_allow_get_current_sessions`,
           `p_allow_to_uplod_a_payroll_file`,
           `p_email`,
           `p_middle_initial`,
           `p_name_prefix`,
           `p_phone`,
           `p_profile_name`,
           `p_status`,
           `p_tpa_id`,
           `p_user_id`
           )
        
        /* use api_nz to avoid replacing previous value if new value is null or blank */
    ON DUPLICATE KEY
        UPDATE
            `employer_id`                   = api.api_nz( `p_employer_id` , `employer_id` ),
            `first_name`                    = api.api_nz( `p_first_name` , `first_name` ),
            `last_name`                     = api.api_nz( `p_last_name` , `last_name` ),
            `allow_get_current_sessions`    = api.api_nz( `p_allow_get_current_sessions` ,
                                                          `allow_get_current_sessions` ),
            `allow_to_uplod_a_payroll_file` = api.api_nz( `p_allow_to_uplod_a_payroll_file` ,
                                                          `allow_to_uplod_a_payroll_file` ),
            `email`                         = api.api_nz( `p_email` , `email` ),
            `middle_initial`                = api.api_nz( `p_middle_initial` , `middle_initial` ),
            `name_prefix`                   = api.api_nz( `p_name_prefix` , `name_prefix` ),
            `phone`                         = api.api_nz( `p_phone` , `phone` ),
            `profile_name`                  = api.api_nz( `p_profile_name` , `profile_name` ),
            `status`                        = api.api_nz( `p_status` , `status` ),
            `tpa_id`                        = api.api_nz( `p_tpa_id` , `tpa_id` ),
            `user_id`                       = api.api_nz( `p_user_id` , `user_id` );

END;

