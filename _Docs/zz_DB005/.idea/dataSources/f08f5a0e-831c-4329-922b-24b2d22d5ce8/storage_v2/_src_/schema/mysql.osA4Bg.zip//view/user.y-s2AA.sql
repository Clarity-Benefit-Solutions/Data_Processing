CREATE VIEW user
AS
    SELECT
        `mysql`.`global_priv`.`Host` `Host`
      , `mysql`.`global_priv`.`User` `User`
      , IF( JSON_VALUE( `mysql`.`global_priv`.`Priv` , '$.plugin' ) IN ('mysql_native_password', 'mysql_old_password') ,
            IFNULL( JSON_VALUE( `mysql`.`global_priv`.`Priv` , '$.authentication_string' ) , '' ) , '' ) `Password`
      , IF( JSON_VALUE( `mysql`.`global_priv`.`Priv` , '$.access' ) & 1 , 'Y' , 'N' ) `Select_priv`
      , IF( JSON_VALUE( `mysql`.`global_priv`.`Priv` , '$.access' ) & 2 , 'Y' , 'N' ) `Insert_priv`
      , IF( JSON_VALUE( `mysql`.`global_priv`.`Priv` , '$.access' ) & 4 , 'Y' , 'N' ) `Update_priv`
      , IF( JSON_VALUE( `mysql`.`global_priv`.`Priv` , '$.access' ) & 8 , 'Y' , 'N' ) `Delete_priv`
      , IF( JSON_VALUE( `mysql`.`global_priv`.`Priv` , '$.access' ) & 16 , 'Y' , 'N' ) `Create_priv`
      , IF( JSON_VALUE( `mysql`.`global_priv`.`Priv` , '$.access' ) & 32 , 'Y' , 'N' ) `Drop_priv`
      , IF( JSON_VALUE( `mysql`.`global_priv`.`Priv` , '$.access' ) & 64 , 'Y' , 'N' ) `Reload_priv`
      , IF( JSON_VALUE( `mysql`.`global_priv`.`Priv` , '$.access' ) & 128 , 'Y' , 'N' ) `Shutdown_priv`
      , IF( JSON_VALUE( `mysql`.`global_priv`.`Priv` , '$.access' ) & 256 , 'Y' , 'N' ) `Process_priv`
      , IF( JSON_VALUE( `mysql`.`global_priv`.`Priv` , '$.access' ) & 512 , 'Y' , 'N' ) `File_priv`
      , IF( JSON_VALUE( `mysql`.`global_priv`.`Priv` , '$.access' ) & 1024 , 'Y' , 'N' ) `Grant_priv`
      , IF( JSON_VALUE( `mysql`.`global_priv`.`Priv` , '$.access' ) & 2048 , 'Y' , 'N' ) `References_priv`
      , IF( JSON_VALUE( `mysql`.`global_priv`.`Priv` , '$.access' ) & 4096 , 'Y' , 'N' ) `Index_priv`
      , IF( JSON_VALUE( `mysql`.`global_priv`.`Priv` , '$.access' ) & 8192 , 'Y' , 'N' ) `Alter_priv`
      , IF( JSON_VALUE( `mysql`.`global_priv`.`Priv` , '$.access' ) & 16384 , 'Y' , 'N' ) `Show_db_priv`
      , IF( JSON_VALUE( `mysql`.`global_priv`.`Priv` , '$.access' ) & 32768 , 'Y' , 'N' ) `Super_priv`
      , IF( JSON_VALUE( `mysql`.`global_priv`.`Priv` , '$.access' ) & 65536 , 'Y' , 'N' ) `Create_tmp_table_priv`
      , IF( JSON_VALUE( `mysql`.`global_priv`.`Priv` , '$.access' ) & 131072 , 'Y' , 'N' ) `Lock_tables_priv`
      , IF( JSON_VALUE( `mysql`.`global_priv`.`Priv` , '$.access' ) & 262144 , 'Y' , 'N' ) `Execute_priv`
      , IF( JSON_VALUE( `mysql`.`global_priv`.`Priv` , '$.access' ) & 524288 , 'Y' , 'N' ) `Repl_slave_priv`
      , IF( JSON_VALUE( `mysql`.`global_priv`.`Priv` , '$.access' ) & 1048576 , 'Y' , 'N' ) `Repl_client_priv`
      , IF( JSON_VALUE( `mysql`.`global_priv`.`Priv` , '$.access' ) & 2097152 , 'Y' , 'N' ) `Create_view_priv`
      , IF( JSON_VALUE( `mysql`.`global_priv`.`Priv` , '$.access' ) & 4194304 , 'Y' , 'N' ) `Show_view_priv`
      , IF( JSON_VALUE( `mysql`.`global_priv`.`Priv` , '$.access' ) & 8388608 , 'Y' , 'N' ) `Create_routine_priv`
      , IF( JSON_VALUE( `mysql`.`global_priv`.`Priv` , '$.access' ) & 16777216 , 'Y' , 'N' ) `Alter_routine_priv`
      , IF( JSON_VALUE( `mysql`.`global_priv`.`Priv` , '$.access' ) & 33554432 , 'Y' , 'N' ) `Create_user_priv`
      , IF( JSON_VALUE( `mysql`.`global_priv`.`Priv` , '$.access' ) & 67108864 , 'Y' , 'N' ) `Event_priv`
      , IF( JSON_VALUE( `mysql`.`global_priv`.`Priv` , '$.access' ) & 134217728 , 'Y' , 'N' ) `Trigger_priv`
      , IF( JSON_VALUE( `mysql`.`global_priv`.`Priv` , '$.access' ) & 268435456 , 'Y' , 'N' ) `Create_tablespace_priv`
      , IF( JSON_VALUE( `mysql`.`global_priv`.`Priv` , '$.access' ) & 536870912 , 'Y' , 'N' ) `Delete_history_priv`
      , ELT( IFNULL( JSON_VALUE( `mysql`.`global_priv`.`Priv` , '$.ssl_type' ) , 0 ) + 1 , '' , 'ANY' , 'X509' ,
             'SPECIFIED' ) `ssl_type`
      , IFNULL( JSON_VALUE( `mysql`.`global_priv`.`Priv` , '$.ssl_cipher' ) , '' ) `ssl_cipher`
      , IFNULL( JSON_VALUE( `mysql`.`global_priv`.`Priv` , '$.x509_issuer' ) , '' ) `x509_issuer`
      , IFNULL( JSON_VALUE( `mysql`.`global_priv`.`Priv` , '$.x509_subject' ) , '' ) `x509_subject`
      , CAST( IFNULL( JSON_VALUE( `mysql`.`global_priv`.`Priv` , '$.max_questions' ) , 0 ) AS unsigned ) `max_questions`
      , CAST( IFNULL( JSON_VALUE( `mysql`.`global_priv`.`Priv` , '$.max_updates' ) , 0 ) AS unsigned ) `max_updates`
      , CAST( IFNULL( JSON_VALUE( `mysql`.`global_priv`.`Priv` , '$.max_connections' ) ,
                      0 ) AS unsigned ) `max_connections`
      , CAST( IFNULL( JSON_VALUE( `mysql`.`global_priv`.`Priv` , '$.max_user_connections' ) ,
                      0 ) AS signed ) `max_user_connections`
      , IFNULL( JSON_VALUE( `mysql`.`global_priv`.`Priv` , '$.plugin' ) , '' ) `plugin`
      , IFNULL( JSON_VALUE( `mysql`.`global_priv`.`Priv` , '$.authentication_string' ) , '' ) `authentication_string`
      , 'N' `password_expired`
      , ELT( IFNULL( JSON_VALUE( `mysql`.`global_priv`.`Priv` , '$.is_role' ) , 0 ) + 1 , 'N' , 'Y' ) `is_role`
      , IFNULL( JSON_VALUE( `mysql`.`global_priv`.`Priv` , '$.default_role' ) , '' ) `default_role`
      , CAST( IFNULL( JSON_VALUE( `mysql`.`global_priv`.`Priv` , '$.max_statement_time' ) ,
                      0.0 ) AS decimal(12, 6) ) `max_statement_time`
    FROM
        `mysql`.`global_priv`;

