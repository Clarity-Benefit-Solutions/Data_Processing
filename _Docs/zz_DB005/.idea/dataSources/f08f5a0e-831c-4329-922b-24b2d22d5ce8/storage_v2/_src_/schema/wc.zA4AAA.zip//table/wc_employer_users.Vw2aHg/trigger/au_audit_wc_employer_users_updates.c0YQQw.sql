CREATE DEFINER = root@`%` TRIGGER au_audit_wc_employer_users_updates
    AFTER UPDATE
    ON wc_employer_users
    FOR EACH ROW
    INSERT INTO `wc`.`wc_employer_users_audit`
                 (
                 `auditAction`,
                 `row_id`,
                 `employer_id`,
                 `first_name`,
                 `last_name`,
                 `allow_get_current_sessions`,
                 `allow_to_uplod_a_payroll_file`,
                 `email`,
                 `middle_initial`,
                 `name_prefix`,
                 `phone`,
                 `profile_name`,
                 `status`,
                 `tpa_id`,
                 `user_id`,
                 `created_at`,
                 `created_by`,
                 `updated_at`,
                 `updated_by`
                 )
                 VALUES (
                        'UPDATE',
                        NEW.`row_id`,
                        NEW.`employer_id`,
                        NEW.`first_name`,
                        NEW.`last_name`,
                        NEW.`allow_get_current_sessions`,
                        NEW.`allow_to_uplod_a_payroll_file`,
                        NEW.`email`,
                        NEW.`middle_initial`,
                        NEW.`name_prefix`,
                        NEW.`phone`,
                        NEW.`profile_name`,
                        NEW.`status`,
                        NEW.`tpa_id`,
                        NEW.`user_id`,
                        NEW.`created_at`,
                        NEW.`created_by`,
                        NEW.`updated_at`,
                        NEW.`updated_by`
                        );

