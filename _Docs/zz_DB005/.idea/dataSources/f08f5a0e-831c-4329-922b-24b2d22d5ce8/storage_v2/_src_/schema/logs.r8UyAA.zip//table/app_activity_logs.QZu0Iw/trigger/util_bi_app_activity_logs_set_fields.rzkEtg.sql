CREATE DEFINER = root@`%` TRIGGER util_bi_app_activity_logs_set_fields
    BEFORE INSERT
    ON app_activity_logs
    FOR EACH ROW
BEGIN
    declare v_days int default 30;
    
    set new.retain_for_no_of_days =
            logs.get_retain_for_no_of_days( new.event_source , new.event_type , new.event_status );

END;

