CREATE
    DEFINER = root@`%` PROCEDURE truncate_el_all_employers_users_participants(
    IN dummy int(1) )
BEGIN
    CALL api.db_show_message( 'truncate_el_employees_employers' , 'Returning without any action' );
    
    /*  CALL api.db_show_message( 'truncate_el_employees_employers' , 'STARTING' );
      
      TRUNCATE TABLE el.el_employer_plans;
      TRUNCATE TABLE el.el_employers;
      TRUNCATE TABLE el.el_participants;
      
      #   do not remove TPA users as we move the file after each import....
      DELETE
      FROM
          el.el_employer_users
      WHERE
          NOT api.api_is_blank( employer_id );
      
      CALL api.db_show_message( 'truncate_el_employees_employers' , 'FINISHED' );*/

END;

