CREATE DEFINER = admin@`%` TRIGGER util_bu_cl_frm_item_metas_set_updated_at_and_by
    BEFORE UPDATE
    ON cl_frm_item_metas
    FOR EACH ROW
BEGIN
    SET new.created_at = old.created_at;
    SET new.created_by = old.created_by;
    SET new.updated_at = now();
    SET new.updated_by = current_user;
END;

