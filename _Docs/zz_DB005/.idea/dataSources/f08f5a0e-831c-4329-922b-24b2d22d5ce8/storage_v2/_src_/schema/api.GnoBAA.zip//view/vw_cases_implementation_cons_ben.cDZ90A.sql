CREATE VIEW vw_cases_implementation_cons_ben
AS
    SELECT
        `a`.`case_id` `case_id`
      , `a`.`employer_name` `employer_name`
      , `a`.`employer_id` `employer_id`
      , `a`.`case_sub_type` `case_sub_type`
      , `api`.`get_sf_case_owner_fullname`( `a`.`sf_case_owner_user_id` ) `sf_case_owner_fullname`
      , `a`.`is_ready_for_processing` `is_ready_for_processing`
      , SUBSTR( `a`.`last_rollout_error` , 1 , 150 ) `last_rollout_error`
      , `a`.`form_invite_token` `form_invite_token`
      , `a`.`wizard_curr_step_no` `wizard_curr_step_no`
      , `a`.`form_curr_page_no` `form_curr_page_no`
      , `a`.`sf_case_id` `sf_case_id`
      , GROUP_CONCAT( DISTINCT CASE
                                   WHEN (`c`.`plan_name` <> '' OR `c`.`plan_name` <> NULL) THEN `c`.`plan_name`
                                   ELSE CASE
                                            WHEN (`c`.`plan_sub_type` <> '' OR `c`.`plan_sub_type` <> NULL)
                                                THEN `c`.`plan_sub_type`
                                            ELSE `c`.`plan_type`
                                        END
                               END ORDER BY `c`.`plan_name` ASC , `c`.`plan_sub_type` ASC , `c`.`plan_name` ASC
                      SEPARATOR ', ' ) `plan_type`
      , MIN( `c`.`plan_year_renewal_date` ) `renewal_date`
      , 'View' `lable`
      , `a`.`case_status` `case_status`
      , CASE
            WHEN (`a`.`case_status` LIKE 'New%' OR `a`.`case_status` LIKE 'Ready For Entry%') THEN 'Waiting'
            WHEN `a`.`case_status` LIKE 'Cancelled%' THEN 'Cancelled'
            ELSE 'Rolled Out'
        END `major_case_status`
      , CONCAT( 'https://portal.claritybenefitsolutions.com' , '/renewals/' , CASE
                                                                                  WHEN `a`.`case_sub_type` = 'CONSUMER_BENEFIT'
                                                                                      THEN 'consumer-benefits'
                                                                                  ELSE 'cobra-benefits'
                                                                              END , '/step-' , 1 , '/?token=' ,
                `a`.`form_invite_token` , '&show_summary=1&frm_page=' , CASE
                                                                            WHEN `a`.`form_curr_page_no` < 1 THEN 1
                                                                            ELSE `a`.`form_curr_page_no`
                                                                        END ) `url`
      , MIN( `b`.`contact_first_name` ) `contact_first_name`
      , MIN( `b`.`contact_last_name` ) `contact_last_name`
      , MIN( `b`.`contact_email` ) `contact_email`
      , MIN( `b`.`contact_phone` ) `contact_phone`
      , `api`.`get_case_status_history`( `a`.`form_invite_token` , 1 ) `current_status_time`
      , `api`.`get_case_notification_history`( `a`.`case_id` , 1 , 'email' , 'Renewal Portal' ,
                                               `a`.`case_sub_type` ) `last_outreach_at`
    FROM
        ((`api`.`api_cases` `a` JOIN `api`.`api_case_contacts` `b` ON (`b`.`case_id` = `a`.`case_id`))
            LEFT JOIN `api`.`api_case_plans_cons_ben` `c` ON (`c`.`case_id` = `a`.`case_id`))
    WHERE
          `a`.`case_type` = 'Implementation'
      AND `a`.`case_sub_type` = 'CONSUMER_BENEFIT'
      AND `b`.`contact_is_cons_ben_contact` = 1
    GROUP BY
        `a`.`case_id`
      , `a`.`employer_name`
      , `a`.`employer_id`
      , `a`.`case_sub_type`
      , `a`.`form_invite_token`
      , `a`.`wizard_curr_step_no`
      , `a`.`form_curr_page_no`
      , `a`.`sf_case_id`
      , `c`.`plan_year_renewal_date`
      , `a`.`case_status`
    ORDER BY
        `c`.`plan_year_renewal_date`
      , `a`.`employer_name`;

