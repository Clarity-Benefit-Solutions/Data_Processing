CREATE VIEW vw_sso_platform_cp
AS
    SELECT
        CASE
            WHEN `t`.`ROW_ID` = `api`.`sso_get_record_for_cp`( `t`.`email` ) THEN 1
            ELSE 0
        END `is_sso_record`
      , `t`.`email` `email`
      , `t`.`is_active` `is_active`
      , `t`.`user_type` `user_type`
      , `t`.`ROW_ID` `ROW_ID`
      , `t`.`orderseq` `orderseq`
      , `t`.`entitytype` `entitytype`
      , `t`.`memberid` `memberid`
      , `t`.`brokerid` `brokerid`
      , `t`.`clientcontactid` `clientcontactid`
      , `t`.`clientid` `clientid`
      , `t`.`clientdivisionid` `clientdivisionid`
      , `t`.`individualidentifier` `individualidentifier`
      , `t`.`contacttype` `contacttype`
      , `t`.`salutation` `salutation`
      , `t`.`firstname` `firstname`
      , `t`.`lastname` `lastname`
      , `t`.`title` `title`
      , `t`.`department` `department`
      , `t`.`phone` `phone`
      , `t`.`phone2` `phone2`
      , `t`.`city` `city`
      , `t`.`state` `state`
      , `t`.`postalcode` `postalcode`
      , `t`.`country` `country`
      , `t`.`active` `active`
      , `t`.`loginstatus` `loginstatus`
      , `t`.`registrationcode` `registrationcode`
      , `t`.`registrationdate` `registrationdate`
      , `t`.`userdisplayname` `userdisplayname`
      , `t`.`allowsso` `allowsso`
      , `t`.`ssoidentifier` `ssoidentifier`
      , `t`.`userid` `userid`
      , `t`.`ssn` `ssn`
      , `t`.`employeeid` `employeeid`
      , `t`.`created_at` `created_at`
      , `t`.`created_by` `created_by`
      , `t`.`updated_at` `updated_at`
      , `t`.`updated_by` `updated_by`
    FROM
        `cp`.`vw_cp_all_sso_users` `t`;

