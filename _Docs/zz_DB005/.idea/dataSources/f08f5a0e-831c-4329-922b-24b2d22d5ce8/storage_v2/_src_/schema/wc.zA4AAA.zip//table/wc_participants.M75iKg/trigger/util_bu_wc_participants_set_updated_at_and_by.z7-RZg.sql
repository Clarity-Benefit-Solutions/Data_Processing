CREATE DEFINER = root@`%` TRIGGER util_bu_wc_participants_set_updated_at_and_by
    BEFORE UPDATE
    ON wc_participants
    FOR EACH ROW
begin
    set new.updated_at = current_timestamp;
    set new.updated_by = current_user;
    
    /* columns used in unique key*/
    set new.email = api.api_nz( new.email , '' );
    set new.cardnumber = api.api_nz( new.cardnumber , '' );
    set new.employeessn = api.api_nz( new.employeessn , '' );
    set new.birthdate = api.api_nz( new.birthdate , '' );
    set new.zip = api.api_nz( new.zip , '' );

end;

