CREATE
    DEFINER = root@`%` FUNCTION ts_get_participant_platforms(
                                                            p_employee_row_id int,
                                                            p_flag varchar(50) ) RETURNS text
BEGIN
    DECLARE v_ret text DEFAULT '';
    DECLARE v_value_to_match float DEFAULT 0;
    
    IF api.api_is_blank( p_employee_row_id ) THEN
        SET v_ret = '';
    END IF;
    
    IF p_flag IN ('registered', 'active') THEN
        SET v_value_to_match = 0;
    ELSE
        SET v_value_to_match = 1;
    END IF;
    
    SELECT
        GROUP_CONCAT( DISTINCT payer_name )
    INTO v_ret
    FROM
        misc.tpa_participant_policies p
            INNER JOIN misc.tpa_participants e ON e.tpa_employee_id = p.tpa_employee_id
    WHERE
          e.row_id = p_employee_row_id
      AND login_needs_correction = v_value_to_match;
    
    RETURN
        api.api_nz( v_ret , '' );

END;

