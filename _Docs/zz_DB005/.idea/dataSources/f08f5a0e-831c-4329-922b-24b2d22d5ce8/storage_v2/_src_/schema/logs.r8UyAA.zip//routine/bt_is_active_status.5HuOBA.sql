CREATE
    DEFINER = root@`%` FUNCTION bt_is_active_status(
    p_status varchar(200) ) RETURNS float
BEGIN
    IF api.api_is_blank( p_status ) THEN
        RETURN 0.0;
    END IF;
    
    SET p_status = upper( p_status );
    
    CASE WHEN p_status IN ('ACTIVE', 'NEW') THEN RETURN 1.0; WHEN p_status IN ('CANCELLED', 'INACTIVE') THEN RETURN 0.0; ELSE RETURN 0.0;
    END CASE;

END;

