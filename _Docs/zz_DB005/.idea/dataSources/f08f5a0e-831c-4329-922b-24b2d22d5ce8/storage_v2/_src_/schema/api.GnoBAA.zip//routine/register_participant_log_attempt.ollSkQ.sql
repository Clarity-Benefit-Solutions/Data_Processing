CREATE
    DEFINER = root@`%` PROCEDURE register_participant_log_attempt(
                                                                 IN p_attempt_type varchar(200),
                                                                 IN p_invite_token varchar(200),
                                                                 IN p_email varchar(200),
                                                                 IN p_first_name varchar(200),
                                                                 IN p_last_name varchar(200),
                                                                 IN p_mobile_number varchar(200),
                                                                 IN p_ssn varchar(200),
                                                                 IN p_employer_id varchar(200),
                                                                 IN p_employee_id varchar(200),
                                                                 IN p_dob varchar(200),
                                                                 IN p_zip varchar(200),
                                                                 IN p_card_number varchar(200),
                                                                 IN p_ignore_email_mismatch int,
                                                                 IN v_matched_user_id int,
                                                                 IN v_matched_row_ids text,
                                                                 IN v_internal_messages text,
                                                                 IN v_user_messages text,
                                                                 IN v_status varchar(200),
                                                                 IN v_email_status longtext,
                                                                 IN v_error_message longtext )
full_proc:

BEGIN
    INSERT INTO api.registration_log (
                                     attempt_type,
                                     invite_token,
                                     email,
                                     first_name,
                                     last_name,
                                     mobile_number,
                                     ssn,
                                     employer_id,
                                     employee_id,
                                     dob,
                                     zip,
                                     card_number,
                                     matched_user_id,
                                     matched_row_ids,
                                     internal_messages,
                                     user_messages,
                                     status,
                                     email_status,
                                     error_message,
                                     ignore_email_mismatch
    )
    VALUES (
           p_attempt_type,
           p_invite_token,
           p_email,
           p_first_name,
           p_last_name,
           p_mobile_number,
           p_ssn,
           p_employer_id,
           p_employee_id,
           p_dob,
           p_zip,
           p_card_number,
           v_matched_user_id,
           v_matched_row_ids,
           v_internal_messages,
           v_user_messages,
           v_status,
           v_email_status,
           v_error_message,
           p_ignore_email_mismatch
           );
    
    SELECT
        p_attempt_type
      , p_email
      , v_status
      , v_email_status
      , v_error_message
      , v_matched_user_id
      , v_matched_row_ids
      , v_internal_messages
      , v_user_messages
      , p_first_name
      , p_invite_token
      , p_last_name
      , p_mobile_number
      , p_ssn
      , p_employer_id
      , p_employee_id
      , p_dob
      , p_zip
      , p_card_number;
    
    LEAVE full_proc;

END;

