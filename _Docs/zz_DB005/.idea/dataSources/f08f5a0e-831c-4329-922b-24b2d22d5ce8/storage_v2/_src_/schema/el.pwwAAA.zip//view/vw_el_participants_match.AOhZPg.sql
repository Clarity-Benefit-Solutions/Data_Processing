CREATE VIEW vw_el_participants_match
AS
    SELECT
        `vw_el_participants`.`row_id` `row_id`
      , `vw_el_participants`.`email` `email`
      , `vw_el_participants`.`firstname` `firstname`
      , `vw_el_participants`.`lastname` `lastname`
      , `vw_el_participants`.`employeessn` `employeessn`
      , `vw_el_participants`.`cardnumber` `cardnumber`
      , `vw_el_participants`.`mobilenumber` `mobilenumber`
      , `vw_el_participants`.`birthdate` `birthdate`
      , `vw_el_participants`.`employeeid` `employeeid`
      , `vw_el_participants`.`employerid` `employerid`
      , `vw_el_participants`.`phone` `phone`
    FROM
        `el`.`vw_el_participants`;

