CREATE DEFINER = root@`%` TRIGGER au_audit_sf_contacts_updates
    AFTER UPDATE
    ON sf_contacts
    FOR EACH ROW
    INSERT INTO `sf`.`sf_contacts_audit`
                 (
                 `auditAction`,
                 `row_id`,
                 `entitytype`,
                 `clientcode`,
                 `clientname`,
                 `fullname`,
                 `ssn`,
                 `contactid`,
                 `contactstatus`,
                 `is_in_wc`,
                 `is_in_cp`,
                 `is_in_bs`,
                 `is_in_en`,
                 `phone`,
                 `email`,
                 `employeeid`,
                 `isprimarycontact`,
                 `created_at`,
                 `created_by`,
                 `updated_at`,
                 `updated_by`
                 )
                 VALUES (
                        'UPDATE',
                        NEW.`row_id`,
                        NEW.`entitytype`,
                        NEW.`clientcode`,
                        NEW.`clientname`,
                        NEW.`fullname`,
                        NEW.`ssn`,
                        NEW.`contactid`,
                        NEW.`contactstatus`,
                        NEW.`is_in_wc`,
                        NEW.`is_in_cp`,
                        NEW.`is_in_bs`,
                        NEW.`is_in_en`,
                        NEW.`phone`,
                        NEW.`email`,
                        NEW.`employeeid`,
                        NEW.`isprimarycontact`,
                        NEW.`created_at`,
                        NEW.`created_by`,
                        NEW.`updated_at`,
                        NEW.`updated_by`
                        );

