CREATE VIEW vw_get_all_fields_for_form
AS
    SELECT
        `f`.`id` `form_id`
      , `f`.`name` `form_name`
      , `fl`.`id` `field_id`
      , `fl`.`field_key` `field_key`
      , `fl`.`name` `field_name`
      , CASE
            WHEN `fl`.`type` = 'divider' THEN `fl`.`name`
            ELSE ''
        END `repeater_name`
      , `fl`.`description` `field_description`
      , `fl`.`type` `field_type`
      , `fl`.`default_value` `field_default_value`
      , `fl`.`options` `fl_options`
      , `fl`.`field_order` `field_order`
      , `fl`.`required` `field_required`
      , `fl`.`field_options` `field_options`
    FROM
        (`portal`.`cl_frm_fields` `fl`
            JOIN `portal`.`cl_frm_forms` `f` ON (`f`.`id` = `fl`.`form_id`))
    WHERE
        `fl`.`type` <> 'hidden'
    ORDER BY
        `fl`.`form_id`
      , `fl`.`field_order`;

