CREATE DEFINER = admin@`%` TRIGGER util_bu_cl_frm_items_keep_save_draft_always
    BEFORE UPDATE
    ON cl_frm_items
    FOR EACH ROW
BEGIN
    SET new.is_draft = 1;
END;

