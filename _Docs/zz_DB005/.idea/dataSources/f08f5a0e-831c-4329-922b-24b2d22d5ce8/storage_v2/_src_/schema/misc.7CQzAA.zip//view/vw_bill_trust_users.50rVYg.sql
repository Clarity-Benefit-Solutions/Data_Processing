CREATE VIEW vw_bill_trust_users
AS
    SELECT
        `misc`.`bill_trust_users`.`email` `email`
      , `bt_is_active_status`( `misc`.`bill_trust_users`.`status` ) `is_active`
      , '1 CLIENT' `user_type`
      , `misc`.`bill_trust_users`.`row_id` `row_id`
      , `misc`.`bill_trust_users`.`line_of_business` `line_of_business`
      , `misc`.`bill_trust_users`.`account_number` `account_number`
      , `misc`.`bill_trust_users`.`branch_name` `branch_name`
      , `misc`.`bill_trust_users`.`account_name` `account_name`
      , `misc`.`bill_trust_users`.`status` `status`
      , `misc`.`bill_trust_users`.`enrolled_date` `enrolled_date`
      , `misc`.`bill_trust_users`.`send_paper_bill` `send_paper_bill`
      , `misc`.`bill_trust_users`.`created_at` `created_at`
      , `misc`.`bill_trust_users`.`created_by` `created_by`
      , `misc`.`bill_trust_users`.`updated_at` `updated_at`
      , `misc`.`bill_trust_users`.`updated_by` `updated_by`
    FROM
        `misc`.`bill_trust_users`
    WHERE
        !`api`.`upsert_ignore_this_email`( `misc`.`bill_trust_users`.`email` , 'bt' );

