CREATE
    DEFINER = admin@`%` FUNCTION get_all_entry_ids_for_all_form_fields(
    p_form_item_id int ) RETURNS text
BEGIN
    DECLARE v_ret text;

    SELECT group_concat(entries)
    INTO v_ret
    FROM (
             SELECT api.api_getPhpSerializedArrayValues(m.meta_value) AS entries
             FROM portal.cl_frm_item_metas m
                      LEFT JOIN portal.cl_frm_items i ON i.id = m.item_id
                      LEFT JOIN portal.cl_frm_fields f ON (m.field_id = f.id)
             WHERE (m.item_id = p_form_item_id)
               AND m.field_id <> 0
               AND f.type = 'divider'
         ) AS t;

    
    SET v_ret = concat(p_form_item_id, ',', v_ret);

    
    SET v_ret = substr(v_ret, 1);
    SET v_ret = substr(v_ret, 1, length(v_ret));

    
    RETURN v_ret;
END;

