CREATE
    DEFINER = root@`%` PROCEDURE upsert_fsa_store_items(
                                                       IN p_expensetypeid varchar(500),
                                                       IN p_label varchar(500),
                                                       IN p_isproduct varchar(500),
                                                       IN p_description longtext,
                                                       IN p_fsaeligibilitytype varchar(500),
                                                       IN p_limitedcarefsaeligibilitytype varchar(500),
                                                       IN p_dependentcarefsaeligibilitytype varchar(500),
                                                       IN p_hsaeligibilitytype varchar(500),
                                                       IN p_hraeligibilitytype varchar(500),
                                                       IN p_learnmorelinkurl varchar(500),
                                                       IN p_learnmorelinktext varchar(500),
                                                       IN p_shoppinglinkurl varchar(500),
                                                       IN p_shoppinglinktext varchar(500),
                                                       IN p_shoppinglinktype varchar(500) )
BEGIN
    
    
    -- handle error that may happen as the table has a few unique keys which may conflict
    DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN
        GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
        SET @text = CONCAT( @text , CONCAT( '
Called With Params: ' , ', expensetypeid: ' , api.api_nz( `p_expensetypeid` , '' ) , ', label: ' ,
                                            api.api_nz( `p_label` , '' ) , ', isproduct: ' ,
                                            api.api_nz( `p_isproduct` , '' ) , ', description: ' ,
                                            api.api_nz( `p_description` , '' ) , ', fsaeligibilitytype: ' ,
                                            api.api_nz( `p_fsaeligibilitytype` , '' ) ,
                                            ', limitedcarefsaeligibilitytype: ' ,
                                            api.api_nz( `p_limitedcarefsaeligibilitytype` , '' ) ,
                                            ', dependentcarefsaeligibilitytype: ' ,
                                            api.api_nz( `p_dependentcarefsaeligibilitytype` , '' ) ,
                                            ', hsaeligibilitytype: ' , api.api_nz( `p_hsaeligibilitytype` , '' ) ,
                                            ', hraeligibilitytype: ' , api.api_nz( `p_hraeligibilitytype` , '' ) ,
                                            ', learnmorelinkurl: ' , api.api_nz( `p_learnmorelinkurl` , '' ) ,
                                            ', learnmorelinktext: ' , api.api_nz( `p_learnmorelinktext` , '' ) ,
                                            ', shoppinglinkurl: ' , api.api_nz( `p_shoppinglinkurl` , '' ) ,
                                            ', shoppinglinktext: ' , api.api_nz( `p_shoppinglinktext` , '' ) ,
                                            ', shoppinglinktype: ' , api.api_nz( `p_shoppinglinktype` , '' ) ) );
        CALL api.db_log_message( 'upsert_fsa_store_items' , CONCAT( 'ERROR: ' , @text ) , 'ERROR' );
    END;
    
    CALL api.db_log_message( 'upsert_fsa_store_items' , CONCAT( 'Called With Params: ' , ', expensetypeid: ' ,
                                                                api.api_nz( `p_expensetypeid` , '' ) , ', label: ' ,
                                                                api.api_nz( `p_label` , '' ) , ', isproduct: ' ,
                                                                api.api_nz( `p_isproduct` , '' ) , ', description: ' ,
                                                                api.api_nz( `p_description` , '' ) ,
                                                                ', fsaeligibilitytype: ' ,
                                                                api.api_nz( `p_fsaeligibilitytype` , '' ) ,
                                                                ', limitedcarefsaeligibilitytype: ' ,
                                                                api.api_nz( `p_limitedcarefsaeligibilitytype` , '' ) ,
                                                                ', dependentcarefsaeligibilitytype: ' ,
                                                                api.api_nz( `p_dependentcarefsaeligibilitytype` , '' ) ,
                                                                ', hsaeligibilitytype: ' ,
                                                                api.api_nz( `p_hsaeligibilitytype` , '' ) ,
                                                                ', hraeligibilitytype: ' ,
                                                                api.api_nz( `p_hraeligibilitytype` , '' ) ,
                                                                ', learnmorelinkurl: ' ,
                                                                api.api_nz( `p_learnmorelinkurl` , '' ) ,
                                                                ', learnmorelinktext: ' ,
                                                                api.api_nz( `p_learnmorelinktext` , '' ) ,
                                                                ', shoppinglinkurl: ' ,
                                                                api.api_nz( `p_shoppinglinkurl` , '' ) ,
                                                                ', shoppinglinktext: ' ,
                                                                api.api_nz( `p_shoppinglinktext` , '' ) ,
                                                                ', shoppinglinktype: ' ,
                                                                api.api_nz( `p_shoppinglinktype` , '' ) ) , 'WARN' );
    
    INSERT INTO `misc`.`fsa_store_items` (
                                         `expensetypeid`,
                                         `label`,
                                         `isproduct`,
                                         `description`,
                                         `fsaeligibilitytype`,
                                         `limitedcarefsaeligibilitytype`,
                                         `dependentcarefsaeligibilitytype`,
                                         `hsaeligibilitytype`,
                                         `hraeligibilitytype`,
                                         `learnmorelinkurl`,
                                         `learnmorelinktext`,
                                         `shoppinglinkurl`,
                                         `shoppinglinktext`,
                                         `shoppinglinktype`
    )
    
    VALUES (
           `p_expensetypeid`,
           `p_label`,
           `p_isproduct`,
           `p_description`,
           `p_fsaeligibilitytype`,
           `p_limitedcarefsaeligibilitytype`,
           `p_dependentcarefsaeligibilitytype`,
           `p_hsaeligibilitytype`,
           `p_hraeligibilitytype`,
           `p_learnmorelinkurl`,
           `p_learnmorelinktext`,
           `p_shoppinglinkurl`,
           `p_shoppinglinktext`,
           `p_shoppinglinktype`
           )
        
        /* use api_nz to avoid replacing previous value if new value is null or blank */
    ON DUPLICATE KEY UPDATE
                         `expensetypeid`                   = api.api_nz( `p_expensetypeid` , `expensetypeid` ),
                         `label`                           = api.api_nz( `p_label` , `label` ),
                         `isproduct`                       = api.api_nz( `p_isproduct` , `isproduct` ),
                         `description`                     = api.api_nz( `p_description` , `description` ),
                         `fsaeligibilitytype`              = api.api_nz( `p_fsaeligibilitytype` , `fsaeligibilitytype` ),
                         `limitedcarefsaeligibilitytype`   = api.api_nz( `p_limitedcarefsaeligibilitytype` ,
                                                                         `limitedcarefsaeligibilitytype` ),
                         `dependentcarefsaeligibilitytype` = api.api_nz( `p_dependentcarefsaeligibilitytype` ,
                                                                         `dependentcarefsaeligibilitytype` ),
                         `hsaeligibilitytype`              = api.api_nz( `p_hsaeligibilitytype` , `hsaeligibilitytype` ),
                         `hraeligibilitytype`              = api.api_nz( `p_hraeligibilitytype` , `hraeligibilitytype` ),
                         `learnmorelinkurl`                = api.api_nz( `p_learnmorelinkurl` , `learnmorelinkurl` ),
                         `learnmorelinktext`               = api.api_nz( `p_learnmorelinktext` , `learnmorelinktext` ),
                         `shoppinglinkurl`                 = api.api_nz( `p_shoppinglinkurl` , `shoppinglinkurl` ),
                         `shoppinglinktext`                = api.api_nz( `p_shoppinglinktext` , `shoppinglinktext` ),
                         `shoppinglinktype`                = api.api_nz( `p_shoppinglinktype` , `shoppinglinktype` );

END;

