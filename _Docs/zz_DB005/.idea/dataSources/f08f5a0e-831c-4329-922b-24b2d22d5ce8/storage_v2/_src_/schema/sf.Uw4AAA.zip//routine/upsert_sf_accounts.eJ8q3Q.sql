CREATE
    DEFINER = root@`%` PROCEDURE upsert_sf_accounts(
                                                   IN p_clientcode varchar(200),
                                                   IN p_clientname varchar(200),
                                                   IN p_clientstatus varchar(200),
                                                   IN p_clienttype varchar(200),
                                                   IN p_if_client_is_active int,
                                                   IN p_if_client_active_start_date datetime )
BEGIN
    
    -- handle error that may happen as the table has a few unique keys which may conflict
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO,
                @text = MESSAGE_TEXT;
            SET @text = CONCAT( @text , CONCAT( '
Called With Params: ' , ', clientcode: ' , api.api_nz( `p_clientcode` , '' ) , ', clientname: ' ,
                                                api.api_nz( `p_clientname` , '' ) , ', clientstatus: ' ,
                                                api.api_nz( `p_clientstatus` , '' ) , ', clienttype: ' ,
                                                api.api_nz( `p_clienttype` , '' ) , ', if_client_is_active: ' ,
                                                api.api_nz( `p_if_client_is_active` , '' ) ,
                                                ', if_client_active_start_date: ' ,
                                                api.api_nz( `p_if_client_active_start_date` , '' ) ) );
            CALL api.db_log_message( 'upsert_sf_accounts' , @text , 'ERROR');
        END;
    
    /* sumeet: do not update if_* - done based on plan_type for accountD*/
    CALL api.db_log_message( 'upsert_sf_accounts' ,
                             CONCAT( 'Called With Params: ' , ', clientcode: ' , api.api_nz( `p_clientcode` , '' ) ,
                                     ', clientname: ' , api.api_nz( `p_clientname` , '' ) , ', clientstatus: ' ,
                                     api.api_nz( `p_clientstatus` , '' ) , ', clienttype: ' ,
                                     api.api_nz( `p_clienttype` , '' ) , ', if_client_is_active: ' ,
                                     api.api_nz( `p_if_client_is_active` , '' ) , ', if_client_active_start_date: ' ,
                                     api.api_nz( `p_if_client_active_start_date` , '' ) ) , 'WARN' );
    
    INSERT INTO `sf`.`sf_accounts` (
                                   `clientcode`,
                                   `clientname`,
                                   `clientstatus`,
                                   `clienttype`
#                                ,    `if_client_is_active`,
#                                    `if_client_active_start_date`
    )
    
    VALUES (
           `p_clientcode`,
           `p_clientname`,
           `p_clientstatus`,
           `p_clienttype`
#         ,   `p_if_client_is_active`,
#            `p_if_client_active_start_date`
           )
        
        /* use api_nz to avoid replacing previous value if new value is null or blank */
    ON DUPLICATE KEY
        UPDATE
            `clientcode`                  = api.api_nz( `p_clientcode` , `clientcode` ),
            `clientname`                  = api.api_nz( `p_clientname` , `clientname` ),
            `clientstatus`                = api.api_nz( `p_clientstatus` , `clientstatus` ),
            `clienttype`                  = api.api_nz( `p_clienttype` , `clienttype` )
# ,            `if_client_is_active`         = api.api_nz_int( `p_if_client_is_active` , `if_client_is_active` ),
#             `if_client_active_start_date` = api.api_nz_date( `p_if_client_active_start_date` ,
#                                                              `if_client_active_start_date` )
    ;

END;

