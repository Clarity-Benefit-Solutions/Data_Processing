CREATE VIEW vw_el_participants
AS
    SELECT
        `el`.`el_participants`.`email` `email`
      , `el_is_active_status`( `el`.`el_participants`.`employeestatus` , `el`.`el_participants`.`employeeid` ,
                               `el`.`el_participants`.`employerid` ) `is_active`
      , `el_is_active_status_employer`( `el`.`el_participants`.`employerid` ) `is_active_employer`
      , '00 EMPLOYEE ' `user_type`
      , `el`.`el_participants`.`row_id` `row_id`
      , `el`.`el_participants`.`employeeid` `employeeid`
      , `el`.`el_participants`.`recordid` `recordid`
      , `el`.`el_participants`.`tpaid` `tpaid`
      , `el`.`el_participants`.`employername` `employername`
      , `el`.`el_participants`.`employerid` `employerid`
      , `el`.`el_participants`.`lastname` `lastname`
      , `el`.`el_participants`.`firstname` `firstname`
      , `el`.`el_participants`.`phone` `phone`
      , `el`.`el_participants`.`addressline1` `addressline1`
      , `el`.`el_participants`.`addressline2` `addressline2`
      , `el`.`el_participants`.`city` `city`
      , `el`.`el_participants`.`state` `state`
      , `el`.`el_participants`.`zip` `zip`
      , `el`.`el_participants`.`country` `country`
      , `el`.`el_participants`.`employeestatus` `employeestatus`
      , `el`.`el_participants`.`reimbursementmethod` `reimbursementmethod`
      , `el`.`el_participants`.`birthdate` `birthdate`
      , `el`.`el_participants`.`employeessn` `employeessn`
      , `el`.`el_participants`.`cardnumber` `cardnumber`
      , `el`.`el_participants`.`mobilenumber` `mobilenumber`
      , `el`.`el_participants`.`created_at` `created_at`
      , `el`.`el_participants`.`created_by` `created_by`
      , `el`.`el_participants`.`updated_at` `updated_at`
      , `el`.`el_participants`.`updated_by` `updated_by`
      , `el`.`el_participants`.`is_used_for_registration` `is_used_for_registration`
    FROM
        `el`.`el_participants`
    WHERE
          !`api`.`upsert_ignore_this_email`( `el`.`el_participants`.`email` , 'wcp' )
      AND !`api`.`upsert_ignore_this_employer_id`( `el`.`el_participants`.`employerid` , 'wcp' );

