CREATE
    DEFINER = root@`%` PROCEDURE upsert_all_bs_platform_contacts_2(
    IN p_email varchar(200) )
full_proc:

BEGIN
    DECLARE v_eeemail varchar(200);
    DECLARE v_is_active varchar(200);
    DECLARE v_user_type varchar(200);
    
    DECLARE v_row_id varchar(200);
    DECLARE v_is_used_for_registration varchar(200);
    DECLARE v_eeclientbencode varchar(200);
    DECLARE v_eedivision varchar(200);
    DECLARE v_eefirstname varchar(200);
    DECLARE v_eelastname varchar(200);
    DECLARE v_eeemployeeid varchar(200);
    DECLARE v_eessn varchar(200);
    DECLARE v_eestatus varchar(200);
    DECLARE v_eeaddress1 varchar(200);
    DECLARE v_eeaddress2 varchar(200);
    DECLARE v_eecity varchar(200);
    DECLARE v_eestate varchar(200);
    DECLARE v_eezip varchar(200);
    DECLARE v_eehomephone varchar(200);
    DECLARE v_eedob varchar(200);
    DECLARE v_eebswiftparticipant varchar(200);
    DECLARE v_eealternateid varchar(200);
    DECLARE v_eeimportuserid varchar(200);
    DECLARE v_eepayrollid varchar(200);
    DECLARE v_eeuserroles varchar(200);
    DECLARE v_eeuserid varchar(200);
    DECLARE v_eeusername varchar(200);
    DECLARE v_eeisemployee varchar(200);
    DECLARE v_eeismanager varchar(200);
    DECLARE v_eeistopdog varchar(200);
    DECLARE v_abbrevurl varchar(200);
    DECLARE v_created_at varchar(200);
    DECLARE v_created_by varchar(200);
    DECLARE v_updated_at varchar(200);
    DECLARE v_updated_by varchar(200);
    
    DECLARE v_finished int;
    DECLARE v_values_cursor CURSOR FOR
        SELECT
            t.is_used_for_registration
          , eeemail
          , is_active
          , user_type
          
          , row_id
          , eeclientbencode
          , eedivision
          , eefirstname
          , eelastname
          , eeemployeeid
          , eessn
          , eestatus
          , eeaddress1
          , eeaddress2
          , eecity
          , eestate
          , eezip
          , eehomephone
          , eeemail
          , eedob
          , eebswiftparticipant
          , eealternateid
          , eeimportuserid
          , eepayrollid
          , eeuserroles
          , eeuserid
          , eeusername
          , eeisemployee
          , eeismanager
          , eeistopdog
          , abbrevurl
          , created_at
          , created_by
          , updated_at
          , updated_by
        FROM
            bs.vw_bs_employees t
        WHERE
            eeemail = p_email
        ORDER BY
            eeemail
          , user_type DESC
          , is_used_for_registration DESC
          , is_active DESC
        LIMIT 1;
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND BEGIN
        SET v_finished = 1;
    END;
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
            CALL db_throw_error( @errno , 'upsert_all_bs_platform_contacts_1' , @text );
        END;
    
    SET @@max_sp_recursion_depth = 12;
    
    OPEN v_values_cursor;
    
    getvalues
    :
    LOOP
        FETCH v_values_cursor INTO v_is_used_for_registration, v_eeemail,
            v_is_active,
            v_user_type
            ,v_row_id
            ,v_eeclientbencode
            ,v_eedivision
            ,v_eefirstname
            ,v_eelastname
            ,v_eeemployeeid
            ,v_eessn
            ,v_eestatus
            ,v_eeaddress1
            ,v_eeaddress2
            ,v_eecity
            ,v_eestate
            ,v_eezip
            ,v_eehomephone
            ,v_eeemail
            ,v_eedob
            ,v_eebswiftparticipant
            ,v_eealternateid
            ,v_eeimportuserid
            ,v_eepayrollid
            ,v_eeuserroles
            ,v_eeuserid
            ,v_eeusername
            ,v_eeisemployee
            ,v_eeismanager
            ,v_eeistopdog
            ,v_abbrevurl
            ,v_created_at
            ,v_created_by
            ,v_updated_at
            ,v_updated_by;
        
        IF v_finished = 1 THEN
            LEAVE getvalues;
        END IF;
        
        IF !api.api_is_blank( v_eeemail ) THEN
            
            CALL api.db_log_message( 'upsert_all_bs_platform_contacts_2' ,
                                     CONCAT(
                                             'Processing BS user for eeemail: ' ,
                                             p_email ,
                                             ' using record with row_id  ' ,
                                             v_row_id ,
                                             ' name: ' ,
                                             v_eefirstname , ' ' , v_eelastname ,
                                             ' dob: ' ,
                                             v_eedob ,
                                             ' and user_type ' ,
                                             v_user_type
                                         ) , 'WARN' );
            
            CALL api.upsert_bs_platform_user(
                    v_eeemail ,
                    v_eeemail ,
                    v_eefirstname ,
                    v_eelastname ,
                    v_eehomephone ,
                    v_eessn
                , v_eeuserid
                , v_eeimportuserid
                , v_eeusername
                , v_eeemployeeid
                , v_eeemail
                , v_eepayrollid
                , v_eedob
                , v_is_active
                , v_eeisemployee
                , v_eeismanager
                , v_eeistopdog
                , v_abbrevurl
                , v_row_id
                , v_eeclientbencode
                , v_eezip
                , v_is_used_for_registration );
        END IF;
    END LOOP getvalues;
END;

