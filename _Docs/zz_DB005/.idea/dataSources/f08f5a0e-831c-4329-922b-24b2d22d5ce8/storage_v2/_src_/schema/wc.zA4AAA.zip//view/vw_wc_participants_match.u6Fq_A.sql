CREATE VIEW vw_wc_participants_match
AS
    SELECT
        `vw_wc_participants`.`row_id` `row_id`
      , `vw_wc_participants`.`email` `email`
      , `vw_wc_participants`.`firstname` `firstname`
      , `vw_wc_participants`.`lastname` `lastname`
      , `vw_wc_participants`.`employeessn` `employeessn`
      , `vw_wc_participants`.`cardnumber` `cardnumber`
      , `vw_wc_participants`.`mobilenumber` `mobilenumber`
      , `vw_wc_participants`.`birthdate` `birthdate`
      , `vw_wc_participants`.`employeeid` `employeeid`
      , `vw_wc_participants`.`employerid` `employerid`
      , `vw_wc_participants`.`phone` `phone`
    FROM
        `wc`.`vw_wc_participants`;

