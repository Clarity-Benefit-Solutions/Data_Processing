CREATE
    DEFINER = root@`%` FUNCTION get_sf_case_owner_fullname(
    p_sf_case_owner_user_id varchar(50) ) RETURNS varchar(200)
BEGIN
    
    declare v_ret varchar(200) default '';
    
    select
        sf_case_owner_full_name
    into v_ret
    from
        sf.case_owner_master
    where
        sf_case_owner_user_id = p_sf_case_owner_user_id
    limit 1;
    
    return ifnull( v_ret , '' );

END;

