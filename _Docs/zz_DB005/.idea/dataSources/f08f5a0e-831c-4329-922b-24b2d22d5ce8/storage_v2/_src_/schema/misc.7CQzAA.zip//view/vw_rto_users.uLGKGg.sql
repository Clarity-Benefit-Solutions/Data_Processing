CREATE VIEW vw_rto_users
AS
    SELECT
        `misc`.`rto_users`.`email` `email`
      , `rto_is_active_status`( 'ACTIVE' ) `is_active`
      , CASE
            WHEN `misc`.`rto_users`.`role` = 'Agent' THEN '3 TPA'
            WHEN `misc`.`rto_users`.`role` = 'Broker' THEN '2 BROKER'
            WHEN `misc`.`rto_users`.`role` = 'Client' THEN '1 CLIENT'
            WHEN `misc`.`rto_users`.`role` IN ('Y', 'N') THEN '000 INVALID'
            ELSE '1 CLIENT'
        END `user_type`
      , `misc`.`rto_users`.`row_id` `row_id`
      , `misc`.`rto_users`.`role` `role`
      , `misc`.`rto_users`.`first_name` `first_name`
      , `misc`.`rto_users`.`last_name` `last_name`
      , `misc`.`rto_users`.`company_name` `company_name`
      , `misc`.`rto_users`.`created_date` `created_date`
      , `misc`.`rto_users`.`group_id` `group_id`
      , `misc`.`rto_users`.`external_id` `external_id`
      , `misc`.`rto_users`.`created_at` `created_at`
      , `misc`.`rto_users`.`created_by` `created_by`
      , `misc`.`rto_users`.`updated_at` `updated_at`
      , `misc`.`rto_users`.`updated_by` `updated_by`
    FROM
        `misc`.`rto_users`
    WHERE
        !`api`.`upsert_ignore_this_email`( `misc`.`rto_users`.`email` , 'rto' );

