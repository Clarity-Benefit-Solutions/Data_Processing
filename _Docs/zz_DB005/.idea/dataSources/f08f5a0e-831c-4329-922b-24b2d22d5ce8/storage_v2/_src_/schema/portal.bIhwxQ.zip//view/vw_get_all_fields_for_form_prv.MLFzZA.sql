CREATE VIEW vw_get_all_fields_for_form_prv
AS
    SELECT
        `t`.`form_id` `form_id`
      , `t`.`form_name` `form_name`
      , CASE
            WHEN (`t`.`field_type` LIKE 'html' AND `t`.`field_description` LIKE '%heading%') THEN `t`.`field_name`
            ELSE ''
        END `page_name`
      , `t`.`field_name` `field_name`
      , CASE
            WHEN `t`.`field_type` = 'divider' THEN `t`.`field_name`
            ELSE ''
        END `repeater_name`
      , `t`.`field_order` `field_order`
      , `t`.`field_key` `field_key`
      , `t`.`field_id` `field_id`
      , `t`.`field_description` `field_description`
      , `t`.`field_default_value` `field_default_value`
      , `t`.`fl_options` `fl_options`
      , `t`.`field_options` `field_options`
      , `t`.`field_required` `field_required`
      , `t`.`field_type` `field_type`
    FROM
        (
            SELECT
                `f`.`id` `form_id`
              , `f`.`name` `form_name`
              , `fl`.`id` `field_id`
              , `fl`.`field_key` `field_key`
              , `fl`.`name` `field_name`
              , `fl`.`description` `field_description`
              , `fl`.`type` `field_type`
              , `fl`.`default_value` `field_default_value`
              , `fl`.`options` `fl_options`
              , `fl`.`field_order` `field_order`
              , `fl`.`required` `field_required`
              , `fl`.`field_options` `field_options`
            FROM
                (`portal`.`cl_frm_fields` `fl`
                    JOIN `portal`.`cl_frm_forms` `f` ON (`f`.`id` = `fl`.`form_id`))
            WHERE
                `fl`.`type` <> 'hidden'
        ) `t`;

