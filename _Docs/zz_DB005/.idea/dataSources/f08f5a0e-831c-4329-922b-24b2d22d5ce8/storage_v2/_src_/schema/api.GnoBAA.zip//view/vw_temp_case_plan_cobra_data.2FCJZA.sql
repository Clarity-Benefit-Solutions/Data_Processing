CREATE VIEW vw_temp_case_plan_cobra_data
AS
    SELECT
        `c`.`case_id` `case_id`
      , `c`.`employer_name` `employer_name`
      , `p`.`case_plan_id` `case_plan_id`
      , `p`.`status` `status`
      , `p`.`plan_type` `plan_type`
      , `p`.`plan_name` `plan_name`
      , `p`.`plan_sub_type` `plan_sub_type`
      , `p`.`plan_order` `plan_order`
      , `p`.`ben_term_type` `ben_term_type`
      , `p`.`new_ben_term_type` `new_ben_term_type`
      , `p`.`plan_year_start_date` `plan_year_start_date`
      , `p`.`plan_year_end_date` `plan_year_end_date`
      , `p`.`plan_year_renewal_date` `plan_year_renewal_date`
      , `p`.`plan_should_terminate` `plan_should_terminate`
      , `p`.`plan_year_termination_date` `plan_year_termination_date`
      , `p`.`should_default_participants_to_different_plan` `should_default_participants_to_different_plan`
      , `p`.`default_participants_to_different_plan_name` `default_participants_to_different_plan_name`
      , `p`.`plan_is_new` `plan_is_new`
      , `p`.`carrier_name` `carrier_name`
      , `p`.`policygroup_number` `policygroup_number`
      , `p`.`is_fully_insured` `is_fully_insured`
      , `p`.`is_self_funded` `is_self_funded`
      , `p`.`insurance_type` `insurance_type`
      , `p`.`plan_is_for_specific_division` `plan_is_for_specific_division`
      , `p`.`division_name` `division_name`
      , `p`.`coverage_termination` `coverage_termination`
      , `p`.`plan_rate_type` `plan_rate_type`
      , `p`.`is_cap_dependents_age20` `is_cap_dependents_age20`
      , `p`.`pct_50_charge_disability_extension` `pct_50_charge_disability_extension`
      , `p`.`new_pct_100_rate_for_coverage_level` `new_pct_100_rate_for_coverage_level`
    FROM
        (`api`.`api_cases` `c`
            JOIN `api`.`api_case_plans_cobra` `p` ON (`c`.`case_id` = `p`.`case_id`))
    ORDER BY
        `c`.`employer_name`
      , `c`.`case_id`
      , `p`.`plan_type`
      , `p`.`plan_sub_type`;

