CREATE
    DEFINER = admin@`%` PROCEDURE app_log_activities(
                                                    IN p_user_id varchar(100),
                                                    IN p_email_id varchar(200),
                                                    IN p_case_id varchar(100),
                                                    IN p_wp_user_id varchar(100),
                                                    IN p_ip_address varchar(50),
                                                    IN p_event_source varchar(100),
                                                    IN p_event_type longtext,
                                                    IN p_event_status varchar(200),
                                                    IN p_dump longtext )
BEGIN
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
        BEGIN
            GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE,
                @errno = MYSQL_ERRNO,
                @text = MESSAGE_TEXT;
            CALL db_log_error(@errno,
                              'app_log_activities',
                              @text,
                              @sqlstate);
        END;

    INSERT INTO logs.app_activity_logs (user_id,
                                        email_id,
                                        case_id,
                                        wp_user_id,
                                        ip_address,
                                        event_source,
                                        event_type,
                                        event_status,
                                        dump)
    VALUES (p_user_id,
            p_email_id,
            p_case_id,
            p_wp_user_id,
            p_ip_address,
            p_event_source,
            p_event_type,
            p_event_status,
            p_dump);
END;

