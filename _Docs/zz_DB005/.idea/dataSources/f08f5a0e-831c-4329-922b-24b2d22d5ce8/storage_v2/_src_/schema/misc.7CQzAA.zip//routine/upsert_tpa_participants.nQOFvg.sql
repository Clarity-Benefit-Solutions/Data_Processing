CREATE
    DEFINER = root@`%` PROCEDURE upsert_tpa_participants(
                                                        IN p_tpa_employee_id int,
                                                        IN p_tpa_employer_id int,
                                                        IN p_email varchar(200),
                                                        IN p_first_name varchar(100),
                                                        IN p_last_name varchar(100),
                                                        IN p_ssn varchar(50),
                                                        IN p_alegeus_key varchar(50),
                                                        IN p_wex_key varchar(50),
                                                        IN p_archived int,
                                                        IN p_can_make_claim_requests int,
                                                        IN p_can_use_portal int,
                                                        IN p_phone_home varchar(50),
                                                        IN p_phone_mobile varchar(50),
                                                        IN p_unread_count int,
                                                        IN p_user_ids varchar(50) )
BEGIN
    
    -- handle error that may happen as the table has a few unique keys which may conflict
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO,
                @text = MESSAGE_TEXT;
            SET @text = CONCAT( @text , CONCAT( '
 Called With Params: ' , 'tpa_employee_id: ' , api.api_nz( `p_tpa_employee_id` , '' ) , 'tpa_employer_id: ' ,
                                                api.api_nz( `p_tpa_employer_id` , '' ) , 'email: ' ,
                                                api.api_nz( `p_email` , '' ) , 'first_name: ' ,
                                                api.api_nz( `p_first_name` , '' ) , 'last_name: ' ,
                                                api.api_nz( `p_last_name` , '' ) , 'ssn: ' ,
                                                api.api_nz( `p_ssn` , '' ) , 'alegeus_key: ' ,
                                                api.api_nz( `p_alegeus_key` , '' ) , 'wex_key: ' ,
                                                api.api_nz( `p_wex_key` , '' ) , 'archived: ' ,
                                                api.api_nz( `p_archived` , '' ) , 'can_make_claim_requests: ' ,
                                                api.api_nz( `p_can_make_claim_requests` , '' ) , 'can_use_portal: ' ,
                                                api.api_nz( `p_can_use_portal` , '' ) , 'phone_home: ' ,
                                                api.api_nz( `p_phone_home` , '' ) , 'phone_mobile: ' ,
                                                api.api_nz( `p_phone_mobile` , '' ) , 'unread_count: ' ,
                                                api.api_nz( `p_unread_count` , '' ) , 'user_ids: ' ,
                                                api.api_nz( `p_user_ids` , '' ) ) );
            CALL api.db_log_message( 'upsert_tpa_participants' , @text , 'ERROR');
        END;
    
    CALL api.db_log_message( 'upsert_tpa_participants' , CONCAT( 'Called With Params: ' , 'tpa_employee_id: ' ,
                                                                 api.api_nz( `p_tpa_employee_id` , '' ) ,
                                                                 'tpa_employer_id: ' ,
                                                                 api.api_nz( `p_tpa_employer_id` , '' ) , 'email: ' ,
                                                                 api.api_nz( `p_email` , '' ) , 'first_name: ' ,
                                                                 api.api_nz( `p_first_name` , '' ) , 'last_name: ' ,
                                                                 api.api_nz( `p_last_name` , '' ) , 'ssn: ' ,
                                                                 api.api_nz( `p_ssn` , '' ) , 'alegeus_key: ' ,
                                                                 api.api_nz( `p_alegeus_key` , '' ) , 'wex_key: ' ,
                                                                 api.api_nz( `p_wex_key` , '' ) , 'archived: ' ,
                                                                 api.api_nz( `p_archived` , '' ) ,
                                                                 'can_make_claim_requests: ' ,
                                                                 api.api_nz( `p_can_make_claim_requests` , '' ) ,
                                                                 'can_use_portal: ' ,
                                                                 api.api_nz( `p_can_use_portal` , '' ) ,
                                                                 'phone_home: ' , api.api_nz( `p_phone_home` , '' ) ,
                                                                 'phone_mobile: ' ,
                                                                 api.api_nz( `p_phone_mobile` , '' ) ,
                                                                 'unread_count: ' ,
                                                                 api.api_nz( `p_unread_count` , '' ) , 'user_ids: ' ,
                                                                 api.api_nz( `p_user_ids` , '' ) ) , 'WARN' );
    
    /**/
    DELETE
    FROM
        misc.tpa_participant_policies
    WHERE
        tpa_employee_id = p_tpa_employee_id;
    /**/
    INSERT INTO `misc`.`tpa_participants` (
                                          `tpa_employee_id`,
                                          `tpa_employer_id`,
                                          `email`,
                                          `first_name`,
                                          `last_name`,
                                          `ssn`,
                                          `alegeus_key`,
                                          `wex_key`,
                                          `archived`,
                                          `can_make_claim_requests`,
                                          `can_use_portal`,
                                          `phone_home`,
                                          `phone_mobile`,
                                          `unread_count`,
                                          `user_ids`
    )
    
    VALUES (
           `p_tpa_employee_id`,
           `p_tpa_employer_id`,
           `p_email`,
           `p_first_name`,
           `p_last_name`,
           `p_ssn`,
           `p_alegeus_key`,
           `p_wex_key`,
           `p_archived`,
           `p_can_make_claim_requests`,
           `p_can_use_portal`,
           `p_phone_home`,
           `p_phone_mobile`,
           `p_unread_count`,
           `p_user_ids`
           )
        
        /* use api_nz to avoid replacing previous value if new value is null or blank */
    ON DUPLICATE KEY
        UPDATE
            `tpa_employee_id`         = api.api_nz_int( `p_tpa_employee_id` , `tpa_employee_id` ),
            `tpa_employer_id`         = api.api_nz_int( `p_tpa_employer_id` , `tpa_employer_id` ),
            `email`                   = api.api_nz( `p_email` , `email` ),
            `first_name`              = api.api_nz( `p_first_name` , `first_name` ),
            `last_name`               = api.api_nz( `p_last_name` , `last_name` ),
            `ssn`                     = api.api_nz( `p_ssn` , `ssn` ),
            `alegeus_key`             = api.api_nz( `p_alegeus_key` , `alegeus_key` ),
            `wex_key`                 = api.api_nz( `p_wex_key` , `wex_key` ),
            `archived`                = api.api_nz_int( `p_archived` , `archived` ),
            `can_make_claim_requests` = api.api_nz_int( `p_can_make_claim_requests` , `can_make_claim_requests` ),
            `can_use_portal`          = api.api_nz_int( `p_can_use_portal` , `can_use_portal` ),
            `phone_home`              = api.api_nz( `p_phone_home` , `phone_home` ),
            `phone_mobile`            = api.api_nz( `p_phone_mobile` , `phone_mobile` ),
            `unread_count`            = api.api_nz_int( `p_unread_count` , `unread_count` ),
            `user_ids`                = api.api_nz( `p_user_ids` , `user_ids` );

END;

