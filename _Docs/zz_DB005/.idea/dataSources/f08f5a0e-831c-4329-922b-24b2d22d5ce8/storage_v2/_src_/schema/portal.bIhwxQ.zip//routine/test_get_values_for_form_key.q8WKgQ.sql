CREATE
    DEFINER = root@`%` FUNCTION test_get_values_for_form_key(
                                                            p_token varchar(50),
                                                            p_add_header int,
                                                            p_only_for_field_key varchar(200),
                                                            p_only_field_current_value int ) RETURNS longtext
BEGIN
    DECLARE v_csv longtext DEFAULT '';
    SET v_csv = portal.get_values_for_form_key( p_token , p_add_header , NULL , NULL , p_only_for_field_key ,
                                                p_only_field_current_value );
    
    RETURN v_csv;

END;

