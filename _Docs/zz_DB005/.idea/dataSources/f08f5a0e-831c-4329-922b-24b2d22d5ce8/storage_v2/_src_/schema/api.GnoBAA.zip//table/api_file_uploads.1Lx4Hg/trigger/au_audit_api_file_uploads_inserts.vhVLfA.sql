CREATE DEFINER = admin@`%` TRIGGER au_audit_api_file_uploads_inserts
    AFTER INSERT
    ON api_file_uploads
    FOR EACH ROW
    INSERT INTO `api`.`api_file_uploads_audit`
                 (`auditAction`, `case_id`, `uploaded_by_user_id`, `platform_name`, `platform_template_name`,
                  `file_status`, `file_name`, `checker_results`, `upload_results`, `upload_errors`, `created_at`,
                  `created_by`, `updated_at`, `updated_by`, `file_upload_id`, `sf_new_task_id`)
                 VALUES ('INSERT', NEW.`case_id`, NEW.`uploaded_by_user_id`, NEW.`platform_name`,
                         NEW.`platform_template_name`, NEW.`file_status`, NEW.`file_name`, NEW.`checker_results`,
                         NEW.`upload_results`, NEW.`upload_errors`, NEW.`created_at`, NEW.`created_by`,
                         NEW.`updated_at`, NEW.`updated_by`, NEW.`file_upload_id`, NEW.`sf_new_task_id`);

