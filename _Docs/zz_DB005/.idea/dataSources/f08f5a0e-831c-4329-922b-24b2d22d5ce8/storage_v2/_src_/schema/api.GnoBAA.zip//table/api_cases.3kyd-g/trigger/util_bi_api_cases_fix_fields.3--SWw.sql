CREATE DEFINER = admin@`%` TRIGGER util_bi_api_cases_fix_fields
    BEFORE UPDATE
    ON api_cases
    FOR EACH ROW
BEGIN
    if api.api_is_blank(new.legal_business_name) then
        set new.legal_business_name = new.employer_name;
    end if;
END;

