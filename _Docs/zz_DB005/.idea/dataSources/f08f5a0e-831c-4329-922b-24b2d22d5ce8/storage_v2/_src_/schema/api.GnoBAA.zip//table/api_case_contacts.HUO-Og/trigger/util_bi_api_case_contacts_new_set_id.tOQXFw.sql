CREATE DEFINER = root@`%` TRIGGER util_bi_api_case_contacts_new_set_id
    BEFORE INSERT
    ON api_case_contacts
    FOR EACH ROW
BEGIN
    IF api.api_is_blank(new.case_contact_id) THEN
        SET new.case_contact_id = api.api_uuid();
    END IF;

    
    SET new.contact_email_org = new.contact_email;
END;

