CREATE DEFINER = root@`%` TRIGGER au_audit_sf_accounts_deletes
    AFTER DELETE
    ON sf_accounts
    FOR EACH ROW
    INSERT INTO `sf`.`sf_accounts_audit`
                 (
                 `auditAction`,
                 `row_id`,
                 `clientcode`,
                 `clientname`,
                 `clientstatus`,
                 `clienttype`,
                 `created_at`,
                 `created_by`,
                 `updated_at`,
                 `updated_by`,
                 `if_client_is_active`,
                 `if_client_active_start_date`
                 )
                 VALUES (
                        'DELETE',
                        OLD.`row_id`,
                        OLD.`clientcode`,
                        OLD.`clientname`,
                        OLD.`clientstatus`,
                        OLD.`clienttype`,
                        OLD.`created_at`,
                        OLD.`created_by`,
                        OLD.`updated_at`,
                        OLD.`updated_by`,
                        OLD.`if_client_is_active`,
                        OLD.`if_client_active_start_date`
                        );

