CREATE DEFINER = root@`%` TRIGGER au_audit_wc_employers_inserts
    AFTER INSERT
    ON wc_employers
    FOR EACH ROW
    INSERT INTO `wc`.`wc_employers_audit`
                 (
                 `auditAction`,
                 `employer_id`,
                 `employer_name`,
                 `active_first_use`,
                 `bucket_split`,
                 `city`,
                 `email_address`,
                 `copay_auto_renew`,
                 `employer_status`,
                 `recurring_expense_auto_renew`,
                 `state`,
                 `tpa_id`,
                 `created_at`,
                 `created_by`,
                 `updated_at`,
                 `updated_by`
                 )
                 VALUES (
                        'INSERT',
                        NEW.`employer_id`,
                        NEW.`employer_name`,
                        NEW.`active_first_use`,
                        NEW.`bucket_split`,
                        NEW.`city`,
                        NEW.`email_address`,
                        NEW.`copay_auto_renew`,
                        NEW.`employer_status`,
                        NEW.`recurring_expense_auto_renew`,
                        NEW.`state`,
                        NEW.`tpa_id`,
                        NEW.`created_at`,
                        NEW.`created_by`,
                        NEW.`updated_at`,
                        NEW.`updated_by`
                        );

