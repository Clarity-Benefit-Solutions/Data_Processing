CREATE
    DEFINER = root@`%` FUNCTION if_reward_amount(
    p_employer_id varchar(200) ) RETURNS float
BEGIN
    DECLARE v_ret float DEFAULT 0;
    
    SELECT
        MAX( rewardamount )
    INTO v_ret
    FROM
        sf.sf_account_plans
    WHERE
          clientcode = p_employer_id
      AND plantype IN ('U21', 'CRA')
    LIMIT 1;
    
    RETURN api.api_nz_float( v_ret , 0 );

END;

