CREATE VIEW vw_sso_platform_bt
AS
    SELECT
        `t`.`email` `email`
      , CASE
            WHEN `t`.`row_id` = `api`.`sso_get_record_for_bt`( `t`.`email` ) THEN 1
            ELSE 0
        END `is_sso_record`
      , `t`.`is_active` `is_active`
      , `t`.`user_type` `user_type`
      , `t`.`row_id` `row_id`
      , `t`.`line_of_business` `line_of_business`
      , `t`.`account_number` `account_number`
      , `t`.`branch_name` `branch_name`
      , `t`.`account_name` `account_name`
      , `t`.`status` `status`
      , `t`.`enrolled_date` `enrolled_date`
      , `t`.`send_paper_bill` `send_paper_bill`
      , `t`.`created_at` `created_at`
      , `t`.`created_by` `created_by`
      , `t`.`updated_at` `updated_at`
      , `t`.`updated_by` `updated_by`
    FROM
        `misc`.`vw_bill_trust_users` `t`;

