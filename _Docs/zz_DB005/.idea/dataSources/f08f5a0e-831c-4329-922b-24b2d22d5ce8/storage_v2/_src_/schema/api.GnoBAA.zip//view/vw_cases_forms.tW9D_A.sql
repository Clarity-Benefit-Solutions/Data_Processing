CREATE VIEW vw_cases_forms
AS
    SELECT
        `a`.`case_id` `case_id`
      , `a`.`employer_name` `employer_name`
      , `api`.`get_sf_case_owner_fullname`( `a`.`sf_case_owner_user_id` ) `sf_case_owner_fullname`
      , SUBSTR( `a`.`last_rollout_error` , 1 , 150 ) `last_rollout_error`
      , `a`.`employer_id` `employer_id`
      , `a`.`case_type` `case_type`
      , `a`.`case_sub_type` `case_sub_type`
      , `a`.`form_invite_token` `form_invite_token`
      , `a`.`wizard_curr_step_no` `wizard_curr_step_no`
      , `a`.`form_curr_page_no` `form_curr_page_no`
      , `a`.`sf_case_id` `sf_case_id`
      , `a`.`is_ready_for_processing` `is_ready_for_processing`
      , `a`.`is_used_for_testing` `is_used_for_testing`
      , `a`.`sf_case_owner_user_id` `sf_case_owner_user_id`
      , `a`.`case_status` `status`
      , CASE
            WHEN `a`.`case_status` LIKE 'Client Notified%' THEN 'Start'
            WHEN `a`.`case_status` LIKE 'In Progress%' THEN 'Resume'
            ELSE 'View'
        END `lable`
      , CASE
            WHEN `a`.`case_status` IN
                 ('New', 'Contact Changed', 'Contact Changed: Task Created', 'Ready For Entry', 'Closed',
                  'Cancelled: Hidden') THEN 0
            ELSE 1
        END `is_visible_to_client`
      , CASE
            WHEN `a`.`case_status` LIKE 'Client Notified%' THEN 'Not Started'
            ELSE `api`.`api_fix_case_status_for_user_display`( `a`.`case_status` )
        END `case_status`
      , CASE
            WHEN (`a`.`case_status` LIKE 'New%' OR `a`.`case_status` LIKE 'Ready For Entry%') THEN 'Waiting'
            WHEN `a`.`case_status` LIKE 'Cancelled%' THEN 'Cancelled'
            ELSE 'Rolled Out'
        END `major_case_status`
      , CONCAT( 'https://portal.claritybenefitsolutions.com' , '/forms/form/?token=' , `a`.`form_invite_token` ) `url`
      , MIN( `b`.`contact_first_name` ) `contact_first_name`
      , MIN( `b`.`contact_last_name` ) `contact_last_name`
      , MIN( `b`.`contact_email` ) `contact_email`
      , MIN( `b`.`contact_email` ) `email_sent_to`
      , MIN( `b`.`contact_phone` ) `contact_phone`
      , `api`.`get_case_status_history`( `a`.`form_invite_token` , 1 ) `current_status_time`
      , `api`.`get_case_notification_history`( `a`.`case_id` , 1 , 'email' , 'Renewal Portal' ,
                                               `a`.`case_sub_type` ) `last_outreach_at`
      , '2021-02-26' `renewal_date`
      , CASE
            WHEN `a`.`case_sub_type` = 'Covid2021Info'
                THEN 'Optional Provisions in Consolidated Appropriations Act, 2021'
            ELSE `a`.`case_sub_type`
        END `products`
      , `api`.`get_cases_forms_covide2021infofieldvalue`( `a`.`form_invite_token` , '%intro%' ) `valueofapproveall`
      , `api`.`get_cases_forms_covide2021infofieldvalue`( `a`.`form_invite_token` , '%carryover%' ) `valueofcarryover`
      , `api`.`get_cases_forms_covide2021infofieldvalue`( `a`.`form_invite_token` ,
                                                          '%grace_period%' ) `valueofgraceperiod`
      , `api`.`get_cases_forms_covide2021infofieldvalue`( `a`.`form_invite_token` ,
                                                          '%co_gp%' ) `valueofcarryoverandgpdenial`
      , `api`.`get_cases_forms_covide2021infofieldvalue`( `a`.`form_invite_token` , '%relife%' ) `valueoftemprelief`
      , `api`.`get_cases_forms_covide2021infofieldvalue`( `a`.`form_invite_token` ,
                                                          '%reimbursement%' ) `valueofspenddown`
      , `api`.`get_cases_forms_covide2021infofieldvalue`( `a`.`form_invite_token` , '%election%' ) `valueofelection`
    FROM
        (`api`.`api_cases` `a`
            JOIN `api`.`api_case_contacts` `b` ON (`b`.`case_id` = `a`.`case_id`))
    WHERE
          `a`.`case_type` = 'Forms'
      AND CASE
              WHEN `a`.`case_sub_type` = 'Covid2021Info' THEN `b`.`contact_is_cons_ben_contact` = 1
              ELSE (`b`.`contact_is_cobra_contact` = 1 OR `b`.`contact_is_cons_ben_contact` = 1)
          END
    GROUP BY
        `a`.`case_id`
      , `a`.`employer_name`
      , `a`.`employer_id`
      , `a`.`case_sub_type`
      , `a`.`form_invite_token`
      , `a`.`wizard_curr_step_no`
      , `a`.`form_curr_page_no`
      , `a`.`sf_case_id`
      , `a`.`case_status`
    ORDER BY
        `a`.`employer_name`;

