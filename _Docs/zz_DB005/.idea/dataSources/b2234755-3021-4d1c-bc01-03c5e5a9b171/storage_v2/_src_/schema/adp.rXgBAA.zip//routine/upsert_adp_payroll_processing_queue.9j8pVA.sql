create
    definer = root@`%` procedure upsert_adp_payroll_processing_queue(
                                                                    IN p_status varchar(50),
                                                                    IN p_ben_code varchar(50),
                                                                    IN p_associate_id varchar(50),
                                                                    IN p_employee_id varchar(50),
                                                                    IN p_plan_id varchar(50),
                                                                    IN p_account_type_code varchar(50),
                                                                    IN p_plan_start_date date,
                                                                    IN p_plan_end_date date,
                                                                    IN p_adp_payroll_code varchar(50),
                                                                    IN p_org_id varchar(50),
                                                                    IN p_paymentDate date )
BEGIN
    
    -- handle error that may happen as the table has a few unique keys which may conflict
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO,
                @text = MESSAGE_TEXT;
            SET @text = CONCAT( @text , CONCAT( '
Called With Params: ' , ', status: ' , api.api_nz( `p_status` , '' ) , ', ben_code: ' ,
                                                api.api_nz( `p_ben_code` , '' ) , ', associate_id: ' ,
                                                api.api_nz( `p_associate_id` , '' ) , ', employee_id: ' ,
                                                api.api_nz( `p_employee_id` , '' ) , ', plan_id: ' ,
                                                api.api_nz( `p_plan_id` , '' ) , ', account_type_code: ' ,
                                                api.api_nz( `p_account_type_code` , '' ) , ', plan_start_date: ' ,
                                                api.api_nz( `p_plan_start_date` , '' ) , ', plan_end_date: ' ,
                                                api.api_nz( `p_plan_end_date` , '' ) , ', adp_payroll_code: ' ,
                                                api.api_nz( `p_adp_payroll_code` , '' ) , ', org_id: ' ,
                                                api.api_nz( `p_org_id` , '' ) , ', paymentDate: ' ,
                                                api.api_nz( `p_paymentDate` , '' ) ) );
            CALL api.db_log_message( 'upsert_adp_payroll_processing_queue' , @text , 'ERROR' );
        END;
    
    CALL api.db_log_message( 'upsert_adp_payroll_processing_queue' ,
                             CONCAT( 'Called With Params: ' , ', status: ' , api.api_nz( `p_status` , '' ) ,
                                     ', ben_code: ' , api.api_nz( `p_ben_code` , '' ) , ', associate_id: ' ,
                                     api.api_nz( `p_associate_id` , '' ) , ', employee_id: ' ,
                                     api.api_nz( `p_employee_id` , '' ) , ', plan_id: ' ,
                                     api.api_nz( `p_plan_id` , '' ) , ', account_type_code: ' ,
                                     api.api_nz( `p_account_type_code` , '' ) , ', plan_start_date: ' ,
                                     api.api_nz( `p_plan_start_date` , '' ) , ', plan_end_date: ' ,
                                     api.api_nz( `p_plan_end_date` , '' ) , ', adp_payroll_code: ' ,
                                     api.api_nz( `p_adp_payroll_code` , '' ) , ', org_id: ' ,
                                     api.api_nz( `p_org_id` , '' ) , ', paymentDate: ' ,
                                     api.api_nz( `p_paymentDate` , '' ) ) , 'WARN' );
    
    INSERT INTO `adp`.`adp_payroll_processing_queue` (
                                                     `status`,
                                                     `ben_code`,
                                                     `associate_id`,
                                                     `employee_id`,
                                                     `plan_id`,
                                                     `account_type_code`,
                                                     `plan_start_date`,
                                                     `plan_end_date`,
                                                     `adp_payroll_code`,
                                                     `org_id`,
                                                     `paymentDate`
    )
    
    VALUES (
           `p_status`,
           `p_ben_code`,
           `p_associate_id`,
           `p_employee_id`,
           `p_plan_id`,
           `p_account_type_code`,
           `p_plan_start_date`,
           `p_plan_end_date`,
           `p_adp_payroll_code`,
           `p_org_id`,
           `p_paymentDate`
           )
        
        /* use api_nz to avoid replacing previous value if new value is null or blank */
    ON DUPLICATE KEY
        UPDATE
            `status`            = api.api_nz( `p_status` , `status` ),
            `ben_code`          = api.api_nz( `p_ben_code` , `ben_code` ),
            `associate_id`      = api.api_nz( `p_associate_id` , `associate_id` ),
            `employee_id`       = api.api_nz( `p_employee_id` , `employee_id` ),
            `plan_id`           = api.api_nz( `p_plan_id` , `plan_id` ),
            `account_type_code` = api.api_nz( `p_account_type_code` , `account_type_code` ),
            `plan_start_date`   = api.api_nz_date( `p_plan_start_date` , `plan_start_date` ),
            `plan_end_date`     = api.api_nz_date( `p_plan_end_date` , `plan_end_date` ),
            `adp_payroll_code`  = api.api_nz( `p_adp_payroll_code` , `adp_payroll_code` ),
            `org_id`            = api.api_nz( `p_org_id` , `org_id` ),
            `paymentDate`       = api.api_nz_date( `p_paymentDate` , `paymentDate` );

END;

