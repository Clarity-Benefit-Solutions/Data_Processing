create
    definer = root@`%` procedure upsert_adp_deduction_codes(
                                                           IN p_bencode varchar(50),
                                                           IN p_org_id varchar(50),
                                                           IN p_adp_code varchar(100),
                                                           IN p_adp_description varchar(100),
                                                           IN p_alegeus_account_type varchar(100),
                                                           IN p_alegeus_plan_id varchar(100),
                                                           IN p_plan_start_date date,
                                                           IN p_plan_end_date date )
BEGIN


 -- handle error that may happen as the table has a few unique keys which may conflict
                         DECLARE EXIT HANDLER FOR SQLEXCEPTION
                         BEGIN
                         GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO,
                         @text = MESSAGE_TEXT;
                         SET @text = CONCAT(@text, Concat('
 Called With Params: ','bencode: ',api.api_nz(`p_bencode`,''),'org_id: ',api.api_nz(`p_org_id`,''),'adp_code: ',api.api_nz(`p_adp_code`,''),'adp_description: ',api.api_nz(`p_adp_description`,''),'alegeus_account_type: ',api.api_nz(`p_alegeus_account_type`,''),'alegeus_plan_id: ',api.api_nz(`p_alegeus_plan_id`,''),'plan_start_date: ',api.api_nz(`p_plan_start_date`,''),'plan_end_date: ',api.api_nz(`p_plan_end_date`,''))) ;
                         CALL api.db_throw_error(@errno, 'upsert_adp_deduction_codes', @text);  END;


CALL api.db_log_message('upsert_adp_deduction_codes',Concat('Called With Params: ','bencode: ',api.api_nz(`p_bencode`,''),'org_id: ',api.api_nz(`p_org_id`,''),'adp_code: ',api.api_nz(`p_adp_code`,''),'adp_description: ',api.api_nz(`p_adp_description`,''),'alegeus_account_type: ',api.api_nz(`p_alegeus_account_type`,''),'alegeus_plan_id: ',api.api_nz(`p_alegeus_plan_id`,''),'plan_start_date: ',api.api_nz(`p_plan_start_date`,''),'plan_end_date: ',api.api_nz(`p_plan_end_date`,'')),'WARN');


INSERT INTO `adp`.`adp_deduction_codes` (`bencode`,`org_id`,`adp_code`,`adp_description`,`alegeus_account_type`,`alegeus_plan_id`,`plan_start_date`,`plan_end_date`)


VALUES (
 `p_bencode` ,
 `p_org_id` ,
 `p_adp_code` ,
 `p_adp_description` ,
 `p_alegeus_account_type` ,
 `p_alegeus_plan_id` ,
 `p_plan_start_date` ,
 `p_plan_end_date`  )


 /* use api_nz to avoid replacing previous value if new value is null or blank */
      ON DUPLICATE KEY
      UPDATE `bencode` = api.api_nz(`p_bencode`, `bencode` ),`org_id` = api.api_nz(`p_org_id`, `org_id` ),`adp_code` = api.api_nz(`p_adp_code`, `adp_code` ),`adp_description` = api.api_nz(`p_adp_description`, `adp_description` ),`alegeus_account_type` = api.api_nz(`p_alegeus_account_type`, `alegeus_account_type` ),`alegeus_plan_id` = api.api_nz(`p_alegeus_plan_id`, `alegeus_plan_id` ),`plan_start_date` = api.api_nz_date(`p_plan_start_date`, `plan_start_date` ),`plan_end_date` = api.api_nz_date(`p_plan_end_date`, `plan_end_date` );
      


END;

