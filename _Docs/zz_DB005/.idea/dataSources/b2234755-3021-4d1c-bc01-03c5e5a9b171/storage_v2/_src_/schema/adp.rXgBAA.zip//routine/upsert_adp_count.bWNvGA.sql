create
    definer = admin@`%` procedure upsert_adp_count(
                                                  IN p_bencode varchar(50),
                                                  IN p_org_id varchar(50),
                                                  IN p_participant_count varchar(50) )
BEGIN
    
    INSERT INTO adp.adp_count(
                             bencode
                           , org_id
                           , participant_count
    )
    VALUES (
               p_bencode
           ,   p_org_id
           ,   p_participant_count

           )
    ON DUPLICATE KEY UPDATE
                         bencode     				= api.API_NZ( p_bencode , bencode )
                       , org_id       				= api.API_NZ( p_org_id , org_id)
                       , participant_count      = api.API_NZ( p_participant_count , participant_count );

END;

