CREATE
    DEFINER = root@`%` PROCEDURE reg_part_show_matches_cp_part(
                                                              IN p_email varchar(200),
                                                              IN p_ssn varchar(200),
                                                              IN p_dob varchar(200),
                                                              IN p_zip varchar(200),
                                                              IN p_card_number varchar(200) )
full_proc:

BEGIN
    /* do we have a record in platform_users for the email?*/
    SELECT
        
        (/*t.is_active * 1 +*/
                t.matched_email + t.matched_ssn + t.matched_zip +
                t.matched_dob) matched_score
      , t.is_active
      , t.matched_email
      , t.matched_ssn
      , t.matched_dob
      , t.matched_zip
      , t.is_active
      , t.matched_email
      , t.matched_ssn
      , t.matched_dob
      , t.matched_zip
      , t.ROW_ID
      , t.email
      , t.ssn
      , t.postalcode
      , t.dob
      , t.firstname
      , t.lastname
      , t.entitytype
      , t.memberid
      , t.brokerid
      , t.clientcontactid
      , t.clientid
      , t.divisionname
      , t.organizationname
      , t.organizationisactive
      , t.phone
      , t.loginstatus
      , t.registrationcode
      , t.registrationdate
      , t.userdisplayname
      , t.allowsso
      , t.ssoidentifier
      , t.userid
      , t.employeeid
      
      , t.dob
      , t.employerid
    FROM
        (
            SELECT
                
                /* give 1 points to active records as it takes too long to do this in the where clause*/
                /* allow inactive employees whjo maycvh criteria to also register - as they need to do open enrollment*/
                
                CASE
                    /* returns 0, 0.5 (TI) or 1 - take 0.5 and 1 as 1*/
                    WHEN cp.cp_is_active_status( loginstatus , organizationisactive ) > 0 THEN 1
                    ELSE 0
                END
                    is_active
              , CASE
                    WHEN NOT api.api_is_blank( email ) AND email = p_email THEN 1
                    ELSE 0
                END matched_email
              
              , (CASE
                     WHEN NOT api.api_is_blank( p_ssn ) AND
                          (match_ssn_last = p_ssn OR
                           match_ssn_last = RIGHT( p_ssn , 4 )) THEN 1
                     ELSE 0
                 END)
                    matched_ssn
              
              , (CASE
                     WHEN NOT api.api_is_blank( p_dob ) AND
                          (dob = p_dob)
                         THEN 1
                     ELSE 0
                 END) matched_dob
              , (CASE
                     WHEN NOT api.api_is_blank( p_zip ) AND
                          (matched_zip = p_zip) THEN 1
                     ELSE 0
                 END)
                    matched_zip
              
              , ROW_ID
              , email
              , ssn
              , postalcode
              , dob
              , firstname
              , lastname
              , entitytype
              , memberid
              , brokerid
              , clientcontactid
              , clientid
              , divisionname
              , organizationname
              , organizationisactive
              , phone
              , loginstatus
              , registrationcode
              , registrationdate
              , userdisplayname
              , allowsso
              , ssoidentifier
              , userid
              , employeeid
              , employerid
            FROM
                cp.cp_all_sso_users
            WHERE
                ( email like concat(p_email, '%') or
                        (NOT api.api_is_blank( p_ssn ) AND
                         (ssn = p_ssn OR
                          match_ssn_last = RIGHT( p_ssn , 4 ))
                            )
                        OR (NOT api.api_is_blank( p_dob ) AND
                            (dob = p_dob)
                            )
                        OR (NOT api.api_is_blank( p_zip ) AND
                            (matched_zip = p_zip))
                    )
        
        ) t
    
    ORDER BY
        (t.is_active * 1 +
         t.matched_email + t.matched_ssn + t.matched_zip +
         t.matched_dob + matched_email)
        DESC
      , t.registrationdate DESC
    LIMIT 10;

END;

