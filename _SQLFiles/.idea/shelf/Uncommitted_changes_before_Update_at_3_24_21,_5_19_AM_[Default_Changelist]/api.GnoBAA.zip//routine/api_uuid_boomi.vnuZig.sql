CREATE
    DEFINER = admin@`%` FUNCTION api_uuid_boomi(
    dummy int ) RETURNS char(36)
begin
  
  return api_uuid();
end;

