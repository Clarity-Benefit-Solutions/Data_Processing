CREATE
    DEFINER = root@`%` FUNCTION api_fix_case_status_for_user_display(
    p_case_status varchar(200) ) RETURNS varchar(200)
begin
    declare v_pos int default 0;
    set v_pos = position( ':' in p_case_status );
    if (v_pos > 0) then
        return substr( p_case_status , 1 , v_pos - 1 );
    end if;
    return p_case_status;

end;

