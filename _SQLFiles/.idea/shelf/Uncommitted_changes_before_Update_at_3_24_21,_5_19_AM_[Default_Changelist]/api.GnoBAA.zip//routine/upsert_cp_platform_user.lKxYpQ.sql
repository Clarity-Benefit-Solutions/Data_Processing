CREATE
    DEFINER = root@`%` PROCEDURE upsert_cp_platform_user(
                                                        IN p_user_name varchar(200),
                                                        IN p_email varchar(200),
                                                        IN p_first_name varchar(200),
                                                        IN p_last_name varchar(200),
                                                        IN p_alternate_email varchar(200),
                                                        IN p_title varchar(200),
                                                        IN p_mobile_number varchar(200),
                                                        IN p_ssn varchar(200),
                                                        IN p_employee_id varchar(200),
                                                        IN p_cp_client_id varchar(200),
                                                        IN p_cp_broker_id varchar(200),
                                                        IN p_cp_client_contact_id varchar(200),
                                                        IN p_cp_sso_identifier varchar(200),
                                                        IN p_cp_customer_id varchar(200),
                                                        IN p_cp_entity_type varchar(200),
                                                        IN p_cp_user_id varchar(200),
                                                        IN p_cp_member_id varchar(200),
                                                        IN p_cp_allow_sso varchar(200),
                                                        IN p_dob varchar(50),
                                                        IN p_cp_tpa_user_is_active varchar(6),
                                                        IN p_cp_member_user_is_active varchar(6),
                                                        IN p_cp_row_id int,
                                                        IN p_cp_client_user_is_active varchar(6),
                                                        IN p_cp_broker_user_is_active varchar(6),
                                                        IN p_cp_organization_name varchar(200),
                                                        IN p_cp_division_name varchar(200),
                                                        IN p_cp_contact_type varchar(200),
                                                        IN p_cp_registration_code varchar(200),
                                                        IN p_cp_registration_date varchar(200),
                                                        IN p_zip varchar(50),
                                                        IN p_is_used_for_registration varchar(200) )
full_proc:
BEGIN
    
    DECLARE v_count varchar(50) DEFAULT NULL;
    DECLARE v_user_id int DEFAULT NULL;
    DECLARE v_is_locked int DEFAULT NULL;
    
    DECLARE v_cp_contact_division_name varchar(200);
    DECLARE v_cp_member_division_name varchar(200);
    DECLARE v_cp_member_type varchar(200);
    DECLARE v_cp_member_organization_name varchar(200);
    DECLARE v_cp_member_last_name varchar(200);
    DECLARE v_cp_member_zip varchar(200);
    DECLARE v_cp_member_first_name varchar(200);
    DECLARE v_cp_contact_type varchar(200);
    DECLARE v_cp_contact_organization_name varchar(200);
    DECLARE v_cp_contact_last_name varchar(200);
    DECLARE v_cp_contact_first_name varchar(200);
    DECLARE v_cp_contact_registration_code varchar(200);
    DECLARE v_cp_contact_registration_date varchar(200);
    
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION BEGIN
        GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
        CALL db_log_error( @errno , 'upsert_cp_platform_user' , @text , @sqlstate );
    END;
    
    SET p_email = api.api_fix_email( p_email );
    SET p_user_name = api.api_fix_email( p_user_name );
    SET p_ssn = api.api_fix_email( p_ssn );
    SET p_mobile_number = api.api_fix_phone_number( p_mobile_number );
    SET p_dob = api.api_fix_date( p_dob );
    SET p_zip = api.api_fix_zip( p_zip );
    
    CALL api.db_log_message( 'upsert_cp_platform_user' ,
                             CONCAT( 'CALLED EMAIL: ' , api.api_nz( p_email , '' ) , 'row_id: ' ,
                                     api.api_nz( p_cp_row_id , '' ) , ' is_tpa_user_active: ' ,
                                     api.api_nz( p_cp_tpa_user_is_active , '' ) , ' P_is_member_user_active: ' ,
                                     api.api_nz( p_cp_member_user_is_active , '' ) , ' P_ROW_ID: ' ,
                                     api.api_nz( p_cp_row_id , '' ) , ' P_is_client_user_active: ' ,
                                     api.api_nz( p_cp_client_user_is_active , '' ) , ' P_is_broker_user_active: ' ,
                                     api.api_nz( p_cp_broker_user_is_active , '' ) , ' p_cp_registration_date: ' ,
                                     api.api_nz( p_cp_registration_date , '' ) ) , 'WARN' );
    
    IF api.api_is_blank( p_email ) OR api.api_is_blank( p_user_name ) THEN
        CALL api.db_log_message( 'upsert_cp_platform_user' ,
                                 CONCAT( 'Not Inserting record as email or username is blank ' , 'SSO ID: ' ,
                                         api.api_nz( p_cp_sso_identifier , '' ) , '  AND user_id: ' ,
                                         api.api_nz( p_cp_user_id , '' ) ) , 'WARN' );
        
        LEAVE full_proc;
    END IF;
    
    /*  IF api.api_is_blank( p_cp_sso_identifier ) AND api.api_is_blank( p_cp_user_id ) THEN
          CALL api.db_log_error( 50001 , 'upsert_cp_platform_user' ,
                                 CONCAT( 'Not Inserting record as p_cp_sso_identifier, p_cp_user_id are all blank ' ,
                                         'SSO ID: ' , api.api_nz( p_cp_sso_identifier , '' ) , '  AND user_id: ' ,
                                         api.api_nz( p_cp_user_id , '' ) ) , 'WARN' );
          
          LEAVE full_proc;
      END IF;
      */
    
    /* check for existing record using email*/
    SELECT
        COUNT( * )
      , user_id
      , CASE
            WHEN is_verified THEN 1
            ELSE 0
        END
    INTO v_count, v_user_id, v_is_locked
    FROM
        api.platform_users
    WHERE
        (email <=> p_email);
    
    SET v_user_id = api.api_nz_int( v_user_id , 0 );
    SET v_is_locked = api.api_nz_int( v_is_locked , 0 );
    
    CALL api.db_log_message( 'upsert_cp_platform_user' ,
                             CONCAT( v_count , ' Records found for EMAIL: ' , api.api_nz( p_email , '' ) ) ,
                             'WARN' );
    
    /* set other vars by entity tyope*/
    IF p_cp_entity_type = 'QB' OR p_cp_entity_type = 'SPM' THEN
        
        SET v_cp_contact_first_name = '<NULL>';
        SET v_cp_contact_last_name = '<NULL>';
        SET v_cp_contact_type = '<NULL>';
        SET v_cp_contact_organization_name = '<NULL>';
        SET v_cp_contact_division_name = '<NULL>';
        SET v_cp_contact_registration_code = '<NULL>';
        SET v_cp_contact_registration_date = '<NULL>';
        
        SET v_cp_member_first_name = p_first_name;
        SET v_cp_member_last_name = p_last_name;
        SET v_cp_member_type = p_cp_contact_type;
        SET v_cp_member_organization_name = p_cp_organization_name;
        SET v_cp_member_division_name = p_cp_division_name;
        SET v_cp_member_zip = p_zip;
    
    ELSEIF p_cp_entity_type LIKE '%CLIENT%' OR p_cp_entity_type LIKE '%BROKER%' OR p_cp_entity_type LIKE '%TPA%' THEN
        
        SET v_cp_contact_first_name = p_first_name;
        SET v_cp_contact_last_name = p_last_name;
        SET v_cp_contact_type = p_cp_contact_type;
        SET v_cp_contact_organization_name = p_cp_organization_name;
        SET v_cp_contact_division_name = p_cp_division_name;
        SET v_cp_contact_registration_code = p_cp_registration_code;
        SET v_cp_contact_registration_date = p_cp_registration_date;
        
        SET v_cp_member_first_name = '<NULL>';
        SET v_cp_member_last_name = '<NULL>';
        SET v_cp_member_organization_name = '<NULL>';
        SET v_cp_member_division_name = '<NULL>';
        SET v_cp_member_type = '<NULL>';
        SET v_cp_member_zip = '<NULL>';
    
    ELSE
        
        SET v_cp_contact_first_name = '<NULL>';
        SET v_cp_contact_last_name = '<NULL>';
        SET v_cp_contact_type = '<NULL>';
        SET v_cp_contact_organization_name = '<NULL>';
        SET v_cp_contact_division_name = '<NULL>';
        SET v_cp_contact_registration_code = '<NULL>';
        SET v_cp_contact_registration_date = '<NULL>';
        
        SET v_cp_member_first_name = '<NULL>';
        SET v_cp_member_last_name = '<NULL>';
        SET v_cp_member_organization_name = '<NULL>';
        SET v_cp_member_division_name = '<NULL>';
        SET v_cp_member_type = '<NULL>';
        SET v_cp_member_zip = '<NULL>';
    
    END IF;
    
    /* sumeet: 2021-03-16 if not p_is_used_for_registration and not is_locked (i.e. registered), only aggregate email, clear other fields for parts*/
    IF NOT v_is_locked AND NOT p_is_used_for_registration AND (p_cp_entity_type = 'QB' OR p_cp_entity_type = 'SPM') THEN
        /**/
        CALL api.db_log_message( 'upsert_cp_platform_user' ,
                                 CONCAT(
                                         ' Clearing Platform Record Attrs as not AdminUser and not p_is_used_for_registration and not v_is_locked for EMAIL: ' ,
                                         api.api_nz( p_email , '' ) ) ,
                                 'WARN' );
        #         SET p_first_name = '<NULL>';
        #         SET p_last_name = '<NULL>';
        #         SET p_alternate_email = '<NULL>';
        #         SET p_mobile_number = '<NULL>';
        SET p_title = '<NULL>';
        SET p_ssn = '<NULL>';
        SET p_employee_id = '<NULL>';
        SET p_cp_client_id = '<NULL>';
        SET p_cp_broker_id = '<NULL>';
        SET p_cp_client_contact_id = '<NULL>';
        SET p_cp_sso_identifier = '<NULL>';
        SET p_cp_customer_id = '<NULL>';
        SET p_cp_entity_type = '<NULL>';
        SET p_cp_user_id = '<NULL>';
        SET p_cp_member_id = '<NULL>';
        SET p_cp_allow_sso = '<NULL>';
        SET p_dob = '<NULL>';
        SET p_cp_tpa_user_is_active = 0;
        SET p_cp_member_user_is_active = 0;
        SET p_cp_row_id = 0;
        SET p_cp_client_user_is_active = 0;
        SET p_cp_broker_user_is_active = 0;
        SET p_cp_organization_name = '<NULL>';
        SET p_cp_division_name = '<NULL>';
        SET p_cp_contact_type = '<NULL>';
        SET p_cp_registration_code = '<NULL>';
        SET p_cp_registration_date = '<NULL>';
        SET p_zip = '<NULL>';
        
        SET v_cp_contact_first_name = '<NULL>';
        SET v_cp_contact_last_name = '<NULL>';
        SET v_cp_contact_type = '<NULL>';
        SET v_cp_contact_organization_name = '<NULL>';
        SET v_cp_contact_division_name = '<NULL>';
        SET v_cp_contact_registration_code = '<NULL>';
        SET v_cp_contact_registration_date = '<NULL>';
        
        SET v_cp_member_first_name = '<NULL>';
        SET v_cp_member_last_name = '<NULL>';
        SET v_cp_member_organization_name = '<NULL>';
        SET v_cp_member_division_name = '<NULL>';
        SET v_cp_member_type = '<NULL>';
        SET v_cp_member_zip = '<NULL>';
    END IF;
    
    IF api.api_cbool( v_user_id ) THEN
        
        CALL api.db_log_message( 'upsert_cp_platform_user' ,
                                 CONCAT( 'UPDATING existing ' , v_count , ' records for EMAIL: ' ,
                                         api.api_nz( p_email , '' ) , ' is_tpa_user_active: ' ,
                                         api.api_nz( p_cp_tpa_user_is_active , '' ) , ' P_is_member_user_active: ' ,
                                         api.api_nz( p_cp_member_user_is_active , '' ) , ' P_ROW_ID: ' ,
                                         api.api_nz( p_cp_row_id , '' ) , ' P_is_client_user_active: ' ,
                                         api.api_nz( p_cp_client_user_is_active , '' ) ,
                                         'P_is_broker_user_active: ' ,
                                         api.api_nz( p_cp_broker_user_is_active , '' ) ) , 'WARN' );
        
        UPDATE api.platform_users
        SET
            user_name                    = api.api_if_true_else( v_is_locked , user_name ,
                                                                 api.api_nz( p_user_name , user_name ) )
          , first_name                   = api.api_if_true_else( v_is_locked , first_name ,
                                                                 api.api_nz( p_first_name , first_name ) )
          , last_name                    = api.api_if_true_else( v_is_locked , last_name ,
                                                                 api.api_nz( p_last_name , last_name ) )
          , email                        = api.api_if_true_else( v_is_locked , email , api.api_nz( p_email , email ) )
          , title                        = api.api_if_true_else( v_is_locked , title , api.api_nz( p_title , title ) )
          , mobile_number                = api.api_if_true_else( v_is_locked , mobile_number ,
                                                                 api.api_nz( p_mobile_number , mobile_number ) )
          , ssn                          = api.api_if_true_else( v_is_locked , ssn , api.api_nz( p_ssn , ssn ) )
          , dob                          = api.api_if_true_else( v_is_locked , dob , api.api_nz( p_dob , dob ) )
          , employee_id                  = api.api_if_true_else( v_is_locked , employee_id ,
                                                                 api.api_nz( p_employee_id , employee_id ) )
          , alternate_email              = api.api_if_true_else( v_is_locked , alternate_email ,
                                                                 api.api_nz( p_alternate_email , alternate_email ) )
          , cp_client_id                 = api.api_nz( p_cp_client_id , cp_client_id )
          , cp_broker_id                 = api.api_nz( p_cp_broker_id , cp_broker_id )
          , cp_client_contact_id         = api.api_nz( p_cp_client_contact_id , cp_client_contact_id )
          , cp_sso_identifier            = api.api_nz( p_cp_sso_identifier , cp_sso_identifier )
          , cp_customer_id               = api.api_nz( p_cp_customer_id , cp_customer_id )
          , cp_entity_type               = api.api_nz( p_cp_entity_type , cp_entity_type )
          , cp_user_id                   = api.api_nz( p_cp_user_id , cp_user_id )
          , cp_member_id                 = api.api_nz( p_cp_member_id , cp_member_id )
          , cp_allow_sso                 = api.api_nz( p_cp_allow_sso , cp_allow_sso )
          , cp_tpa_user_is_active        = api_cbool( api.api_nz( p_cp_tpa_user_is_active , cp_tpa_user_is_active ) )
          , cp_member_user_is_active     = api_cbool(
                api.api_nz( p_cp_member_user_is_active , cp_member_user_is_active ) )
          , cp_dob                       = api.api_nz( p_dob , cp_dob )
          , cp_ssn                       = api.api_nz( p_ssn , cp_ssn )
          , cp_email                     = api.api_nz( p_email , cp_email )
          , cp_row_id                    = api.api_nz( p_cp_row_id , cp_row_id )
          , cp_client_user_is_active     =api_cbool(
                api.api_nz( p_cp_client_user_is_active , cp_client_user_is_active ) )
          , cp_broker_user_is_active     =api_cbool(
                api.api_nz( p_cp_broker_user_is_active , cp_broker_user_is_active ) )
          
          , cp_contact_division_name     = api.api_nz( v_cp_contact_division_name , cp_contact_division_name )
          , cp_member_division_name      = api.api_nz( v_cp_member_division_name , cp_member_division_name )
          , cp_member_type               = api.api_nz( v_cp_member_type , cp_member_type )
          , cp_member_organization_name  = api.api_nz( v_cp_member_organization_name , cp_member_organization_name )
          , cp_member_last_name          = api.api_nz( v_cp_member_last_name , cp_member_last_name )
          , cp_member_first_name         = api.api_nz( v_cp_member_first_name , cp_member_first_name )
          , cp_contact_type              = api.api_nz( v_cp_contact_type , cp_contact_type )
          , cp_contact_organization_name = api.api_nz( v_cp_contact_organization_name , cp_contact_organization_name )
          , cp_contact_last_name         = api.api_nz( v_cp_contact_last_name , cp_contact_last_name )
          , cp_contact_first_name        = api.api_nz( v_cp_contact_first_name , cp_contact_first_name )
          , cp_contact_registration_code = api.api_nz( v_cp_contact_registration_code , cp_contact_registration_code )
          , cp_contact_registration_date = api.api_nz( v_cp_contact_registration_date , cp_contact_registration_date )
          , zip                          = api.api_nz( v_cp_member_zip , zip )
          , cp_zip                       = api.api_nz( v_cp_member_zip , cp_zip )
          , last_updated_from            = 'upsert_cp_platform_user'
        WHERE
            (email <=> p_email);
        
        LEAVE full_proc;
    END IF;
    
    CALL api.db_log_message( 'upsert_cp_platform_user' ,
                             CONCAT( 'UPSERTING record for SSO ID: ' , api.api_nz( p_cp_sso_identifier , '' ) ,
                                     ' AND user_id: ' , api.api_nz( p_cp_user_id , '' ) ) , 'WARN' );
    
    INSERT INTO api.platform_users(
                                    user_name
                                  , first_name
                                  , last_name
                                  , email
                                  , title
                                  , mobile_number
                                  , cp_client_id
                                  , cp_broker_id
                                  , cp_client_contact_id
                                  , cp_sso_identifier
                                  , cp_customer_id
                                  , cp_entity_type
                                  , cp_user_id
                                  , cp_member_id
                                  , cp_allow_sso
                                  , cp_tpa_user_is_active
                                  , cp_member_user_is_active
                                  , ssn
                                  , dob
                                  , employee_id
                                  , alternate_email
                                  , cp_dob
                                  , cp_ssn
                                  , cp_email
                                  , cp_row_id
                                  , last_updated_from
                                  , cp_client_user_is_active
                                  , cp_broker_user_is_active
                                  , cp_contact_division_name
                                  , cp_member_division_name
                                  , cp_member_type
                                  , cp_member_organization_name
                                  , cp_member_last_name
                                  , cp_member_first_name
                                  , cp_contact_type
                                  , cp_contact_organization_name
                                  , cp_contact_last_name
                                  , cp_contact_first_name
                                  , cp_contact_registration_code
                                  , cp_contact_registration_date
                                  , zip
                                  , cp_zip
    )
    VALUES (
               p_user_name
           ,   p_first_name
           ,   p_last_name
           ,   p_email
           ,   p_title
           ,   p_mobile_number
           ,   p_cp_client_id
           ,   p_cp_broker_id
           ,   p_cp_client_contact_id
           ,   p_cp_sso_identifier
           ,   p_cp_customer_id
           ,   p_cp_entity_type
           ,   p_cp_user_id
           ,   p_cp_member_id
           ,   p_cp_allow_sso
           ,   api_cbool( p_cp_tpa_user_is_active )
           ,   api_cbool( p_cp_member_user_is_active )
           ,   p_ssn
           ,   p_dob
           ,   p_employee_id
           ,   p_alternate_email
           ,   p_dob
           ,   p_ssn
           ,   p_email
           ,   p_cp_row_id
           ,   'upsert_cp_platform_user'
           ,   p_cp_client_user_is_active
           ,   p_cp_broker_user_is_active
           ,   v_cp_contact_division_name
           ,   v_cp_member_division_name
           ,   v_cp_member_type
           ,   v_cp_member_organization_name
           ,   v_cp_member_last_name
           ,   v_cp_member_first_name
           ,   v_cp_contact_type
           ,   v_cp_contact_organization_name
           ,   v_cp_contact_last_name
           ,   v_cp_contact_first_name
           ,   v_cp_contact_registration_code
           ,   v_cp_contact_registration_date
           ,   v_cp_member_zip
           ,   v_cp_member_zip
           )
    
    ON DUPLICATE KEY UPDATE
                         user_name                    = api.api_if_true_else( v_is_locked , user_name ,
                                                                              api.api_nz( p_user_name , user_name ) )
                       , first_name                   = api.api_if_true_else( v_is_locked , first_name ,
                                                                              api.api_nz( p_first_name , first_name ) )
                       , last_name                    = api.api_if_true_else( v_is_locked , last_name ,
                                                                              api.api_nz( p_last_name , last_name ) )
                       , email                        = api.api_if_true_else( v_is_locked , email ,
                                                                              api.api_nz( p_email , email ) )
                       , title                        = api.api_if_true_else( v_is_locked , title ,
                                                                              api.api_nz( p_title , title ) )
                       , mobile_number                = api.api_if_true_else( v_is_locked , mobile_number ,
                                                                              api.api_nz( p_mobile_number , mobile_number ) )
                       , ssn                          = api.api_if_true_else( v_is_locked , ssn , api.api_nz( p_ssn , ssn ) )
                       , dob                          = api.api_if_true_else( v_is_locked , dob , api.api_nz( p_dob , dob ) )
                       , employee_id                  = api.api_if_true_else( v_is_locked , employee_id ,
                                                                              api.api_nz( p_employee_id , employee_id ) )
                       , alternate_email              = api.api_if_true_else( v_is_locked , alternate_email ,
                                                                              api.api_nz( p_alternate_email , alternate_email ) )
                       , cp_client_id                 = api.api_nz( p_cp_client_id , cp_client_id )
                       , cp_broker_id                 = api.api_nz( p_cp_broker_id , cp_broker_id )
                       , cp_client_contact_id         = api.api_nz( p_cp_client_contact_id , cp_client_contact_id )
                       , cp_sso_identifier            = api.api_nz( p_cp_sso_identifier , cp_sso_identifier )
                       , cp_customer_id               = api.api_nz( p_cp_customer_id , cp_customer_id )
                       , cp_entity_type               = api.api_nz( p_cp_entity_type , cp_entity_type )
                       , cp_user_id                   = api.api_nz( p_cp_user_id , cp_user_id )
                       , cp_member_id                 = api.api_nz( p_cp_member_id , cp_member_id )
                       , cp_allow_sso                 = api.api_nz( p_cp_allow_sso , cp_allow_sso )
                       , cp_tpa_user_is_active        = api_cbool(
                api.api_nz( p_cp_tpa_user_is_active , cp_tpa_user_is_active ) )
                       , cp_member_user_is_active     = api_cbool(
                api.api_nz( p_cp_member_user_is_active , cp_member_user_is_active ) )
                       , cp_dob                       = api.api_nz( p_dob , cp_dob )
                       , cp_ssn                       = api.api_nz( p_ssn , cp_ssn )
                       , cp_email                     = api.api_nz( p_email , cp_email )
                       , cp_row_id                    = api.api_nz( p_cp_row_id , cp_row_id )
                       , cp_client_user_is_active     =api_cbool(
                api.api_nz( p_cp_client_user_is_active , cp_client_user_is_active ) )
                       , cp_broker_user_is_active     =api_cbool(
                api.api_nz( p_cp_broker_user_is_active , cp_broker_user_is_active ) )
       
                       , cp_contact_division_name     = api.api_nz( v_cp_contact_division_name , cp_contact_division_name )
                       , cp_member_division_name      = api.api_nz( v_cp_member_division_name , cp_member_division_name )
                       , cp_member_type               = api.api_nz( v_cp_member_type , cp_member_type )
                       , cp_member_organization_name  = api.api_nz( v_cp_member_organization_name ,
                                                                    cp_member_organization_name )
                       , cp_member_last_name          = api.api_nz( v_cp_member_last_name , cp_member_last_name )
                       , cp_member_first_name         = api.api_nz( v_cp_member_first_name , cp_member_first_name )
                       , cp_contact_type              = api.api_nz( v_cp_contact_type , cp_contact_type )
                       , cp_contact_organization_name = api.api_nz( v_cp_contact_organization_name ,
                                                                    cp_contact_organization_name )
                       , cp_contact_last_name         = api.api_nz( v_cp_contact_last_name , cp_contact_last_name )
                       , cp_contact_first_name        = api.api_nz( v_cp_contact_first_name , cp_contact_first_name )
                       , cp_contact_registration_code = api.api_nz( v_cp_contact_registration_code ,
                                                                    cp_contact_registration_code )
                       , cp_contact_registration_date = api.api_nz( v_cp_contact_registration_date ,
                                                                    cp_contact_registration_date )
                       , zip                          = api.api_nz( v_cp_member_zip , zip )
                       , cp_zip                       = api.api_nz( v_cp_member_zip , cp_zip )
                       , last_updated_from            = 'upsert_cp_platform_user';

END;

