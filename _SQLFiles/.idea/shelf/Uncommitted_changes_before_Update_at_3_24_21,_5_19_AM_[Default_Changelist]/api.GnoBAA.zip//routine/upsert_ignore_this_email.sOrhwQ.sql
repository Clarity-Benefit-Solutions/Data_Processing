CREATE
    DEFINER = root@`%` FUNCTION upsert_ignore_this_email(
                                                        p_email varchar(200),
                                                        p_platform varchar(50) ) RETURNS int(1)
BEGIN
    
    IF api.api_is_blank( p_email ) THEN
        RETURN 0;
    END IF;
    
    SET p_platform = LOWER( TRIM( api_nz( p_platform , '' ) ) );
    
    IF p_platform IN ('bt', 'rto', 'sf', 'wcp') THEN
        RETURN 0;
    END IF;
    
    IF p_platform IN ('wca', 'bs', 'cp', 'en') AND p_email LIKE '%@claritybenefitsolutions.com' THEN
        RETURN 1;
    END IF;
    
    RETURN 0;

END;

