CREATE
    DEFINER = admin@`%` PROCEDURE util_generate_upsert_sql_for_table(
                                                                    IN dbname varchar(100),
                                                                    IN tablename varchar(100) )
BEGIN
    
    SELECT
        dbname
      , db_table
      , concat( 'CREATE OR REPLACE PROCEDURE `' , dbname , '`.`' , 'upsert_' , db_table , '` ' , ' (' ,
                column_params_with_type , ') ' , "\r" , ' BEGIN ' , "\r\r\r" , ' -- handle error that may happen as the table has a few unique keys which may conflict
                   DECLARE EXIT HANDLER FOR SQLEXCEPTION
                   BEGIN
                   GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO,
                   @text = MESSAGE_TEXT;
                   SET @text = CONCAT(@text, Concat(' , "' \r" , 'Called With Params: ' , "'," , log_params , ")" , ') ;
                   CALL db_throw_error(@errno, ' , "'" , 'upsert_' , db_table , "'" , ', @text);
                    END;' , "\r\r\r" , 'CALL api.db_log_message(' , "'" , 'upsert_' , db_table , "'" , ',' , 'Concat(' ,
                "'" , 'Called With Params: ' , "'," , log_params , ")" , ",'" , 'WARN' , "'" , ');' , "\r\r\r"
                'INSERT INTO `' , dbname , '`.`' , db_table , '` ' , '(' , table_data.column_names , ') ' , "\r\r\r" '
VALUES (' , table_data.column_params , ' )' , "\r\r\r" ' /* use api_nz to avoid replacing previous value if new value is null or blank */
ON DUPLICATE KEY
UPDATE ' , table_data.column_set_clause , ';
' , "\r\r\r" '
END;' , "\r\r\r" ) procsql
    FROM
        (
            
            
            SELECT
                table_order_key
              , table_name db_table
              , group_concat( "\r  `p_" , column_name , "` " , column_type ORDER BY
                              column_order_key ) column_params_with_type
              , group_concat( "\r  `p_" , column_name , "` " ORDER BY column_order_key ) column_params
              , group_concat( "`" , column_name , "`" ORDER BY column_order_key ) column_names
              , group_concat( "`" , column_name , "` = " , util_generate_upsert_sql_nz_string( column_type ) , "(`p_" ,
                              column_name , "`, `" , column_name , "` )" ORDER BY column_order_key ) column_set_clause
              , group_concat( "', " , column_name , ': ' , "'," , "api.api_nz(`p_" , column_name , "`, '') " ORDER BY
                              column_order_key ) log_params
            FROM
                (
                    SELECT
                        information_schema.tables.table_name table_name
                      , information_schema.columns.column_name column_name
                      , information_schema.columns.column_type column_type
                      , information_schema.tables.create_time table_order_key
                      , information_schema.columns.ordinal_position column_order_key
                    FROM
                        information_schema.tables
                            JOIN information_schema.columns
                                 ON information_schema.tables.table_name = information_schema.columns.table_name
                    WHERE
                          information_schema.tables.table_schema = dbname
                      AND information_schema.columns.table_schema = dbname
                      AND information_schema.tables.table_name NOT LIKE "audit\_%"
                      AND information_schema.columns.column_name NOT LIKE 'created_at'
                      AND information_schema.columns.column_name NOT LIKE 'created_by'
                      AND information_schema.columns.column_name NOT LIKE 'updated_at'
                      AND information_schema.columns.column_name NOT LIKE 'updated_by'
                      AND information_schema.columns.is_generated = 'NEVER'
                      AND information_schema.columns.extra NOT LIKE 'auto_increment'
                ) table_column_ordering_info
            
            WHERE
                table_name = tablename
            GROUP BY
                table_name
        ) table_data
    ORDER BY
        table_order_key;
END;

