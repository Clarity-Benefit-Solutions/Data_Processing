CREATE
    DEFINER = admin@`%` FUNCTION api_nz_date(
                                            value varchar(200),
                                            valueifnullorempty varchar(200) ) RETURNS date
BEGIN
    IF ifnull(value, '') = '' THEN
        RETURN api_cdate(valueifnullorempty);
        /* sumeet: allow force setting a value to null by passing '<NULL>'*/
    ELSEIF ifnull(
                   value
               , '') = '<NULL>' THEN
        RETURN NULL;
    ELSE
        RETURN api_cdate(value);
    END IF;
END;

