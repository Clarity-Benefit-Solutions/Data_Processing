CREATE
    DEFINER = root@`%` PROCEDURE upsert_sf_platform_user(
                                                        IN p_user_name varchar(200),
                                                        IN p_email varchar(200),
                                                        IN p_first_name varchar(200),
                                                        IN p_last_name varchar(200),
                                                        IN p_mobile_number varchar(200),
                                                        IN p_ssn varchar(200),
                                                        IN p_sf_employee_id varchar(200),
                                                        IN p_dob varchar(50),
                                                        IN p_sf_is_active int,
                                                        IN p_sf_is_employee int,
                                                        IN p_sf_is_client int,
                                                        IN p_sf_is_broker int,
                                                        IN p_sf_row_id int,
                                                        IN p_sf_employer_id varchar(200),
                                                        IN p_sf_is_in_bs int,
                                                        IN p_sf_is_in_cp int,
                                                        IN p_sf_is_in_en int,
                                                        IN p_sf_is_in_wc int )
full_proc:
BEGIN
    DECLARE v_count varchar(50) DEFAULT NULL;
    DECLARE v_user_id varchar(50) DEFAULT NULL;
    DECLARE v_is_locked varchar(5) DEFAULT NULL;
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN
        GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
        CALL db_log_error( @errno , 'upsert_sf_platform_user' , @text , @sqlstate );
    END;
    
    SET p_email = api.api_fix_email( p_email );
    SET p_user_name = api.api_fix_email( p_user_name );
    SET p_ssn = api.api_fix_email( p_ssn );
    SET p_sf_employee_id = api.api_fix_email( p_sf_employee_id );
    SET p_mobile_number = api.api_fix_phone_number( p_mobile_number );
    SET p_dob = api.api_fix_date( p_dob );
    
    IF api.api_is_blank( p_email ) OR api.api_is_blank( p_user_name ) THEN
        CALL api.db_log_message( 'upsert_sf_platform_user' ,
                                 CONCAT( 'Not Inserting record as either email or username is blank ' ,
                                         'Import First Name: ' , api.api_nz( p_first_name , '' ) , ' AND Last Name: ' ,
                                         api.api_nz( p_last_name , '' ) ) , 'WARN' );
        
        LEAVE full_proc;
    END IF;
    
    IF !api.api_is_blank( p_email ) THEN
        
        SELECT
            COUNT( * )
          , user_id
          , CASE
                WHEN is_verified OR is_ready_for_sso_processing THEN 1
                ELSE 0
            END
        INTO v_count, v_user_id, v_is_locked
        FROM
            api.platform_users
        WHERE
            (email = p_email);
        
        SET v_user_id = api.api_nz( v_user_id , '' );
        
        CALL api.db_log_message( 'upsert_sf_platform_user' ,
                                 CONCAT( v_count , ' Records found for EMAIL: ' , api.api_nz( p_email , '' ) ) ,
                                 'WARN' );
        IF api.api_cbool( v_user_id ) THEN
            CALL api.db_log_message( 'upsert_sf_platform_user' ,
                                     CONCAT( 'UPDATING existing ' , v_count , ' records for EMAIL: ' ,
                                             api.api_nz( p_email , '' ) ) , 'WARN' );
            
            UPDATE api.platform_users
            SET
                user_name         = api_if_true_else( v_is_locked , user_name , api_nz( p_user_name , user_name ) )
              , first_name        = api_if_true_else( v_is_locked , first_name , api_nz( p_first_name , first_name ) )
              , last_name         = api_if_true_else( v_is_locked , last_name , api_nz( p_last_name , last_name ) )
              , email             = api_if_true_else( v_is_locked , email , api_nz( p_email , email ) )
              , mobile_number     = api_if_true_else( v_is_locked , mobile_number ,
                                                      api_nz( p_mobile_number , mobile_number ) )
              , ssn               = api_if_true_else( v_is_locked , ssn , api_nz( p_ssn , ssn ) )
              , dob               = api_if_true_else( v_is_locked , dob , api_nz( p_dob , dob ) )
              , employee_id       = api_if_true_else( v_is_locked , employee_id ,
                                                      api_nz( p_sf_employee_id , employee_id ) )
              
              , sf_employer_id    = api_nz( p_sf_employer_id , sf_employer_id )
              , sf_dob            = api_nz( p_dob , sf_dob )
              , sf_ssn            = api_nz( p_ssn , sf_ssn )
              , sf_email          = api_nz( p_email , sf_email )
              , sf_user_is_active = api_cbool( api_nz( p_sf_is_active , sf_user_is_active ) )
              , sf_is_employee    = api_cbool( api_nz( p_sf_is_employee , sf_is_employee ) )
              , sf_is_client= api_cbool( api_nz( p_sf_is_client , sf_is_client ) )
              , sf_is_broker= api_cbool( api_nz( p_sf_is_broker , sf_is_broker ) )
              , sf_row_id= api_nz( p_sf_row_id , sf_row_id )
              , en_is_manager     = api_cbool( CASE
                                                   WHEN p_sf_is_in_en > 0 THEN p_sf_is_in_en
                                                   ELSE en_is_manager
                                               END )
              , last_updated_from = 'upsert_sf_platform_user'
            WHERE
                (email = p_email);
            
            LEAVE full_proc;
        END IF;
    END IF;
    
    CALL api.db_log_message( 'upsert_sf_platform_user' ,
                             CONCAT( 'UPSERTING record for Import First Name: ' , api.api_nz( p_first_name , '' ) ,
                                     ' AND Last Name: ' , api.api_nz( p_last_name , '' ) ) , 'WARN' );
    
    INSERT INTO api.platform_users(
                                    user_name
                                  , first_name
                                  , last_name
                                  , email
                                  , mobile_number
                                  , sf_dob
                                  , dob
                                  , ssn
                                  , employee_id
                                  , sf_user_is_active
                                  , sf_employer_id
                                  , sf_ssn
                                  , sf_email
                                  , sf_is_employee
                                  , sf_is_client
                                  , sf_is_broker
                                  , sf_row_id
                                  , en_is_manager
                                  , last_updated_from
    )
    VALUES (
               p_user_name
           ,   p_first_name
           ,   p_last_name
           ,   p_email
           ,   p_mobile_number
           ,   p_dob
           ,   p_dob
           ,   p_ssn
           ,   p_sf_employee_id
           ,   api_cbool( p_sf_is_active )
           ,   p_sf_employer_id
           ,   p_ssn
           ,   p_email
           ,   api_cbool( p_sf_is_employee )
           ,   api_cbool( p_sf_is_client )
           ,   api_cbool( p_sf_is_broker )
           ,   p_sf_row_id
           ,   p_sf_is_in_en
           ,   'upsert_sf_platform_user'
           )
    
    ON DUPLICATE KEY UPDATE
                         user_name         = api_if_true_else( v_is_locked , user_name ,
                                                               api_nz( p_user_name , user_name ) )
                       , first_name        = api_if_true_else( v_is_locked , first_name ,
                                                               api_nz( p_first_name , first_name ) )
                       , last_name         = api_if_true_else( v_is_locked , last_name ,
                                                               api_nz( p_last_name , last_name ) )
                       , email             = api_if_true_else( v_is_locked , email , api_nz( p_email , email ) )
                       , mobile_number     = api_if_true_else( v_is_locked , mobile_number ,
                                                               api_nz( p_mobile_number , mobile_number ) )
                       , ssn               = api_if_true_else( v_is_locked , ssn , api_nz( p_ssn , ssn ) )
                       , dob               = api_if_true_else( v_is_locked , dob , api_nz( p_dob , dob ) )
                       , employee_id       = api_if_true_else( v_is_locked , employee_id ,
                                                               api_nz( p_sf_employee_id , employee_id ) )
       
                       , sf_employer_id    = api_nz( p_sf_employer_id , sf_employer_id )
                       , sf_dob            = api_nz( p_dob , sf_dob )
                       , sf_ssn            = api_nz( p_ssn , sf_ssn )
                       , sf_email          = api_nz( p_email , sf_email )
                       , sf_user_is_active = api_cbool( api_nz( p_sf_is_active , sf_user_is_active ) )
                       , sf_is_employee    = api_cbool( api_nz( p_sf_is_employee , sf_is_employee ) )
                       , sf_is_client= api_cbool( api_nz( p_sf_is_client , sf_is_client ) )
                       , sf_is_broker= api_cbool( api_nz( p_sf_is_broker , sf_is_broker ) )
                       , sf_row_id= api_nz( p_sf_row_id , sf_row_id )
                       , en_is_manager     = api_cbool( CASE
                                                            WHEN p_sf_is_in_en > 0 THEN p_sf_is_in_en
                                                            ELSE en_is_manager
                                                        END )
                       , last_updated_from = 'upsert_sf_platform_user';

END;

