CREATE
    DEFINER = root@`%` FUNCTION sso_get_record_for_rto(
    p_email varchar(200) ) RETURNS varchar(200)
BEGIN
    DECLARE v_row_id varchar(200) DEFAULT NULL;
    
    IF api.api_is_blank( p_email ) THEN
        RETURN 0;
    END IF;
    
    SELECT
        row_id
    INTO v_row_id
    FROM
        misc.vw_rto_users t
    WHERE
        email = p_email
    ORDER BY
        email
      , user_type DESC
      , is_active DESC
    LIMIT 1;
    
    RETURN v_row_id;

END;

