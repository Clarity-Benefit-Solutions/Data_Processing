CREATE
    DEFINER = root@`%` FUNCTION get_registration_invite_count(
    p_email varchar(200) ) RETURNS text
BEGIN
    
    DECLARE v_count int(11);
    
    select
        count( * )
    into v_count
    
    FROM
        api.api_notification_logs
    WHERE
        destination_address = p_email
            and notification_type like 'email'
            and notification_category = 'Registration';
    
    return api.api_nz_int( v_count , 0);
END;

