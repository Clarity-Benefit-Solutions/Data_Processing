CREATE DEFINER = root@`%` TRIGGER bi_platform_users_new_fix_fields
    BEFORE INSERT
    ON platform_users
    FOR EACH ROW
BEGIN
    SET new.email = api.api_fix_email( new.email );
    SET new.user_name = api.api_fix_email( new.user_name );
    
    SET new.ssn = api.api_fix_ssn( new.ssn );
    SET new.employee_id = api.api_fix_ssn( new.employee_id );
    
    SET new.cp_ssn = api.api_fix_ssn( new.cp_ssn );
    SET new.wc_ssn = api.api_fix_ssn( new.wc_ssn );
    SET new.bs_ssn = api.api_fix_ssn( new.bs_ssn );
    
    SET new.dob = api.api_fix_date( new.dob );
    SET new.cp_dob = api.api_fix_date( new.cp_dob );
    SET new.bs_dob = api.api_fix_date( new.bs_dob );
    SET new.wc_dob = api.api_fix_date( new.wc_dob );
    
    SET new.is_invalid = api.api_cint( new.is_invalid );
    SET new.is_ready_for_sso_processing = api.api_cint( new.is_ready_for_sso_processing );
    SET new.is_invited = api.api_cint( new.is_invited );
    SET new.is_verified = api.api_cint( new.is_verified );
    
    SET new.bs_user_is_active = api.api_cint( new.bs_user_is_active );
    SET new.cp_allow_sso = api.api_cint( new.cp_allow_sso );
    SET new.cp_member_user_is_active = api.api_cint( new.cp_member_user_is_active );
    SET new.cp_tpa_user_is_active = api.api_cint( new.cp_tpa_user_is_active );
    SET new.wca_user_is_active = api.api_cint( new.wca_user_is_active );
    SET new.wcp_user_is_active = api.api_cint( new.wcp_user_is_active );
    
    set new.zip = api.api_fix_zip( new.zip );
    set new.cp_zip = api.api_fix_zip( new.cp_zip );
    set new.bs_zip = api.api_fix_zip( new.bs_zip );
    set new.en_zip = api.api_fix_zip( new.en_zip );
    set new.wc_zip = api.api_fix_zip( new.wc_zip );

END;

