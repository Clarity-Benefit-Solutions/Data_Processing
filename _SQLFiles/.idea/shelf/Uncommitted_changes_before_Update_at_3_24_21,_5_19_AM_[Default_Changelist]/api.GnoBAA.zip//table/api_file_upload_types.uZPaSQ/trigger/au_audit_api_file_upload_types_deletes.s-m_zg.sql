CREATE DEFINER = admin@`%` TRIGGER au_audit_api_file_upload_types_deletes
    AFTER DELETE
    ON api_file_upload_types
    FOR EACH ROW
    INSERT INTO `api`.`api_file_upload_types_audit`
                 (`auditAction`, `platform_name`, `platform_template_name`, `platform_template_status`,
                  `platform_template_type`, `platform_template_download_file_name`, `platform_template_content`,
                  `platform_template_file_url`, `upload_destination_host`, `upload_destination_url`, `created_at`,
                  `created_by`, `updated_at`, `updated_by`)
                 VALUES ('DELETE', OLD.`platform_name`, OLD.`platform_template_name`, OLD.`platform_template_status`,
                         OLD.`platform_template_type`, OLD.`platform_template_download_file_name`,
                         OLD.`platform_template_content`, OLD.`platform_template_file_url`,
                         OLD.`upload_destination_host`, OLD.`upload_destination_url`, OLD.`created_at`,
                         OLD.`created_by`, OLD.`updated_at`, OLD.`updated_by`);

