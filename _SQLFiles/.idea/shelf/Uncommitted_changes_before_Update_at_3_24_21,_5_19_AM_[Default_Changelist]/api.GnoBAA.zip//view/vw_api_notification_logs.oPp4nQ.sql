CREATE DEFINER = root@`%` VIEW vw_api_notification_logs
AS
    SELECT
        `n`.`notification_id` `NotificationId`
      , `n`.`destination_address` `DestinationAddress`
      , `n`.`notification_type` `NotificationType`
      , `n`.`notification_category` `NotificationCategory`
      , `n`.`notification_sub_category` `NotificationSubCategory`
      , `n`.`notification_label` `NotificationLabel`
      , `n`.`notification_status` `NotificationStatus`
      , `n`.`user_id` `UserId`
      , `u`.`first_name` `FirstName`
      , `u`.`last_name` `LastName`
      , `u`.`mobile_number` `MobileNumber`
      , `u`.`is_tpa_admin` `IsTpaAdmin`
      , `u`.`is_broker` `IsBroker`
      , `u`.`is_client` `IsClient`
      , `u`.`is_particpant` `IsParticpant`
      , `u`.`is_verified` `IsVerified`
      , `n`.`case_id` `CaseId`
      , `c`.`case_type` `CaseType`
      , `c`.`case_sub_type` `CaseSubType`
      , `c`.`employer_name` `EmployerName`
      , `c`.`sf_case_id` `SfCaseId`
      , `n`.`notification_sent_at` `NotificationSentAt`
    FROM
        ((`api`.`api_notification_logs` `n` LEFT JOIN `api`.`api_cases` `c` ON (`n`.`case_id` = `c`.`case_id`))
            LEFT JOIN `api`.`vw_platform_sso_users` `u` ON (`n`.`user_id` = `u`.`user_id`));

