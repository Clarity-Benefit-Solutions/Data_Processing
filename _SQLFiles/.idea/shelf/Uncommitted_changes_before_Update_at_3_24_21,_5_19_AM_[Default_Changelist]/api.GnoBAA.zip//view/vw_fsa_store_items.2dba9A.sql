CREATE DEFINER = root@`%` VIEW vw_fsa_store_items
AS
    SELECT
        `misc`.`fsa_store_items`.`rowid` `rowid`
      , `misc`.`fsa_store_items`.`expensetypeid` `expensetypeid`
      , `misc`.`fsa_store_items`.`label` `label`
      , SUBSTR( `misc`.`fsa_store_items`.`label` , 1 , 1 ) `labelfirstchar`
      , `misc`.`fsa_store_items`.`isproduct` `isproduct`
      , `misc`.`fsa_store_items`.`description` `description`
      , `misc`.`fsa_store_items`.`fsaeligibilitytype` `fsaeligibilitytype`
      , `misc`.`fsa_store_items`.`limitedcarefsaeligibilitytype` `limitedcarefsaeligibilitytype`
      , `misc`.`fsa_store_items`.`dependentcarefsaeligibilitytype` `dependentcarefsaeligibilitytype`
      , `misc`.`fsa_store_items`.`hsaeligibilitytype` `hsaeligibilitytype`
      , `misc`.`fsa_store_items`.`hraeligibilitytype` `hraeligibilitytype`
      , `misc`.`fsa_store_items`.`shoppinglinkurl` `learnmorelinkurl`
      , `misc`.`fsa_store_items`.`learnmorelinktext` `learnmorelinktext`
      , `misc`.`fsa_store_items`.`shoppinglinkurl` `shoppinglinkurl`
      , `misc`.`fsa_store_items`.`shoppinglinktext` `shoppinglinktext`
      , `misc`.`fsa_store_items`.`shoppinglinktype` `shoppinglinktype`
      , `misc`.`get_fsa_store_url`( `misc`.`fsa_store_items`.`shoppinglinkurl` ,
                                    `misc`.`fsa_store_items`.`learnmorelinkurl` ,
                                    `misc`.`fsa_store_items`.`shoppinglinktext` ,
                                    `misc`.`fsa_store_items`.`learnmorelinktext` ,
                                    `misc`.`fsa_store_items`.`shoppinglinktype` ,
                                    `misc`.`fsa_store_items`.`label` ) `url`
      , `misc`.`fsa_store_items`.`created_at` `created_at`
      , `misc`.`fsa_store_items`.`created_by` `created_by`
      , `misc`.`fsa_store_items`.`updated_at` `updated_at`
      , `misc`.`fsa_store_items`.`updated_by` `updated_by`
      , CASE
            WHEN `misc`.`fsa_store_items`.`fsaeligibilitytype` LIKE 'Eligible%' THEN 1
            ELSE 0
        END `fsaeligibile`
      , CASE
            WHEN `misc`.`fsa_store_items`.`hsaeligibilitytype` LIKE 'Eligible%' THEN 1
            ELSE 0
        END `hsaeligibile`
      , CASE
            WHEN `misc`.`fsa_store_items`.`hraeligibilitytype` LIKE 'Eligible%' THEN 1
            ELSE 0
        END `hraeligibile`
      , CASE
            WHEN `misc`.`fsa_store_items`.`limitedcarefsaeligibilitytype` LIKE 'Eligible%' THEN 1
            ELSE 0
        END `limitedcarefsaeligibile`
      , CASE
            WHEN `misc`.`fsa_store_items`.`dependentcarefsaeligibilitytype` LIKE 'Eligible%' THEN 1
            ELSE 0
        END `dependentcarefsaeligibile`
    FROM
        `misc`.`fsa_store_items`
    ORDER BY
        `misc`.`fsa_store_items`.`label`;

