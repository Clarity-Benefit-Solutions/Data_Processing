CREATE DEFINER = root@`%` VIEW vw_sso_platform_rto
AS
    SELECT
        `t`.`email` `email`
      , CASE
            WHEN `t`.`row_id` = `api`.`sso_get_record_for_rto`( `t`.`email` ) THEN 1
            ELSE 0
        END `is_sso_record`
      , `t`.`is_active` `is_active`
      , `t`.`user_type` `user_type`
      , `t`.`row_id` `row_id`
      , `t`.`role` `role`
      , `t`.`first_name` `first_name`
      , `t`.`last_name` `last_name`
      , `t`.`company_name` `company_name`
      , `t`.`created_date` `created_date`
      , `t`.`group_id` `group_id`
      , `t`.`external_id` `external_id`
      , `t`.`created_at` `created_at`
      , `t`.`created_by` `created_by`
      , `t`.`updated_at` `updated_at`
      , `t`.`updated_by` `updated_by`
    FROM
        `misc`.`vw_rto_users` `t`;

