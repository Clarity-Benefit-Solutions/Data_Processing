CREATE DEFINER = admin@`%` VIEW vw_temp_case_contacts_data
AS
    SELECT
        `c`.`case_id` `case_id`
      , `c`.`employer_name` `employer_name`
      , `p`.`contact_type` `contact_type`
      , `p`.`organization_name` `organization_name`
      , `p`.`organization_state` `organization_state`
      , `p`.`organization_zip` `organization_zip`
      , `p`.`contact_sub_type` `contact_sub_type`
      , `p`.`contact_title` `contact_title`
      , `p`.`contact_first_name` `contact_first_name`
      , `p`.`contact_last_name` `contact_last_name`
      , `p`.`contact_email` `contact_email`
      , `p`.`contact_phone` `contact_phone`
      , `p`.`contact_is_cons_ben_contact` `contact_is_cons_ben_contact`
      , `p`.`contact_is_cobra_contact` `contact_is_cobra_contact`
      , `p`.`contact_is_ben_admin_contact` `contact_is_ben_admin_contact`
    FROM
        (`api`.`api_cases` `c`
            JOIN `api`.`api_case_contacts` `p` ON (`c`.`case_id` = `p`.`case_id`))
    ORDER BY
        `c`.`employer_name`
      , `c`.`case_id`
      , `p`.`contact_email`;

