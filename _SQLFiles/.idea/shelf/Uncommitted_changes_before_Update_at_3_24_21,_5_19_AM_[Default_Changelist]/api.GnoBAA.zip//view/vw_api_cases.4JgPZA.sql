CREATE DEFINER = admin@`%` VIEW vw_api_cases
AS
    SELECT
        `api`.`api_cases`.`case_id` `case_id`
      , `api`.`api_cases`.`case_status` `case_status`
      , `api`.`api_cases`.`version_no` `version_no`
      , `api`.`api_cases`.`case_type` `case_type`
      , `api`.`api_cases`.`case_sub_type` `case_sub_type`
      , `api`.`api_cases`.`employer_id` `employer_id`
      , `api`.`api_cases`.`employer_name` `employer_name`
      , `api`.`api_cases`.`employer_division_name` `employer_division_name`
      , `api`.`api_cases`.`sf_case_id` `sf_case_id`
      , `api`.`api_cases`.`sf_account_no` `sf_account_no`
      , `api`.`api_cases`.`form_invite_token` `form_invite_token`
      , `api`.`api_cases`.`form_curr_page_no` `form_curr_page_no`
      , `api`.`api_cases`.`wizard_curr_step_no` `wizard_curr_step_no`
      , `api`.`api_cases`.`form_type` `form_type`
      , `api`.`api_cases`.`form_entry_id` `form_entry_id`
      , `api`.`api_cases`.`legal_business_name` `legal_business_name`
      , `api`.`api_cases`.`dba` `dba`
      , `api`.`api_cases`.`street_physical_address` `street_physical_address`
      , `api`.`api_cases`.`street_line2` `street_line2`
      , `api`.`api_cases`.`city` `city`
      , `api`.`api_cases`.`state` `state`
      , `api`.`api_cases`.`zip` `zip`
      , `api`.`api_cases`.`phone` `phone`
      , `api`.`api_cases`.`fax` `fax`
      , `api`.`api_cases`.`web_address` `web_address`
      , `api`.`api_cases`.`incorporation_date` `incorporation_date`
      , `api`.`api_cases`.`laws_of_state` `laws_of_state`
      , `api`.`api_cases`.`healthcare_carrier` `healthcare_carrier`
      , `api`.`api_cases`.`healthcare_plan_type` `healthcare_plan_type`
      , `api`.`api_cases`.`dental_care_carrier` `dental_care_carrier`
      , `api`.`api_cases`.`dental_care_plan_type` `dental_care_plan_type`
      , `api`.`api_cases`.`vision_care_carrier` `vision_care_carrier`
      , `api`.`api_cases`.`vision_care_plan_type` `vision_care_plan_type`
      , `api`.`api_cases`.`cons_ben_plan_open_enrollment_start_date` `cons_ben_plan_open_enrollment_start_date`
      , `api`.`api_cases`.`cons_ben_plan_open_enrollment_end_date` `cons_ben_plan_open_enrollment_end_date`
      , `api`.`api_cases`.`cons_ben_plan_enrollment_method_employees` `cons_ben_plan_enrollment_method_employees`
      , `api`.`api_cases`.`cons_ben_plan_enrollment_data_transmission_to_clarity` `cons_ben_plan_enrollment_data_transmission_to_clarity`
      , `api`.`api_cases`.`cons_ben_plan_estimated_date_enrollment_data_delivery` `cons_ben_plan_estimated_date_enrollment_data_delivery`
      , `api`.`api_cases`.`cons_ben_plan_type` `cons_ben_plan_type`
      , `api`.`api_cases`.`cons_ben_plan_employee_class` `cons_ben_plan_employee_class`
      , `api`.`api_cases`.`cons_ben_plan_first_payroll_date` `cons_ben_plan_first_payroll_date`
      , `api`.`api_cases`.`cons_ben_plan_waiting_period` `cons_ben_plan_waiting_period`
      , `api`.`api_cases`.`cons_ben_plan_parking_transit_waiting_period` `cons_ben_plan_parking_transit_waiting_period`
      , `api`.`api_cases`.`cons_ben_plan_qualified_dependents` `cons_ben_plan_qualified_dependents`
      , `api`.`api_cases`.`cobra_plan_open_enrollment_start_date` `cobra_plan_open_enrollment_start_date`
      , `api`.`api_cases`.`cobra_plan_open_enrollment_end_date` `cobra_plan_open_enrollment_end_date`
      , `api`.`api_cases`.`cobra_plan_enrollment_method_employees` `cobra_plan_enrollment_method_employees`
      , `api`.`api_cases`.`cobra_plan_enrollment_data_transmission_to_clarity` `cobra_plan_enrollment_data_transmission_to_clarity`
      , `api`.`api_cases`.`cobra_plan_estimated_date_enrollment_data_delivery` `cobra_plan_estimated_date_enrollment_data_delivery`
      , `api`.`api_cases`.`cobra_plan_type` `cobra_plan_type`
      , `api`.`api_cases`.`cobra_plan_employee_class` `cobra_plan_employee_class`
      , `api`.`api_cases`.`cobra_plan_first_payroll_date` `cobra_plan_first_payroll_date`
      , `api`.`api_cases`.`cobra_plan_waiting_period` `cobra_plan_waiting_period`
      , `api`.`api_cases`.`cobra_plan_parking_transit_waiting_period` `cobra_plan_parking_transit_waiting_period`
      , `api`.`api_cases`.`cobra_plan_qualified_dependents` `cobra_plan_qualified_dependents`
      , `api`.`api_cases`.`is_ready_for_processing` `is_ready_for_processing`
      , `api`.`api_cases`.`cons_ben_has_rol_plan` `cons_ben_has_rol_plan`
      , `api`.`api_cases`.`created_at` `created_at`
      , `api`.`api_cases`.`created_by` `created_by`
      , `api`.`api_cases`.`updated_at` `updated_at`
      , `api`.`api_cases`.`updated_by` `updated_by`
    FROM
        `api`.`api_cases`;

