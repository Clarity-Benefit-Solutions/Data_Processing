CREATE DEFINER = admin@`%` VIEW vw_additional_service_options_for_employer_id
AS
    SELECT
        1 `employer_id`;

