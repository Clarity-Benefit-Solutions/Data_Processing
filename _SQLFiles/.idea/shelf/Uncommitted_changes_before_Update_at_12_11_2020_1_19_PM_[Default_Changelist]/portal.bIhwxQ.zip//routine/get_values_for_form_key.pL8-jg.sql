create
    definer = admin@`%` procedure get_values_for_form_key(IN p_form_item_key varchar(50), IN p_add_header int,
                                                          IN p_page_name varchar(200),
                                                          IN p_repeater_field_name varchar(200), OUT v_CSV longtext)
BEGIN

    DECLARE v_item_id int;
    DECLARE v_item_created_at timestamp;
    DECLARE v_entry_created_at timestamp;

    -- get id of item
    SELECT id, created_at
    INTO v_item_id , v_item_created_at
    FROM
        portal.cl_frm_items
    WHERE
        item_key = p_form_item_key;

    -- get time entry was first created from audit table
    SELECT created_at
    INTO v_entry_created_at
    FROM
        portal.cl_frm_items_audit
    WHERE
          item_key = p_form_item_key
      AND auditAction = 'INSERT'
    ORDER BY
        cl_frm_items_audit.created_at DESC
    LIMIT 1;

    IF api.api_is_blank( v_entry_created_at ) THEN
        CALL api.db_log_message( 'get_values_for_form_key',
                                 concat( 'Could not get Entry Created at for Item:  ', p_form_item_key ), 'WARN' );
        -- take a very early date so everything will show as Changes
        SET v_entry_created_at = v_item_created_at;
    END IF;


    CALL api.db_log_message( 'get_values_for_form_key',
                             concat( 'Using Entry Created Time:  ', v_entry_created_at ), 'WARN' );

    -- add one minute
    SET v_entry_created_at = TIMESTAMPADD( MINUTE, 1, v_entry_created_at );

    CALL portal.get_values_for_form_entry( v_entry_created_at, v_item_id, p_add_header, p_page_name,
                                           p_repeater_field_name, v_CSV );

END;

