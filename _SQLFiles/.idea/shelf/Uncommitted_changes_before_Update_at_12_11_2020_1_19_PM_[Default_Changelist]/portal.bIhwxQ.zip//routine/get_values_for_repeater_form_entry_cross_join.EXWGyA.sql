create
    definer = admin@`%` procedure get_values_for_repeater_form_entry_cross_join(IN p_entry_created_at timestamp,
                                                                                IN p_curr_form_item_id int,
                                                                                IN p_org_form_item_id int,
                                                                                IN p_page_name varchar(200),
                                                                                IN p_repeater_field_name varchar(200),
                                                                                OUT v_CSV longtext)
BEGIN

    DECLARE v_curr_item_id varchar(100);
    DECLARE v_curr_form_id varchar(100);
    DECLARE v_curr_form_name varchar(200);
    DECLARE v_curr_page_name varchar(500);
    DECLARE v_curr_field_order int;
    DECLARE v_curr_field_name varchar(500);
    DECLARE v_curr_value_has_changed varchar(10);
    DECLARE v_curr_current_value text;
    DECLARE v_curr_original_value text;
    DECLARE v_curr_field_key varchar(500);
    DECLARE v_curr_field_id varchar(100);
    DECLARE v_curr_field_type varchar(100);
    DECLARE v_curr_created_at timestamp;
    DECLARE v_curr_updated_at timestamp;

    DECLARE v_org_item_id varchar(100);
    DECLARE v_org_form_id varchar(100);
    DECLARE v_org_form_name varchar(200);
    DECLARE v_org_page_name varchar(500);
    DECLARE v_org_field_order int;
    DECLARE v_org_field_name varchar(500);
    DECLARE v_org_value_has_changed varchar(10);
    DECLARE v_org_current_value text;
    DECLARE v_org_original_value text;
    DECLARE v_org_field_key varchar(500);
    DECLARE v_org_field_id varchar(100);
    DECLARE v_org_field_type varchar(100);
    DECLARE v_org_created_at timestamp;
    DECLARE v_org_updated_at timestamp;

    DECLARE v_finished int;

    DECLARE v_rowCsv text;

    DECLARE v_counter int;

    DECLARE v_values_cursor CURSOR FOR SELECT api.api_nz(curr.item_id, ''),
                                              api.api_nz(curr.form_id, ''),
                                              api.api_nz(curr.form_name, ''),
                                              api.api_nz(curr.page_name, ''),
                                              api.api_nz(curr.field_order, ''),
                                              api.api_nz(curr.field_name, ''),
                                              api.api_nz(curr.value_has_changed, ''),
                                              api.api_nz(curr.current_value, ''),
                                              api.api_nz(curr.original_value, ''),
                                              api.api_nz(curr.field_key, ''),
                                              api.api_nz(curr.field_id, ''),
                                              api.api_nz(curr.field_type, ''),
                                              curr.created_at,
                                              curr.updated_at,
                                              api.api_nz(org.item_id, ''),
                                              api.api_nz(org.form_id, ''),
                                              api.api_nz(org.form_name, ''),
                                              api.api_nz(org.page_name, ''),
                                              api.api_nz(org.field_order, ''),
                                              api.api_nz(org.field_name, ''),
                                              api.api_nz(org.value_has_changed, ''),
                                              api.api_nz(org.current_value, ''),
                                              api.api_nz(org.original_value, ''),
                                              api.api_nz(org.field_key, ''),
                                              api.api_nz(org.field_id, ''),
                                              api.api_nz(org.field_type, ''),
                                              api.api_nz_date(org.created_at,curr.created_at),
                                              org.updated_at
                                       FROM vw_get_values_for_form_entry curr
                                                CROSS JOIN portal.vw_get_org_values_for_form_entry org
                                                           ON curr.field_id = org.field_id
                                       WHERE curr.item_id = p_curr_form_item_id
                                         AND org.item_id = p_org_form_item_id;

    DECLARE CONTINUE HANDLER FOR NOT FOUND BEGIN
        SET v_finished = 1;

    END;

    SET @@max_sp_recursion_depth = 12;

    SET v_CSV = '';

    --
    OPEN v_values_cursor;
    #
 /*   CALL api.db_log_message('get_values_for_repeater_form_entry',
                            concat(p_repeater_field_name, ': Curr Entry ID:  ', p_curr_form_item_id,
                                   ': Org Entry ID:  ', p_org_form_item_id, ' created at: ', p_entry_created_at),
                            'INFO');*/
    getValues
    :
    LOOP
        SET v_rowCsv = '';
--
        FETCH v_values_cursor INTO v_curr_item_id, v_curr_form_id, v_curr_form_name, v_curr_page_name, v_curr_field_order, v_curr_field_name, v_curr_value_has_changed, v_curr_current_value, v_curr_original_value, v_curr_field_key, v_curr_field_id, v_curr_field_type, v_curr_created_at, v_curr_updated_at, v_org_item_id, v_org_form_id, v_org_form_name, v_org_page_name, v_org_field_order, v_org_field_name, v_org_value_has_changed, v_org_current_value, v_org_original_value, v_org_field_key, v_org_field_id, v_org_field_type, v_org_created_at, v_org_updated_at;

        IF v_finished = 1 THEN LEAVE getValues; END IF;

        SET v_curr_page_name = api.api_nz(
                api.api_nz(p_page_name, portal.get_page_heading_for_field(v_curr_form_id, v_curr_field_order)), '');
        #
      /*  CALL api.db_log_message('get_values_for_all_fields_for_form_entry',
                                concat('Got Values Field Key:  ', v_curr_field_key, ' Org Val: ', v_curr_original_value,
                                       ' New val: ', v_curr_current_value, ' entry created at: ', p_entry_created_at,
                                       ' value created at: ', v_curr_created_at), 'INFO');*/

        -- handle undefined
        IF v_curr_current_value = 'undefined' THEN SET v_curr_current_value = ''; END IF;
        IF v_curr_original_value = 'undefined' THEN SET v_curr_original_value = ''; END IF;
        IF v_org_current_value = 'undefined' THEN SET v_org_current_value = ''; END IF;
        IF v_org_original_value = 'undefined' THEN SET v_org_original_value = ''; END IF;

        -- check v_curr_current_value against v_org_original_value
        -- IF v_curr_value_has_changed <> '1' THEN

        -- if we did not get any auditRecord for original value, use the one from the meta_table itself
#         IF api.api_is_blank(v_org_original_value) THEN SET v_org_original_value = v_curr_original_value; END IF;

        -- mark as changed
        IF v_curr_current_value <> v_org_original_value THEN SET v_curr_value_has_changed = '1'; END IF;

        #         -- if updated time, ity has changed
        IF /*v_curr_value_has_changed <> '1' AND*/ v_curr_created_at > date_add(p_entry_created_at, INTERVAL 5 MINUTE) THEN
            SET v_curr_value_has_changed = '1';
        END IF;
        -- END IF;
        --
        IF v_curr_value_has_changed = '1' THEN
            SET v_curr_value_has_changed = 'Yes';
        ELSE
            SET v_curr_value_has_changed = 'No';
        END IF;

        -- double quotes
        SET v_curr_original_value = replace(v_curr_original_value, '"', '""');
        SET v_curr_current_value = replace(v_curr_current_value, '"', '""');

        -- row CSV
        SET v_rowCsv = CONCAT(v_rowCsv, api.QT(), api.api_nz(v_curr_item_id, ''), api.QT(), ',',
                              api.QT(),
                              api.api_nz(v_curr_form_id, ''), api.QT(), ',',
                              api.QT(), api.api_nz(v_curr_form_name, ''), api.QT(), ',',
                              api.QT(), api.api_nz(v_curr_page_name, ''), api.QT(), ',',
                              api.QT(), api.api_nz(p_repeater_field_name, ''), api.QT(), ',',
                              api.QT(), api.api_nz(v_curr_field_name, ''), api.QT(), ',',
                              api.QT(), NOT api.api_is_blank(p_repeater_field_name), api.QT(), ',',
                              api.QT(), api.api_nz(v_curr_field_id, ''), api.QT(), ',',
                              api.QT(), api.api_nz(v_curr_field_key, ''), api.QT(), ',',
                              api.QT(), api.api_nz(v_curr_field_type, ''), api.QT(), ',',
                              api.QT(), api.api_nz(v_curr_value_has_changed, ''), api.QT(), ',',
                              api.QT(), api.api_nz(v_org_original_value, ''), api.QT(), ',',
                              api.QT(), api.api_nz(v_curr_current_value, ''), api.QT(), ',',
                              api.QT(), api.api_nz(v_org_item_id, ''), api.QT(), ',',
                              api.QT(), api.api_nz(p_entry_created_at, ''), api.QT(), ',',
                              api.QT(), api.api_nz(v_curr_created_at, ''), api.QT(), ',',
                              char(13));

      /*  CALL api.db_log_message('get_values_for_all_fields_for_form_entry',
                                concat(' -- Field: ', v_curr_field_name, ' , FieldKey: ', v_curr_field_key, ', CSV:',
                                       char(13), v_rowCsv), 'INFO');*/

        IF api.api_nz(v_rowCsv, '') <> '' THEN SET v_CSV = concat(v_CSV, v_rowCsv); END IF;

    END LOOP getValues;

END;

