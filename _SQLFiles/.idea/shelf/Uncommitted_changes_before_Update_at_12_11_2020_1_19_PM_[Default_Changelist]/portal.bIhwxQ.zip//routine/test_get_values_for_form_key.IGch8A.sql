CREATE
    DEFINER = admin@`%` PROCEDURE test_get_values_for_form_key()
begin
declare v_CSV longtext;
CALL portal.get_values_for_form_key('e2d4c9529bbd2f1c0993eaa3c7ef2082', 1, NULL, NULL, v_CSV)
;
SELECT v_CSV;
end;

