create definer = admin@`%` view vw_get_org_values_for_form_entry as
select `v`.`item_id`        AS `item_id`,
       `f`.`form_id`        AS `form_id`,
       `f`.`form_name`      AS `form_name`,
       ''                   AS `page_name`,
       `f`.`field_order`    AS `field_order`,
       `f`.`field_name`     AS `field_name`,
       `f`.`repeater_name`  AS `repeater_name`,
       0                    AS `value_has_changed`,
       `v`.`current_value`  AS `current_value`,
       `v`.`original_value` AS `original_value`,
       `f`.`field_key`      AS `field_key`,
       `f`.`field_id`       AS `field_id`,
       `v`.`field_type`     AS `field_type`,
       `v`.`created_at`     AS `created_at`,
       `v`.`updated_at`     AS `updated_at`
from (`portal`.`vw_get_all_fields_for_form` `f`
         left join `portal`.`vw_get_org_meta_values` `v` on (`f`.`field_id` = `v`.`field_id`))
order by `f`.`form_id`, `f`.`field_order`;

