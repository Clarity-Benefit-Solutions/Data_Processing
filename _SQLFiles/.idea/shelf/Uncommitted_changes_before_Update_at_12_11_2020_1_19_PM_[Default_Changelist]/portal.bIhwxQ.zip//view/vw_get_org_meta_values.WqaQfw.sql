create definer = admin@`%` view vw_get_org_meta_values as
select `m`.`item_id`                                                  AS `item_id`,
       `get_page_heading_for_field`(`f`.`form_id`, `f`.`field_order`) AS `page_name`,
       `m`.`field_id`                                                 AS `field_id`,
       `f`.`type`                                                     AS `field_type`,
       ''                                                             AS `form_name`,
       `f`.`field_order`                                              AS `field_order`,
       `f`.`form_id`                                                  AS `form_id`,
       `f`.`field_key`                                                AS `field_key`,
       `f`.`name`                                                     AS `field_name`,
       `api`.`api_nz`(`m`.`current_value`, '')                        AS `current_value`,
       `api`.`api_nz`(`m`.`original_value`, '')                       AS `original_value`,
       `m`.`created_at`                                               AS `created_at`,
       `m`.`updated_at`                                               AS `updated_at`
from (`portal`.`vw_get_org_meta_audit_values` `m`
         join `portal`.`cl_frm_fields` `f` on (`m`.`field_id` = `f`.`id`));

