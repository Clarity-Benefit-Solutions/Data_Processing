create definer = admin@`%` view vw_get_all_fields_for_form as
select `f`.`id`                                                       AS `form_id`,
       `f`.`name`                                                     AS `form_name`,
       `fl`.`id`                                                      AS `field_id`,
       `fl`.`field_key`                                               AS `field_key`,
       `fl`.`name`                                                    AS `field_name`,
       case when `fl`.`type` = 'divider' then `fl`.`name` else '' end AS `repeater_name`,
       `fl`.`description`                                             AS `field_description`,
       `fl`.`type`                                                    AS `field_type`,
       `fl`.`default_value`                                           AS `field_default_value`,
       `fl`.`options`                                                 AS `fl_options`,
       `fl`.`field_order`                                             AS `field_order`,
       `fl`.`required`                                                AS `field_required`,
       `fl`.`field_options`                                           AS `field_options`
from (`portal`.`cl_frm_fields` `fl`
         join `portal`.`cl_frm_forms` `f` on (`f`.`id` = `fl`.`form_id`))
where `fl`.`type` <> 'hidden'
order by `fl`.`form_id`, `fl`.`field_order`;

