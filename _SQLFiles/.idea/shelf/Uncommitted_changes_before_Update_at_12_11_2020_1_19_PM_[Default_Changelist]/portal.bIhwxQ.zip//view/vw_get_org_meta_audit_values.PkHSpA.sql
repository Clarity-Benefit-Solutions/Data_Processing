create definer = admin@`%` view vw_get_org_meta_audit_values as
select `m`.`item_id`                            AS `item_id`,
       `m`.`field_id`                           AS `field_id`,
       `api`.`api_nz`(`m`.`meta_value`, '')     AS `current_value`,
       `api`.`api_nz`(`m`.`org_meta_value`, '') AS `original_value`,
       `m`.`created_at`                         AS `created_at`,
       `m`.`updated_at`                         AS `updated_at`
from `portal`.`cl_frm_item_metas_audit` `m`
where `m`.`auditAction` = 'INSERT';

