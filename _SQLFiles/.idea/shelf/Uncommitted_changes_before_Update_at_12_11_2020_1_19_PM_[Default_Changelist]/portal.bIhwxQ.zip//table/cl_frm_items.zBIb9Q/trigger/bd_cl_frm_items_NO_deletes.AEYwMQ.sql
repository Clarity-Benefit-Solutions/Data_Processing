create definer = admin@`%` trigger bd_cl_frm_items_NO_deletes
    before delete
    on cl_frm_items
    for each row
BEGIN
   /* IF (api.api_is_blank(old.parent_item_id) OR old.parent_item_id <= 0) THEN
        CALL api.db_throw_error(5001, 'bd_cl_frm_items_NO_deletes',
                                concat('CANNOT DELETE A PARENT ENTRY! ID: ', old.id, ' item Key: ', old.item_key,
                                       'form id: ', old.form_id, ' name: ', old.name));
    END IF;*/
END;

