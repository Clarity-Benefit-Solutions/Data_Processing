create definer = admin@`%` trigger util_bi_cl_frm_items_set_updated_at_and_by
    before insert
    on cl_frm_items
    for each row
BEGIN
    SET new.created_at = NOW();
    SET new.created_by = current_user;
    SET new.updated_at = NOW();
    SET new.updated_by = current_user;
END;

