create definer = admin@`%` trigger au_audit_cl_frm_items_inserts
    after insert
    on cl_frm_items
    for each row
    INSERT INTO `portal`.`cl_frm_items_audit`
                 (`auditAction`,`id`,`item_key`,`name`,`description`,`ip`,`form_id`,`post_id`,`user_id`,`parent_item_id`,`is_draft`,`updated_by`,`created_at`,`updated_at`,`created_by`)
                 VALUES
                 ('INSERT',NEW.`id`,NEW.`item_key`,NEW.`name`,NEW.`description`,NEW.`ip`,NEW.`form_id`,NEW.`post_id`,NEW.`user_id`,NEW.`parent_item_id`,NEW.`is_draft`,NEW.`updated_by`,NEW.`created_at`,NEW.`updated_at`,NEW.`created_by`);

