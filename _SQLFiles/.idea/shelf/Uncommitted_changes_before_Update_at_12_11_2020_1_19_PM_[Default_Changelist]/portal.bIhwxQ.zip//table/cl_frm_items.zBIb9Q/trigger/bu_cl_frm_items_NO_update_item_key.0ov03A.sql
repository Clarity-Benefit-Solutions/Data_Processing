create definer = admin@`%` trigger bu_cl_frm_items_NO_update_item_key
    before update
    on cl_frm_items
    for each row
BEGIN
    /*IF (new.item_key <> old.item_key) THEN
        CALL api.db_throw_error(5001, 'bu_cl_frm_items_NO_update_item_key',
                                concat('CANNOT UPDATE A ITEM KEY : ', old.id, ' item Key: ', old.item_key, 'form id: ',
                                       old.form_id, ' name: ', old.name));
    END IF;*/

  /*  IF (NOT api.api_is_blank(old.name) AND (new.name <> old.name or api.api_is_blank(new.name))) THEN
        CALL api.db_throw_error(5001, 'bu_cl_frm_items_NO_update_item_name',
                                concat('CANNOT UPDATE A ITEM KEY : ', old.id, ' item Key: ', old.item_key, 'form id: ',
                                       old.form_id, ' name: ', old.name));
    END IF;*/
END;

