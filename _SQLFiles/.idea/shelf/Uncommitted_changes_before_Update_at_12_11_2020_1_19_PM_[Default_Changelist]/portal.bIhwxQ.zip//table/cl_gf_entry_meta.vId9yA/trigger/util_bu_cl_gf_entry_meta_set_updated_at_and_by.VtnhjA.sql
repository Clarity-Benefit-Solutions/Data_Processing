create definer = admin@`%` trigger util_bu_cl_gf_entry_meta_set_updated_at_and_by
    before update
    on cl_gf_entry_meta
    for each row
BEGIN
    SET new.updated_at = CURRENT_TIMESTAMP;
    SET new.updated_by = current_user;
END;

