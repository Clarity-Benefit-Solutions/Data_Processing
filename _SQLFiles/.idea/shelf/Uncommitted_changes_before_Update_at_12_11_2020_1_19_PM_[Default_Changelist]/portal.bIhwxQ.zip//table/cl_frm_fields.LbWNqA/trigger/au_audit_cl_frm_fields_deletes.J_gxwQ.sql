create definer = admin@`%` trigger au_audit_cl_frm_fields_deletes
    after delete
    on cl_frm_fields
    for each row
    INSERT INTO `portal`.`cl_frm_fields_audit`
                 (`auditAction`,`id`,`field_key`,`name`,`description`,`type`,`default_value`,`options`,`field_order`,`required`,`field_options`,`form_id`,`created_at`,`created_by`,`updated_at`,`updated_by`)
                 VALUES
                 ('DELETE',OLD.`id`,OLD.`field_key`,OLD.`name`,OLD.`description`,OLD.`type`,OLD.`default_value`,OLD.`options`,OLD.`field_order`,OLD.`required`,OLD.`field_options`,OLD.`form_id`,OLD.`created_at`,OLD.`created_by`,OLD.`updated_at`,OLD.`updated_by`);

