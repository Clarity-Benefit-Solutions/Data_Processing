create definer = admin@`%` trigger au_audit_cl_frm_forms_deletes
    after delete
    on cl_frm_forms
    for each row
    INSERT INTO `portal`.`cl_frm_forms_audit`
                 (`auditAction`,`id`,`form_key`,`name`,`description`,`parent_form_id`,`logged_in`,`editable`,`is_template`,`default_template`,`status`,`options`,`created_at`,`created_by`,`updated_at`,`updated_by`)
                 VALUES
                 ('DELETE',OLD.`id`,OLD.`form_key`,OLD.`name`,OLD.`description`,OLD.`parent_form_id`,OLD.`logged_in`,OLD.`editable`,OLD.`is_template`,OLD.`default_template`,OLD.`status`,OLD.`options`,OLD.`created_at`,OLD.`created_by`,OLD.`updated_at`,OLD.`updated_by`);

