create definer = admin@`%` trigger util_bu_cl_frm_item_metas_set_org_values
    before insert
    on cl_frm_item_metas
    for each row
BEGIN
    SET new.org_meta_value = api.api_nz(new.org_meta_value, new.meta_value);
    SET new.org_meta_values_updated_at = now();
    SET new.created_at = now();
    SET new.updated_at = now();
END;

