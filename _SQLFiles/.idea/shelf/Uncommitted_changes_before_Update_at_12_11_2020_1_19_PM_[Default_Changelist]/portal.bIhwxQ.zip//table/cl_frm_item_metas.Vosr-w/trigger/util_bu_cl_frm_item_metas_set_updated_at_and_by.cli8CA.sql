create definer = admin@`%` trigger util_bu_cl_frm_item_metas_set_updated_at_and_by
    before update
    on cl_frm_item_metas
    for each row
BEGIN
    SET new.created_at = old.created_at;
    SET new.created_by = old.created_by;
    SET new.updated_at = now();
    SET new.updated_by = current_user;
END;

