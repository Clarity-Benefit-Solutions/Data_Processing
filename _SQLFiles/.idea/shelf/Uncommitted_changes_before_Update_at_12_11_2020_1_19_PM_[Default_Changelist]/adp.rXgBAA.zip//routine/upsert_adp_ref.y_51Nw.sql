create
    definer = admin@`%` procedure upsert_adp_ref(IN p_bencode varchar(75), IN p_org_id varchar(75),
                                                 IN p_last_update datetime, IN p_sf_id varchar(75),
                                                 IN p_bswiftgroup varchar(75))
BEGIN
    

    

    INSERT INTO adp.adp_ref( bencode
                           , org_id
                           , last_update
									, sf_id
									, bswiftgroup)
    VALUES ( p_bencode
           , p_org_id
           , p_last_update
			  , p_sf_id
			  , p_bswiftgroup)
    ON DUPLICATE KEY UPDATE bencode     = ifnull(p_bencode, bencode)
                          , org_id      = ifnull(p_org_id, org_id)
                          , last_update = ifnull(p_last_update, last_update)
								  , sf_id		 = ifnull(p_sf_id, sf_id)
								  , bswiftgroup = IFNULL(p_bswiftgroup, bswiftgroup);
END;

