create definer = admin@`%` trigger util_bu_cp_carrier_set_updated_at_and_by
    before update
    on cp_carrier
    for each row
BEGIN
    SET new.updated_at = CURRENT_TIMESTAMP;
    SET new.updated_by = current_user;
END;

