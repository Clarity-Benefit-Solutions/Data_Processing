create
    definer = admin@`%` procedure sp_transaction_template()
BEGIN
    
    DECLARE v_started_trn bool DEFAULT 0;
    DECLARE v_rollback bool DEFAULT 0;
    
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
        BEGIN
            SET v_rollback = 1;
            GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
            CALL log_error(@errno, 'upsert_cp_platform_user', @text, @sqlstate);


        END;

    
    IF !@@in_transaction THEN
        START TRANSACTION; SET v_started_trn = 1;
    END IF;

    


    IF v_started_trn THEN IF v_rollback THEN ROLLBACK; ELSE COMMIT; END IF; END IF;

END;

