create
    definer = admin@`%` procedure upsert_api_case_plans_cobra(IN p_case_plan_id varchar(50), IN p_case_id varchar(50),
                                                              IN p_status varchar(50), IN p_version_no int,
                                                              IN p_plan_type varchar(50), IN p_plan_name varchar(100),
                                                              IN p_plan_sub_type varchar(50), IN p_plan_order int,
                                                              IN p_ben_term_type varchar(50),
                                                              IN p_new_ben_term_type varchar(50),
                                                              IN p_plan_year_start_date date,
                                                              IN p_plan_year_end_date date,
                                                              IN p_plan_year_renewal_date date,
                                                              IN p_plan_should_terminate int,
                                                              IN p_plan_year_termination_date date,
                                                              IN p_should_default_participants_to_different_plan int,
                                                              IN p_default_participants_to_different_plan_name varchar(100),
                                                              IN p_plan_is_new int, IN p_carrier_name varchar(100),
                                                              IN p_policygroup_number varchar(100),
                                                              IN p_is_fully_insured int(1), IN p_is_self_funded int(1),
                                                              IN p_insurance_type varchar(100),
                                                              IN p_plan_is_for_specific_division varchar(100),
                                                              IN p_division_name varchar(100),
                                                              IN p_coverage_termination varchar(100),
                                                              IN p_plan_rate_type varchar(100),
                                                              IN p_is_currently_offering_subsidies int(1),
                                                              IN p_is_cap_dependents_age20 int(1),
                                                              IN p_pct_50_charge_disability_extension int(1),
                                                              IN p_new_pct_100_rate_for_coverage_level int(1))
BEGIN


    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO,
                @text = MESSAGE_TEXT;
            SET @text = CONCAT( @text, Concat( '
Called With Params: ', ', case_plan_id: ', api.api_nz( `p_case_plan_id`, '' ), ', case_id: ',
                                               api.api_nz( `p_case_id`, '' ),
                                               ', status: ', api.api_nz( `p_status`, '' ), ', version_no: ',
                                               api.api_nz( `p_version_no`, '' ), ', plan_type: ',
                                               api.api_nz( `p_plan_type`, '' ), ', plan_name: ',
                                               api.api_nz( `p_plan_name`, '' ), ', plan_sub_type: ',
                                               api.api_nz( `p_plan_sub_type`, '' ), ', plan_order: ',
                                               api.api_nz( `p_plan_order`, '' ), ', ben_term_type: ',
                                               api.api_nz( `p_ben_term_type`, '' ), ', new_ben_term_type: ',
                                               api.api_nz( `p_new_ben_term_type`, '' ), ', plan_year_start_date: ',
                                               api.api_nz( `p_plan_year_start_date`, '' ), ', plan_year_end_date: ',
                                               api.api_nz( `p_plan_year_end_date`, '' ), ', plan_year_renewal_date: ',
                                               api.api_nz( `p_plan_year_renewal_date`, '' ),
                                               ', plan_should_terminate: ',
                                               api.api_nz( `p_plan_should_terminate`, '' ),
                                               ', plan_year_termination_date: ',
                                               api.api_nz( `p_plan_year_termination_date`, '' ),
                                               ', should_default_participants_to_different_plan: ',
                                               api.api_nz( `p_should_default_participants_to_different_plan`, '' ),
                                               ', default_participants_to_different_plan_name: ',
                                               api.api_nz( `p_default_participants_to_different_plan_name`, '' ),
                                               ', plan_is_new: ', api.api_nz( `p_plan_is_new`, '' ), ', carrier_name: ',
                                               api.api_nz( `p_carrier_name`, '' ), ', policygroup_number: ',
                                               api.api_nz( `p_policygroup_number`, '' ), ', is_fully_insured: ',
                                               api.api_nz( `p_is_fully_insured`, '' ), ', is_self_funded: ',
                                               api.api_nz( `p_is_self_funded`, '' ), ', insurance_type: ',
                                               api.api_nz( `p_insurance_type`, '' ),
                                               ', plan_is_for_specific_division: ',
                                               api.api_nz( `p_plan_is_for_specific_division`, '' ), ', division_name: ',
                                               api.api_nz( `p_division_name`, '' ), ', coverage_termination: ',
                                               api.api_nz( `p_coverage_termination`, '' ), ', plan_rate_type: ',
                                               api.api_nz( `p_plan_rate_type`, '' ),
                                               ', is_currently_offering_subsidies: ',
                                               api.api_nz( `p_is_currently_offering_subsidies`, '' ),
                                               ', is_cap_dependents_age20: ',
                                               api.api_nz( `p_is_cap_dependents_age20`, '' ),
                                               ', pct_50_charge_disability_extension: ',
                                               api.api_nz( `p_pct_50_charge_disability_extension`, '' ),
                                               ', new_pct_100_rate_for_coverage_level: ',
                                               api.api_nz( `p_new_pct_100_rate_for_coverage_level`, '' ) ) );
            CALL db_throw_error( @errno, 'upsert_api_case_plans_cobra', @text );
        END;


    CALL api.db_log_message( 'upsert_api_case_plans_cobra',
                             Concat( 'Called With Params: ', ', case_plan_id: ', api.api_nz( `p_case_plan_id`, '' ),
                                     ', case_id: ', api.api_nz( `p_case_id`, '' ), ', status: ',
                                     api.api_nz( `p_status`, '' ),
                                     ', version_no: ', api.api_nz( `p_version_no`, '' ), ', plan_type: ',
                                     api.api_nz( `p_plan_type`, '' ), ', plan_name: ', api.api_nz( `p_plan_name`, '' ),
                                     ', plan_sub_type: ', api.api_nz( `p_plan_sub_type`, '' ), ', plan_order: ',
                                     api.api_nz( `p_plan_order`, '' ), ', ben_term_type: ',
                                     api.api_nz( `p_ben_term_type`, '' ), ', new_ben_term_type: ',
                                     api.api_nz( `p_new_ben_term_type`, '' ), ', plan_year_start_date: ',
                                     api.api_nz( `p_plan_year_start_date`, '' ), ', plan_year_end_date: ',
                                     api.api_nz( `p_plan_year_end_date`, '' ), ', plan_year_renewal_date: ',
                                     api.api_nz( `p_plan_year_renewal_date`, '' ), ', plan_should_terminate: ',
                                     api.api_nz( `p_plan_should_terminate`, '' ), ', plan_year_termination_date: ',
                                     api.api_nz( `p_plan_year_termination_date`, '' ),
                                     ', should_default_participants_to_different_plan: ',
                                     api.api_nz( `p_should_default_participants_to_different_plan`, '' ),
                                     ', default_participants_to_different_plan_name: ',
                                     api.api_nz( `p_default_participants_to_different_plan_name`, '' ),
                                     ', plan_is_new: ',
                                     api.api_nz( `p_plan_is_new`, '' ), ', carrier_name: ',
                                     api.api_nz( `p_carrier_name`, '' ), ', policygroup_number: ',
                                     api.api_nz( `p_policygroup_number`, '' ), ', is_fully_insured: ',
                                     api.api_nz( `p_is_fully_insured`, '' ), ', is_self_funded: ',
                                     api.api_nz( `p_is_self_funded`, '' ), ', insurance_type: ',
                                     api.api_nz( `p_insurance_type`, '' ), ', plan_is_for_specific_division: ',
                                     api.api_nz( `p_plan_is_for_specific_division`, '' ), ', division_name: ',
                                     api.api_nz( `p_division_name`, '' ), ', coverage_termination: ',
                                     api.api_nz( `p_coverage_termination`, '' ), ', plan_rate_type: ',
                                     api.api_nz( `p_plan_rate_type`, '' ), ', is_currently_offering_subsidies: ',
                                     api.api_nz( `p_is_currently_offering_subsidies`, '' ),
                                     ', is_cap_dependents_age20: ',
                                     api.api_nz( `p_is_cap_dependents_age20`, '' ),
                                     ', pct_50_charge_disability_extension: ',
                                     api.api_nz( `p_pct_50_charge_disability_extension`, '' ),
                                     ', new_pct_100_rate_for_coverage_level: ',
                                     api.api_nz( `p_new_pct_100_rate_for_coverage_level`, '' ) ), 'WARN' );


    INSERT
    INTO
        `api`.`api_case_plans_cobra`
    (
        `case_plan_id`
    ,   `case_id`
    ,   `status`
    ,   `version_no`
    ,   `plan_type`
    ,   `plan_name`
    ,   `plan_sub_type`
    ,   `plan_order`
    ,   `ben_term_type`
    ,   `new_ben_term_type`
    ,   `plan_year_start_date`
    ,   `plan_year_end_date`
    ,   `plan_year_renewal_date`
    ,   `plan_should_terminate`
    ,   `plan_year_termination_date`
    ,   `should_default_participants_to_different_plan`
    ,   `default_participants_to_different_plan_name`
    ,   `plan_is_new`
    ,   `carrier_name`
    ,   `policygroup_number`
    ,   `is_fully_insured`
    ,   `is_self_funded`
    ,   `insurance_type`
    ,   `plan_is_for_specific_division`
    ,   `division_name`
    ,   `coverage_termination`
    ,   `plan_rate_type`
    ,   `is_currently_offering_subsidies`
    ,   `is_cap_dependents_age20`
    ,   `pct_50_charge_disability_extension`
    ,   `new_pct_100_rate_for_coverage_level`
    )


    VALUES
    (
        `p_case_plan_id`
    ,   `p_case_id`
    ,   `p_status`
    ,   `p_version_no`
    ,   `p_plan_type`
    ,   `p_plan_name`
    ,   `p_plan_sub_type`
    ,   `p_plan_order`
    ,   `p_ben_term_type`
    ,   `p_new_ben_term_type`
    ,   `p_plan_year_start_date`
    ,   `p_plan_year_end_date`
    ,   `p_plan_year_renewal_date`
    ,   `p_plan_should_terminate`
    ,   `p_plan_year_termination_date`
    ,   `p_should_default_participants_to_different_plan`
    ,   `p_default_participants_to_different_plan_name`
    ,   `p_plan_is_new`
    ,   `p_carrier_name`
    ,   `p_policygroup_number`
    ,   `p_is_fully_insured`
    ,   `p_is_self_funded`
    ,   `p_insurance_type`
    ,   `p_plan_is_for_specific_division`
    ,   `p_division_name`
    ,   `p_coverage_termination`
    ,   `p_plan_rate_type`
    ,   `p_is_currently_offering_subsidies`
    ,   `p_is_cap_dependents_age20`
    ,   `p_pct_50_charge_disability_extension`
    ,   `p_new_pct_100_rate_for_coverage_level`
    )


    ON DUPLICATE KEY
        UPDATE
            `case_plan_id`                                  = api.api_nz( `p_case_plan_id`, `case_plan_id` )
          , `case_id`                                       = api.api_nz( `p_case_id`, `case_id` )
          , `status`                                        = api.api_nz( `p_status`, `status` )
          , `version_no`                                    = api.api_nz_int( `p_version_no`, `version_no` )
          , `plan_type`                                     = api.api_nz( `p_plan_type`, `plan_type` )
          , `plan_name`                                     = api.api_nz( `p_plan_name`, `plan_name` )
          , `plan_sub_type`                                 = api.api_nz( `p_plan_sub_type`, `plan_sub_type` )
          , `plan_order`                                    = api.api_nz_int( `p_plan_order`, `plan_order` )
          , `ben_term_type`                                 = api.api_nz( `p_ben_term_type`, `ben_term_type` )
          , `new_ben_term_type`                             = api.api_nz( `p_new_ben_term_type`, `new_ben_term_type` )
          , `plan_year_start_date`                          = api.api_nz_date( `p_plan_year_start_date`, `plan_year_start_date` )
          , `plan_year_end_date`                            = api.api_nz_date( `p_plan_year_end_date`, `plan_year_end_date` )
          , `plan_year_renewal_date`                        = api.api_nz_date( `p_plan_year_renewal_date`, `plan_year_renewal_date` )
          , `plan_should_terminate`                         = api.api_nz_int( `p_plan_should_terminate`, `plan_should_terminate` )
          , `plan_year_termination_date`                    = api.api_nz_date( `p_plan_year_termination_date`,
                                                                               `plan_year_termination_date` )
          , `should_default_participants_to_different_plan` = api.api_nz_int(
                `p_should_default_participants_to_different_plan`,
                `should_default_participants_to_different_plan` )
          , `default_participants_to_different_plan_name`   = api.api_nz(
                `p_default_participants_to_different_plan_name`, `default_participants_to_different_plan_name` )
          , `plan_is_new`                                   = api.api_nz_int( `p_plan_is_new`, `plan_is_new` )
          , `carrier_name`                                  = api.api_nz( `p_carrier_name`, `carrier_name` )
          , `policygroup_number`                            = api.api_nz( `p_policygroup_number`, `policygroup_number` )
          , `is_fully_insured`                              = api.api_nz_int( `p_is_fully_insured`, `is_fully_insured` )
          , `is_self_funded`                                = api.api_nz_int( `p_is_self_funded`, `is_self_funded` )
          , `insurance_type`                                = api.api_nz( `p_insurance_type`, `insurance_type` )
          , `plan_is_for_specific_division`                 = api.api_nz( `p_plan_is_for_specific_division`,
                                                                          `plan_is_for_specific_division` )
          , `division_name`                                 = api.api_nz( `p_division_name`, `division_name` )
          , `coverage_termination`                          = api.api_nz( `p_coverage_termination`, `coverage_termination` )
          , `plan_rate_type`                                = api.api_nz( `p_plan_rate_type`, `plan_rate_type` )
          , `is_currently_offering_subsidies`               = api.api_nz_int( `p_is_currently_offering_subsidies`,
                                                                              `is_currently_offering_subsidies` )
          , `is_cap_dependents_age20`                       = api.api_nz_int( `p_is_cap_dependents_age20`,
                                                                              `is_cap_dependents_age20` )
          , `pct_50_charge_disability_extension`            = api.api_nz_int( `p_pct_50_charge_disability_extension`,
                                                                              `pct_50_charge_disability_extension` )
          , `new_pct_100_rate_for_coverage_level`           = api.api_nz_int( `p_new_pct_100_rate_for_coverage_level`,
                                                                              `new_pct_100_rate_for_coverage_level` );


END;

