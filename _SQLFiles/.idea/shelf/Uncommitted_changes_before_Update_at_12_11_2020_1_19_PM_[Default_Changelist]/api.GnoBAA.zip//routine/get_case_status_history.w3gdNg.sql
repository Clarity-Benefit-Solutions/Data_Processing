create
    definer = admin@`%` function get_case_status_history(p_case_invite_token varchar(50), p_only_last_status_change int) returns text
BEGIN

    DECLARE v_ret text DEFAULT '';
    DECLARE v_finished int;

    DECLARE v_last_case_status varchar(75);

    DECLARE v_auditAction enum ('INSERT', 'UPDATE', 'DELETE');
    DECLARE v_auditTimestamp timestamp;
    DECLARE v_last_status_time text;
    DECLARE v_auditId int(14);
    DECLARE v_case_id varchar(75);
    DECLARE v_case_status varchar(75);
    DECLARE v_is_ready_for_processing int(1);

    DECLARE v_counter int;
    DECLARE v_values_cursor CURSOR FOR SELECT auditAction
                                            , auditTimestamp
                                            , auditId
                                            , case_id
                                            , case_status
                                            , is_ready_for_processing
                                       FROM api.api_cases_audit
                                       WHERE form_invite_token = p_case_invite_token
                                       ORDER BY auditTimestamp ASC;

    DECLARE CONTINUE HANDLER FOR NOT FOUND BEGIN
        SET v_finished = 1;

    END;

    SET v_ret = '';
    SET v_last_case_status = '';

    SET @@max_sp_recursion_depth = 12;
    OPEN v_values_cursor;
    #
    /*  CALL api.db_log_message( 'get_values_for_all_fields_for_form_entry',
                               concat( 'Processing Form Entry ID:  ', p_form_item_id, ' created at: ',
                                       p_entry_created_at ),
                               'INFO' );*/
    getValues
    :
    LOOP

        --
        FETCH v_values_cursor INTO v_auditAction
            , v_auditTimestamp
            , v_auditId
            , v_case_id
            , v_case_status
            , v_is_ready_for_processing;

        IF v_finished = 1 THEN LEAVE getValues; END IF;

        IF v_case_status <> v_last_case_status THEN
            SET v_ret =
                    concat(v_ret, '<span class="case_status">', v_case_status, '</span>', '<span class="case_status">',
                           DATE_FORMAT(v_auditTimestamp, '%m/%d/%Y %h:%I %p'), '</span>',
                           '<span class="case_status is_ready">', v_is_ready_for_processing, '</span>',
                           char(10),
                           char(13));
            SET v_last_status_time = DATE_FORMAT(v_auditTimestamp, '%m/%d/%Y %h:%I %p');
        END IF;

        SET v_last_case_status = v_case_status;

    END LOOP getValues;

    IF p_only_last_status_change THEN
        RETURN v_last_status_time;
    ELSE
        RETURN v_ret;
    END IF;

END;

