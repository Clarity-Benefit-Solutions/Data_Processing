create
    definer = admin@`%` function api_cdate(value varchar(200)) returns date
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
            
            CALL api.db_log_error( @errno , 'api_cdate' , @text , @`sqlstate` );
            
            RETURN null;
        END;
    
    RETURN cast( value AS date );

END;

