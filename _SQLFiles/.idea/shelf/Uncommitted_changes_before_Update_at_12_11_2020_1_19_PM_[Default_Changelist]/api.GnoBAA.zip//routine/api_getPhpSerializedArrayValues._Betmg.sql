create
    definer = admin@`%` function api_getPhpSerializedArrayValues(_input_string text) returns text
    comment 'Function returns last value from serialized array by specific index key.'
BEGIN
    
    
    DECLARE _value, _output TEXT;
    DECLARE i INT;
    SET _output := '';
    SET i = 0;
    SET _value = 'DUMMY';
    WHILE i <= 100 AND _value IS NOT NULL
        DO
            
            SET _value = api.api_getPhpSerializedArrayValueByIndex(_input_string, i);

            IF _value IS NOT NULL THEN
                IF i > 0 THEN
                    SET _value = concat(',', _value);
                END IF;
                SET _output = concat(_output, _value);
            END IF;
            SET i = i + 1;

        END WHILE;

    RETURN _output;
END;

