create
    definer = admin@`%` function cp_get_default_customer_id() returns varchar(10)
BEGIN
  RETURN '146';
END;

