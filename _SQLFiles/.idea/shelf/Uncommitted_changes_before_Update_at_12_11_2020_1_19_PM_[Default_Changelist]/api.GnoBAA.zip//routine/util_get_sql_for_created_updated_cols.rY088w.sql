create
    definer = admin@`%` function util_get_sql_for_created_updated_cols(table_name varchar(500), table_schema varchar(64)) returns longtext
BEGIN
  DECLARE v_sql                 longtext;
  DECLARE v_table_name_no_dot   varchar(200);

  SET v_table_name_no_dot = util_get_text_after_last_dot(table_name);

  SET v_sql               =
        CONCAT(
          'ALTER TABLE '
         ,ifnull(
            table_name
           ,'')
         ,CHAR(13)
         ,'ADD created_at timestamp DEFAULT CURRENT_TIMESTAMP;'
         ,CHAR(13)
         ,'ALTER TABLE '
         ,ifnull(
            table_name
           ,'')
         ,CHAR(13)
         ,'ADD created_by varchar(200) DEFAULT current_user;'
         ,CHAR(13)
         ,CHAR(13)
         ,'ALTER TABLE '
         ,ifnull(
            table_name
           ,'')
         ,CHAR(13)
         ,' ADD updated_at timestamp DEFAULT CURRENT_TIMESTAMP ; '
         ,CHAR(13)
         ,CHAR(13)
         ,'ALTER TABLE '
         ,ifnull(
            table_name
           ,'')
         ,CHAR(13)
         ,' ADD updated_by varchar(200) DEFAULT current_user; '
         ,CHAR(13)
         ,CONCAT(
            '-- DROP TRIGGER IF EXISTS '
           ,table_schema
           ,'.util_bu_')
         ,ifnull(
            v_table_name_no_dot
           ,'')
         ,'_set_updated_at_and_by; '
         ,CHAR(13)
         ,CHAR(13)
         ,CONCAT(
            'CREATE TRIGGER  '
           ,table_schema
           ,'.util_bu_')
         ,ifnull(
            v_table_name_no_dot
           ,'')
         ,'_set_updated_at_and_by'
         ,CHAR(13)
         ,'BEFORE UPDATE  ON  '
         ,ifnull(
            table_name
           ,'')
         ,CHAR(13)
         ,'FOR EACH ROW '
         ,CHAR(13)
         ,'BEGIN '
         ,CHAR(13)
         ,'SET new.updated_at = CURRENT_TIMESTAMP;'
         ,CHAR(13)
         ,'SET new.updated_by = current_user; '
         ,CHAR(13)
         ,'END; ');

  RETURN v_sql;
END;

