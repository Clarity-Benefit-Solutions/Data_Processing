create
    definer = admin@`%` function api_nz(value text, valueifnullorempty text) returns text
BEGIN
  IF ifnull(
       value
      ,'') = ''
  THEN
    RETURN ifnull(valueIfNullOrEmpty, '');
  ELSE
    RETURN value;
  END IF;
END;

