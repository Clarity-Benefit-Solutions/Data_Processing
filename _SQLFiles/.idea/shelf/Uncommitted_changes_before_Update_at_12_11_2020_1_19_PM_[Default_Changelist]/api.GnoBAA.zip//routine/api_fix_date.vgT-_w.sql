create
    definer = admin@`%` function api_fix_date(value varchar(200)) returns date
BEGIN
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
        BEGIN
            GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
            CALL log_error(@errno, 'api_fix_date', @text, @sqlstate);
            return null;
        END;
        
    if api.api_is_blank(value) THEN
        return null;
    ELSE
        return cast(value as date);
    END IF;
    
END;

