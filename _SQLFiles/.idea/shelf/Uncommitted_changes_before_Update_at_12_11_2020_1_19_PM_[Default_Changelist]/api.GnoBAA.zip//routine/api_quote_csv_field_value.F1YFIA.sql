create
    definer = admin@`%` function api_quote_csv_field_value(value text) returns text
BEGIN
    RETURN replace(ifnull(value, ''), QT(), concat(QT(), QT()));

END;

