create
    definer = admin@`%` function util_strposrev(instring text, insubstring text) returns int
BEGIN
  DECLARE result   INTEGER;

  IF POSITION(insubstring IN instring) = 0
  THEN
    
    SET result = 0;
  ELSEIF LENGTH(insubstring) = 1
  THEN
    
    SET result =
          1 + LENGTH(instring) - POSITION(insubstring IN REVERSE(instring));
  ELSE
    
    SET result =
          2 +
          LENGTH(instring) -
          LENGTH(insubstring) -
          POSITION(REVERSE(insubstring) IN REVERSE(instring));
  END IF;

  RETURN result;
END;

