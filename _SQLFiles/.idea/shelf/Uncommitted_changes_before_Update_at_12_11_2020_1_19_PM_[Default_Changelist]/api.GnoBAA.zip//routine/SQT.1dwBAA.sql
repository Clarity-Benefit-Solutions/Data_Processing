create
    definer = admin@`%` function SQT() returns varchar(1)
BEGIN
    RETURN CHAR(39);
END;

