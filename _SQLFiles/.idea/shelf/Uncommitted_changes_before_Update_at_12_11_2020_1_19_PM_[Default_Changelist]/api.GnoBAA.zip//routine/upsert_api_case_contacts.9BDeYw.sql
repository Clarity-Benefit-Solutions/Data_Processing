create
    definer = admin@`%` procedure upsert_api_case_contacts(IN p_case_contact_id varchar(50), IN p_case_id varchar(50),
                                                           IN p_sf_contact_id varchar(50), IN p_status varchar(50),
                                                           IN p_version_no int, IN p_contact_type varchar(50),
                                                           IN p_organization_name varchar(100),
                                                           IN p_organization_state varchar(50),
                                                           IN p_organization_zip varchar(10),
                                                           IN p_contact_sub_type varchar(50),
                                                           IN p_contact_title varchar(50),
                                                           IN p_contact_first_name varchar(100),
                                                           IN p_contact_last_name varchar(100),
                                                           IN p_contact_email varchar(200),
                                                           IN p_contact_phone varchar(100),
                                                           IN p_contact_is_cons_ben_contact int(1),
                                                           IN p_contact_is_cobra_contact int(1),
                                                           IN p_contact_is_ben_admin_contact int(1),
                                                           IN p_contact_email_org varchar(200),
                                                           IN p_benefit_plan_type varchar(200))
BEGIN

    -- handle error that may happen as the table has a few unique keys which may conflict
    DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN
        GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
        SET @text = CONCAT( @text, Concat( '
Called With Params: ', ', case_contact_id: ', api.api_nz( `p_case_contact_id`, '' ), ', case_id: ',
                                           api.api_nz( `p_case_id`, '' ), ', sf_contact_id: ',
                                           api.api_nz( `p_sf_contact_id`, '' ), ', status: ',
                                           api.api_nz( `p_status`, '' ),
                                           ', version_no: ', api.api_nz( `p_version_no`, '' ), ', contact_type: ',
                                           api.api_nz( `p_contact_type`, '' ), ', organization_name: ',
                                           api.api_nz( `p_organization_name`, '' ), ', organization_state: ',
                                           api.api_nz( `p_organization_state`, '' ), ', organization_zip: ',
                                           api.api_nz( `p_organization_zip`, '' ), ', contact_sub_type: ',
                                           api.api_nz( `p_contact_sub_type`, '' ), ', contact_title: ',
                                           api.api_nz( `p_contact_title`, '' ), ', contact_first_name: ',
                                           api.api_nz( `p_contact_first_name`, '' ), ', contact_last_name: ',
                                           api.api_nz( `p_contact_last_name`, '' ), ', contact_email: ',
                                           api.api_nz( `p_contact_email`, '' ), ', contact_phone: ',
                                           api.api_nz( `p_contact_phone`, '' ), ', contact_is_cons_ben_contact: ',
                                           api.api_nz( `p_contact_is_cons_ben_contact`, '' ),
                                           ', contact_is_cobra_contact: ',
                                           api.api_nz( `p_contact_is_cobra_contact`, '' ),
                                           ', contact_is_ben_admin_contact: ',
                                           api.api_nz( `p_contact_is_ben_admin_contact`, '' ), ', contact_email_org: ',
                                           api.api_nz( `p_contact_email_org`, '' ), ', benefit_plan_type: ',
                                           api.api_nz( `p_benefit_plan_type`, '' ) ) );
        CALL db_throw_error( @errno, 'upsert_api_case_contacts', @text );
    END;

    CALL api.db_log_message( 'upsert_api_case_contacts',
                             Concat( 'Called With Params: ', ', case_contact_id: ',
                                     api.api_nz( `p_case_contact_id`, '' ),
                                     ', case_id: ', api.api_nz( `p_case_id`, '' ), ', sf_contact_id: ',
                                     api.api_nz( `p_sf_contact_id`, '' ), ', status: ', api.api_nz( `p_status`, '' ),
                                     ', version_no: ', api.api_nz( `p_version_no`, '' ), ', contact_type: ',
                                     api.api_nz( `p_contact_type`, '' ), ', organization_name: ',
                                     api.api_nz( `p_organization_name`, '' ), ', organization_state: ',
                                     api.api_nz( `p_organization_state`, '' ), ', organization_zip: ',
                                     api.api_nz( `p_organization_zip`, '' ), ', contact_sub_type: ',
                                     api.api_nz( `p_contact_sub_type`, '' ), ', contact_title: ',
                                     api.api_nz( `p_contact_title`, '' ), ', contact_first_name: ',
                                     api.api_nz( `p_contact_first_name`, '' ), ', contact_last_name: ',
                                     api.api_nz( `p_contact_last_name`, '' ), ', contact_email: ',
                                     api.api_nz( `p_contact_email`, '' ), ', contact_phone: ',
                                     api.api_nz( `p_contact_phone`, '' ), ', contact_is_cons_ben_contact: ',
                                     api.api_nz( `p_contact_is_cons_ben_contact`, '' ), ', contact_is_cobra_contact: ',
                                     api.api_nz( `p_contact_is_cobra_contact`, '' ), ', contact_is_ben_admin_contact: ',
                                     api.api_nz( `p_contact_is_ben_admin_contact`, '' ), ', contact_email_org: ',
                                     api.api_nz( `p_contact_email_org`, '' ), ', benefit_plan_type: ',
                                     api.api_nz( `p_benefit_plan_type`, '' ) ), 'WARN' );

    INSERT
    INTO
        `api`.`api_case_contacts`
    (
        `case_contact_id`
    ,   `case_id`
    ,   `sf_contact_id`
    ,   `status`
    ,   `version_no`
    ,   `contact_type`
    ,   `organization_name`
    ,   `organization_state`
    ,   `organization_zip`
    ,   `contact_sub_type`
    ,   `contact_title`
    ,   `contact_first_name`
    ,   `contact_last_name`
    ,   `contact_email`
    ,   `contact_phone`
    ,   `contact_is_cons_ben_contact`
    ,   `contact_is_cobra_contact`
    ,   `contact_is_ben_admin_contact`
    ,   `contact_email_org`
    ,   `benefit_plan_type`
    )

    VALUES
    (
        `p_case_contact_id`
    ,   `p_case_id`
    ,   `p_sf_contact_id`
    ,   `p_status`
    ,   `p_version_no`
    ,   `p_contact_type`
    ,   `p_organization_name`
    ,   `p_organization_state`
    ,   `p_organization_zip`
    ,   `p_contact_sub_type`
    ,   `p_contact_title`
    ,   `p_contact_first_name`
    ,   `p_contact_last_name`
    ,   `p_contact_email`
    ,   `p_contact_phone`
    ,   `p_contact_is_cons_ben_contact`
    ,   `p_contact_is_cobra_contact`
    ,   `p_contact_is_ben_admin_contact`
    ,   `p_contact_email_org`
    ,   `p_benefit_plan_type`
    )

        /* use api_nz to avoid replacing previous value if new value is null or blank */
    ON DUPLICATE KEY UPDATE
                         `case_contact_id`              = api.api_nz( `p_case_contact_id`, `case_contact_id` )
                       , `case_id`                      = api.api_nz( `p_case_id`, `case_id` )
                       , `sf_contact_id`                = api.api_nz( `p_sf_contact_id`, `sf_contact_id` )
                       , `status`                       = api.api_nz( `p_status`, `status` )
                       , `version_no`                   = api.api_nz_int( `p_version_no`, `version_no` )
                       , `contact_type`                 = api.api_nz( `p_contact_type`, `contact_type` )
                       , `organization_name`            = api.api_nz( `p_organization_name`, `organization_name` )
                       , `organization_state`           = api.api_nz( `p_organization_state`, `organization_state` )
                       , `organization_zip`             = api.api_nz( `p_organization_zip`, `organization_zip` )
                       , `contact_sub_type`             = api.api_nz( `p_contact_sub_type`, `contact_sub_type` )
                       , `contact_title`                = api.api_nz( `p_contact_title`, `contact_title` )
                       , `contact_first_name`           = api.api_nz( `p_contact_first_name`, `contact_first_name` )
                       , `contact_last_name`            = api.api_nz( `p_contact_last_name`, `contact_last_name` )
                       , `contact_email`                = api.api_nz( `p_contact_email`, `contact_email` )
                       , `contact_phone`                = api.api_nz( `p_contact_phone`, `contact_phone` )
                       , `contact_is_cons_ben_contact`  = api.api_nz_int( `p_contact_is_cons_ben_contact`,
                                                                          `contact_is_cons_ben_contact` )
                       , `contact_is_cobra_contact`     = api.api_nz_int( `p_contact_is_cobra_contact`,
                                                                          `contact_is_cobra_contact` )
                       , `contact_is_ben_admin_contact` = api.api_nz_int( `p_contact_is_ben_admin_contact`,
                                                                          `contact_is_ben_admin_contact` )
                       , `contact_email_org`            = api.api_nz( `p_contact_email_org`, `contact_email_org` )
                       , `benefit_plan_type`            = api.api_nz( `p_benefit_plan_type`, `benefit_plan_type` );

END;

