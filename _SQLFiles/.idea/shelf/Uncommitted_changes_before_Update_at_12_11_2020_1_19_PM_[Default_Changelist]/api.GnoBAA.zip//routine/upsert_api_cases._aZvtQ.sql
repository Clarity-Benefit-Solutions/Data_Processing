create
    definer = admin@`%` procedure upsert_api_cases(IN p_case_id varchar(50), IN p_case_status varchar(75),
                                                   IN p_is_ready_for_processing int(1), IN p_version_no int,
                                                   IN p_case_type varchar(50), IN p_case_sub_type varchar(50),
                                                   IN p_employer_id varchar(70), IN p_employer_name varchar(150),
                                                   IN p_employer_division_name varchar(150),
                                                   IN p_sf_case_id varchar(100),
                                                   IN p_sf_case_owner_user_id varchar(200),
                                                   IN p_sf_account_no varchar(100), IN p_form_invite_token varchar(50),
                                                   IN p_form_curr_page_no int, IN p_wizard_curr_step_no int,
                                                   IN p_form_type varchar(100), IN p_form_entry_id varchar(50),
                                                   IN p_legal_business_name varchar(70), IN p_dba varchar(50),
                                                   IN p_street_physical_address varchar(200),
                                                   IN p_street_line2 varchar(100), IN p_city varchar(70),
                                                   IN p_state varchar(70), IN p_zip varchar(70), IN p_phone varchar(70),
                                                   IN p_fax varchar(70), IN p_web_address varchar(70),
                                                   IN p_incorporation_date varchar(70), IN p_laws_of_state varchar(70),
                                                   IN p_healthcare_carrier varchar(70),
                                                   IN p_healthcare_plan_type varchar(70),
                                                   IN p_dental_care_carrier varchar(70),
                                                   IN p_dental_care_plan_type varchar(70),
                                                   IN p_vision_care_carrier varchar(70),
                                                   IN p_vision_care_plan_type varchar(70),
                                                   IN p_cons_ben_plan_open_enrollment_start_date date,
                                                   IN p_cons_ben_plan_open_enrollment_end_date date,
                                                   IN p_cons_ben_plan_enrollment_method_employees varchar(100),
                                                   IN p_cons_ben_plan_enrollment_data_transmission_to_clarity varchar(100),
                                                   IN p_cons_ben_plan_estimated_date_enrollment_data_delivery varchar(100),
                                                   IN p_cons_ben_plan_type varchar(100),
                                                   IN p_cons_ben_plan_employee_class varchar(100),
                                                   IN p_cons_ben_plan_first_payroll_date date,
                                                   IN p_cons_ben_plan_waiting_period int,
                                                   IN p_cons_ben_plan_parking_transit_waiting_period int,
                                                   IN p_cons_ben_plan_qualified_dependents int,
                                                   IN p_cobra_plan_open_enrollment_start_date date,
                                                   IN p_cobra_plan_open_enrollment_end_date date,
                                                   IN p_cobra_plan_enrollment_method_employees varchar(100),
                                                   IN p_cobra_plan_enrollment_data_transmission_to_clarity varchar(100),
                                                   IN p_cobra_plan_estimated_date_enrollment_data_delivery varchar(100),
                                                   IN p_cobra_plan_type varchar(100),
                                                   IN p_cobra_plan_employee_class varchar(100),
                                                   IN p_cobra_plan_first_payroll_date date,
                                                   IN p_cobra_plan_waiting_period int,
                                                   IN p_cobra_plan_parking_transit_waiting_period int,
                                                   IN p_cobra_plan_qualified_dependents int,
                                                   IN p_cons_ben_has_rol_plan int,
                                                   IN p_cons_ben_number_of_benefit_eligible_employees int,
                                                   IN p_cons_ben_number_of_participating_employees int,
                                                   IN p_cons_ben_plan_enrollment_template varchar(100),
                                                   IN p_cons_ben_plan_enrollment_template_tpa_name varchar(100),
                                                   IN p_cons_ben_plan_payroll_group varchar(100),
                                                   IN p_cons_ben_funding_method varchar(200))
BEGIN


    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO,
                @text = MESSAGE_TEXT;
            SET @text = CONCAT( @text, Concat( '
Called With Params: ', ', case_id: ', api.api_nz( `p_case_id`, '' ), ', case_status: ',
                                               api.api_nz( `p_case_status`, '' ),
                                               ', is_ready_for_processing: ',
                                               api.api_nz( `p_is_ready_for_processing`, '' ),
                                               ', version_no: ', api.api_nz( `p_version_no`, '' ), ', case_type: ',
                                               api.api_nz( `p_case_type`, '' ), ', case_sub_type: ',
                                               api.api_nz( `p_case_sub_type`, '' ), ', employer_id: ',
                                               api.api_nz( `p_employer_id`, '' ), ', employer_name: ',
                                               api.api_nz( `p_employer_name`, '' ), ', employer_division_name: ',
                                               api.api_nz( `p_employer_division_name`, '' ), ', sf_case_id: ',
                                               api.api_nz( `p_sf_case_id`, '' ), ', sf_case_owner_user_id: ',
                                               api.api_nz( `p_sf_case_owner_user_id`, '' ), ', sf_account_no: ',
                                               api.api_nz( `p_sf_account_no`, '' ), ', form_invite_token: ',
                                               api.api_nz( `p_form_invite_token`, '' ), ', form_curr_page_no: ',
                                               api.api_nz( `p_form_curr_page_no`, '' ), ', wizard_curr_step_no: ',
                                               api.api_nz( `p_wizard_curr_step_no`, '' ), ', form_type: ',
                                               api.api_nz( `p_form_type`, '' ), ', form_entry_id: ',
                                               api.api_nz( `p_form_entry_id`, '' ), ', legal_business_name: ',
                                               api.api_nz( `p_legal_business_name`, '' ), ', dba: ',
                                               api.api_nz( `p_dba`, '' ), ', street_physical_address: ',
                                               api.api_nz( `p_street_physical_address`, '' ), ', street_line2: ',
                                               api.api_nz( `p_street_line2`, '' ), ', city: ',
                                               api.api_nz( `p_city`, '' ),
                                               ', state: ', api.api_nz( `p_state`, '' ), ', zip: ',
                                               api.api_nz( `p_zip`, '' ),
                                               ', phone: ', api.api_nz( `p_phone`, '' ), ', fax: ',
                                               api.api_nz( `p_fax`, '' ),
                                               ', web_address: ', api.api_nz( `p_web_address`, '' ),
                                               ', incorporation_date: ', api.api_nz( `p_incorporation_date`, '' ),
                                               ', laws_of_state: ', api.api_nz( `p_laws_of_state`, '' ),
                                               ', healthcare_carrier: ', api.api_nz( `p_healthcare_carrier`, '' ),
                                               ', healthcare_plan_type: ', api.api_nz( `p_healthcare_plan_type`, '' ),
                                               ', dental_care_carrier: ', api.api_nz( `p_dental_care_carrier`, '' ),
                                               ', dental_care_plan_type: ', api.api_nz( `p_dental_care_plan_type`, '' ),
                                               ', vision_care_carrier: ', api.api_nz( `p_vision_care_carrier`, '' ),
                                               ', vision_care_plan_type: ', api.api_nz( `p_vision_care_plan_type`, '' ),
                                               ', cons_ben_plan_open_enrollment_start_date: ',
                                               api.api_nz( `p_cons_ben_plan_open_enrollment_start_date`, '' ),
                                               ', cons_ben_plan_open_enrollment_end_date: ',
                                               api.api_nz( `p_cons_ben_plan_open_enrollment_end_date`, '' ),
                                               ', cons_ben_plan_enrollment_method_employees: ',
                                               api.api_nz( `p_cons_ben_plan_enrollment_method_employees`, '' ),
                                               ', cons_ben_plan_enrollment_data_transmission_to_clarity: ',
                                               api.api_nz( `p_cons_ben_plan_enrollment_data_transmission_to_clarity`,
                                                           '' ),
                                               ', cons_ben_plan_estimated_date_enrollment_data_delivery: ',
                                               api.api_nz( `p_cons_ben_plan_estimated_date_enrollment_data_delivery`,
                                                           '' ),
                                               ', cons_ben_plan_type: ', api.api_nz( `p_cons_ben_plan_type`, '' ),
                                               ', cons_ben_plan_employee_class: ',
                                               api.api_nz( `p_cons_ben_plan_employee_class`, '' ),
                                               ', cons_ben_plan_first_payroll_date: ',
                                               api.api_nz( `p_cons_ben_plan_first_payroll_date`, '' ),
                                               ', cons_ben_plan_waiting_period: ',
                                               api.api_nz( `p_cons_ben_plan_waiting_period`, '' ),
                                               ', cons_ben_plan_parking_transit_waiting_period: ',
                                               api.api_nz( `p_cons_ben_plan_parking_transit_waiting_period`, '' ),
                                               ', cons_ben_plan_qualified_dependents: ',
                                               api.api_nz( `p_cons_ben_plan_qualified_dependents`, '' ),
                                               ', cobra_plan_open_enrollment_start_date: ',
                                               api.api_nz( `p_cobra_plan_open_enrollment_start_date`, '' ),
                                               ', cobra_plan_open_enrollment_end_date: ',
                                               api.api_nz( `p_cobra_plan_open_enrollment_end_date`, '' ),
                                               ', cobra_plan_enrollment_method_employees: ',
                                               api.api_nz( `p_cobra_plan_enrollment_method_employees`, '' ),
                                               ', cobra_plan_enrollment_data_transmission_to_clarity: ',
                                               api.api_nz( `p_cobra_plan_enrollment_data_transmission_to_clarity`, '' ),
                                               ', cobra_plan_estimated_date_enrollment_data_delivery: ',
                                               api.api_nz( `p_cobra_plan_estimated_date_enrollment_data_delivery`, '' ),
                                               ', cobra_plan_type: ', api.api_nz( `p_cobra_plan_type`, '' ),
                                               ', cobra_plan_employee_class: ',
                                               api.api_nz( `p_cobra_plan_employee_class`, '' ),
                                               ', cobra_plan_first_payroll_date: ',
                                               api.api_nz( `p_cobra_plan_first_payroll_date`, '' ),
                                               ', cobra_plan_waiting_period: ',
                                               api.api_nz( `p_cobra_plan_waiting_period`, '' ),
                                               ', cobra_plan_parking_transit_waiting_period: ',
                                               api.api_nz( `p_cobra_plan_parking_transit_waiting_period`, '' ),
                                               ', cobra_plan_qualified_dependents: ',
                                               api.api_nz( `p_cobra_plan_qualified_dependents`, '' ),
                                               ', cons_ben_has_rol_plan: ', api.api_nz( `p_cons_ben_has_rol_plan`, '' ),
                                               ', cons_ben_number_of_benefit_eligible_employees: ',
                                               api.api_nz( `p_cons_ben_number_of_benefit_eligible_employees`, '' ),
                                               ', cons_ben_number_of_participating_employees: ',
                                               api.api_nz( `p_cons_ben_number_of_participating_employees`, '' ),
                                               ', cons_ben_plan_enrollment_template: ',
                                               api.api_nz( `p_cons_ben_plan_enrollment_template`, '' ),
                                               ', cons_ben_plan_enrollment_template_tpa_name: ',
                                               api.api_nz( `p_cons_ben_plan_enrollment_template_tpa_name`, '' ),
                                               ', cons_ben_plan_payroll_group: ',
                                               api.api_nz( `p_cons_ben_plan_payroll_group`, '' ),
                                               ', cons_ben_funding_method: ',
                                               api.api_nz( `p_cons_ben_funding_method`, '' ) ) );
            CALL db_throw_error( @errno, 'upsert_api_cases', @text );
        END;


    CALL api.db_log_message( 'upsert_api_cases',
                             Concat( 'Called With Params: ', ', case_id: ', api.api_nz( `p_case_id`, '' ),
                                     ', case_status: ', api.api_nz( `p_case_status`, '' ),
                                     ', is_ready_for_processing: ',
                                     api.api_nz( `p_is_ready_for_processing`, '' ), ', version_no: ',
                                     api.api_nz( `p_version_no`, '' ), ', case_type: ', api.api_nz( `p_case_type`, '' ),
                                     ', case_sub_type: ', api.api_nz( `p_case_sub_type`, '' ), ', employer_id: ',
                                     api.api_nz( `p_employer_id`, '' ), ', employer_name: ',
                                     api.api_nz( `p_employer_name`, '' ), ', employer_division_name: ',
                                     api.api_nz( `p_employer_division_name`, '' ), ', sf_case_id: ',
                                     api.api_nz( `p_sf_case_id`, '' ), ', sf_case_owner_user_id: ',
                                     api.api_nz( `p_sf_case_owner_user_id`, '' ), ', sf_account_no: ',
                                     api.api_nz( `p_sf_account_no`, '' ), ', form_invite_token: ',
                                     api.api_nz( `p_form_invite_token`, '' ), ', form_curr_page_no: ',
                                     api.api_nz( `p_form_curr_page_no`, '' ), ', wizard_curr_step_no: ',
                                     api.api_nz( `p_wizard_curr_step_no`, '' ), ', form_type: ',
                                     api.api_nz( `p_form_type`, '' ), ', form_entry_id: ',
                                     api.api_nz( `p_form_entry_id`, '' ), ', legal_business_name: ',
                                     api.api_nz( `p_legal_business_name`, '' ), ', dba: ', api.api_nz( `p_dba`, '' ),
                                     ', street_physical_address: ', api.api_nz( `p_street_physical_address`, '' ),
                                     ', street_line2: ', api.api_nz( `p_street_line2`, '' ), ', city: ',
                                     api.api_nz( `p_city`, '' ), ', state: ', api.api_nz( `p_state`, '' ), ', zip: ',
                                     api.api_nz( `p_zip`, '' ), ', phone: ', api.api_nz( `p_phone`, '' ), ', fax: ',
                                     api.api_nz( `p_fax`, '' ), ', web_address: ', api.api_nz( `p_web_address`, '' ),
                                     ', incorporation_date: ', api.api_nz( `p_incorporation_date`, '' ),
                                     ', laws_of_state: ', api.api_nz( `p_laws_of_state`, '' ), ', healthcare_carrier: ',
                                     api.api_nz( `p_healthcare_carrier`, '' ), ', healthcare_plan_type: ',
                                     api.api_nz( `p_healthcare_plan_type`, '' ), ', dental_care_carrier: ',
                                     api.api_nz( `p_dental_care_carrier`, '' ), ', dental_care_plan_type: ',
                                     api.api_nz( `p_dental_care_plan_type`, '' ), ', vision_care_carrier: ',
                                     api.api_nz( `p_vision_care_carrier`, '' ), ', vision_care_plan_type: ',
                                     api.api_nz( `p_vision_care_plan_type`, '' ),
                                     ', cons_ben_plan_open_enrollment_start_date: ',
                                     api.api_nz( `p_cons_ben_plan_open_enrollment_start_date`, '' ),
                                     ', cons_ben_plan_open_enrollment_end_date: ',
                                     api.api_nz( `p_cons_ben_plan_open_enrollment_end_date`, '' ),
                                     ', cons_ben_plan_enrollment_method_employees: ',
                                     api.api_nz( `p_cons_ben_plan_enrollment_method_employees`, '' ),
                                     ', cons_ben_plan_enrollment_data_transmission_to_clarity: ',
                                     api.api_nz( `p_cons_ben_plan_enrollment_data_transmission_to_clarity`, '' ),
                                     ', cons_ben_plan_estimated_date_enrollment_data_delivery: ',
                                     api.api_nz( `p_cons_ben_plan_estimated_date_enrollment_data_delivery`, '' ),
                                     ', cons_ben_plan_type: ', api.api_nz( `p_cons_ben_plan_type`, '' ),
                                     ', cons_ben_plan_employee_class: ',
                                     api.api_nz( `p_cons_ben_plan_employee_class`, '' ),
                                     ', cons_ben_plan_first_payroll_date: ',
                                     api.api_nz( `p_cons_ben_plan_first_payroll_date`, '' ),
                                     ', cons_ben_plan_waiting_period: ',
                                     api.api_nz( `p_cons_ben_plan_waiting_period`, '' ),
                                     ', cons_ben_plan_parking_transit_waiting_period: ',
                                     api.api_nz( `p_cons_ben_plan_parking_transit_waiting_period`, '' ),
                                     ', cons_ben_plan_qualified_dependents: ',
                                     api.api_nz( `p_cons_ben_plan_qualified_dependents`, '' ),
                                     ', cobra_plan_open_enrollment_start_date: ',
                                     api.api_nz( `p_cobra_plan_open_enrollment_start_date`, '' ),
                                     ', cobra_plan_open_enrollment_end_date: ',
                                     api.api_nz( `p_cobra_plan_open_enrollment_end_date`, '' ),
                                     ', cobra_plan_enrollment_method_employees: ',
                                     api.api_nz( `p_cobra_plan_enrollment_method_employees`, '' ),
                                     ', cobra_plan_enrollment_data_transmission_to_clarity: ',
                                     api.api_nz( `p_cobra_plan_enrollment_data_transmission_to_clarity`, '' ),
                                     ', cobra_plan_estimated_date_enrollment_data_delivery: ',
                                     api.api_nz( `p_cobra_plan_estimated_date_enrollment_data_delivery`, '' ),
                                     ', cobra_plan_type: ', api.api_nz( `p_cobra_plan_type`, '' ),
                                     ', cobra_plan_employee_class: ', api.api_nz( `p_cobra_plan_employee_class`, '' ),
                                     ', cobra_plan_first_payroll_date: ',
                                     api.api_nz( `p_cobra_plan_first_payroll_date`, '' ),
                                     ', cobra_plan_waiting_period: ',
                                     api.api_nz( `p_cobra_plan_waiting_period`, '' ),
                                     ', cobra_plan_parking_transit_waiting_period: ',
                                     api.api_nz( `p_cobra_plan_parking_transit_waiting_period`, '' ),
                                     ', cobra_plan_qualified_dependents: ',
                                     api.api_nz( `p_cobra_plan_qualified_dependents`, '' ), ', cons_ben_has_rol_plan: ',
                                     api.api_nz( `p_cons_ben_has_rol_plan`, '' ),
                                     ', cons_ben_number_of_benefit_eligible_employees: ',
                                     api.api_nz( `p_cons_ben_number_of_benefit_eligible_employees`, '' ),
                                     ', cons_ben_number_of_participating_employees: ',
                                     api.api_nz( `p_cons_ben_number_of_participating_employees`, '' ),
                                     ', cons_ben_plan_enrollment_template: ',
                                     api.api_nz( `p_cons_ben_plan_enrollment_template`, '' ),
                                     ', cons_ben_plan_enrollment_template_tpa_name: ',
                                     api.api_nz( `p_cons_ben_plan_enrollment_template_tpa_name`, '' ),
                                     ', cons_ben_plan_payroll_group: ',
                                     api.api_nz( `p_cons_ben_plan_payroll_group`, '' ),
                                     ', cons_ben_funding_method: ', api.api_nz( `p_cons_ben_funding_method`, '' ) ),
                             'WARN' );


    INSERT
    INTO
        `api`.`api_cases`
    (
        `case_id`
    ,   `case_status`
    ,   `is_ready_for_processing`
    ,   `version_no`
    ,   `case_type`
    ,   `case_sub_type`
    ,   `employer_id`
    ,   `employer_name`
    ,   `employer_division_name`
    ,   `sf_case_id`
    ,   `sf_case_owner_user_id`
    ,   `sf_account_no`
    ,   `form_invite_token`
    ,   `form_curr_page_no`
    ,   `wizard_curr_step_no`
    ,   `form_type`
    ,   `form_entry_id`
    ,   `legal_business_name`
    ,   `dba`
    ,   `street_physical_address`
    ,   `street_line2`
    ,   `city`
    ,   `state`
    ,   `zip`
    ,   `phone`
    ,   `fax`
    ,   `web_address`
    ,   `incorporation_date`
    ,   `laws_of_state`
    ,   `healthcare_carrier`
    ,   `healthcare_plan_type`
    ,   `dental_care_carrier`
    ,   `dental_care_plan_type`
    ,   `vision_care_carrier`
    ,   `vision_care_plan_type`
    ,   `cons_ben_plan_open_enrollment_start_date`
    ,   `cons_ben_plan_open_enrollment_end_date`
    ,   `cons_ben_plan_enrollment_method_employees`
    ,   `cons_ben_plan_enrollment_data_transmission_to_clarity`
    ,   `cons_ben_plan_estimated_date_enrollment_data_delivery`
    ,   `cons_ben_plan_type`
    ,   `cons_ben_plan_employee_class`
    ,   `cons_ben_plan_first_payroll_date`
    ,   `cons_ben_plan_waiting_period`
    ,   `cons_ben_plan_parking_transit_waiting_period`
    ,   `cons_ben_plan_qualified_dependents`
    ,   `cobra_plan_open_enrollment_start_date`
    ,   `cobra_plan_open_enrollment_end_date`
    ,   `cobra_plan_enrollment_method_employees`
    ,   `cobra_plan_enrollment_data_transmission_to_clarity`
    ,   `cobra_plan_estimated_date_enrollment_data_delivery`
    ,   `cobra_plan_type`
    ,   `cobra_plan_employee_class`
    ,   `cobra_plan_first_payroll_date`
    ,   `cobra_plan_waiting_period`
    ,   `cobra_plan_parking_transit_waiting_period`
    ,   `cobra_plan_qualified_dependents`
    ,   `cons_ben_has_rol_plan`
    ,   `cons_ben_number_of_benefit_eligible_employees`
    ,   `cons_ben_number_of_participating_employees`
    ,   `cons_ben_plan_enrollment_template`
    ,   `cons_ben_plan_enrollment_template_tpa_name`
    ,   `cons_ben_plan_payroll_group`
    ,   `cons_ben_funding_method`
    ,   last_updated_from
    )


    VALUES
    (
        `p_case_id`
    ,   `p_case_status`
    ,   `p_is_ready_for_processing`
    ,   `p_version_no`
    ,   `p_case_type`
    ,   `p_case_sub_type`
    ,   `p_employer_id`
    ,   `p_employer_name`
    ,   `p_employer_division_name`
    ,   `p_sf_case_id`
    ,   `p_sf_case_owner_user_id`
    ,   `p_sf_account_no`
    ,   `p_form_invite_token`
    ,   `p_form_curr_page_no`
    ,   `p_wizard_curr_step_no`
    ,   `p_form_type`
    ,   `p_form_entry_id`
    ,   `p_legal_business_name`
    ,   `p_dba`
    ,   `p_street_physical_address`
    ,   `p_street_line2`
    ,   `p_city`
    ,   `p_state`
    ,   `p_zip`
    ,   `p_phone`
    ,   `p_fax`
    ,   `p_web_address`
    ,   `p_incorporation_date`
    ,   `p_laws_of_state`
    ,   `p_healthcare_carrier`
    ,   `p_healthcare_plan_type`
    ,   `p_dental_care_carrier`
    ,   `p_dental_care_plan_type`
    ,   `p_vision_care_carrier`
    ,   `p_vision_care_plan_type`
    ,   `p_cons_ben_plan_open_enrollment_start_date`
    ,   `p_cons_ben_plan_open_enrollment_end_date`
    ,   `p_cons_ben_plan_enrollment_method_employees`
    ,   `p_cons_ben_plan_enrollment_data_transmission_to_clarity`
    ,   `p_cons_ben_plan_estimated_date_enrollment_data_delivery`
    ,   `p_cons_ben_plan_type`
    ,   `p_cons_ben_plan_employee_class`
    ,   `p_cons_ben_plan_first_payroll_date`
    ,   `p_cons_ben_plan_waiting_period`
    ,   `p_cons_ben_plan_parking_transit_waiting_period`
    ,   `p_cons_ben_plan_qualified_dependents`
    ,   `p_cobra_plan_open_enrollment_start_date`
    ,   `p_cobra_plan_open_enrollment_end_date`
    ,   `p_cobra_plan_enrollment_method_employees`
    ,   `p_cobra_plan_enrollment_data_transmission_to_clarity`
    ,   `p_cobra_plan_estimated_date_enrollment_data_delivery`
    ,   `p_cobra_plan_type`
    ,   `p_cobra_plan_employee_class`
    ,   `p_cobra_plan_first_payroll_date`
    ,   `p_cobra_plan_waiting_period`
    ,   `p_cobra_plan_parking_transit_waiting_period`
    ,   `p_cobra_plan_qualified_dependents`
    ,   `p_cons_ben_has_rol_plan`
    ,   `p_cons_ben_number_of_benefit_eligible_employees`
    ,   `p_cons_ben_number_of_participating_employees`
    ,   `p_cons_ben_plan_enrollment_template`
    ,   `p_cons_ben_plan_enrollment_template_tpa_name`
    ,   `p_cons_ben_plan_payroll_group`
    ,   `p_cons_ben_funding_method`
    ,   'upsert_api_cases'
    )


    ON DUPLICATE KEY
        UPDATE
            `case_id`                                               = api.api_nz( `p_case_id`, `case_id` )
          , `case_status`                                           = api.api_nz( `p_case_status`, `case_status` )
          , `is_ready_for_processing`                               = api.api_nz_int( `p_is_ready_for_processing`,
                                                                                      `is_ready_for_processing` )
          , `version_no`                                            = api.api_nz_int( `p_version_no`, `version_no` )
          , `case_type`                                             = api.api_nz( `p_case_type`, `case_type` )
          , `case_sub_type`                                         = api.api_nz( `p_case_sub_type`, `case_sub_type` )
          , `employer_id`                                           = api.api_nz( `p_employer_id`, `employer_id` )
          , `employer_name`                                         = api.api_nz( `p_employer_name`, `employer_name` )
          , `employer_division_name`                                = api.api_nz( `p_employer_division_name`, `employer_division_name` )
          , `sf_case_id`                                            = api.api_nz( `p_sf_case_id`, `sf_case_id` )
          , `sf_case_owner_user_id`                                 = api.api_nz( `p_sf_case_owner_user_id`, `sf_case_owner_user_id` )
          , `sf_account_no`                                         = api.api_nz( `p_sf_account_no`, `sf_account_no` )
          , `form_invite_token`                                     = api.api_nz( `p_form_invite_token`, `form_invite_token` )
          , `form_curr_page_no`                                     = api.api_nz_int( `p_form_curr_page_no`, `form_curr_page_no` )
          , `wizard_curr_step_no`                                   = api.api_nz_int( `p_wizard_curr_step_no`, `wizard_curr_step_no` )
          , `form_type`                                             = api.api_nz( `p_form_type`, `form_type` )
          , `form_entry_id`                                         = api.api_nz( `p_form_entry_id`, `form_entry_id` )
          , `legal_business_name`                                   = api.api_nz( `p_legal_business_name`, `legal_business_name` )
          , `dba`                                                   = api.api_nz( `p_dba`, `dba` )
          , `street_physical_address`                               = api.api_nz( `p_street_physical_address`, `street_physical_address` )
          , `street_line2`                                          = api.api_nz( `p_street_line2`, `street_line2` )
          , `city`                                                  = api.api_nz( `p_city`, `city` )
          , `state`                                                 = api.api_nz( `p_state`, `state` )
          , `zip`                                                   = api.api_nz( `p_zip`, `zip` )
          , `phone`                                                 = api.api_nz( `p_phone`, `phone` )
          , `fax`                                                   = api.api_nz( `p_fax`, `fax` )
          , `web_address`                                           = api.api_nz( `p_web_address`, `web_address` )
          , `incorporation_date`                                    = api.api_nz( `p_incorporation_date`, `incorporation_date` )
          , `laws_of_state`                                         = api.api_nz( `p_laws_of_state`, `laws_of_state` )
          , `healthcare_carrier`                                    = api.api_nz( `p_healthcare_carrier`, `healthcare_carrier` )
          , `healthcare_plan_type`                                  = api.api_nz( `p_healthcare_plan_type`, `healthcare_plan_type` )
          , `dental_care_carrier`                                   = api.api_nz( `p_dental_care_carrier`, `dental_care_carrier` )
          , `dental_care_plan_type`                                 = api.api_nz( `p_dental_care_plan_type`, `dental_care_plan_type` )
          , `vision_care_carrier`                                   = api.api_nz( `p_vision_care_carrier`, `vision_care_carrier` )
          , `vision_care_plan_type`                                 = api.api_nz( `p_vision_care_plan_type`, `vision_care_plan_type` )
          , `cons_ben_plan_open_enrollment_start_date`              = api.api_nz_date(
                `p_cons_ben_plan_open_enrollment_start_date`, `cons_ben_plan_open_enrollment_start_date` )
          , `cons_ben_plan_open_enrollment_end_date`                = api.api_nz_date(
                `p_cons_ben_plan_open_enrollment_end_date`, `cons_ben_plan_open_enrollment_end_date` )
          , `cons_ben_plan_enrollment_method_employees`             = api.api_nz(
                `p_cons_ben_plan_enrollment_method_employees`, `cons_ben_plan_enrollment_method_employees` )
          , `cons_ben_plan_enrollment_data_transmission_to_clarity` = api.api_nz(
                `p_cons_ben_plan_enrollment_data_transmission_to_clarity`,
                `cons_ben_plan_enrollment_data_transmission_to_clarity` )
          , `cons_ben_plan_estimated_date_enrollment_data_delivery` = api.api_nz(
                `p_cons_ben_plan_estimated_date_enrollment_data_delivery`,
                `cons_ben_plan_estimated_date_enrollment_data_delivery` )
          , `cons_ben_plan_type`                                    = api.api_nz( `p_cons_ben_plan_type`, `cons_ben_plan_type` )
          , `cons_ben_plan_employee_class`                          = api.api_nz( `p_cons_ben_plan_employee_class`,
                                                                                  `cons_ben_plan_employee_class` )
          , `cons_ben_plan_first_payroll_date`                      = api.api_nz_date(
                `p_cons_ben_plan_first_payroll_date`, `cons_ben_plan_first_payroll_date` )
          , `cons_ben_plan_waiting_period`                          = api.api_nz_int(
                `p_cons_ben_plan_waiting_period`, `cons_ben_plan_waiting_period` )
          , `cons_ben_plan_parking_transit_waiting_period`          = api.api_nz_int(
                `p_cons_ben_plan_parking_transit_waiting_period`,
                `cons_ben_plan_parking_transit_waiting_period` )
          , `cons_ben_plan_qualified_dependents`                    = api.api_nz_int(
                `p_cons_ben_plan_qualified_dependents`, `cons_ben_plan_qualified_dependents` )
          , `cobra_plan_open_enrollment_start_date`                 = api.api_nz_date(
                `p_cobra_plan_open_enrollment_start_date`, `cobra_plan_open_enrollment_start_date` )
          , `cobra_plan_open_enrollment_end_date`                   = api.api_nz_date(
                `p_cobra_plan_open_enrollment_end_date`, `cobra_plan_open_enrollment_end_date` )
          , `cobra_plan_enrollment_method_employees`                = api.api_nz(
                `p_cobra_plan_enrollment_method_employees`, `cobra_plan_enrollment_method_employees` )
          , `cobra_plan_enrollment_data_transmission_to_clarity`    = api.api_nz(
                `p_cobra_plan_enrollment_data_transmission_to_clarity`,
                `cobra_plan_enrollment_data_transmission_to_clarity` )
          , `cobra_plan_estimated_date_enrollment_data_delivery`    = api.api_nz(
                `p_cobra_plan_estimated_date_enrollment_data_delivery`,
                `cobra_plan_estimated_date_enrollment_data_delivery` )
          , `cobra_plan_type`                                       = api.api_nz( `p_cobra_plan_type`, `cobra_plan_type` )
          , `cobra_plan_employee_class`                             = api.api_nz( `p_cobra_plan_employee_class`,
                                                                                  `cobra_plan_employee_class` )
          , `cobra_plan_first_payroll_date`                         = api.api_nz_date(
                `p_cobra_plan_first_payroll_date`, `cobra_plan_first_payroll_date` )
          , `cobra_plan_waiting_period`                             = api.api_nz_int( `p_cobra_plan_waiting_period`,
                                                                                      `cobra_plan_waiting_period` )
          , `cobra_plan_parking_transit_waiting_period`             = api.api_nz_int(
                `p_cobra_plan_parking_transit_waiting_period`, `cobra_plan_parking_transit_waiting_period` )
          , `cobra_plan_qualified_dependents`                       = api.api_nz_int(
                `p_cobra_plan_qualified_dependents`, `cobra_plan_qualified_dependents` )
          , `cons_ben_has_rol_plan`                                 = api.api_nz_int( `p_cons_ben_has_rol_plan`, `cons_ben_has_rol_plan` )
          , `cons_ben_number_of_benefit_eligible_employees`         = api.api_nz_int(
                `p_cons_ben_number_of_benefit_eligible_employees`,
                `cons_ben_number_of_benefit_eligible_employees` )
          , `cons_ben_number_of_participating_employees`            = api.api_nz_int(
                `p_cons_ben_number_of_participating_employees`, `cons_ben_number_of_participating_employees` )
          , `cons_ben_plan_enrollment_template`                     = api.api_nz(
                `p_cons_ben_plan_enrollment_template`, `cons_ben_plan_enrollment_template` )
          , `cons_ben_plan_enrollment_template_tpa_name`            = api.api_nz(
                `p_cons_ben_plan_enrollment_template_tpa_name`, `cons_ben_plan_enrollment_template_tpa_name` )
          , `cons_ben_plan_payroll_group`                           = api.api_nz( `p_cons_ben_plan_payroll_group`,
                                                                                  `cons_ben_plan_payroll_group` )
          , `cons_ben_funding_method`                               = api.api_nz( `p_cons_ben_funding_method`,
                                                                                  `cons_ben_funding_method`,
                                                                                  last_updated_from = 'upsert_api_cases' );


END;

