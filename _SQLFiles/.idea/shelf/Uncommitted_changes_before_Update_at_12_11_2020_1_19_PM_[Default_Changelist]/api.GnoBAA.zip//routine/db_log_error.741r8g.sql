create
    definer = admin@`%` procedure db_log_error(IN p_err_no varchar(50), IN p_err_source varchar(200),
                                               IN p_err_msg longtext, IN p_sqlstate varchar(200))
BEGIN

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
        END;

    INSERT
    INTO
        api.db_error_log (
                        sql_state
                      , err_no
                      , err_source
                      , err_msg)
    VALUES
    (
        p_sqlstate
    ,   p_err_no
    ,   p_err_source
    ,   p_err_msg);
END;

