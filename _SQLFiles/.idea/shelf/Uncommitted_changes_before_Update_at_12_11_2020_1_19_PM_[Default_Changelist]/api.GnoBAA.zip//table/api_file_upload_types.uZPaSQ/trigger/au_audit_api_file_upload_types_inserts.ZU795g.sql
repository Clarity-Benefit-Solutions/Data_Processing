create definer = admin@`%` trigger au_audit_api_file_upload_types_inserts
    after insert
    on api_file_upload_types
    for each row
    INSERT INTO `api`.`api_file_upload_types_audit`
                 (`auditAction`, `platform_name`, `platform_template_name`, `platform_template_status`,
                  `platform_template_type`, `platform_template_download_file_name`, `platform_template_content`,
                  `platform_template_file_url`, `upload_destination_host`, `upload_destination_url`, `created_at`,
                  `created_by`, `updated_at`, `updated_by`)
                 VALUES ('INSERT', NEW.`platform_name`, NEW.`platform_template_name`, NEW.`platform_template_status`,
                         NEW.`platform_template_type`, NEW.`platform_template_download_file_name`,
                         NEW.`platform_template_content`, NEW.`platform_template_file_url`,
                         NEW.`upload_destination_host`, NEW.`upload_destination_url`, NEW.`created_at`,
                         NEW.`created_by`, NEW.`updated_at`, NEW.`updated_by`);

