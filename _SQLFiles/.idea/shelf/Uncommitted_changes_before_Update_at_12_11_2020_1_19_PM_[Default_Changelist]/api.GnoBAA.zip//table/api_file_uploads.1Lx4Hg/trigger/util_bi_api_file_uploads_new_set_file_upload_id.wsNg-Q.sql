create definer = admin@`%` trigger util_bi_api_file_uploads_new_set_file_upload_id
    before insert
    on api_file_uploads
    for each row
BEGIN
    IF api.api_is_blank(new.file_upload_id) THEN
        SET new.file_upload_id = api.api_uuid();
    END IF;


END;

