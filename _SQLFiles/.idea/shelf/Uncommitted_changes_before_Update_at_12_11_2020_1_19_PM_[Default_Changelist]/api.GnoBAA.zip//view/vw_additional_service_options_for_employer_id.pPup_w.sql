create definer = admin@`%` view vw_additional_service_options_for_employer_id as
select 1 AS `employer_id`;

