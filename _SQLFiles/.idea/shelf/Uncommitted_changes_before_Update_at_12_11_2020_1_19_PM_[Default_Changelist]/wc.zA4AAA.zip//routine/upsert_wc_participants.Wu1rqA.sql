create
    definer = admin@`%` procedure upsert_wc_participants(IN recordid varchar(50), IN tpaid varchar(50),
                                                         IN employername varchar(50), IN employerid varchar(50),
                                                         IN employeeid varchar(50), IN lastname varchar(50),
                                                         IN firstname varchar(50), IN phone varchar(50),
                                                         IN addressline1 varchar(100), IN addressline2 varchar(100),
                                                         IN city varchar(50), IN state varchar(50), IN zip varchar(50),
                                                         IN country varchar(50), IN email varchar(200),
                                                         IN employeestatus varchar(50),
                                                         IN reimbursementmethod varchar(50), IN birthdate varchar(50),
                                                         IN employeessn varchar(50), IN cardnumber varchar(50),
                                                         IN mobilenumber varchar(50))
BEGIN


    CALL api.db_log_message( 'upsert_wc_participants',
                             concat( 'Processing Employee ID: ', employeeid, ', Name: ', firstname ),
                             'WARN' );
    INSERT
    INTO
        wc.wc_participants(
                            recordid
                          , tpaid
                          , employername
                          , employerid
                          , employeeid
                          , lastname
                          , firstname
                          , phone
                          , addressline1
                          , addressline2
                          , city
                          , state
                          , zip
                          , country
                          , email
                          , employeestatus
                          , reimbursementmethod
                          , birthdate
                          , employeessn
                          , cardnumber
                          , mobilenumber
    )
    VALUES
    (
        recordid
    ,   tpaid
    ,   employername
    ,   employerid
    ,   employeeid
    ,   lastname
    ,   firstname
    ,   phone
    ,   addressline1
    ,   addressline2
    ,   city
    ,   state
    ,   zip
    ,   country
    ,   email
    ,   employeestatus
    ,   reimbursementmethod
    ,   birthdate
    ,   employeessn
    ,   cardnumber
    ,   mobilenumber
    )
    ON DUPLICATE KEY UPDATE
                         recordid            = recordid
                       , tpaid               = tpaid
                       , employername        = employername
                       , employerid          = employerid
                       , employeeid          = employeeid
                       , lastname            = lastname
                       , firstname           = firstname
                       , phone               = phone
                       , addressline1        = addressline1
                       , addressline2        = addressline2
                       , city                = city
                       , state               = state
                       , zip                 = zip
                       , country             = country
                       , email               = email
                       , employeestatus      = employeestatus
                       , reimbursementmethod = reimbursementmethod
                       , birthdate           = birthdate
                       , employeessn         = employeessn
                       , cardnumber          = cardnumber
                       , mobilenumber        = mobilenumber;
END;

