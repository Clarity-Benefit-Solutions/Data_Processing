create definer = admin@`%` trigger util_bu_wc_participants_set_updated_at_and_by
    before update
    on wc_participants
    for each row
begin
    set new.updated_at = current_timestamp;
    set new.updated_by = current_user;
end;

