create definer = admin@`%` trigger ai_wc_participants_upsert_sso_users
    after insert
    on wc_participants
    for each row
BEGIN
    CALL api.upsert_wc_platform_user(
            new.Email
        , new.Email
        , new.FirstName
        , new.LastName
        , new.MobileNumber
        , api.api_fix_ssn(api.api_nz(new.EmployeeSSN, new.EmployeeID))
        , NULL 
        , NULL 
        , NULL 
        , NULL 
        , NEW.TPAID 
        , NEW.EmployerID 
        , NEW.EmployeeID 
        , NEW.BirthDate 
        , NEW.CardNumber 
        , 0 
        , api.api_cbool(NEW.EmployeeStatus) 
        , 0
        , new.row_id
        );

END;

