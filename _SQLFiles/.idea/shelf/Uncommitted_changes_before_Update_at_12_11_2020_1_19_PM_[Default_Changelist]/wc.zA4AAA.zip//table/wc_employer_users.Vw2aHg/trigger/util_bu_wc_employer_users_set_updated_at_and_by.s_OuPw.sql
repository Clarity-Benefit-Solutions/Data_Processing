create definer = admin@`%` trigger util_bu_wc_employer_users_set_updated_at_and_by
    before update
    on wc_employer_users
    for each row
BEGIN
    SET new.updated_at = CURRENT_TIMESTAMP;
    SET new.updated_by = current_user;
END;

