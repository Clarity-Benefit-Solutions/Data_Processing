create
    definer = rdsadmin@localhost procedure rds_skip_repl_error()
BEGIN
  DECLARE v_threads_running int;
  DECLARE v_sleep int;
  DECLARE v_called_by_user VARCHAR(50);
  DECLARE v_mysql_version VARCHAR(20);
  DECLARE sql_logging BOOLEAN;
  select @@sql_log_bin into sql_logging;
  Select user() into v_called_by_user;
  Select version() into v_mysql_version;
  SELECT COUNT(1) into v_threads_running FROM information_schema.processlist WHERE user = 'system user' AND command IN ('Slave_IO', 'Slave_SQL');
  if v_threads_running = 1 
  then
    STOP SLAVE;
    SET GLOBAL SQL_SLAVE_SKIP_COUNTER = 1;
    START SLAVE;
    Select 'Statement in error has been skipped' as Message;
    select sleep(2) into v_sleep;
    SELECT COUNT(1) into v_threads_running FROM information_schema.processlist WHERE user = 'system user' AND command IN ('Slave_IO', 'Slave_SQL');
    if v_threads_running = 2 then
      Select 'Slave is running normally' as Message;
          set @@sql_log_bin=off;
      INSERT into mysql.rds_history(called_by_user, action, mysql_version) values (v_called_by_user,'skip_repl_error:OK',v_mysql_version);
          commit;
      set @@sql_log_bin=sql_logging;
    else
      Select 'Slave has encountered a new error. Please use SHOW SLAVE STATUS to see the error.' as Message;
          set @@sql_log_bin=off;
      INSERT into mysql.rds_history(called_by_user, action, mysql_version) values (v_called_by_user,'skip_repl_error:ERR',v_mysql_version);
          commit;
      set @@sql_log_bin=sql_logging;
    end if;
  elseif v_threads_running = 2 
  then
     Select 'Slave is running normally.  No errors detected to skip.' as Message;
  elseif v_threads_running = 0 
  then
     Select 'Slave is down or disabled.' as Message;
  end if;
END;

