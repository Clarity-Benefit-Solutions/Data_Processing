CREATE
    DEFINER = admin@`%` FUNCTION wc_is_active_status( p_status varchar(200) ) RETURNS int(1)
begin
    if api.api_is_blank( p_status ) then
        return 0;
    end if;

    set p_status = upper( p_status );

    case p_status
        when p_status in (
                           'ACTIVE',
                           'NEW',
                           'TEMPORARILY INACTIVE',
                           'TI' )

            then
                return 1;
        when p_status in (
                           'PERMANENTLY INACTIVE',
                           'PI'
            )

            then
                return 0;
        else return 0;
    end case;

end;

