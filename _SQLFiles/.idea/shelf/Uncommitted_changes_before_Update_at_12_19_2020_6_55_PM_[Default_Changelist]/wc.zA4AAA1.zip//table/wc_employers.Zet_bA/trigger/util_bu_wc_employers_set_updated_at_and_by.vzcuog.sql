CREATE DEFINER = admin@`%` TRIGGER util_bu_wc_employers_set_updated_at_and_by
    BEFORE UPDATE
    ON wc_employers
    FOR EACH ROW
BEGIN
    SET new.updated_at = CURRENT_TIMESTAMP;
    SET new.updated_by = current_user;
END;

