CREATE DEFINER = admin@`%` VIEW vw_get_all_fields_for_form AS
SELECT f.id             AS form_id,
       f.name           AS form_name,
       fl.id            AS field_id,
       fl.field_key     AS field_key,
       fl.name          AS field_name,
       CASE
           WHEN fl.type = 'divider'
               THEN fl.name
           ELSE ''
       END              AS repeater_name,
       fl.description   AS field_description,
       fl.type          AS field_type,
       fl.default_value AS field_default_value,
       fl.options       AS fl_options,
       fl.field_order   AS field_order,
       fl.required      AS field_required,
       fl.field_options AS field_options
FROM ( portal.cl_frm_fields fl
         JOIN portal.cl_frm_forms f ON (f.id = fl.form_id))
WHERE fl.type <> 'hidden'
ORDER BY fl.form_id, fl.field_order;

