CREATE DEFINER = admin@`%` VIEW vw_get_all_current_and_original_form_values AS
SELECT t.item_id     AS item_id,
       t.page_name   AS page_name,
       CASE
           WHEN t.field_type = 'divider'
               THEN t.field_name
           ELSE ''
       END           AS repeater_name,
       t.field_name  AS field_name,
       CASE
           WHEN t.field_type <> 'divider'
               THEN CASE
                        WHEN t.meta_value = t.org_meta_value
                            THEN 0
                        ELSE 1
                    END
           ELSE 1
       END           AS value_has_changed,
       CASE
           WHEN t.field_type <> 'divider'
               THEN t.meta_value
           ELSE ''
       END           AS current_value,
       CASE
           WHEN t.field_type <> 'divider'
               THEN t.org_meta_value
           ELSE ''
       END           AS original_value,
       t.field_id    AS field_id,
       t.field_type  AS field_type,
       t.form_name   AS form_name,
       t.field_order AS field_order
FROM (SELECT m.item_id                          AS item_id,
             CASE
                 WHEN f.type LIKE 'html' AND f.description LIKE '%heading%'
                     THEN f.name
                 ELSE ''
             END                                AS page_name,
             f.name                             AS field_name,
             api.api_nz( m.meta_value, '' )     AS meta_value,
             api.api_nz( m.org_meta_value, '' ) AS org_meta_value,
             m.field_id                         AS field_id,
             f.type                             AS field_type,
             fr.name                            AS form_name,
             f.field_order                      AS field_order
      FROM ( (portal.cl_frm_item_metas m LEFT JOIN portal.cl_frm_fields f ON (m.field_id = f.id))
               LEFT JOIN portal.cl_frm_forms fr ON (f.form_id = fr.id))
      WHERE f.type <> 'hidden') t;

