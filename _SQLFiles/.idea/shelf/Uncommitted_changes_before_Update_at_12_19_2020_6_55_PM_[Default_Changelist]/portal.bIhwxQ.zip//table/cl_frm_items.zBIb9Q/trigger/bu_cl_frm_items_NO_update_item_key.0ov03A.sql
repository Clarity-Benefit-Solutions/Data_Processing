CREATE DEFINER = admin@`%` TRIGGER bu_cl_frm_items_NO_update_item_key
    BEFORE UPDATE
    ON cl_frm_items
    FOR EACH ROW
BEGIN
    

  
END;

