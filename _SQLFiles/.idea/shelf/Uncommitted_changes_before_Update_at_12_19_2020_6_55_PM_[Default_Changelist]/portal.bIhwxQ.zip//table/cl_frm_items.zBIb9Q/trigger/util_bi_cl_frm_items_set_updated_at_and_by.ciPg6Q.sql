CREATE DEFINER = admin@`%` TRIGGER util_bi_cl_frm_items_set_updated_at_and_by
    BEFORE INSERT
    ON cl_frm_items
    FOR EACH ROW
BEGIN
    SET new.created_at = NOW();
    SET new.created_by = current_user;
    SET new.updated_at = NOW();
    SET new.updated_by = current_user;
END;

