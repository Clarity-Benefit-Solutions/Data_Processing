CREATE DEFINER = admin@`%` TRIGGER bd_cl_frm_items_NO_deletes
    BEFORE DELETE
    ON cl_frm_items
    FOR EACH ROW
BEGIN
   
END;

