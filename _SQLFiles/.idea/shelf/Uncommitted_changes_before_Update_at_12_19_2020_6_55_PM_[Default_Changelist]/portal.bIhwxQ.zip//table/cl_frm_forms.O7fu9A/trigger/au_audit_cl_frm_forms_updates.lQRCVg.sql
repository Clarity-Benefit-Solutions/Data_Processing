CREATE DEFINER = admin@`%` TRIGGER au_audit_cl_frm_forms_updates
    AFTER UPDATE
    ON cl_frm_forms
    FOR EACH ROW
    INSERT INTO `portal`.`cl_frm_forms_audit`
                 (`auditAction`,`id`,`form_key`,`name`,`description`,`parent_form_id`,`logged_in`,`editable`,`is_template`,`default_template`,`status`,`options`,`created_at`,`created_by`,`updated_at`,`updated_by`)
                 VALUES
                 ('UPDATE',NEW.`id`,NEW.`form_key`,NEW.`name`,NEW.`description`,NEW.`parent_form_id`,NEW.`logged_in`,NEW.`editable`,NEW.`is_template`,NEW.`default_template`,NEW.`status`,NEW.`options`,NEW.`created_at`,NEW.`created_by`,NEW.`updated_at`,NEW.`updated_by`);

