CREATE DEFINER = admin@`%` TRIGGER util_bi_cl_frm_item_metas_set_created_at_and_by
    BEFORE INSERT
    ON cl_frm_item_metas
    FOR EACH ROW
BEGIN
    SET new.created_at = CURRENT_TIMESTAMP;
    SET new.created_by = current_user;
END;

