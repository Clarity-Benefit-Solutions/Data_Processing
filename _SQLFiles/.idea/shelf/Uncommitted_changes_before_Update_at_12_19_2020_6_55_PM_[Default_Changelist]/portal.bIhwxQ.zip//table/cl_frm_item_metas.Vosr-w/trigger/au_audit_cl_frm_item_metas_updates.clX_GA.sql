CREATE DEFINER = admin@`%` TRIGGER au_audit_cl_frm_item_metas_updates
    AFTER UPDATE
    ON cl_frm_item_metas
    FOR EACH ROW
    INSERT INTO `portal`.`cl_frm_item_metas_audit`
                 (`auditAction`, `id`, `meta_value`, `field_id`, `item_id`, `org_meta_value`,
                  `org_meta_values_updated_at`, `created_at`, `created_by`, `updated_at`, `updated_by`)
                 VALUES ('UPDATE', NEW.`id`, NEW.`meta_value`, NEW.`field_id`, NEW.`item_id`, NEW.`org_meta_value`,
                         NEW.`org_meta_values_updated_at`, NEW.`created_at`, NEW.`created_by`, NEW.`updated_at`,
                         NEW.`updated_by`);

