CREATE DEFINER = admin@`%` TRIGGER au_audit_cl_frm_item_metas_deletes
    AFTER DELETE
    ON cl_frm_item_metas
    FOR EACH ROW
    INSERT INTO `portal`.`cl_frm_item_metas_audit`
                 (`auditAction`, `id`, `meta_value`, `field_id`, `item_id`, `org_meta_value`,
                  `org_meta_values_updated_at`, `created_at`, `created_by`, `updated_at`, `updated_by`)
                 VALUES ('DELETE', OLD.`id`, OLD.`meta_value`, OLD.`field_id`, OLD.`item_id`, OLD.`org_meta_value`,
                         OLD.`org_meta_values_updated_at`, OLD.`created_at`, OLD.`created_by`, OLD.`updated_at`,
                         OLD.`updated_by`);

