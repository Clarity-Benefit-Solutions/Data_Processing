CREATE
    DEFINER = admin@`%` FUNCTION api_fix_email( value varchar(200) ) RETURNS varchar(200)
BEGIN
    if api.api_is_blank(value) then
        return null;
    end if;
    set value = lower(trim(value));
    return value;
END;

