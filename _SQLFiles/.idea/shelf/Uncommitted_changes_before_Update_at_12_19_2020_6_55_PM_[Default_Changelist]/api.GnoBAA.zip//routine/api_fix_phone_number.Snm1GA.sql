CREATE
    DEFINER = admin@`%` FUNCTION api_fix_phone_number( value varchar(200) ) RETURNS varchar(200)
BEGIN
    SET value = lower(trim(value));
    SET value = replace(value, '-', '');
    SET value = replace(value, '.', '');
    SET value = replace(value, '(', '');
    SET value = replace(value, ')', '');
    SET value = api_strip_non_digit(value);

    IF api.api_is_blank(value) THEN
        RETURN NULL;
    END IF;

    SET value = RIGHT(value, 10);

    #     IF substring(value, 1, 1) <> '+' THEN
#         SET value = concat('+', api_get_default_country_code(), value);
#     END IF;

    RETURN value;
END;

