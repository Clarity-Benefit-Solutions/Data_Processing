CREATE
    DEFINER = admin@`%` PROCEDURE db_show_message(
                                                   IN p_msg_source varchar(200)
                                                 , IN p_msg text )
BEGIN

    CALL api.db_log_message( p_msg_source, p_msg, 'INFO' );
END;

