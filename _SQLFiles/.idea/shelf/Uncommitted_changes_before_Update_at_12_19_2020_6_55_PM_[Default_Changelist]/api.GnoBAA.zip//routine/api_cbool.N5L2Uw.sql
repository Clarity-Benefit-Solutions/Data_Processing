CREATE
    DEFINER = admin@`%` FUNCTION api_cbool( value varchar(20) ) RETURNS int(1)
BEGIN
    SET value = lower( trim( value ) );

    IF ifnull( trim( value ) , '' ) = '' OR ifnull( trim( value ) , '' ) = '0' OR
       ifnull( trim( value ) , '' ) = 'false' THEN
        RETURN 0;
    ELSE
        RETURN 1;
    END IF;
END;

