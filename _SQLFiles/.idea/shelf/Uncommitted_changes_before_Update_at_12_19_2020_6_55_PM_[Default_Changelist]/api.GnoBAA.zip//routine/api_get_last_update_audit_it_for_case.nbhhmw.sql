CREATE
    DEFINER = root@`%` FUNCTION api_get_last_update_audit_it_for_case( p_case_id varchar(100) ) RETURNS int
BEGIN
    DECLARE v_audit_id int(11);

    SELECT max( auditId )
    INTO v_audit_id
    FROM api.api_cases_audit
    WHERE case_id = p_case_id
      -- AND auditAction = 'UPDATE'
      AND auditTimestamp < '2020-12-19 05:00:54';

    RETURN v_audit_id;
END;

