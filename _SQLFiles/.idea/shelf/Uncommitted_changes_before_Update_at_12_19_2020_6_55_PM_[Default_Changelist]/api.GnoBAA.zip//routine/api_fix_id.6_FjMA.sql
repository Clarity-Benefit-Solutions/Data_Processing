CREATE
    DEFINER = admin@`%` FUNCTION api_fix_id( value varchar(200) ) RETURNS varchar(200)
BEGIN
    return api_fix_ssn(value);
END;

