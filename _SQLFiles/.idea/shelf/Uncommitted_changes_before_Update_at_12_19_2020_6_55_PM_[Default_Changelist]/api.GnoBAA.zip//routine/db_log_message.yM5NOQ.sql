CREATE
    DEFINER = admin@`%` PROCEDURE db_log_message(
                                                  IN p_msg_source varchar(200)
                                                , IN p_msg text
                                                , IN p_log_level varchar(50) )
BEGIN



    INSERT
    INTO logs.db_message_log (
                        log_level
                      , log_source
                      , log_msg
    )
    VALUES (
               p_log_level
           ,   p_msg_source
           ,   p_msg
           );
END;

