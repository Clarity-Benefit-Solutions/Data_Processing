CREATE
    DEFINER = admin@`%` FUNCTION api_nz(
                                         value text
                                       , valueifnullorempty text ) RETURNS text
BEGIN
  IF ifnull(
       value
      ,'') = ''
  THEN
    RETURN ifnull(valueIfNullOrEmpty, '');
  ELSE
    RETURN value;
  END IF;
END;

