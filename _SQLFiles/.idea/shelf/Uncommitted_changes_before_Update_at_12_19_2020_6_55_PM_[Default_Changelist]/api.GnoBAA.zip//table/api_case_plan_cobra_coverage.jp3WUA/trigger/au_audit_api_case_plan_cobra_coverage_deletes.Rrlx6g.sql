CREATE DEFINER = admin@`%` TRIGGER au_audit_api_case_plan_cobra_coverage_deletes
    AFTER DELETE
    ON api_case_plan_cobra_coverage
    FOR EACH ROW
    INSERT INTO `api`.`api_case_plan_cobra_coverage_audit`
                 (`auditAction`, `case_plan_coverage_id`, `case_plan_id`, `status`, `version_no`, `ben_term_type`,
                  `plan_coverage_level`, `plan_coverage_level_is_new`, `plan_coverage_level_order`,
                  `pct_100_rate_for_coverage_level`, `new_pct_100_rate_for_coverage_level`, `created_at`, `created_by`,
                  `updated_at`, `updated_by`)
                 VALUES ('DELETE', OLD.`case_plan_coverage_id`, OLD.`case_plan_id`, OLD.`status`, OLD.`version_no`,
                         OLD.`ben_term_type`, OLD.`plan_coverage_level`, OLD.`plan_coverage_level_is_new`,
                         OLD.`plan_coverage_level_order`, OLD.`pct_100_rate_for_coverage_level`,
                         OLD.`new_pct_100_rate_for_coverage_level`, OLD.`created_at`, OLD.`created_by`,
                         OLD.`updated_at`, OLD.`updated_by`);

