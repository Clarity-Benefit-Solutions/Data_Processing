CREATE DEFINER = admin@`%` TRIGGER util_bu_api_cases_new_incr_version_no
    BEFORE UPDATE
    ON api_cases
    FOR EACH ROW
BEGIN

    IF api.api_nz( new.case_status, '' ) <> api.api_nz( old.case_status, '' ) THEN
        SET new.version_no = api.api_nz( new.version_no, 0 ) + 1;
    END IF;

    IF new.case_status IN ( 'New', 'Client Notified', 'In Progress', 'Contact Changed' ) THEN
        SET new.wizard_curr_step_no = 1;
    END IF;
    --
    IF new.case_status IS NOT NULL AND new.case_status <> old.case_status THEN
        IF new.case_status IN ('Complete') THEN
            SET new.status_last_completed_at = now( );
        ELSEIF new.case_status NOT IN ('Closed') THEN
            SET new.status_last_completed_at = NULL;
        END IF;
#
        IF new.case_status IN ('Cancelled') THEN
            SET new.status_last_cancelled_at = now( );
        ELSEIF new.case_status NOT LIKE '%Cancelled%' THEN
            SET new.status_last_cancelled_at = NULL;
        END IF;
    END IF;

END;

