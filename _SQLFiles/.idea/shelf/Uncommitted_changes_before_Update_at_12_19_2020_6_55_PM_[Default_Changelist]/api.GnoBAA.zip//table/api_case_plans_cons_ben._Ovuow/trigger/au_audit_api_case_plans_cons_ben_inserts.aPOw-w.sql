CREATE DEFINER = admin@`%` TRIGGER au_audit_api_case_plans_cons_ben_inserts
    AFTER INSERT
    ON api_case_plans_cons_ben
    FOR EACH ROW
    INSERT INTO `api`.`api_case_plans_cons_ben_audit`
                 (`auditAction`, `case_plan_id`, `case_id`, `status`, `version_no`, `plan_type`, `plan_sub_type`,
                  `plan_name`, `plan_order`, `plan_year_start_date`, `plan_year_end_date`, `plan_year_renewal_date`,
                  `min_annual_election_amount`, `max_annual_election_amount`, `employer_contribution_amount`,
                  `employee_contribution_amounts`, `employee_child_contribution_amounts`,
                  `employee_spouse_contribution_amounts`, `family_contribution_amounts`, `runout_period`,
                  `runout_period_terminated_employees`, `add_limited_purpose`, `recommended_feature`,
                  `remove_grace_period`, `add_grace_period`, `grace_period_end_date`, `add_clarity_convenience_card`,
                  `contribution_amounts`, `who_will_pay_first`, `participant_responsible_pay_eligible_expenses`,
                  `funding_frequency`, `eligible_expense_categories`,
                  `will_the_HRA_reimburse_same_expenses_as_current_plan_year`,
                  `HRA_reimburse_same_expenses_as_current_plan_year_if_no`,
                  `HRA_participant_responsible_pay_eligible_expenses_if_yes`, `max_annual_election_amount_is_changed`,
                  `carry_over_features`, `additional_plan_details`, `runout_period_terminated_employees_end_date`,
                  `plan_should_auto_renew`, `created_at`, `created_by`, `updated_at`, `updated_by`)
                 VALUES ('INSERT', NEW.`case_plan_id`, NEW.`case_id`, NEW.`status`, NEW.`version_no`, NEW.`plan_type`,
                         NEW.`plan_sub_type`, NEW.`plan_name`, NEW.`plan_order`, NEW.`plan_year_start_date`,
                         NEW.`plan_year_end_date`, NEW.`plan_year_renewal_date`, NEW.`min_annual_election_amount`,
                         NEW.`max_annual_election_amount`, NEW.`employer_contribution_amount`,
                         NEW.`employee_contribution_amounts`, NEW.`employee_child_contribution_amounts`,
                         NEW.`employee_spouse_contribution_amounts`, NEW.`family_contribution_amounts`,
                         NEW.`runout_period`, NEW.`runout_period_terminated_employees`, NEW.`add_limited_purpose`,
                         NEW.`recommended_feature`, NEW.`remove_grace_period`, NEW.`add_grace_period`,
                         NEW.`grace_period_end_date`, NEW.`add_clarity_convenience_card`, NEW.`contribution_amounts`,
                         NEW.`who_will_pay_first`, NEW.`participant_responsible_pay_eligible_expenses`,
                         NEW.`funding_frequency`, NEW.`eligible_expense_categories`,
                         NEW.`will_the_HRA_reimburse_same_expenses_as_current_plan_year`,
                         NEW.`HRA_reimburse_same_expenses_as_current_plan_year_if_no`,
                         NEW.`HRA_participant_responsible_pay_eligible_expenses_if_yes`,
                         NEW.`max_annual_election_amount_is_changed`, NEW.`carry_over_features`,
                         NEW.`additional_plan_details`, NEW.`runout_period_terminated_employees_end_date`,
                         NEW.`plan_should_auto_renew`, NEW.`created_at`, NEW.`created_by`, NEW.`updated_at`,
                         NEW.`updated_by`);

