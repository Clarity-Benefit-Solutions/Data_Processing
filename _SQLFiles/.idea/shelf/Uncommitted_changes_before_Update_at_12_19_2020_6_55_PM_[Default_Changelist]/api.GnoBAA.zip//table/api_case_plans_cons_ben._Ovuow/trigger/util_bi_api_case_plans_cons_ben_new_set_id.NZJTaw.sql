CREATE DEFINER = admin@`%` TRIGGER util_bi_api_case_plans_cons_ben_new_set_id
    BEFORE INSERT
    ON api_case_plans_cons_ben
    FOR EACH ROW
BEGIN
    IF api.api_is_blank(new.case_plan_id) THEN
        SET new.case_plan_id = api.api_uuid();
    END IF;
END;

