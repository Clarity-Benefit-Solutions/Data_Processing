CREATE DEFINER = admin@`%` TRIGGER bi_platform_users_new_set_invite_token
    BEFORE INSERT
    ON platform_users
    FOR EACH ROW
BEGIN
    IF api.api_is_blank( new.invite_token ) THEN
        SET new.invite_token = api.api_uuid( );
    END IF;

    SET new.user_name = lower( new.email );
END;

