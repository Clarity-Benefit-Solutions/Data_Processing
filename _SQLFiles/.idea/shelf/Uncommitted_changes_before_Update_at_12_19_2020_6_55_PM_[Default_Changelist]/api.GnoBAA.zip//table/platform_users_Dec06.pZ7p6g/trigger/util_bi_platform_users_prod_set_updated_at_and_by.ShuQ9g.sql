CREATE DEFINER = root@`%` TRIGGER util_bi_platform_users_prod_set_updated_at_and_by
    BEFORE INSERT
    ON platform_users_Dec06
    FOR EACH ROW
BEGIN
    SET new.created_at = CURRENT_TIMESTAMP;
    SET new.created_by = current_user;
    SET new.updated_at = CURRENT_TIMESTAMP;
    SET new.updated_by = current_user;
END;

