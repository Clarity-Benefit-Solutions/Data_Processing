CREATE DEFINER = admin@`%` TRIGGER au_audit_api_case_plans_cobra_inserts
    AFTER INSERT
    ON api_case_plans_cobra
    FOR EACH ROW
    INSERT INTO `api`.`api_case_plans_cobra_audit`
                 (`auditAction`, `case_plan_id`, `case_id`, `status`, `version_no`, `plan_type`, `plan_name`,
                  `plan_sub_type`, `plan_order`, `ben_term_type`, `new_ben_term_type`, `plan_year_start_date`,
                  `plan_year_end_date`, `plan_year_renewal_date`, `plan_should_terminate`, `plan_year_termination_date`,
                  `should_default_participants_to_different_plan`, `default_participants_to_different_plan_name`,
                  `plan_is_new`, `carrier_name`, `policygroup_number`, `is_fully_insured`, `is_self_funded`,
                  `insurance_type`, `plan_is_for_specific_division`, `division_name`, `coverage_termination`,
                  `plan_rate_type`, `is_currently_offering_subsidies`, `is_cap_dependents_age20`,
                  `pct_50_charge_disability_extension`, `new_pct_100_rate_for_coverage_level`, `created_at`,
                  `created_by`, `updated_at`, `updated_by`)
                 VALUES ('INSERT', NEW.`case_plan_id`, NEW.`case_id`, NEW.`status`, NEW.`version_no`, NEW.`plan_type`,
                         NEW.`plan_name`, NEW.`plan_sub_type`, NEW.`plan_order`, NEW.`ben_term_type`,
                         NEW.`new_ben_term_type`, NEW.`plan_year_start_date`, NEW.`plan_year_end_date`,
                         NEW.`plan_year_renewal_date`, NEW.`plan_should_terminate`, NEW.`plan_year_termination_date`,
                         NEW.`should_default_participants_to_different_plan`,
                         NEW.`default_participants_to_different_plan_name`, NEW.`plan_is_new`, NEW.`carrier_name`,
                         NEW.`policygroup_number`, NEW.`is_fully_insured`, NEW.`is_self_funded`, NEW.`insurance_type`,
                         NEW.`plan_is_for_specific_division`, NEW.`division_name`, NEW.`coverage_termination`,
                         NEW.`plan_rate_type`, NEW.`is_currently_offering_subsidies`, NEW.`is_cap_dependents_age20`,
                         NEW.`pct_50_charge_disability_extension`, NEW.`new_pct_100_rate_for_coverage_level`,
                         NEW.`created_at`, NEW.`created_by`, NEW.`updated_at`, NEW.`updated_by`);

