CREATE DEFINER = admin@`%` VIEW vw_temp_case_plan_cobra__coverage_data AS
SELECT c.case_id                             AS case_id,
       c.employer_name                       AS employer_name,
       p.case_plan_id                        AS case_plan_id,
       p.status                              AS status,
       p.plan_type                           AS plan_type,
       p.plan_name                           AS plan_name,
       p.plan_sub_type                       AS plan_sub_type,
       p.plan_order                          AS plan_order,
       p.ben_term_type                       AS ben_term_type,
       v.case_plan_coverage_id               AS case_plan_coverage_id,
       v.plan_coverage_level                 AS plan_coverage_level,
       v.plan_coverage_level_is_new          AS plan_coverage_level_is_new,
       v.plan_coverage_level_order           AS plan_coverage_level_order,
       v.pct_100_rate_for_coverage_level     AS pct_100_rate_for_coverage_level,
       v.new_pct_100_rate_for_coverage_level AS new_pct_100_rate_for_coverage_level
FROM ( (api.api_cases c JOIN api.api_case_plans_cobra p ON (c.case_id = p.case_id))
         JOIN api.api_case_plan_cobra_coverage v ON (p.case_plan_id = v.case_plan_id))
ORDER BY c.employer_name, c.case_id, p.plan_type, p.plan_sub_type, p.plan_name, v.plan_coverage_level;

