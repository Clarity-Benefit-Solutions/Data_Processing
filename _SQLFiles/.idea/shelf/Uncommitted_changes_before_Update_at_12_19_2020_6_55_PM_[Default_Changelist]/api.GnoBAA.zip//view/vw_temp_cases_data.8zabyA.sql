CREATE DEFINER = admin@`%` VIEW vw_temp_cases_data AS
SELECT api.api_cases.case_id                 AS case_id,
       api.api_cases.case_status             AS case_status,
       api.api_cases.case_type               AS case_type,
       api.api_cases.case_sub_type           AS case_sub_type,
       api.api_cases.employer_id             AS employer_id,
       api.api_cases.employer_name           AS employer_name,
       api.api_cases.employer_division_name  AS employer_division_name,
       api.api_cases.sf_case_id              AS sf_case_id,
       api.api_cases.sf_account_no           AS sf_account_no,
       api.api_cases.legal_business_name     AS legal_business_name,
       api.api_cases.dba                     AS dba,
       api.api_cases.street_physical_address AS street_physical_address,
       api.api_cases.street_line2            AS street_line2,
       api.api_cases.city                    AS city,
       api.api_cases.state                   AS state,
       api.api_cases.zip                     AS zip,
       api.api_cases.phone                   AS phone,
       api.api_cases.fax                     AS fax,
       api.api_cases.web_address             AS web_address,
       api.api_cases.incorporation_date      AS incorporation_date,
       api.api_cases.laws_of_state           AS laws_of_state
FROM api.api_cases
ORDER BY api.api_cases.employer_name, api.api_cases.case_id;

