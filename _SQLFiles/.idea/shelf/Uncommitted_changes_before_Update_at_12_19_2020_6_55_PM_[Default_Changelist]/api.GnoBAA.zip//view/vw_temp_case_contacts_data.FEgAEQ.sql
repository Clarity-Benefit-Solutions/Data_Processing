CREATE DEFINER = admin@`%` VIEW vw_temp_case_contacts_data AS
SELECT c.case_id                      AS case_id,
       c.employer_name                AS employer_name,
       p.contact_type                 AS contact_type,
       p.organization_name            AS organization_name,
       p.organization_state           AS organization_state,
       p.organization_zip             AS organization_zip,
       p.contact_sub_type             AS contact_sub_type,
       p.contact_title                AS contact_title,
       p.contact_first_name           AS contact_first_name,
       p.contact_last_name            AS contact_last_name,
       p.contact_email                AS contact_email,
       p.contact_phone                AS contact_phone,
       p.contact_is_cons_ben_contact  AS contact_is_cons_ben_contact,
       p.contact_is_cobra_contact     AS contact_is_cobra_contact,
       p.contact_is_ben_admin_contact AS contact_is_ben_admin_contact
FROM ( api.api_cases c
         JOIN api.api_case_contacts p ON (c.case_id = p.case_id))
ORDER BY c.employer_name, c.case_id, p.contact_email;

