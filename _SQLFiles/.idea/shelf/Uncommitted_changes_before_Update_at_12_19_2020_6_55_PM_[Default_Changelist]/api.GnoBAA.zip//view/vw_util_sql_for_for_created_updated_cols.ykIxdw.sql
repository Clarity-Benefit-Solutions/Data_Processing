CREATE DEFINER = admin@`%` VIEW vw_util_sql_for_for_created_updated_cols AS
SELECT c.TABLE_SCHEMA                                                                                       AS table_schema,
       c.TABLE_NAME                                                                                         AS table_name,
       util_get_sql_for_created_updated_cols( concat( c.TABLE_SCHEMA, '.', c.TABLE_NAME ),
                                              c.TABLE_SCHEMA )                                              AS util_get_sql_for_created_updated_cols
FROM information_schema.tables c
WHERE c.TABLE_TYPE = 'BASE TABLE'
  AND c.TABLE_SCHEMA NOT IN ( 'performance_schema', 'information_schema', 'mysql' );

