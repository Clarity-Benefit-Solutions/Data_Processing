CREATE
    DEFINER = admin@`%` PROCEDURE upsert_en_employees(
                                                       IN p_companyidentifier varchar(200)
                                                     , IN p_firstname varchar(200)
                                                     , IN p_lastname varchar(200)
                                                     , IN p_employeeid varchar(200)
                                                     , IN p_ssn varchar(200)
                                                     , IN p_employeestatus varchar(200)
                                                     , IN p_address1 varchar(200)
                                                     , IN p_address2 varchar(200)
                                                     , IN p_city varchar(200)
                                                     , IN p_state varchar(200)
                                                     , IN p_zip varchar(200)
                                                     , IN p_phone varchar(200)
                                                     , IN p_email varchar(200)
                                                     , IN p_dob varchar(200)
                                                     , IN p_enparticipant varchar(200)
                                                     , IN p_terminationdate varchar(200) )
BEGIN

    CALL api.db_show_message( 'upsert_en_employees',
                              concat( ' Processing Employ ', p_employeeid, ', ', p_firstname ) );


    SET p_state = api.api_cbool( p_state );

    INSERT
    INTO
        en.en_employees(
                         companyidentifier
                       , firstname
                       , lastname
                       , employeeid
                       , ssn
                       , employeestatus
                       , address1
                       , address2
                       , city
                       , state
                       , zip
                       , phone
                       , email
                       , dob
                       , enparticipant
                       , terminationdate
    )
    VALUES
    (
        p_companyidentifier
    ,   p_firstname
    ,   p_lastname
    ,   p_employeeid
    ,   p_ssn
    ,   p_employeestatus
    ,   p_address1
    ,   p_address2
    ,   p_city
    ,   p_state
    ,   p_zip
    ,   p_phone
    ,   p_email
    ,   p_dob
    ,   p_enparticipant
    ,   p_terminationdate
    )
    ON DUPLICATE KEY UPDATE
                         companyidentifier = p_companyidentifier
                       , firstname         = p_firstname
                       , lastname          = p_lastname
                       , employeeid        = p_employeeid
                       , ssn               = p_ssn
                       , employeestatus    = p_employeestatus
                       , address1          = p_address1
                       , address2          = p_address2
                       , city              = p_city
                       , state             = p_state
                       , zip               = p_zip
                       , phone             = p_phone
                       , email             = p_email
                       , dob               = p_dob
                       , enparticipant     = p_enparticipant
                       , terminationdate   = p_terminationdate;

END;

