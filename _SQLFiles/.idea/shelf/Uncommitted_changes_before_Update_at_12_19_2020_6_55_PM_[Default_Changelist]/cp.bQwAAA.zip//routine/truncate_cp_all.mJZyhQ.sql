CREATE
    DEFINER = admin@`%` PROCEDURE truncate_cp_all( IN dummy int(1) )
BEGIN

    CALL api.db_show_message( 'truncate_cp_all', 'STARTING' );

    TRUNCATE TABLE cp.cp_all_sso_users;


    CALL api.db_show_message( 'truncate_cp_all', 'FINISHED' );

    SELECT 'truncate_cp_all: SUCCESS';

END;

