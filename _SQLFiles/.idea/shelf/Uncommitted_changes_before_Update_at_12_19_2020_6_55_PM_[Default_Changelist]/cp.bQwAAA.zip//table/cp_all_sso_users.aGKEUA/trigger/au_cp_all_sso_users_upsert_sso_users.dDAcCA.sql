CREATE DEFINER = admin@`%` TRIGGER au_cp_all_sso_users_upsert_sso_users
    AFTER UPDATE
    ON cp_all_sso_users
    FOR EACH ROW
BEGIN
    DECLARE p_cp_tpa_user_is_active varchar(6) DEFAULT NULL;
    DECLARE p_cp_member_user_is_active varchar(6) DEFAULT NULL;

    IF (!api.api_is_blank(new.userid)) THEN
        SET p_cp_tpa_user_is_active = api.api_cbool(new.active);
    END IF;

    IF (!api.api_is_blank(new.ssoidentifier)) THEN
        SET p_cp_member_user_is_active = api.api_cbool(new.active);
    END IF;


    
    CALL api.upsert_cp_platform_user(lower(new.email),
                                     lower(new.email),
                                     new.firstname,
                                     new.lastname,
                                     NULL,
                                     new.title,
                                     new.phone,
                                     new.ssn,
                                     new.employeeid,
                                     new.clientid,
                                     new.brokerid,
                                     new.clientcontactid,
                                     new.ssoidentifier,
                                     api.cp_get_default_customer_id(),
                                     new.entitytype,
                                     new.userid,
                                     new.memberid,
                                     new.allowsso,
                                     NULL,
                                     p_cp_tpa_user_is_active,
                                     p_cp_member_user_is_active,
                                     new.row_id);

END;

