create 

    function get_total_processed_this_period(
    @header_id int ) returns money as
begin
    declare @amount money;
    --      total both [COMMISSION_PAID] + [OPEN_BALANCE] as that would be waht we sent out for the poeriod in question
    select
            @amount = sum( dbo.get_invoice_sent_total_processed_this_period( INVOICE_NUM , month , year ) )
    from
        [dbo].[STATEMENT_DETAILS]
    where
        HEADER_ID = @header_id;
    
    return isnull( @amount , 0 );
end
go

