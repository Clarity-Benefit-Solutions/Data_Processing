CREATE VIEW dbo.[mbi_no_errors]
    AS
        SELECT distinct
            m.mbi_file_name --, m.data_row AS mbi_line
        FROM
            dbo.mbi_file_table AS m
                left join (
                              select distinct
                                  mbi_file_name
                              from
                                  dbo.[res_file_table]
                          ) as r
                          on m.mbi_file_name = r.mbi_file_name
        WHERE
            --              m.row_type IN ('IH', 'IB', 'IC', 'IZ', 'II', 'ID') and
            r.mbi_file_name is null
go

