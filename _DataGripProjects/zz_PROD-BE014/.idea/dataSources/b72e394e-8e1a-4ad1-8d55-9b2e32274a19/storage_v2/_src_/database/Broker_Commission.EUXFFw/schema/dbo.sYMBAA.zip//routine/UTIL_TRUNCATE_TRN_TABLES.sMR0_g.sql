create 
 procedure UTIL_TRUNCATE_TRN_TABLES @param varchar(10) as
begin
    
    if @param != 'FORCE'
        begin
            select
                'Did not nothing as FORCE not passed'
            return;
        end;
    
    delete
    from
        dbo.Import_Archive;
    delete
    from
        dbo.Import_OCT;
    
    delete
    from
        dbo.STATEMENT_DETAILS_ARCHIVE;
    delete
    from
        dbo.STATEMENT_DETAILS;
    delete
    from
        dbo.STATEMENT_HEADER_ARCHIVE;
    
    delete
    from
        dbo.STATEMENT_HEADER;
    delete
    from
        dbo.SENT_INVOICE;
end;
go

