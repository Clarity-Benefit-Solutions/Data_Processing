CREATE DEFINER = admin@`%` TRIGGER util_bu_api_case_plans_cons_ben_new_incr_version_no
    BEFORE UPDATE
    ON api_case_plans_cons_ben
    FOR EACH ROW
BEGIN
    
    IF api.api_nz(new.status, '') <> api.api_nz(old.status, '') THEN
        SET new.version_no = api.api_nz(new.version_no, 0) + 1;
    END IF;
END;

