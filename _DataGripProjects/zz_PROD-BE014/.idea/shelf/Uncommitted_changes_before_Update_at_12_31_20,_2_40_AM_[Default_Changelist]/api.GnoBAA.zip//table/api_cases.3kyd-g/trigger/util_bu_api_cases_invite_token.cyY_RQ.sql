CREATE DEFINER = admin@`%` TRIGGER util_bu_api_cases_invite_token
    BEFORE UPDATE
    ON api_cases
    FOR EACH ROW
BEGIN
    DECLARE v_invite_token varchar(100);
    DECLARE v_portalPath varchar(1000);

    
    SET new.form_invite_token = old.form_invite_token;

    
    SET v_invite_token = new.form_invite_token;

    SET v_portalPath = 'https://portal.claritybenefitsolutions.com';

    IF new.case_type = 'Renewal' THEN
        IF new.case_sub_type = 'CONSUMER_BENEFIT' THEN
            SET v_portalPath = concat(v_portalPath, '/renewals/consumer-benefits/step-1?token=');
        ELSEIF new.case_sub_type = 'COBRA' THEN
            SET v_portalPath = concat(v_portalPath, '/renewals/cobra-benefits/step-1?token=');
        ELSE
            SET v_portalPath = concat(v_portalPath, '/case/?token=');
        END IF;
    ELSE
        SET v_portalPath = concat(v_portalPath, '/case/?token=');
    END IF;


    
    SET new.portal_case_edit_url = concat(v_portalPath, v_invite_token);
    

END;

