CREATE DEFINER = admin@`%` TRIGGER bi_platform_users_set_invite_token
    BEFORE INSERT
    ON platform_users_Dec06
    FOR EACH ROW
BEGIN
    if api.api_is_blank(new.invite_token) then
        SET new.invite_token = api.api_uuid();
    end if;

    set new.user_name = lower(new.email);
END;

