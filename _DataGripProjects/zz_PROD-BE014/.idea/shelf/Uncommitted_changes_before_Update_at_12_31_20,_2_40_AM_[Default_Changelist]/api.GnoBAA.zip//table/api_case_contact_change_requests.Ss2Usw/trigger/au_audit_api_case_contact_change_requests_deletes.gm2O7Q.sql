CREATE DEFINER = admin@`%` TRIGGER au_audit_api_case_contact_change_requests_deletes
    AFTER DELETE
    ON api_case_contact_change_requests
    FOR EACH ROW
    INSERT INTO `api`.`api_case_contact_change_requests_audit`
                 (`auditAction`, `case_contact_change_id`, `case_contact_id`, `case_id`, `sf_contact_id`, `status`,
                  `sf_case_owner_user_id`, `sf_task_id`, `version_no`, `contact_type`, `organization_name`,
                  `organization_state`, `organization_zip`, `contact_sub_type`, `contact_title`, `contact_first_name`,
                  `contact_last_name`, `contact_email`, `contact_phone`, `contact_is_cons_ben_contact`,
                  `contact_is_cobra_contact`, `contact_is_ben_admin_contact`, `created_at`, `created_by`, `updated_at`,
                  `updated_by`)
                 VALUES ('DELETE', OLD.`case_contact_change_id`, OLD.`case_contact_id`, OLD.`case_id`,
                         OLD.`sf_contact_id`, OLD.`status`, OLD.`sf_case_owner_user_id`, OLD.`sf_task_id`,
                         OLD.`version_no`, OLD.`contact_type`, OLD.`organization_name`, OLD.`organization_state`,
                         OLD.`organization_zip`, OLD.`contact_sub_type`, OLD.`contact_title`, OLD.`contact_first_name`,
                         OLD.`contact_last_name`, OLD.`contact_email`, OLD.`contact_phone`,
                         OLD.`contact_is_cons_ben_contact`, OLD.`contact_is_cobra_contact`,
                         OLD.`contact_is_ben_admin_contact`, OLD.`created_at`, OLD.`created_by`, OLD.`updated_at`,
                         OLD.`updated_by`);

