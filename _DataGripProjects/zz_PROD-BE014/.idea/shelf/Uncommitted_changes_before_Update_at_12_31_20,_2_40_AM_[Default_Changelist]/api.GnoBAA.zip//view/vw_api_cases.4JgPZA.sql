CREATE DEFINER = admin@`%` VIEW vw_api_cases AS
    SELECT
        `api`.`api_cases`.`case_id`                                               AS `case_id`
      , `api`.`api_cases`.`case_status`                                           AS `case_status`
      , `api`.`api_cases`.`version_no`                                            AS `version_no`
      , `api`.`api_cases`.`case_type`                                             AS `case_type`
      , `api`.`api_cases`.`case_sub_type`                                         AS `case_sub_type`
      , `api`.`api_cases`.`employer_id`                                           AS `employer_id`
      , `api`.`api_cases`.`employer_name`                                         AS `employer_name`
      , `api`.`api_cases`.`employer_division_name`                                AS `employer_division_name`
      , `api`.`api_cases`.`sf_case_id`                                            AS `sf_case_id`
      , `api`.`api_cases`.`sf_account_no`                                         AS `sf_account_no`
      , `api`.`api_cases`.`form_invite_token`                                     AS `form_invite_token`
      , `api`.`api_cases`.`form_curr_page_no`                                     AS `form_curr_page_no`
      , `api`.`api_cases`.`wizard_curr_step_no`                                   AS `wizard_curr_step_no`
      , `api`.`api_cases`.`form_type`                                             AS `form_type`
      , `api`.`api_cases`.`form_entry_id`                                         AS `form_entry_id`
      , `api`.`api_cases`.`legal_business_name`                                   AS `legal_business_name`
      , `api`.`api_cases`.`dba`                                                   AS `dba`
      , `api`.`api_cases`.`street_physical_address`                               AS `street_physical_address`
      , `api`.`api_cases`.`street_line2`                                          AS `street_line2`
      , `api`.`api_cases`.`city`                                                  AS `city`
      , `api`.`api_cases`.`state`                                                 AS `state`
      , `api`.`api_cases`.`zip`                                                   AS `zip`
      , `api`.`api_cases`.`phone`                                                 AS `phone`
      , `api`.`api_cases`.`fax`                                                   AS `fax`
      , `api`.`api_cases`.`web_address`                                           AS `web_address`
      , `api`.`api_cases`.`incorporation_date`                                    AS `incorporation_date`
      , `api`.`api_cases`.`laws_of_state`                                         AS `laws_of_state`
      , `api`.`api_cases`.`healthcare_carrier`                                    AS `healthcare_carrier`
      , `api`.`api_cases`.`healthcare_plan_type`                                  AS `healthcare_plan_type`
      , `api`.`api_cases`.`dental_care_carrier`                                   AS `dental_care_carrier`
      , `api`.`api_cases`.`dental_care_plan_type`                                 AS `dental_care_plan_type`
      , `api`.`api_cases`.`vision_care_carrier`                                   AS `vision_care_carrier`
      , `api`.`api_cases`.`vision_care_plan_type`                                 AS `vision_care_plan_type`
      , `api`.`api_cases`.`cons_ben_plan_open_enrollment_start_date`              AS `cons_ben_plan_open_enrollment_start_date`
      , `api`.`api_cases`.`cons_ben_plan_open_enrollment_end_date`                AS `cons_ben_plan_open_enrollment_end_date`
      , `api`.`api_cases`.`cons_ben_plan_enrollment_method_employees`             AS `cons_ben_plan_enrollment_method_employees`
      , `api`.`api_cases`.`cons_ben_plan_enrollment_data_transmission_to_clarity` AS `cons_ben_plan_enrollment_data_transmission_to_clarity`
      , `api`.`api_cases`.`cons_ben_plan_estimated_date_enrollment_data_delivery` AS `cons_ben_plan_estimated_date_enrollment_data_delivery`
      , `api`.`api_cases`.`cons_ben_plan_type`                                    AS `cons_ben_plan_type`
      , `api`.`api_cases`.`cons_ben_plan_employee_class`                          AS `cons_ben_plan_employee_class`
      , `api`.`api_cases`.`cons_ben_plan_first_payroll_date`                      AS `cons_ben_plan_first_payroll_date`
      , `api`.`api_cases`.`cons_ben_plan_waiting_period`                          AS `cons_ben_plan_waiting_period`
      , `api`.`api_cases`.`cons_ben_plan_parking_transit_waiting_period`          AS `cons_ben_plan_parking_transit_waiting_period`
      , `api`.`api_cases`.`cons_ben_plan_qualified_dependents`                    AS `cons_ben_plan_qualified_dependents`
      , `api`.`api_cases`.`cobra_plan_open_enrollment_start_date`                 AS `cobra_plan_open_enrollment_start_date`
      , `api`.`api_cases`.`cobra_plan_open_enrollment_end_date`                   AS `cobra_plan_open_enrollment_end_date`
      , `api`.`api_cases`.`cobra_plan_enrollment_method_employees`                AS `cobra_plan_enrollment_method_employees`
      , `api`.`api_cases`.`cobra_plan_enrollment_data_transmission_to_clarity`    AS `cobra_plan_enrollment_data_transmission_to_clarity`
      , `api`.`api_cases`.`cobra_plan_estimated_date_enrollment_data_delivery`    AS `cobra_plan_estimated_date_enrollment_data_delivery`
      , `api`.`api_cases`.`cobra_plan_type`                                       AS `cobra_plan_type`
      , `api`.`api_cases`.`cobra_plan_employee_class`                             AS `cobra_plan_employee_class`
      , `api`.`api_cases`.`cobra_plan_first_payroll_date`                         AS `cobra_plan_first_payroll_date`
      , `api`.`api_cases`.`cobra_plan_waiting_period`                             AS `cobra_plan_waiting_period`
      , `api`.`api_cases`.`cobra_plan_parking_transit_waiting_period`             AS `cobra_plan_parking_transit_waiting_period`
      , `api`.`api_cases`.`cobra_plan_qualified_dependents`                       AS `cobra_plan_qualified_dependents`
      , `api`.`api_cases`.`is_ready_for_processing`                               AS `is_ready_for_processing`
      , `api`.`api_cases`.`cons_ben_has_rol_plan`                                 AS `cons_ben_has_rol_plan`
      , `api`.`api_cases`.`created_at`                                            AS `created_at`
      , `api`.`api_cases`.`created_by`                                            AS `created_by`
      , `api`.`api_cases`.`updated_at`                                            AS `updated_at`
      , `api`.`api_cases`.`updated_by`                                            AS `updated_by`
    FROM
        `api`.`api_cases`;

