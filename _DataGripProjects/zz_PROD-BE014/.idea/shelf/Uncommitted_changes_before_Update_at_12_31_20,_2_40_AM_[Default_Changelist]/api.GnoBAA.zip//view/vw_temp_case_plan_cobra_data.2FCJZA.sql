CREATE DEFINER = admin@`%` VIEW vw_temp_case_plan_cobra_data AS
    SELECT
        `c`.`case_id`                                       AS `case_id`
      , `c`.`employer_name`                                 AS `employer_name`
      , `p`.`case_plan_id`                                  AS `case_plan_id`
      , `p`.`status`                                        AS `status`
      , `p`.`plan_type`                                     AS `plan_type`
      , `p`.`plan_name`                                     AS `plan_name`
      , `p`.`plan_sub_type`                                 AS `plan_sub_type`
      , `p`.`plan_order`                                    AS `plan_order`
      , `p`.`ben_term_type`                                 AS `ben_term_type`
      , `p`.`new_ben_term_type`                             AS `new_ben_term_type`
      , `p`.`plan_year_start_date`                          AS `plan_year_start_date`
      , `p`.`plan_year_end_date`                            AS `plan_year_end_date`
      , `p`.`plan_year_renewal_date`                        AS `plan_year_renewal_date`
      , `p`.`plan_should_terminate`                         AS `plan_should_terminate`
      , `p`.`plan_year_termination_date`                    AS `plan_year_termination_date`
      , `p`.`should_default_participants_to_different_plan` AS `should_default_participants_to_different_plan`
      , `p`.`default_participants_to_different_plan_name`   AS `default_participants_to_different_plan_name`
      , `p`.`plan_is_new`                                   AS `plan_is_new`
      , `p`.`carrier_name`                                  AS `carrier_name`
      , `p`.`policygroup_number`                            AS `policygroup_number`
      , `p`.`is_fully_insured`                              AS `is_fully_insured`
      , `p`.`is_self_funded`                                AS `is_self_funded`
      , `p`.`insurance_type`                                AS `insurance_type`
      , `p`.`plan_is_for_specific_division`                 AS `plan_is_for_specific_division`
      , `p`.`division_name`                                 AS `division_name`
      , `p`.`coverage_termination`                          AS `coverage_termination`
      , `p`.`plan_rate_type`                                AS `plan_rate_type`
      , `p`.`is_cap_dependents_age20`                       AS `is_cap_dependents_age20`
      , `p`.`pct_50_charge_disability_extension`            AS `pct_50_charge_disability_extension`
      , `p`.`new_pct_100_rate_for_coverage_level`           AS `new_pct_100_rate_for_coverage_level`
    FROM
        ( `api`.`api_cases` `c`
            JOIN `api`.`api_case_plans_cobra` `p`
                 ON (`c`.`case_id` = `p`.`case_id`))
    ORDER BY
        `c`.`employer_name`, `c`.`case_id`, `p`.`plan_type`, `p`.`plan_sub_type`;

