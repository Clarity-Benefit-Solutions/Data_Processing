CREATE DEFINER = admin@`%` VIEW vw_sso_platform_en AS
    SELECT
        `t`.`email`             AS `email`
      , CASE
            WHEN `t`.`row_id` = `api`.`sso_get_record_for_en`( `t`.`email` ) THEN 1
            ELSE 0 END          AS `is_sso_record`
      , `t`.`is_active`         AS `is_active`
      , `t`.`user_type`         AS `user_type`
      , `t`.`row_id`            AS `row_id`
      , `t`.`companyidentifier` AS `companyidentifier`
      , `t`.`firstname`         AS `firstname`
      , `t`.`lastname`          AS `lastname`
      , `t`.`ssn`               AS `ssn`
      , `t`.`employeeid`        AS `employeeid`
      , `t`.`employeestatus`    AS `employeestatus`
      , `t`.`address1`          AS `address1`
      , `t`.`address2`          AS `address2`
      , `t`.`city`              AS `city`
      , `t`.`state`             AS `state`
      , `t`.`zip`               AS `zip`
      , `t`.`phone`             AS `phone`
      , `t`.`dob`               AS `dob`
      , `t`.`terminationdate`   AS `terminationdate`
      , `t`.`enparticipant`     AS `enparticipant`
      , `t`.`created_at`        AS `created_at`
      , `t`.`created_by`        AS `created_by`
      , `t`.`updated_at`        AS `updated_at`
      , `t`.`updated_by`        AS `updated_by`
    FROM
        `en`.`vw_en_employees` `t`;

