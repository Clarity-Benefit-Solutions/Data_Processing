CREATE DEFINER = admin@`%` VIEW vw_temp_case_plan_cons_ben_data AS
    SELECT
        `c`.`case_id`                                                   AS `case_id`
      , `c`.`employer_name`                                             AS `employer_name`
      , `p`.`case_plan_id`                                              AS `case_plan_id`
      , `p`.`status`                                                    AS `status`
      , `p`.`plan_type`                                                 AS `plan_type`
      , `p`.`plan_sub_type`                                             AS `plan_sub_type`
      , `p`.`plan_name`                                                 AS `plan_name`
      , `p`.`plan_order`                                                AS `plan_order`
      , `p`.`plan_year_start_date`                                      AS `plan_year_start_date`
      , `p`.`plan_year_end_date`                                        AS `plan_year_end_date`
      , `p`.`plan_year_renewal_date`                                    AS `plan_year_renewal_date`
      , `p`.`min_annual_election_amount`                                AS `min_annual_election_amount`
      , `p`.`max_annual_election_amount`                                AS `max_annual_election_amount`
      , `p`.`employer_contribution_amount`                              AS `employer_contribution_amount`
      , `p`.`employee_contribution_amounts`                             AS `employee_contribution_amounts`
      , `p`.`employee_child_contribution_amounts`                       AS `employee_child_contribution_amounts`
      , `p`.`employee_spouse_contribution_amounts`                      AS `employee_spouse_contribution_amounts`
      , `p`.`family_contribution_amounts`                               AS `family_contribution_amounts`
      , `p`.`runout_period`                                             AS `runout_period`
      , `p`.`runout_period_terminated_employees`                        AS `runout_period_terminated_employees`
      , `p`.`add_limited_purpose`                                       AS `add_limited_purpose`
      , `p`.`recommended_feature`                                       AS `recommended_feature`
      , `p`.`remove_grace_period`                                       AS `remove_grace_period`
      , `p`.`add_grace_period`                                          AS `add_grace_period`
      , `p`.`add_clarity_convenience_card`                              AS `add_clarity_convenience_card`
      , `p`.`contribution_amounts`                                      AS `contribution_amounts`
      , `p`.`who_will_pay_first`                                        AS `who_will_pay_first`
      , `p`.`participant_responsible_pay_eligible_expenses`             AS `participant_responsible_pay_eligible_expenses`
      , `p`.`funding_frequency`                                         AS `funding_frequency`
      , `p`.`eligible_expense_categories`                               AS `eligible_expense_categories`
      , `p`.`will_the_HRA_reimburse_same_expenses_as_current_plan_year` AS `will_the_HRA_reimburse_same_expenses_as_current_plan_year`
      , `p`.`HRA_reimburse_same_expenses_as_current_plan_year_if_no`    AS `HRA_reimburse_same_expenses_as_current_plan_year_if_no`
      , `p`.`HRA_participant_responsible_pay_eligible_expenses_if_yes`  AS `HRA_participant_responsible_pay_eligible_expenses_if_yes`
      , `p`.`max_annual_election_amount_is_changed`                     AS `max_annual_election_amount_is_changed`
      , `p`.`carry_over_features`                                       AS `carry_over_features`
      , `p`.`additional_plan_details`                                   AS `additional_plan_details`
      , `p`.`runout_period_terminated_employees_end_date`               AS `runout_period_terminated_employees_end_date`
      , `p`.`plan_should_auto_renew`                                    AS `plan_should_auto_renew`
    FROM
        ( `api`.`api_cases` `c`
            JOIN `api`.`api_case_plans_cons_ben` `p`
                 ON (`c`.`case_id` = `p`.`case_id`))
    ORDER BY
        `c`.`employer_name`, `c`.`case_id`, `p`.`plan_type`, `p`.`plan_sub_type`;

