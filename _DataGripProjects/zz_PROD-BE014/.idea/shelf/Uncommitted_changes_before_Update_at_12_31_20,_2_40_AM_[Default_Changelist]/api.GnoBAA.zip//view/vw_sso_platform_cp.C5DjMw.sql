CREATE DEFINER = admin@`%` VIEW vw_sso_platform_cp AS
    SELECT
        CASE
            WHEN `t`.`ROW_ID` = `api`.`sso_get_record_for_cp`( `t`.`email` ) THEN 1
            ELSE 0 END             AS `is_sso_record`
      , `t`.`email`                AS `email`
      , `t`.`is_active`            AS `is_active`
      , `t`.`user_type`            AS `user_type`
      , `t`.`ROW_ID`               AS `ROW_ID`
      , `t`.`orderseq`             AS `orderseq`
      , `t`.`entitytype`           AS `entitytype`
      , `t`.`memberid`             AS `memberid`
      , `t`.`brokerid`             AS `brokerid`
      , `t`.`clientcontactid`      AS `clientcontactid`
      , `t`.`clientid`             AS `clientid`
      , `t`.`clientdivisionid`     AS `clientdivisionid`
      , `t`.`individualidentifier` AS `individualidentifier`
      , `t`.`contacttype`          AS `contacttype`
      , `t`.`salutation`           AS `salutation`
      , `t`.`firstname`            AS `firstname`
      , `t`.`lastname`             AS `lastname`
      , `t`.`title`                AS `title`
      , `t`.`department`           AS `department`
      , `t`.`phone`                AS `phone`
      , `t`.`phone2`               AS `phone2`
      , `t`.`city`                 AS `city`
      , `t`.`state`                AS `state`
      , `t`.`postalcode`           AS `postalcode`
      , `t`.`country`              AS `country`
      , `t`.`active`               AS `active`
      , `t`.`loginstatus`          AS `loginstatus`
      , `t`.`registrationcode`     AS `registrationcode`
      , `t`.`registrationdate`     AS `registrationdate`
      , `t`.`userdisplayname`      AS `userdisplayname`
      , `t`.`allowsso`             AS `allowsso`
      , `t`.`ssoidentifier`        AS `ssoidentifier`
      , `t`.`userid`               AS `userid`
      , `t`.`ssn`                  AS `ssn`
      , `t`.`employeeid`           AS `employeeid`
      , `t`.`created_at`           AS `created_at`
      , `t`.`created_by`           AS `created_by`
      , `t`.`updated_at`           AS `updated_at`
      , `t`.`updated_by`           AS `updated_by`
    FROM
        `cp`.`vw_cp_all_sso_users` `t`;

