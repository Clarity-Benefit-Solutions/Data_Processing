CREATE DEFINER = admin@`%` VIEW vw_sso_platform_bs AS
    SELECT
        `t`.`eeemail`             AS `eeemail`
      , CASE
            WHEN `t`.`row_id` = `api`.`sso_get_record_for_bs`( `t`.`eeemail` ) THEN 1
            ELSE 0 END            AS `is_sso_record`
      , `t`.`is_active`           AS `is_active`
      , `t`.`user_type`           AS `user_type`
      , `t`.`row_id`              AS `row_id`
      , `t`.`eeclientbencode`     AS `eeclientbencode`
      , `t`.`eedivision`          AS `eedivision`
      , `t`.`eefirstname`         AS `eefirstname`
      , `t`.`eelastname`          AS `eelastname`
      , `t`.`eeemployeeid`        AS `eeemployeeid`
      , `t`.`eessn`               AS `eessn`
      , `t`.`eestatus`            AS `eestatus`
      , `t`.`eeaddress1`          AS `eeaddress1`
      , `t`.`eeaddress2`          AS `eeaddress2`
      , `t`.`eecity`              AS `eecity`
      , `t`.`eestate`             AS `eestate`
      , `t`.`eezip`               AS `eezip`
      , `t`.`eehomephone`         AS `eehomephone`
      , `t`.`eedob`               AS `eedob`
      , `t`.`eebswiftparticipant` AS `eebswiftparticipant`
      , `t`.`eealternateid`       AS `eealternateid`
      , `t`.`eeimportuserid`      AS `eeimportuserid`
      , `t`.`eepayrollid`         AS `eepayrollid`
      , `t`.`eeuserroles`         AS `eeuserroles`
      , `t`.`eeuserid`            AS `eeuserid`
      , `t`.`eeusername`          AS `eeusername`
      , `t`.`eeisemployee`        AS `eeisemployee`
      , `t`.`eeismanager`         AS `eeismanager`
      , `t`.`eeistopdog`          AS `eeistopdog`
      , `t`.`abbrevurl`           AS `abbrevurl`
      , `t`.`created_at`          AS `created_at`
      , `t`.`created_by`          AS `created_by`
      , `t`.`updated_at`          AS `updated_at`
      , `t`.`updated_by`          AS `updated_by`
    FROM
        `bs`.`vw_bs_employees` `t`;

