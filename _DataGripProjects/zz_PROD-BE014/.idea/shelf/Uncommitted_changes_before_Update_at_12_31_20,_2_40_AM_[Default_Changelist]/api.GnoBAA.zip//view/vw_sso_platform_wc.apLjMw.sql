CREATE DEFINER = admin@`%` VIEW vw_sso_platform_wc AS
    SELECT
        CASE
            WHEN `t`.`row_id` = `api`.`sso_get_record_for_wc`( `t`.`email` ) THEN 1
            ELSE 0 END                      AS `is_sso_record`
      , `t`.`email`                         AS `email`
      , `t`.`is_active`                     AS `is_active`
      , `t`.`user_type`                     AS `user_type`
      , `t`.`tpa_id`                        AS `tpa_id`
      , `t`.`user_id`                       AS `user_id`
      , `t`.`profile_name`                  AS `profile_name`
      , `t`.`middle_initial`                AS `middle_initial`
      , `t`.`name_prefix`                   AS `name_prefix`
      , `t`.`phone`                         AS `phone`
      , `t`.`row_id`                        AS `row_id`
      , `t`.`employer_id`                   AS `employer_id`
      , `t`.`first_name`                    AS `first_name`
      , `t`.`last_name`                     AS `last_name`
      , `t`.`allow_get_current_sessions`    AS `allow_get_current_sessions`
      , `t`.`allow_to_uplod_a_payroll_file` AS `allow_to_uplod_a_payroll_file`
      , `t`.`status`                        AS `status`
      , `t`.`created_at`                    AS `created_at`
      , `t`.`created_by`                    AS `created_by`
      , `t`.`updated_at`                    AS `updated_at`
      , `t`.`updated_by`                    AS `updated_by`
    FROM
        `wc`.`vw_wc_employer_users` `t`;

