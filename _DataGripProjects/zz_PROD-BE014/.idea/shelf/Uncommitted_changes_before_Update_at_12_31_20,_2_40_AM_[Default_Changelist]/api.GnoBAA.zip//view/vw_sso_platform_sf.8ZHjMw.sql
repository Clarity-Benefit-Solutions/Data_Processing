CREATE DEFINER = admin@`%` VIEW vw_sso_platform_sf AS
    SELECT
        CASE
            WHEN `t`.`row_id` = `api`.`sso_get_record_for_sf`( `t`.`email` ) THEN 1
            ELSE 0 END         AS `is_sso_record`
      , `t`.`email`            AS `email`
      , `t`.`is_active`        AS `is_active`
      , `t`.`user_type`        AS `user_type`
      , `t`.`row_id`           AS `row_id`
      , `t`.`entitytype`       AS `entitytype`
      , `t`.`clientcode`       AS `clientcode`
      , `t`.`clientname`       AS `clientname`
      , `t`.`fullname`         AS `fullname`
      , `t`.`ssn`              AS `ssn`
      , `t`.`contactid`        AS `contactid`
      , `t`.`contactstatus`    AS `contactstatus`
      , `t`.`is_in_wc`         AS `is_in_wc`
      , `t`.`is_in_cp`         AS `is_in_cp`
      , `t`.`is_in_bs`         AS `is_in_bs`
      , `t`.`is_in_en`         AS `is_in_en`
      , `t`.`phone`            AS `phone`
      , `t`.`employeeid`       AS `employeeid`
      , `t`.`isprimarycontact` AS `isprimarycontact`
      , `t`.`created_at`       AS `created_at`
      , `t`.`created_by`       AS `created_by`
      , `t`.`updated_at`       AS `updated_at`
      , `t`.`updated_by`       AS `updated_by`
    FROM
        `sf`.`vw_sf_contacts` `t`;

