CREATE
    DEFINER = admin@`%` FUNCTION api_fix_ssn(value varchar(200)) RETURNS varchar(200)
BEGIN
    SET value = lower(trim(value));
    SET value = replace(value, '-', '');
    SET value = replace(value, '.', '');

    if api.api_is_blank(value) then
        return null;
    end if;

    IF length(value) >= 7 THEN
        SET value = concat(substring(value, 1, 3), '-', substring(value, 4, 2), '-', substring(value, 6));
    END IF;

    RETURN value;
END;

