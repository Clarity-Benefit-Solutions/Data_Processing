CREATE
    DEFINER = admin@`%` PROCEDURE upsert_api_case_plan_cobra_divisions(IN p_case_plan_division_id varchar(250)
, IN p_case_plan_id varchar(50), IN p_status varchar(50), IN p_version_no int, IN p_division_sort_order int
, IN p_division_name varchar(50))
BEGIN


    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO,
                @text = MESSAGE_TEXT;
            SET @text = CONCAT( @text, Concat( '
Called With Params: ', ', case_plan_division_id: ', api.api_nz( `p_case_plan_division_id`, '' ), ', case_plan_id: ',
                                               api.api_nz( `p_case_plan_id`, '' ), ', status: ',
                                               api.api_nz( `p_status`, '' ),
                                               ', version_no: ', api.api_nz( `p_version_no`, '' ),
                                               ', division_sort_order: ', api.api_nz( `p_division_sort_order`, '' ),
                                               ', division_name: ', api.api_nz( `p_division_name`, '' ) ) );
            CALL db_throw_error( @errno, 'upsert_api_case_plan_cobra_divisions', @text );
        END;


    CALL api.db_log_message( 'upsert_api_case_plan_cobra_divisions',
                             Concat( 'Called With Params: ', ', case_plan_division_id: ',
                                     api.api_nz( `p_case_plan_division_id`, '' ), ', case_plan_id: ',
                                     api.api_nz( `p_case_plan_id`, '' ), ', status: ', api.api_nz( `p_status`, '' ),
                                     ', version_no: ', api.api_nz( `p_version_no`, '' ), ', division_sort_order: ',
                                     api.api_nz( `p_division_sort_order`, '' ), ', division_name: ',
                                     api.api_nz( `p_division_name`, '' ) ), 'WARN' );


    INSERT
    INTO
        `api`.`api_case_plan_cobra_divisions`
    (
        `case_plan_division_id`, `case_plan_id`, `status`, `version_no`, `division_sort_order`, `division_name`
    )


    VALUES
    (
        `p_case_plan_division_id`
    ,   `p_case_plan_id`
    ,   `p_status`
    ,   `p_version_no`
    ,   `p_division_sort_order`
    ,   `p_division_name`
    )


    ON DUPLICATE KEY
        UPDATE
            `case_plan_division_id` = api.api_nz( `p_case_plan_division_id`, `case_plan_division_id` )
          , `case_plan_id`          = api.api_nz( `p_case_plan_id`, `case_plan_id` )
          , `status`                = api.api_nz( `p_status`, `status` )
          , `version_no`            = api.api_nz_int( `p_version_no`, `version_no` )
          , `division_sort_order`   = api.api_nz_int( `p_division_sort_order`, `division_sort_order` )
          , `division_name`         = api.api_nz( `p_division_name`, `division_name` );


END;

