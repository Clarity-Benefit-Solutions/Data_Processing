CREATE
    DEFINER = admin@`%` FUNCTION QT() RETURNS varchar(1)
BEGIN
    RETURN '"';
END;

