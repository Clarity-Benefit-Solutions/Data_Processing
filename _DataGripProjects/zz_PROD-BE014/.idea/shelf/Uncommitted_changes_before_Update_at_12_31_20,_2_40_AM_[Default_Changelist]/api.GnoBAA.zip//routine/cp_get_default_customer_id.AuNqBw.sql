CREATE
    DEFINER = admin@`%` FUNCTION cp_get_default_customer_id() RETURNS varchar(10)
BEGIN
  RETURN '146';
END;

