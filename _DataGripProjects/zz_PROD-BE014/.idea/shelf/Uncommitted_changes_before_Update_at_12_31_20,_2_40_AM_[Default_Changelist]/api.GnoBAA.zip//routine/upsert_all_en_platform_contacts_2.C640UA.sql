CREATE
    DEFINER = admin@`%` PROCEDURE upsert_all_en_platform_contacts_2(IN p_email varchar(200))
full_proc:

BEGIN
    DECLARE v_email varchar(200);
    DECLARE v_is_active varchar(200);
    DECLARE v_user_type varchar(200);
#
    DECLARE v_row_id varchar(200);
    DECLARE v_companyidentifier varchar(200);
    DECLARE v_firstname varchar(200);
    DECLARE v_lastname varchar(200);
    DECLARE v_ssn varchar(200);
    DECLARE v_employeeid varchar(200);
    DECLARE v_employeestatus varchar(200);
    DECLARE v_address1 varchar(200);
    DECLARE v_address2 varchar(200);
    DECLARE v_city varchar(200);
    DECLARE v_state varchar(200);
    DECLARE v_zip varchar(200);
    DECLARE v_phone varchar(200);
#     DECLARE v_email  varchar(200);
    DECLARE v_dob varchar(200);
    DECLARE v_terminationdate varchar(200);
    DECLARE v_enparticipant varchar(200);
    DECLARE v_created_at varchar(200);
    DECLARE v_created_by varchar(200);
    DECLARE v_updated_at varchar(200);
    DECLARE v_updated_by varchar(200);
#
    DECLARE v_finished int;
    DECLARE v_values_cursor CURSOR FOR
        SELECT
            email
          , is_active
          , user_type
          , row_id
          , companyidentifier
          , firstname
          , lastname
          , ssn
          , employeeid
          , employeestatus
          , address1
          , address2
          , city
          , state
          , zip
          , phone
#           ,email
          , dob
          , terminationdate
          , enparticipant
          , created_at
          , created_by
          , updated_at
          , updated_by
        FROM
            en.vw_en_employees t
        WHERE
            email = p_email
        ORDER BY
            email, user_type DESC, is_active DESC/*, isprimarycontact DESC*/
        LIMIT 1;

    DECLARE CONTINUE HANDLER FOR NOT FOUND BEGIN
        SET v_finished = 1;
    END;

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
            CALL db_throw_error( @errno, 'upsert_all_en_platform_contacts_1', @text );
        END;

    SET @@max_sp_recursion_depth = 12;

    OPEN v_values_cursor;

    getValues
    :
    LOOP
        FETCH v_values_cursor INTO v_email,
            v_is_active,
            v_user_type
            ,v_row_id
            ,v_companyidentifier
            ,v_firstname
            ,v_lastname
            ,v_ssn
            ,v_employeeid
            ,v_employeestatus
            ,v_address1
            ,v_address2
            ,v_city
            ,v_state
            ,v_zip
            ,v_phone
#             ,v_email
            ,v_dob
            ,v_terminationdate
            ,v_enparticipant
            ,v_created_at
            ,v_created_by
            ,v_updated_at
            ,v_updated_by;

        IF v_finished = 1 THEN
            LEAVE getValues;
        END IF;

        IF !api.api_is_blank( v_email ) THEN
            CALL api.db_log_message( 'upsert_all_en_platform_contacts_2',
                                     CONCAT(
                                             'Processing EN user for email: ',
                                             p_email,
                                             ' using record with row_id  ',
                                             v_row_id,
                                             ' name: ',
                                             v_firstname, ' ', v_lastname,
                                             ' and user_type ',
                                             v_user_type
                                         ), 'WARN' );

            #             SET v_employer_id = api.api_nz( v_employer_id, '<NULL>' );
            #
            CALL api.upsert_en_platform_user(
                    v_email,
                    v_email,
                    v_firstname,
                    v_lastname,
                    v_phone,
                    v_ssn
                , v_employeeid
                , v_dob
                , v_is_active
                , v_user_type LIKE '%EMPLOYEE%'
                , v_user_type LIKE '%CLIENT%' OR v_user_type LIKE '%BROKER%'
                , v_user_type LIKE '%TPA%'
                , v_row_id
                , v_companyidentifier
                );
        END IF;
    END LOOP getValues;
END;

