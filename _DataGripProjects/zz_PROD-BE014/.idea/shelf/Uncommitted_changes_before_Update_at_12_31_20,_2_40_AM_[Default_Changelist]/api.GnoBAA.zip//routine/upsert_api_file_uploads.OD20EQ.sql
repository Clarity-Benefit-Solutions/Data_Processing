CREATE
    DEFINER = admin@`%` PROCEDURE upsert_api_file_uploads(IN p_file_upload_id varchar(50)
, IN p_uploaded_by_user_id varchar(50), IN p_platform_name varchar(50), IN p_platform_template_name varchar(100)
, IN p_file_status varchar(50), IN p_checker_results longtext, IN p_upload_results longtext)
BEGIN


    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO,
                @text = MESSAGE_TEXT;
            SET @text = CONCAT( @text, Concat( '
Called With Params: ', ', file_upload_id: ', api.api_nz( `p_file_upload_id`, '' ), ', uploaded_by_user_id: ',
                                               api.api_nz( `p_uploaded_by_user_id`, '' ), ', platform_name: ',
                                               api.api_nz( `p_platform_name`, '' ), ', platform_template_name: ',
                                               api.api_nz( `p_platform_template_name`, '' ), ', file_status: ',
                                               api.api_nz( `p_file_status`, '' ), ', checker_results: ',
                                               api.api_nz( `p_checker_results`, '' ), ', upload_results: ',
                                               api.api_nz( `p_upload_results`, '' ) ) );
            CALL db_throw_error( @errno, 'upsert_api_file_uploads', @text );
        END;

    CALL api.db_log_message( 'upsert_api_file_uploads',
                             Concat( 'Called With Params: ', ', file_upload_id: ', api.api_nz( `p_file_upload_id`, '' ),
                                     ', uploaded_by_user_id: ', api.api_nz( `p_uploaded_by_user_id`, '' ),
                                     ', platform_name: ', api.api_nz( `p_platform_name`, '' ),
                                     ', platform_template_name: ',
                                     api.api_nz( `p_platform_template_name`, '' ), ', file_status: ',
                                     api.api_nz( `p_file_status`, '' ), ', checker_results: ',
                                     api.api_nz( `p_checker_results`, '' ), ', upload_results: ',
                                     api.api_nz( `p_upload_results`, '' ) ), 'WARN' );

    INSERT
    INTO
        `api`.`api_file_uploads`
    (
        `file_upload_id`
    ,   `uploaded_by_user_id`
    ,   `platform_name`
    ,   `platform_template_name`
    ,   `file_status`
    ,   `checker_results`
    ,   `upload_results`
    )

    VALUES
    (
        `p_file_upload_id`
    ,   `p_uploaded_by_user_id`
    ,   `p_platform_name`
    ,   `p_platform_template_name`
    ,   `p_file_status`
    ,   `p_checker_results`
    ,   `p_upload_results`
    )


    ON DUPLICATE KEY
        UPDATE
            `file_upload_id`         = api.api_nz( `p_file_upload_id`, `file_upload_id` )
          , `uploaded_by_user_id`    = api.api_nz( `p_uploaded_by_user_id`, `uploaded_by_user_id` )
          , `platform_name`          = api.api_nz( `p_platform_name`, `platform_name` )
          , `platform_template_name` = api.api_nz( `p_platform_template_name`, `platform_template_name` )
          , `file_status`            = api.api_nz( `p_file_status`, `file_status` )
          , `checker_results`        = api.api_nz( `p_checker_results`, `checker_results` )
          , `upload_results`         = api.api_nz( `p_upload_results`, `upload_results` );

END;

