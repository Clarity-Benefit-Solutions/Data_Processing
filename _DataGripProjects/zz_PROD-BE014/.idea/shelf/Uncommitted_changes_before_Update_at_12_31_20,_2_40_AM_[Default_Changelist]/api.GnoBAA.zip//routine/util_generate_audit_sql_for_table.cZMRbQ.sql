CREATE
    DEFINER = admin@`%` PROCEDURE util_generate_audit_sql_for_table(IN dbName varchar(100), IN tableName varchar(100))
BEGIN

    SELECT dbName,
           table_data.audit_table,
           table_data.audit_table_prv,
           concat("DROP TABLE IF EXISTS `", dbName, "`.`", table_data.audit_table_prv, "`;\r",
                  "RENAME TABLE `", dbName, "`.`", table_data.audit_table, "` to `", dbName, "`.`",
                  table_data.audit_table_prv, "` ;\r",
                  "DROP TABLE IF EXISTS `", dbName, "`.`",
                  table_data.audit_table, "`;\r",
                  "CREATE TABLE `", dbName, "`.`", table_data.audit_table, "`\r",
                  "(\r",
                  "  `auditAction` ENUM ('INSERT', 'UPDATE', 'DELETE'),\r",
                  "  `auditTimestamp` timestamp DEFAULT CURRENT_TIMESTAMP,\r",
                  "  `auditId` INT(14) AUTO_INCREMENT,",
                  column_defs, ",\r"
                  "  PRIMARY KEY (`auditId`),\r",
                  "  INDEX (`auditTimestamp`)\r",
                  ")\r",
                  "  ENGINE = InnoDB;\r\r",
                  concat('INSERT INTO `', dbName, '`.`', table_data.audit_table, '` ', '(',
                         api.util_get_column_list_for_table(dbName, table_data.audit_table),
                         ') ', "\r",
                         'SELECT ',
                         api.util_get_column_list_for_table(dbName, table_data.audit_table),
                         ' FROM `', dbName, '`.`', table_data.audit_table_prv, '` ;'
                      ), "\r\r\r",
                  concat('DROP table `', dbName, '`.`', table_data.audit_table_prv, '` ;'
                      ), "\r\r\r",
                  " DROP TRIGGER IF EXISTS `", dbName, "`.`", table_data.insert_trigger, "`;
                     \r",
                  "CREATE TRIGGER `", dbName, "`.`", table_data.insert_trigger, "`\r", "  AFTER INSERT ON `",
                  dbName, "`.`", table_data.db_table, "`\r", "  FOR EACH ROW INSERT INTO `", dbName, "`.`",
                  table_data.audit_table, "`\r", "     (`auditAction`,", table_data.column_names, ")\r", "  VALUES\r",
                  "     ('INSERT',", table_data.NEWcolumn_names, ");
                     \r\r",
                  "DROP TRIGGER IF EXISTS `", dbName, "`.`", table_data.update_trigger, "`;
                     \r",
                  "CREATE TRIGGER `", dbName, "`.`", table_data.update_trigger, "`\r", "  AFTER UPDATE ON `",
                  dbName, "`.`", table_data.db_table, "`\r", "  FOR EACH ROW INSERT INTO `", dbName, "`.`",
                  table_data.audit_table, "`\r", "     (`auditAction`,", table_data.column_names, ")\r", "  VALUES\r",
                  "     ('UPDATE',", table_data.NEWcolumn_names, ");
                     \r\r",
                  "DROP TRIGGER IF EXISTS `", dbName, "`.`", table_data.delete_trigger, "`;
                     \r",
                  "CREATE TRIGGER `", dbName, "`.`", table_data.delete_trigger, "`\r", "  AFTER DELETE ON `",
                  dbName, "`.`", table_data.db_table, "`\r", "  FOR EACH ROW INSERT INTO `", dbName, "`.`",
                  table_data.audit_table, "`\r", "     (`auditAction`,", table_data.column_names, ")\r", "  VALUES\r",
                  "     ('DELETE',", table_data.OLDcolumn_names, ");
                     \r\r")
    FROM (
             
             
             SELECT table_order_key,
                    TABLE_NAME                                                                      AS db_table,
                    concat(TABLE_NAME, "_audit")                                                    AS audit_table,
                    concat("tmp_prv_", TABLE_NAME, "_audit")                                        AS audit_table_prv,
                    concat("au_audit_", TABLE_NAME, "_inserts")                                     AS insert_trigger,
                    concat("au_audit_", TABLE_NAME, "_updates")                                     AS update_trigger,
                    concat("au_audit_", TABLE_NAME, "_deletes")                                     AS delete_trigger,
                    group_concat("\r  `", COLUMN_NAME, "` ", column_type ORDER BY column_order_key) AS column_defs,
                    group_concat("`", COLUMN_NAME, "`" ORDER BY column_order_key)                   AS column_names,
                    group_concat("NEW.`", COLUMN_NAME, "`" ORDER BY column_order_key)               AS NEWcolumn_names,
                    group_concat("OLD.`", COLUMN_NAME, "`" ORDER BY column_order_key)               AS OLDcolumn_names
             FROM (
                      
                      
                      
                      
                      
                      
                      SELECT information_schema.tables.table_name        AS TABLE_NAME,
                             information_schema.columns.column_name      AS COLUMN_NAME,
                             information_schema.columns.column_type      AS column_type,
                             information_schema.tables.create_time       AS table_order_key,
                             information_schema.columns.ordinal_position AS column_order_key
                      FROM information_schema.tables
                               JOIN information_schema.columns
                                    ON information_schema.tables.table_name = information_schema.columns.table_name
                      WHERE information_schema.tables.table_schema = dbName
                        AND information_schema.columns.table_schema = dbName
                        AND information_schema.tables.table_name NOT LIKE "audit\_%") table_column_ordering_info
             WHERE TABLE_NAME = tableName
             GROUP BY TABLE_NAME) table_data
    ORDER BY table_order_key;
END;

