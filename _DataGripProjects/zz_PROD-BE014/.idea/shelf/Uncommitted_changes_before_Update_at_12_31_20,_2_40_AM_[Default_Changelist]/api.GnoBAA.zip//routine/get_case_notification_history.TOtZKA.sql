CREATE
    DEFINER = admin@`%` FUNCTION get_case_notification_history(p_case_id varchar(50), p_only_last_status_change int
, p_notification_type varchar(200), p_notification_category varchar(200)
, p_notification_sub_category varchar(200)) RETURNS text
BEGIN

    DECLARE v_ret text DEFAULT '';
    DECLARE v_finished int;

    DECLARE v_notification_id int(11);
    DECLARE v_user_id varchar(200);
    DECLARE v_destination_address varchar(200);
    DECLARE v_notification_type varchar(75);
    DECLARE v_notification_category varchar(200);
    DECLARE v_notification_sub_category varchar(200);
    DECLARE v_notification_content longtext;
    DECLARE v_last_notification_sent_at text;
    DECLARE v_notification_sent_at timestamp;

    DECLARE v_counter int;
    DECLARE v_values_cursor CURSOR FOR SELECT notification_id,
                                              user_id,
                                              destination_address,
                                              notification_type,
                                              notification_category,
                                              notification_sub_category,
                                              notification_content,
                                              notification_sent_at
                                       FROM api.api_notification_logs
                                       WHERE user_id = p_case_id
                                         and notification_type like concat('%', p_notification_type, '%')
                                         and notification_category like concat('%', p_notification_category, '%')
                                         and notification_sub_category like
                                             concat('%', p_notification_sub_category, '%')
                                       ORDER BY notification_sent_at ASC;

    DECLARE CONTINUE HANDLER FOR NOT FOUND BEGIN
        SET v_finished = 1;

    END;

    SET v_ret = '';
    SET v_last_notification_sent_at = '';

    SET @@max_sp_recursion_depth = 12;
    OPEN v_values_cursor;
    #
    /*  CALL api.db_log_message( 'get_values_for_all_fields_for_form_entry',
                               concat( 'Processing Form Entry ID:  ', p_form_item_id, ' created at: ',
                                       p_entry_created_at ),
                               'INFO' );*/
    getValues
    :
    LOOP

        --
        FETCH v_values_cursor INTO v_notification_id,
            v_user_id,
            v_destination_address,
            v_notification_type,
            v_notification_category,
            v_notification_sub_category,
            v_notification_content,
            v_notification_sent_at;

        IF v_finished = 1 THEN LEAVE getValues; END IF;

#         IF v_notification_sent_at <> v_notification_sub_category THEN
        SET v_ret =
                concat(v_ret, '<span class="case_status">', v_notification_sent_at,
                       '</span>', '<span class="case_status">', v_destination_address, '</span>',
                       '</span>', '<span class="case_status">', v_notification_type, '</span>',
                       '</span>', '<span class="case_status">', v_notification_category, '</span>',
                       '</span>', '<span class="case_status">', v_notification_sub_category, '</span>',
                       '<span class="case_status">',
                       DATE_FORMAT(v_notification_sent_at, '%m/%d/%Y %h:%I %p'), '</span>',
                       char(10),
                       char(13));
        SET v_last_notification_sent_at = DATE_FORMAT(v_notification_sent_at, '%m/%d/%Y %h:%I %p');
#         END IF;

        SET v_notification_sub_category = v_notification_sent_at;

    END LOOP getValues;

    IF p_only_last_status_change THEN
        RETURN v_last_notification_sent_at;
    ELSE
        RETURN v_ret;
    END IF;

END;

