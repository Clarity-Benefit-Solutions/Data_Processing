CREATE
    DEFINER = admin@`%` FUNCTION api_uuid() RETURNS char(36)
begin
  declare id char(36);
  
  
  set id  = (SELECT md5(uuid()));
  
  return id;
end;

