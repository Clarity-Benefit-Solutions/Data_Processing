CREATE
    DEFINER = admin@`%` FUNCTION api_quote_csv_field_value(value text) RETURNS text
BEGIN
    RETURN replace(ifnull(value, ''), QT(), concat(QT(), QT()));

END;

