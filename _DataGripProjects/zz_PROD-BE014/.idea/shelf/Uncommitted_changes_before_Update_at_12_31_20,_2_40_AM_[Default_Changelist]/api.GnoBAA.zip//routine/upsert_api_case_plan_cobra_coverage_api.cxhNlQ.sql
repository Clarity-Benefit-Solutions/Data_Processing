CREATE
    DEFINER = admin@`%` PROCEDURE upsert_api_case_plan_cobra_coverage_api(IN p_case_plan_coverage_id varchar(50)
, IN p_case_plan_id varchar(50), IN p_status varchar(50), IN p_version_no int, IN p_ben_term_type varchar(50)
, IN p_plan_coverage_level varchar(50), IN p_plan_coverage_level_is_new int, IN p_plan_coverage_level_order int
, IN p_pct_100_rate_for_coverage_level float, IN p_new_pct_100_rate_for_coverage_level float)
BEGIN


    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO,
                @text = MESSAGE_TEXT;
            SET @text = CONCAT( @text, Concat( '
Called With Params: ', ', case_plan_coverage_id: ', api.api_nz( `p_case_plan_coverage_id`, '' ), ', case_plan_id: ',
                                               api.api_nz( `p_case_plan_id`, '' ), ', status: ',
                                               api.api_nz( `p_status`, '' ),
                                               ', version_no: ', api.api_nz( `p_version_no`, '' ), ', ben_term_type: ',
                                               api.api_nz( `p_ben_term_type`, '' ), ', plan_coverage_level: ',
                                               api.api_nz( `p_plan_coverage_level`, '' ),
                                               ', plan_coverage_level_is_new: ',
                                               api.api_nz( `p_plan_coverage_level_is_new`, '' ),
                                               ', plan_coverage_level_order: ',
                                               api.api_nz( `p_plan_coverage_level_order`, '' ),
                                               ', pct_100_rate_for_coverage_level: ',
                                               api.api_nz( `p_pct_100_rate_for_coverage_level`, '' ),
                                               ', new_pct_100_rate_for_coverage_level: ',
                                               api.api_nz( `p_new_pct_100_rate_for_coverage_level`, '' ) ) );
            CALL db_throw_error( @errno, 'upsert_api_case_plan_cobra_coverage', @text );
        END;


    CALL api.db_log_message( 'upsert_api_case_plan_cobra_coverage',
                             Concat( 'Called With Params: ', ', case_plan_coverage_id: ',
                                     api.api_nz( `p_case_plan_coverage_id`, '' ), ', case_plan_id: ',
                                     api.api_nz( `p_case_plan_id`, '' ), ', status: ', api.api_nz( `p_status`, '' ),
                                     ', version_no: ', api.api_nz( `p_version_no`, '' ), ', ben_term_type: ',
                                     api.api_nz( `p_ben_term_type`, '' ), ', plan_coverage_level: ',
                                     api.api_nz( `p_plan_coverage_level`, '' ), ', plan_coverage_level_is_new: ',
                                     api.api_nz( `p_plan_coverage_level_is_new`, '' ), ', plan_coverage_level_order: ',
                                     api.api_nz( `p_plan_coverage_level_order`, '' ),
                                     ', pct_100_rate_for_coverage_level: ',
                                     api.api_nz( `p_pct_100_rate_for_coverage_level`, '' ),
                                     ', new_pct_100_rate_for_coverage_level: ',
                                     api.api_nz( `p_new_pct_100_rate_for_coverage_level`, '' ) ), 'WARN' );


    INSERT
    INTO
        `api`.`api_case_plan_cobra_coverage`
    (
        `case_plan_coverage_id`
    ,   `case_plan_id`
    ,   `status`
    ,   `version_no`
    ,   `ben_term_type`
    ,   `plan_coverage_level`
    ,   `plan_coverage_level_is_new`
    ,   `plan_coverage_level_order`
    ,   `pct_100_rate_for_coverage_level`
    ,   `new_pct_100_rate_for_coverage_level`
    )


    VALUES
    (
        `p_case_plan_coverage_id`
    ,   `p_case_plan_id`
    ,   `p_status`
    ,   `p_version_no`
    ,   `p_ben_term_type`
    ,   `p_plan_coverage_level`
    ,   `p_plan_coverage_level_is_new`
    ,   `p_plan_coverage_level_order`
    ,   `p_pct_100_rate_for_coverage_level`
    ,   `p_new_pct_100_rate_for_coverage_level`
    )


    ON DUPLICATE KEY
        UPDATE
            `case_plan_coverage_id`               = api.api_nz( `p_case_plan_coverage_id`, `case_plan_coverage_id` )
          , `case_plan_id`                        = api.api_nz( `p_case_plan_id`, `case_plan_id` )
          , `status`                              = api.api_nz( `p_status`, `status` )
          , `version_no`                          = api.api_nz_int( `p_version_no`, `version_no` )
          , `ben_term_type`                       = api.api_nz( `p_ben_term_type`, `ben_term_type` )
          , `plan_coverage_level`                 = api.api_nz( `p_plan_coverage_level`, `plan_coverage_level` )
          , `plan_coverage_level_is_new`          = api.api_nz_int( `p_plan_coverage_level_is_new`,
                                                                    `plan_coverage_level_is_new` )
          , `plan_coverage_level_order`           = api.api_nz_int( `p_plan_coverage_level_order`,
                                                                    `plan_coverage_level_order` )
          , `pct_100_rate_for_coverage_level`     = api.api_nz_float( `p_pct_100_rate_for_coverage_level`,
                                                                      `pct_100_rate_for_coverage_level` )
          , `new_pct_100_rate_for_coverage_level` = api.api_nz_float( `p_new_pct_100_rate_for_coverage_level`,
                                                                      `new_pct_100_rate_for_coverage_level` );


END;

