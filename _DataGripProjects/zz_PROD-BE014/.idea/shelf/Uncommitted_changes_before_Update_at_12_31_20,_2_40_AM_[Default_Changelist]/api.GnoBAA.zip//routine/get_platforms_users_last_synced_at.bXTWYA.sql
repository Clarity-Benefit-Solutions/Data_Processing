CREATE
    DEFINER = admin@`%` FUNCTION get_platforms_users_last_synced_at() RETURNS timestamp
BEGIN

    declare v_last_synced_at timestamp default null;

    select last_synced_at into v_last_synced_at
    from api.platform_users_last_synced_at
    order by last_synced_at desc
    limit 1;

    return ifnull(v_last_synced_at, date_add(current_timestamp, INTERVAL - 1 YEAR));

END;

