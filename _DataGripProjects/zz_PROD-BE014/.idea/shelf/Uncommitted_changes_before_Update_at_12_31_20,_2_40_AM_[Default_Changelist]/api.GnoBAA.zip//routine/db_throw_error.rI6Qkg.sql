CREATE
    DEFINER = admin@`%` PROCEDURE db_throw_error(IN p_err_no varchar(50), IN p_err_source varchar(200)
, IN p_err_msg varchar(2000))
BEGIN
    DECLARE v_err_msg VARCHAR(2000);
    SET v_err_msg =
            concat('ERROR ',
                   p_err_source,
                   ' : ',
                   p_err_msg);


    CALL api.db_log_error(p_err_no, p_err_source, p_err_msg, '45000');

    SET v_err_msg = substr(v_err_msg, 1, 500);

    SIGNAL
        SQLSTATE '45000'
        SET MYSQL_ERRNO = p_err_no, MESSAGE_TEXT = v_err_msg;

END;

