CREATE
    DEFINER = admin@`%` FUNCTION api_nz(value text, valueifnullorempty text) RETURNS text
BEGIN
    IF ifnull(
               value
           , '') = ''
    THEN
        RETURN ifnull(valueIfNullOrEmpty, '');
        /* sumeet: allow force setting a value to null by passing '<NULL>'*/
    ELSEIF ifnull(
                   value
               , '') = '<NULL>' THEN
        RETURN NULL;
    ELSE
        RETURN value;
    END IF;
END;

