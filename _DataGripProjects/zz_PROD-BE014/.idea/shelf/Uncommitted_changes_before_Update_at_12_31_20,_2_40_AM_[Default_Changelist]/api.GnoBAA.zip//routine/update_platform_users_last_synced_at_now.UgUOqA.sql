CREATE
    DEFINER = rahulsoni@`%` PROCEDURE update_platform_users_last_synced_at_now()
BEGIN
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
            CALL db_log_error(@errno, 'updated_platform_users_last_synced_at_now', @text, @sqlstate);
        END;

    
    INSERT INTO api.platform_users_last_synced_at (id, last_synced_at)
    VALUES (1,
            current_timestamp)
    ON DUPLICATE KEY UPDATE last_synced_at = current_timestamp;
END;

