CREATE
    DEFINER = admin@`%` FUNCTION api_nz_int(value varchar(200), valueifnullorempty varchar(200)) RETURNS int
BEGIN
    IF ifnull(value, '') = '' THEN
        RETURN api_cint(valueifnullorempty);
        /* sumeet: allow force setting a value to null by passing '<NULL>'*/
    ELSEIF ifnull(
                   value
               , '') = '<NULL>' THEN
        RETURN NULL;
    ELSE
        RETURN api_cint(value);
    END IF;
END;

