CREATE
    DEFINER = admin@`%` FUNCTION util_get_column_list_for_table(dbName varchar(100), tableName varchar(100)) RETURNS text
BEGIN
    DECLARE v_cols text;
    SELECT group_concat('`', column_name, '` ' ORDER BY column_order_key) INTO v_cols
    FROM (
             SELECT information_schema.tables.table_name        AS table_name,
                    information_schema.columns.column_name      AS column_name,
                    information_schema.columns.ordinal_position AS column_order_key
             FROM information_schema.tables
                      JOIN information_schema.columns
                           ON information_schema.tables.table_name = information_schema.columns.table_name
             WHERE information_schema.tables.table_schema = dbName
               AND information_schema.columns.table_schema = dbName
               AND information_schema.tables.table_name = tableName
         ) table_column_ordering_info
    GROUP BY TABLE_NAME;
    

    RETURN ifnull(v_cols, '*');


END;

