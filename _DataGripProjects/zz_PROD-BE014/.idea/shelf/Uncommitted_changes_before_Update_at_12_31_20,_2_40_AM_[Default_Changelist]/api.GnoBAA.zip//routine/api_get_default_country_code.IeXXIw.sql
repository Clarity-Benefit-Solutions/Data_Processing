CREATE
    DEFINER = admin@`%` FUNCTION api_get_default_country_code() RETURNS varchar(5)
BEGIN
    RETURN '1';
END;

