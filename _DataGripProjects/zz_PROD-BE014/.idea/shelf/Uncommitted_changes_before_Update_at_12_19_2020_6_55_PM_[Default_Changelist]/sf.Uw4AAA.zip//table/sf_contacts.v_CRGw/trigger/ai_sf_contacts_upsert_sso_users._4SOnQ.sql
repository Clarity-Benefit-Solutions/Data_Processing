CREATE DEFINER = admin@`%` TRIGGER ai_sf_contacts_upsert_sso_users
    AFTER INSERT
    ON sf_contacts
    FOR EACH ROW
BEGIN
    IF new.entitytype <> 'PARTICIPANT' THEN
        CALL api.upsert_sf_platform_user(
                api.api_fix_email(new.email),
                api.api_fix_email(new.email),
                api.api_get_first_name_from_fullname(new.fullname),
                api.api_get_last_name_from_fullname(new.fullname),
                api.api_fix_phone_number(new.phone),
                api.api_fix_ssn(new.ssn),
                new.employeeid,
                NULL, -- p_dob
                1, -- p_sf_is_active
                0, -- p_sf_is_employee
                CASE WHEN new.entitytype = 'CLIENT' THEN 1 ELSE 0 END, -- p_sf_is_client
                CASE WHEN new.entitytype = 'BROKER' THEN 1 ELSE 0 END, -- p_sf_is_broker
                new.row_id, -- p_sf_row_id
                new.clientcode -- p_sf_employer_id
            );

    END IF;
END;

