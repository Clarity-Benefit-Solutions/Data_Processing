CREATE
    DEFINER = admin@`%` PROCEDURE truncate_sf_contacts( IN dummy int(1) )
BEGIN
    -- show message
    CALL api.db_show_message( 'truncate_sf_contacts', 'STARTING' );
    --
    TRUNCATE TABLE sf.sf_contacts;

    -- show message
    CALL api.db_show_message( 'truncate_sf_contacts', 'FINISHED' );
    --

END;

