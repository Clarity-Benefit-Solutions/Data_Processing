CREATE
    DEFINER = admin@`%` PROCEDURE upsert_sf_contacts(
                                                      IN p_clientcode varchar(75)
                                                    , IN p_clientname varchar(75)
                                                    , IN p_entitytype varchar(75)
                                                    , IN p_fullname varchar(75)
                                                    , IN p_contactid varchar(75)
                                                    , IN p_ssn varchar(75)
                                                    , IN p_contactstatus varchar(75)
                                                    , IN p_is_in_wc varchar(75)
                                                    , IN p_is_in_cp varchar(75)
                                                    , IN p_is_in_bs varchar(75)
                                                    , IN p_is_in_en varchar(75)
                                                    , IN p_phone varchar(75)
                                                    , IN p_email varchar(200)
                                                    , IN p_employeeid varchar(75)
                                                    , IN p_isprimarycontact varchar(75) )
BEGIN

    -- show message
    CALL api.db_log_message( 'upsert_sf_contacts',
                             concat( 'Processing EntityType: ', p_entitytype, ', ClientCode: ', p_clientcode,
                                     ', clientname: ', p_clientname, ', fullname: ', p_fullname ),
                             'WARN' );
    INSERT
    INTO
        sf.sf_contacts(
                        entitytype
                      , clientcode
                      , clientname
                      , fullname
                      , ssn
                      , contactid
                      , contactstatus
                      , is_in_wc
                      , is_in_cp
                      , is_in_bs
                      , is_in_en
                      , phone
                      , email
                      , employeeid
                      , isprimarycontact
    )
    VALUES
    (
        p_entitytype
    ,   p_clientcode
    ,   p_clientname
    ,   p_fullname
    ,   p_ssn
    ,   p_contactid
    ,   p_contactstatus
    ,   p_is_in_wc
    ,   p_is_in_cp
    ,   p_is_in_bs
    ,   p_is_in_en
    ,   p_phone
    ,   p_email
    ,   p_employeeid
    ,   p_isprimarycontact
    )
    ON DUPLICATE KEY UPDATE
                         entitytype=p_entitytype
                       , clientcode=p_clientcode
                       , clientname=p_clientname
                       , fullname=p_fullname
                       , ssn=p_ssn
                       , contactid=p_contactid
                       , contactstatus=p_contactstatus
                       , is_in_wc=p_is_in_wc
                       , is_in_cp=p_is_in_cp
                       , is_in_bs=p_is_in_bs
                       , is_in_en=p_is_in_en
                       , phone=p_phone
                       , email=p_email
                       , employeeid=p_employeeid
                       , isprimarycontact=p_isprimarycontact;
END;

