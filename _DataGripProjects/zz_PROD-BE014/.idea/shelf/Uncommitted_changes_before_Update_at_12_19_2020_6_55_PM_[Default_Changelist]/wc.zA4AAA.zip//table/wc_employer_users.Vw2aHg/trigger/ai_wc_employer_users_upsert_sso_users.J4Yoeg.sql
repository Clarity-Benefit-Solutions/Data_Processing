CREATE DEFINER = admin@`%` TRIGGER ai_wc_employer_users_upsert_sso_users
    AFTER INSERT
    ON wc_employer_users
    FOR EACH ROW
BEGIN
    CALL api.upsert_wc_platform_user(
            new.email,
            new.email,
            new.first_name,
            new.last_name,
            new.phone,
            NULL 
        , new.employer_id 
        , new.tpa_id 
        , new.user_id 
        , NULL 
        , NULL 
        , NULL 
        , NULL 
        , NULL 
        , NULL 
        , api.api_cbool(new.status) 
        , NULL 
        , new.row_id 
        , NULL
        );
END;

