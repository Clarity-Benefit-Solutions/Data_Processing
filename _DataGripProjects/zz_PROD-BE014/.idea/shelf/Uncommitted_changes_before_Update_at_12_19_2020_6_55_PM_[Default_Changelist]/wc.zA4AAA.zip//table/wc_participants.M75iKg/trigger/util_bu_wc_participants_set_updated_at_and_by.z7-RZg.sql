CREATE DEFINER = admin@`%` TRIGGER util_bu_wc_participants_set_updated_at_and_by
    BEFORE UPDATE
    ON wc_participants
    FOR EACH ROW
begin
    set new.updated_at = current_timestamp;
    set new.updated_by = current_user;
end;

