CREATE
    DEFINER = admin@`%` PROCEDURE upsert_wc_employer_plans(
                                                            IN employer_id varchar(200)
                                                          , IN account_type_code varchar(200)
                                                          , IN allow_claims_crossover varchar(200)
                                                          , IN allow_partial_manual_transaction varchar(200)
                                                          , IN annual_elect_max varchar(200)
                                                          , IN annual_elect_min varchar(200)
                                                          , IN auto_deposit_by_pass varchar(200)
                                                          , IN claims_crossover_participant_default varchar(200)
                                                          , IN convenience_fee_amount varchar(200)
                                                          , IN convenience_fee_payor varchar(200)
                                                          , IN coverage_tier_type_id varchar(200)
                                                          , IN default_coverage_tier_id varchar(200)
                                                          , IN default_deposit_calendar_id varchar(200)
                                                          , IN enforce_employee_contribution_limit varchar(200)
                                                          , IN ext_deductible varchar(200)
                                                          , IN fixed_employer_funding_amount varchar(200)
                                                          , IN fixed_employer_funding_amount_individual varchar(200)
                                                          , IN fixed_employer_funding_calendar_id varchar(200)
                                                          , IN grace_period_end_date datetime
                                                          , IN iias_options varchar(200)
                                                          , IN iias_settings varchar(200)
                                                          , IN individual_balance_max varchar(200)
                                                          , IN life_event_calculation_methods varchar(200)
                                                          , IN manual_claim_percent_coverage varchar(200)
                                                          , IN max_total_amount varchar(200)
                                                          , IN max_transaction_amount varchar(200)
                                                          , IN plan_id varchar(200)
                                                          , IN plan_options varchar(200)
                                                          , IN plan_year_end_date datetime
                                                          , IN plan_year_extended_end_date datetime
                                                          , IN plan_year_start_date datetime
                                                          , IN product_partner_account_fee varchar(200)
                                                          , IN product_partner_administrator_id varchar(200)
                                                          , IN product_partner_employer_id varchar(200)
                                                          , IN product_partner_issue_checkbooks varchar(200)
                                                          , IN product_partner_product_id varchar(200)
                                                          , IN product_partner_setup_fee varchar(200)
                                                          , IN reimbursement_method varchar(200)
                                                          , IN rollover_balance_max varchar(200)
                                                          , IN spending_deposit_amount varchar(200)
                                                          , IN spending_limit_period varchar(200)
                                                          , IN spending_transaction_amount varchar(200)
                                                          , IN term_empe_run_out_days varchar(200)
                                                          , IN tpa_id varchar(200) )
BEGIN

    CALL api.db_show_message( 'upsert_wc_employer_plans',
                              concat( ' Processing Employer Plan EmployerID: ', employer_id, 'PlanID: ', plan_id ) );

    INSERT
    INTO
        wc.wc_employer_plans(
                              employer_id
                            , account_type_code
                            , allow_claims_crossover
                            , allow_partial_manual_transaction
                            , annual_elect_max
                            , annual_elect_min
                            , auto_deposit_by_pass
                            , claims_crossover_participant_default
                            , convenience_fee_amount
                            , convenience_fee_payor
                            , coverage_tier_type_id
                            , default_coverage_tier_id
                            , default_deposit_calendar_id
                            , enforce_employee_contribution_limit
                            , ext_deductible
                            , fixed_employer_funding_amount
                            , fixed_employer_funding_amount_individual
                            , fixed_employer_funding_calendar_id
                            , grace_period_end_date
                            , iias_options
                            , iias_settings
                            , individual_balance_max
                            , life_event_calculation_methods
                            , manual_claim_percent_coverage
                            , max_total_amount
                            , max_transaction_amount
                            , plan_id
                            , plan_options
                            , plan_year_end_date
                            , plan_year_extended_end_date
                            , plan_year_start_date
                            , product_partner_account_fee
                            , product_partner_administrator_id
                            , product_partner_employer_id
                            , product_partner_issue_checkbooks
                            , product_partner_product_id
                            , product_partner_setup_fee
                            , reimbursement_method
                            , rollover_balance_max
                            , spending_deposit_amount
                            , spending_limit_period
                            , spending_transaction_amount
                            , term_empe_run_out_days
                            , tpa_id
    )
    VALUES
    (
        employer_id
    ,   account_type_code = account_type_code
    ,   allow_claims_crossover
    ,   allow_partial_manual_transaction
    ,   annual_elect_max
    ,   annual_elect_min
    ,   auto_deposit_by_pass
    ,   claims_crossover_participant_default
    ,   convenience_fee_amount
    ,   convenience_fee_payor
    ,   coverage_tier_type_id
    ,   default_coverage_tier_id
    ,   default_deposit_calendar_id
    ,   enforce_employee_contribution_limit
    ,   ext_deductible
    ,   fixed_employer_funding_amount
    ,   fixed_employer_funding_amount_individual
    ,   fixed_employer_funding_calendar_id
    ,   grace_period_end_date
    ,   iias_options
    ,   iias_settings
    ,   individual_balance_max
    ,   life_event_calculation_methods
    ,   manual_claim_percent_coverage
    ,   max_total_amount
    ,   max_transaction_amount = max_transaction_amount
    ,   plan_id
    ,   plan_options
    ,   plan_year_end_date
    ,   plan_year_extended_end_date
    ,   plan_year_start_date
    ,   product_partner_account_fee
    ,   product_partner_administrator_id
    ,   product_partner_employer_id
    ,   product_partner_issue_checkbooks
    ,   product_partner_product_id
    ,   product_partner_setup_fee
    ,   reimbursement_method
    ,   rollover_balance_max
    ,   spending_deposit_amount
    ,   spending_limit_period
    ,   spending_transaction_amount
    ,   term_empe_run_out_days
    ,   tpa_id
    )
    ON DUPLICATE KEY UPDATE
                         employer_id                              = employer_id
                       , allow_claims_crossover                   = allow_claims_crossover
                       , allow_partial_manual_transaction         = allow_partial_manual_transaction
                       , annual_elect_max                         = annual_elect_max
                       , annual_elect_min                         = annual_elect_min
                       , auto_deposit_by_pass                     = auto_deposit_by_pass
                       , claims_crossover_participant_default     = claims_crossover_participant_default
                       , convenience_fee_amount                   = convenience_fee_amount
                       , convenience_fee_payor                    = convenience_fee_payor
                       , coverage_tier_type_id                    = coverage_tier_type_id
                       , default_coverage_tier_id                 = default_coverage_tier_id
                       , default_deposit_calendar_id              = default_deposit_calendar_id
                       , enforce_employee_contribution_limit      = enforce_employee_contribution_limit
                       , ext_deductible                           = ext_deductible
                       , fixed_employer_funding_amount            = fixed_employer_funding_amount
                       , fixed_employer_funding_amount_individual = fixed_employer_funding_amount_individual
                       , fixed_employer_funding_calendar_id       = fixed_employer_funding_calendar_id
                       , grace_period_end_date                    = grace_period_end_date
                       , iias_options                             = iias_options
                       , iias_settings                            = iias_settings
                       , individual_balance_max                   = individual_balance_max
                       , life_event_calculation_methods           = life_event_calculation_methods
                       , manual_claim_percent_coverage            = manual_claim_percent_coverage
                       , max_total_amount                         = max_total_amount
                       , plan_id                                  = plan_id
                       , plan_options                             = plan_options
                       , plan_year_end_date                       = plan_year_end_date
                       , plan_year_extended_end_date              = plan_year_extended_end_date
                       , plan_year_start_date                     = plan_year_start_date
                       , product_partner_account_fee              = product_partner_account_fee
                       , product_partner_administrator_id         = product_partner_administrator_id
                       , product_partner_employer_id              = product_partner_employer_id
                       , product_partner_issue_checkbooks         = product_partner_issue_checkbooks
                       , product_partner_product_id               = product_partner_product_id
                       , product_partner_setup_fee                = product_partner_setup_fee
                       , reimbursement_method                     = reimbursement_method
                       , rollover_balance_max                     = rollover_balance_max
                       , spending_deposit_amount                  = spending_deposit_amount
                       , spending_limit_period                    = spending_limit_period
                       , spending_transaction_amount              = spending_transaction_amount
                       , term_empe_run_out_days                   = term_empe_run_out_days
                       , tpa_id                                   = tpa_id;
END;

