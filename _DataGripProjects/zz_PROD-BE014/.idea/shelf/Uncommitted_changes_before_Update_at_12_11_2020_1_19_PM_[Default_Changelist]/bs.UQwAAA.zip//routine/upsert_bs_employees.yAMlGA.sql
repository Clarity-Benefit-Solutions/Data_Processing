create
    definer = admin@`%` procedure upsert_bs_employees(IN p_eeclientbencode varchar(200), IN p_eedivision varchar(200),
                                                      IN p_eefirstname varchar(200), IN p_eelastname varchar(200),
                                                      IN p_eeemployeeid varchar(200), IN p_eessn varchar(200),
                                                      IN p_eestatus varchar(200), IN p_eeaddress1 varchar(200),
                                                      IN p_eeaddress2 varchar(200), IN p_eecity varchar(200),
                                                      IN p_eestate varchar(200), IN p_eezip varchar(200),
                                                      IN p_eehomephone varchar(200), IN p_eeemail varchar(200),
                                                      IN p_eedob varchar(200), IN p_eebswiftparticipant varchar(200),
                                                      IN p_eealternateid varchar(200), IN p_eeimportuserid varchar(200),
                                                      IN p_eepayrollid varchar(200), IN p_eeuserid varchar(200),
                                                      IN p_eeusername varchar(200), IN p_eeisemployee varchar(200),
                                                      IN p_eeismanager varchar(200), IN p_eeistopdog varchar(200),
                                                      IN p_abbrevurl varchar(200))
BEGIN

    CALL api.db_show_message( 'upsert_bs_employees',
                              concat( ' Processing Employee ', p_eeemployeeid, ', ', p_eefirstname ) );


    SET p_eestate = api.api_cbool( p_eestate );
    SET p_eeisemployee = api.api_cbool( p_eeisemployee );
    SET p_eeismanager = api.api_cbool( p_eeismanager );
    SET p_eeistopdog = api.api_cbool( p_eeistopdog );

    INSERT
    INTO
        bs.bs_employees(
                         eeclientbencode
                       , eedivision
                       , eefirstname
                       , eelastname
                       , eeemployeeid
                       , eessn
                       , eestatus
                       , eeaddress1
                       , eeaddress2
                       , eecity
                       , eestate
                       , eezip
                       , eehomephone
                       , eeemail
                       , eedob
                       , eebswiftparticipant
                       , eealternateid
                       , eeimportuserid
                       , eepayrollid
                       , eeuserid
                       , eeusername
                       , eeisemployee
                       , eeismanager
                       , eeistopdog
                       , abbrevurl
    )
    VALUES
    (
        p_eeclientbencode
    ,   p_eedivision
    ,   p_eefirstname
    ,   p_eelastname
    ,   p_eeemployeeid
    ,   p_eessn
    ,   p_eestatus
    ,   p_eeaddress1
    ,   p_eeaddress2
    ,   p_eecity
    ,   p_eestate
    ,   p_eezip
    ,   p_eehomephone
    ,   p_eeemail
    ,   p_eedob
    ,   p_eebswiftparticipant
    ,   p_eealternateid
    ,   p_eeimportuserid
    ,   p_eepayrollid
    ,   p_eeuserid
    ,   p_eeusername
    ,   p_eeisemployee
    ,   p_eeismanager
    ,   p_eeistopdog
    ,   p_abbrevurl
    )
    ON DUPLICATE KEY UPDATE
                         eeclientbencode     = p_eeclientbencode
                       , eedivision          = p_eedivision
                       , eefirstname         = p_eefirstname
                       , eelastname          = p_eelastname
                       , eeemployeeid        = p_eeemployeeid
                       , eessn               = p_eessn
                       , eestatus            = p_eestatus
                       , eeaddress1          = p_eeaddress1
                       , eeaddress2          = p_eeaddress2
                       , eecity              = p_eecity
                       , eestate             = p_eestate
                       , eezip               = p_eezip
                       , eehomephone         = p_eehomephone
                       , eeemail             = p_eeemail
                       , eedob               = p_eedob
                       , eebswiftparticipant = p_eebswiftparticipant
                       , eealternateid       = p_eealternateid
                       , eeimportuserid      = p_eeimportuserid
                       , eepayrollid         = p_eepayrollid
                       , eeuserid            = p_eeuserid
                       , eeusername          = p_eeusername
                       , eeisemployee        = p_eeisemployee
                       , eeismanager         = p_eeismanager
                       , eeistopdog          = p_eeistopdog
                       , abbrevurl           = p_abbrevurl;

END;

