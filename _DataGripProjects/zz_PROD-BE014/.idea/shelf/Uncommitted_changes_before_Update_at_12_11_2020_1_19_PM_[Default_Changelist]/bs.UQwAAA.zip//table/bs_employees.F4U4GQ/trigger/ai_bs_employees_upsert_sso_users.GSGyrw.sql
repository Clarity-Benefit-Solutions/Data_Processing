create definer = admin@`%` trigger ai_bs_employees_upsert_sso_users
    after insert
    on bs_employees
    for each row
BEGIN
    CALL api.upsert_bs_platform_user(api.api_fix_email(new.eeemail), api.api_fix_email(new.eeemail), new.eefirstname,
                                     new.eelastname, new.eehomephone, api.api_fix_ssn(new.eessn), new.eeuserid,
                                     new.eeimportuserid, new.eeusername, api.api_fix_ssn(new.eessn), new.eeemail,
                                     new.eepayrollid
        , api.api_fix_date(new.eedob)
        , api.api_cbool(new.eestatus) 
        , api.api_cbool(new.eeisemployee), api.api_cbool(new.eeismanager), api.api_cbool(new.eeistopdog),
                                     new.abbrevurl, new.row_id, new.eeclientbencode);

END;

