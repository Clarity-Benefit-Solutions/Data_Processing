create
    definer = admin@`%` procedure truncate_cp_all(IN dummy int(1))
BEGIN
    -- show message
    CALL api.db_show_message('truncate_cp_all', 'STARTING');
    --
    truncate table cp.cp_all_sso_users;

    -- show message
    CALL api.db_show_message('truncate_cp_all', 'FINISHED');
    --
    select 'truncate_cp_all: SUCCESS';

END;

