CREATE
    DEFINER = admin@`%` PROCEDURE get_all_values_for_all_form_fields(IN p_parent_item_id int)
BEGIN


    SELECT *
    FROM vw_get_all_values_for_all_form_fields
    WHERE item_id IN (portal.get_all_entry_ids_for_all_form_fields(p_parent_item_id))
    ORDER BY item_id, field_order;

END;

