CREATE
    DEFINER = admin@`%` PROCEDURE get_all_current_and_original_values_for_parent_item_id(IN p_form_item_id int, IN p_form_item_key varchar(50))
BEGIN
    DECLARE v_entryIds text;
    DECLARE v_sql text;

    SET v_entryIds = portal.get_all_entry_ids_for_all_form_fields(p_form_item_id, p_form_item_key);

    SET v_sql = concat('SELECT *  FROM vw_get_all_values_for_all_form_fields
    WHERE item_id IN (', v_entryIds, ') ',
                       'ORDER BY field_order;');

    EXECUTE IMMEDIATE v_sql;

END;

