CREATE
    DEFINER = admin@`%` PROCEDURE get_values_for_all_fields_for_form_entry(IN p_form_item_id int, IN r_CSV text, IN p_add_header int)
BEGIN
    DECLARE v_item_id varchar(100);
    DECLARE v_form_id varchar(100);
    DECLARE v_form_name varchar(200);
    DECLARE v_page_name varchar(200);
    DECLARE v_field_order int;
    DECLARE v_field_name varchar(100);
    DECLARE v_repeater_name varchar(100);
    DECLARE v_value_has_changed int;
    DECLARE v_current_value text;
    DECLARE v_original_value text;
    DECLARE v_field_key varchar(100);
    DECLARE v_field_id varchar(100);
    DECLARE v_field_type varchar(100);

    DECLARE v_repeater_entries text;
    DECLARE v_repeater_entries_values text;

    DECLARE v_finished int;

    DECLARE v_CSV text;
    DECLARE v_rowCsv text;

    DECLARE v_values_cursor CURSOR FOR
        SELECT item_id,
               form_id,
               form_name,
               page_name,
               field_order,
               field_name,
               repeater_name,
               value_has_changed,
               current_value,
               original_value,
               field_key,
               field_id,
               field_type
        FROM vw_get_values_for_form_entry
        WHERE item_id = p_form_item_id
        ORDER BY form_id, field_order;

    DECLARE CONTINUE HANDLER
        FOR NOT FOUND SET v_finished = 1;

    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
        BEGIN
            GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
            CALL api.db_log_error(@errno, 'get_values_for_all_fields_for_form_entry', @text, @sqlstate);
        END;

    -- header row
    SET v_CSV = CONCAT(QT(), 'Page Title', QT(), ',',
                       QT(), 'Field Title', QT(), ',',
                       QT(), 'Previous Value', QT(), ',',
                       QT(), 'New Value', QT(), ',',
                       QT(), 'Has Changed', QT(),
                       char(13), char(10));

    -- loop thru all fields
    OPEN v_values_cursor;

    CALL api.db_log_message('get_values_for_all_fields_for_form_entry',
                            concat('Processing Form Entrty ID:  ', p_form_item_id),
                            'INFO');
    getValues:
    LOOP
        FETCH v_values_cursor INTO v_item_id,
            v_form_id,
            v_form_name,
            v_page_name,
            v_field_order,
            v_field_name,
            v_repeater_name,
            v_value_has_changed,
            v_current_value,
            v_original_value,
            v_field_key,
            v_field_id,
            v_field_type;

        --
        IF v_finished = 1 THEN
            LEAVE getValues;
        END IF;


        IF v_field_type = 'divider' THEN
            SET v_repeater_entries = api.api_getPhpSerializedArrayValues(v_current_value);
            SET v_repeater_name = '';
        END IF;

       /* -- get csv
        SET v_rowCsv =
                api.get_api_cases_new_prv_field_value(
                        p_row_id, v_field_page_label, v_field_label, v_db_field_name, p_prv_version_no,
                        p_new_version_no, p_only_if_changed);
        --
        CALL api.db_log_message('get_values_for_all_fields_for_form_entry',
                                concat(' -- Field: ', v_field_label, ' , DbField: ', v_db_field_name,
                                       ', CSV:', char(13), char(10), v_rowCsv),
                                'INFO');*/


        -- if got blank data, there were no changes and p_only_if_changed was 1
        IF api.api_nz(v_rowCsv, '') <> '' THEN
            SET v_CSV = concat(v_CSV,
                               v_rowCsv,
                               char(13), char(10)
                );
        END IF;
        --
    END LOOP getValues;


    SET r_CSV = v_CSV;

    SELECT r_CSV;
END;

