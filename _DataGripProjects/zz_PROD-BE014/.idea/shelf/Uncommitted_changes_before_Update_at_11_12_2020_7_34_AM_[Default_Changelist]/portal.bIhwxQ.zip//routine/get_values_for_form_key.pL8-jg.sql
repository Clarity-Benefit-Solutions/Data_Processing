create
    definer = admin@`%` procedure get_values_for_form_key(IN p_form_item_key varchar(50), IN p_add_header int,
                                                          IN p_page_name varchar(200),
                                                          IN p_repeater_field_name varchar(200), OUT v_CSV text)
BEGIN


    DECLARE v_item_id int;

    SELECT id INTO v_item_id FROM portal.cl_frm_items WHERE item_key = p_form_item_key;
    CALL portal.get_values_for_form_entry(v_item_id, p_add_header, p_page_name, p_repeater_field_name, v_CSV);

#     SELECT v_CSV;

END;

