CREATE
    DEFINER = admin@`%` PROCEDURE get_values_for_all_fields_for_form_entry(IN p_form_item_id int, IN p_add_header int,
                                                                           IN p_repeater_field_name varchar(200),
                                                                           OUT v_CSV text)
BEGIN

    DECLARE v_item_id varchar(100);
    DECLARE v_form_id varchar(100);
    DECLARE v_form_name varchar(200);
    DECLARE v_page_name varchar(200);
    DECLARE v_curr_page_name varchar(200);
    DECLARE v_field_order int;
    DECLARE v_field_name varchar(100);
#     DECLARE v_repeater_name varchar(100);
    DECLARE v_value_has_changed int;
    DECLARE v_current_value text;
    DECLARE v_original_value text;
    DECLARE v_field_key varchar(100);
    DECLARE v_field_id varchar(100);
    DECLARE v_field_type varchar(100);


    DECLARE v_repeater_entry_id int;
    DECLARE v_repeater_entry_csv text;

    DECLARE v_finished int;

    DECLARE v_rowCsv text;

    DECLARE v_counter int;

    DECLARE v_values_cursor CURSOR FOR
        SELECT item_id,
               form_id,
               form_name,
               page_name,
               field_order,
               field_name,
#                repeater_name,
               value_has_changed,
               current_value,
               original_value,
               field_key,
               field_id,
               field_type
        FROM vw_get_values_for_form_entry
        WHERE item_id = p_form_item_id
        ORDER BY form_id, field_order;

    DECLARE CONTINUE HANDLER
        FOR NOT FOUND SET v_finished = 1;

    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
        BEGIN
            GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
            CALL api.db_log_error(@errno, 'get_values_for_all_fields_for_form_entry', @text, @sqlstate);
        END;

    SET v_CSV = '';

    -- header row
    IF p_add_header THEN
        SET v_CSV = CONCAT(api.QT(), 'Item Id', api.QT(), ',',
                           api.QT(), 'Form Id', api.QT(), ',',
                           api.QT(), 'Form Name', api.QT(), ',',
                           api.QT(), 'Page Name', api.QT(), ',',
                           api.QT(), 'Repeater Name', api.QT(), ',',
                           api.QT(), 'Field Name', api.QT(), ',',
                           api.QT(), 'Is Repeater Field', api.QT(), ',',
                           api.QT(), 'Field Id', api.QT(), ',',
                           api.QT(), 'Field Key', api.QT(), ',',
                           api.QT(), 'Field Type', api.QT(), ',',
                           api.QT(), 'Has Changed', api.QT(), ',',
                           api.QT(), 'Original Value', api.QT(), ',',
                           api.QT(), 'Current Value', api.QT(),
                           char(13));
    END IF;

    -- loop thru all fields
    OPEN v_values_cursor;

    CALL api.db_log_message('get_values_for_all_fields_for_form_entry',
                            concat('Processing Form Entry ID:  ', p_form_item_id),
                            'INFO');
    getValues:
    LOOP
        FETCH v_values_cursor INTO v_item_id,
            v_form_id,
            v_form_name,
            v_page_name,
            v_field_order,
            v_field_name,
#             v_repeater_name,
            v_value_has_changed,
            v_current_value,
            v_original_value,
            v_field_key,
            v_field_id,
            v_field_type;

        --
        IF v_finished = 1 THEN
            LEAVE getValues;
        END IF;


        SET v_curr_page_name = api.api_nz(v_page_name, v_curr_page_name);


        --
        IF v_field_type <> 'divider' /*AND NOT api.api_is_blank(v_current_value) */THEN
            SET v_rowCsv = CONCAT(api.QT(), api.api_nz(v_item_id, ''), api.QT(), ',',
                                  api.QT(), api.api_nz(v_form_id, ''), api.QT(), ',',
                                  api.QT(), api.api_nz(v_form_name, ''), api.QT(), ',',
                                  api.QT(), api.api_nz(v_page_name, ''), api.QT(), ',',
                                  api.QT(), api.api_nz(p_repeater_field_name, ''), api.QT(), ',',
                                  api.QT(), api.api_nz(v_field_name, ''), api.QT(), ',',
                                  api.QT(), NOT api.api_is_blank(p_repeater_field_name), api.QT(), ',',
                                  api.QT(), api.api_nz(v_field_id, ''), api.QT(), ',',
                                  api.QT(), api.api_nz(v_field_key, ''), api.QT(), ',',
                                  api.QT(), api.api_nz(v_field_type, ''), api.QT(), ',',
                                  api.QT(), api.api_nz(v_value_has_changed, ''), api.QT(), ',',
                                  api.QT(), api.api_nz(v_original_value, ''), api.QT(), ',',
                                  api.QT(), api.api_nz(v_current_value, ''), api.QT(), ',',
                                  char(13));

        ELSE

            CALL api.db_log_message('get_values_for_all_fields_for_form_entry',
                                    concat(' -- Processing Repeater Field: ', v_field_name, ' , SubEntries: ',
                                           v_current_value),
                                    'INFO');
            SET v_rowCsv = '';

            SET v_counter = 0;
            SET v_repeater_entry_id = 0;
            WHILE v_counter <= 20 AND v_repeater_entry_id IS NOT NULL
                DO
                    SET v_repeater_entry_id = api.api_getPhpSerializedArrayValueByIndex(v_current_value, v_counter);
                    IF v_repeater_entry_id IS NOT NULL THEN
                        --
                        CALL get_values_for_all_fields_for_form_entry(v_repeater_entry_id, 0, v_field_name,
                                                                      v_repeater_entry_csv);
                        --
                        SET v_rowCsv = concat(v_rowcsv, v_repeater_entry_csv);
                    END IF;
                    SET v_counter = v_counter + 1;
                END WHILE;

        END IF;
        --
        CALL api.db_log_message('get_values_for_all_fields_for_form_entry',
                                concat(' -- Field: ', v_field_name, ' , FieldKey: ', v_field_key,
                                       ', CSV:', char(13), v_rowCsv),
                                'INFO');


        -- if got blank data, there were no changes and p_only_if_changed was 1
        IF api.api_nz(v_rowCsv, '') <> '' THEN
            SET v_CSV = concat(v_CSV,
                               v_rowCsv
                );
        END IF;
        --
    END LOOP getValues;


    SELECT v_CSV;
END;

