create
    definer = admin@`%` function get_page_heading_for_field(p_form_id int, p_field_order int) returns varchar(1000)
BEGIN

    DECLARE v_page_heading varchar(1000);

    SELECT name
    INTO v_page_heading
    FROM portal.cl_frm_fields
    WHERE form_id = p_form_id
      AND field_order < p_field_order
      AND `type` LIKE 'html'
      AND `description` LIKE '%heading%'
      AND !api.api_is_blank(name)
    ORDER BY field_order DESC
    LIMIT 1;

    RETURN api.api_nz(v_page_heading, '');

END;

