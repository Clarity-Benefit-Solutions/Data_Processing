create definer = admin@`%` view vw_get_all_fields_for_form_prv as
select `t`.`form_id`                                                            AS `form_id`,
       `t`.`form_name`                                                          AS `form_name`,
       case
           when (`t`.`field_type` like 'html' and `t`.`field_description` like '%heading%') then `t`.`field_name`
           else '' end                                                          AS `page_name`,
       `t`.`field_name`                                                         AS `field_name`,
       case when `t`.`field_type` = 'divider' then `t`.`field_name` else '' end AS `repeater_name`,
       `t`.`field_order`                                                        AS `field_order`,
       `t`.`field_key`                                                          AS `field_key`,
       `t`.`field_id`                                                           AS `field_id`,
       `t`.`field_description`                                                  AS `field_description`,
       `t`.`field_default_value`                                                AS `field_default_value`,
       `t`.`fl_options`                                                         AS `fl_options`,
       `t`.`field_options`                                                      AS `field_options`,
       `t`.`field_required`                                                     AS `field_required`,
       `t`.`field_type`                                                         AS `field_type`
from (select `f`.`id`             AS `form_id`,
             `f`.`name`           AS `form_name`,
             `fl`.`id`            AS `field_id`,
             `fl`.`field_key`     AS `field_key`,
             `fl`.`name`          AS `field_name`,
             `fl`.`description`   AS `field_description`,
             `fl`.`type`          AS `field_type`,
             `fl`.`default_value` AS `field_default_value`,
             `fl`.`options`       AS `fl_options`,
             `fl`.`field_order`   AS `field_order`,
             `fl`.`required`      AS `field_required`,
             `fl`.`field_options` AS `field_options`
      from (`portal`.`cl_frm_fields` `fl`
               join `portal`.`cl_frm_forms` `f` on (`f`.`id` = `fl`.`form_id`))
      where `fl`.`type` <> 'hidden') `t`;

