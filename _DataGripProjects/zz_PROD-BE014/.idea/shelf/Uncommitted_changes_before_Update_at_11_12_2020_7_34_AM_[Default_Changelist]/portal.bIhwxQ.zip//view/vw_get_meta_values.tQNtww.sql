create definer = admin@`%` view vw_get_meta_values as
select `t`.`item_id`        AS `item_id`,
       `t`.`form_name`      AS `form_name`,
       `t`.`page_name`      AS `page_name`,
       `t`.`field_name`     AS `field_name`,
       `t`.`field_order`    AS `field_order`,
       case
           when `t`.`field_type` <> 'divider'
               then case when `t`.`original_value` = `t`.`current_value` then 0 else 1 end
           else 1 end       AS `value_has_changed`,
       `t`.`original_value` AS `original_value`,
       `t`.`current_value`  AS `current_value`,
       `t`.`field_id`       AS `field_id`,
       `t`.`form_id`        AS `form_id`,
       `t`.`field_type`     AS `field_type`
from (select `m`.`item_id`                                                                                         AS `item_id`,
             case
                 when (`f`.`type` like 'html' and `f`.`description` like '%heading%') then `f`.`name`
                 else '' end                                                                                       AS `page_name`,
             `f`.`name`                                                                                            AS `field_name`,
             `api`.`api_nz`(`m`.`meta_value`, '')                                                                  AS `current_value`,
             `api`.`api_nz`(`m`.`org_meta_value`, '')                                                              AS `original_value`,
             `m`.`field_id`                                                                                        AS `field_id`,
             `f`.`type`                                                                                            AS `field_type`,
             `fr`.`name`                                                                                           AS `form_name`,
             `f`.`field_order`                                                                                     AS `field_order`,
             `f`.`form_id`                                                                                         AS `form_id`
      from ((`portal`.`cl_frm_item_metas` `m` join `portal`.`cl_frm_fields` `f` on (`m`.`field_id` = `f`.`id`))
               join `portal`.`cl_frm_forms` `fr` on (`f`.`form_id` = `fr`.`id`))
      where `f`.`type` <> 'hidden') `t`;

