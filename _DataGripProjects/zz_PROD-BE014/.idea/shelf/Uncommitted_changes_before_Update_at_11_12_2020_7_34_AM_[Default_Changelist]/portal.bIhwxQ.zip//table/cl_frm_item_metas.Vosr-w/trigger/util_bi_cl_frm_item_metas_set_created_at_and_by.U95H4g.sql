create definer = admin@`%` trigger util_bi_cl_frm_item_metas_set_created_at_and_by
    before insert
    on cl_frm_item_metas
    for each row
BEGIN
    SET new.created_at = CURRENT_TIMESTAMP;
    SET new.created_by = current_user;
END;

