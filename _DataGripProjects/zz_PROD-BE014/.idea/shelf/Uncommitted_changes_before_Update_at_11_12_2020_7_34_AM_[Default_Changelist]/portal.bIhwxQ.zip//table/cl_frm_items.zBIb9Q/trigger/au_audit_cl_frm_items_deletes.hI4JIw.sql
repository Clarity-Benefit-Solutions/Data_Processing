create definer = admin@`%` trigger au_audit_cl_frm_items_deletes
    after delete
    on cl_frm_items
    for each row
    INSERT INTO `portal`.`cl_frm_items_audit`
                 (`auditAction`,`id`,`item_key`,`name`,`description`,`ip`,`form_id`,`post_id`,`user_id`,`parent_item_id`,`is_draft`,`updated_by`,`created_at`,`updated_at`,`created_by`)
                 VALUES
                 ('DELETE',OLD.`id`,OLD.`item_key`,OLD.`name`,OLD.`description`,OLD.`ip`,OLD.`form_id`,OLD.`post_id`,OLD.`user_id`,OLD.`parent_item_id`,OLD.`is_draft`,OLD.`updated_by`,OLD.`created_at`,OLD.`updated_at`,OLD.`created_by`);

