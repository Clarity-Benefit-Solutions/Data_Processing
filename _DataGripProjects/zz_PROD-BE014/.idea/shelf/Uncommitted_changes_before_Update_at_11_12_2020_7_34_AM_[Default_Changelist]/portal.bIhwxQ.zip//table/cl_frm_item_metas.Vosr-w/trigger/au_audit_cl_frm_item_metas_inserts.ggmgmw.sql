create definer = admin@`%` trigger au_audit_cl_frm_item_metas_inserts
    after insert
    on cl_frm_item_metas
    for each row
    INSERT INTO `portal`.`cl_frm_item_metas_audit`
                 (`auditAction`, `id`, `meta_value`, `field_id`, `item_id`, `org_meta_value`,
                  `org_meta_values_updated_at`, `created_at`, `created_by`, `updated_at`, `updated_by`)
                 VALUES ('INSERT', NEW.`id`, NEW.`meta_value`, NEW.`field_id`, NEW.`item_id`, NEW.`org_meta_value`,
                         NEW.`org_meta_values_updated_at`, NEW.`created_at`, NEW.`created_by`, NEW.`updated_at`,
                         NEW.`updated_by`);

