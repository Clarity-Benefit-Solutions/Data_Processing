create definer = admin@`%` trigger util_bu_cl_signups_set_updated_at_and_by
    before update
    on cl_signups
    for each row
BEGIN
    SET new.updated_at = CURRENT_TIMESTAMP;
    SET new.updated_by = current_user;
END;

