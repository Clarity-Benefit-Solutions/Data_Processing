create definer = admin@`%` trigger au_audit_cl_frm_fields_inserts
    after insert
    on cl_frm_fields
    for each row
    INSERT INTO `portal`.`cl_frm_fields_audit`
                 (`auditAction`,`id`,`field_key`,`name`,`description`,`type`,`default_value`,`options`,`field_order`,`required`,`field_options`,`form_id`,`created_at`,`created_by`,`updated_at`,`updated_by`)
                 VALUES
                 ('INSERT',NEW.`id`,NEW.`field_key`,NEW.`name`,NEW.`description`,NEW.`type`,NEW.`default_value`,NEW.`options`,NEW.`field_order`,NEW.`required`,NEW.`field_options`,NEW.`form_id`,NEW.`created_at`,NEW.`created_by`,NEW.`updated_at`,NEW.`updated_by`);

