create definer = admin@`%` trigger util_bu_cl_term_taxonomy_set_updated_at_and_by
    before update
    on cl_term_taxonomy
    for each row
BEGIN
    SET new.updated_at = CURRENT_TIMESTAMP;
    SET new.updated_by = current_user;
END;

