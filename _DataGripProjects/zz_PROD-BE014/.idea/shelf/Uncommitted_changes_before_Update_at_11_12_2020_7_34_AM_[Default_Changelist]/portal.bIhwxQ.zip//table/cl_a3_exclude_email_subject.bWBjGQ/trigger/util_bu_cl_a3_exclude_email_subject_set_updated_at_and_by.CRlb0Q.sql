create definer = admin@`%` trigger util_bu_cl_a3_exclude_email_subject_set_updated_at_and_by
    before update
    on cl_a3_exclude_email_subject
    for each row
BEGIN
    SET new.updated_at = CURRENT_TIMESTAMP;
    SET new.updated_by = current_user;
END;

