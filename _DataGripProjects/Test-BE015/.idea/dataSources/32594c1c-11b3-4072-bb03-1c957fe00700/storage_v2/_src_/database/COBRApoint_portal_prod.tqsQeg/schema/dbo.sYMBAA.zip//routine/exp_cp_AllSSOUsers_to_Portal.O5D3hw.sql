create PROCEDURE [dbo].[exp_cp_AllSSOUsers_to_Portal](
    @p_only_for_email nvarchar(200) = '%' ) AS
BEGIN
    DECLARE @msg1 nvarchar(max)
    --
    declare @usetransaction int = 1;
    DECLARE @rowno int = 0
    DECLARE @combinerows int = 25
    DECLARE @batch int = 100
    
    /**/
    DECLARE @upsertsql nvarchar(max);
    DECLARE @orderseq nvarchar(500);
    DECLARE @entitytype nvarchar(500);
    DECLARE @memberid nvarchar(500);
    DECLARE @brokerid nvarchar(500);
    DECLARE @clientcontactid nvarchar(500);
    DECLARE @clientid nvarchar(500);
    DECLARE @clientdivisionid nvarchar(500);
    DECLARE @organizationname nvarchar(500);
    DECLARE @organizationisactive nvarchar(500);
    DECLARE @divisionname nvarchar(500);
    DECLARE @individualidentifier nvarchar(500);
    DECLARE @contacttype nvarchar(500);
    DECLARE @salutation nvarchar(500);
    DECLARE @firstname nvarchar(500);
    DECLARE @lastname nvarchar(500);
    DECLARE @email nvarchar(500);
    DECLARE @title nvarchar(500);
    DECLARE @department nvarchar(500);
    DECLARE @phone nvarchar(500);
    DECLARE @phone2 nvarchar(500);
    DECLARE @city nvarchar(500);
    DECLARE @state nvarchar(500);
    DECLARE @postalcode nvarchar(500);
    DECLARE @country nvarchar(500);
    DECLARE @active nvarchar(500);
    DECLARE @loginstatus nvarchar(500);
    DECLARE @registrationcode nvarchar(500);
    DECLARE @registrationdate nvarchar(500);
    DECLARE @userdisplayname nvarchar(500);
    DECLARE @allowsso nvarchar(500);
    DECLARE @ssoidentifier nvarchar(500);
    DECLARE @userid nvarchar(500);
    DECLARE @ssn nvarchar(500);
    DECLARE @dob nvarchar(500);
    DECLARE @employerid nvarchar(500);
    DECLARE @employeeid nvarchar(500);
    
    DECLARE db_cursor CURSOR FOR SELECT
                                     [OrderSeq]
                                   , [entitytype]
                                   , [MemberID]
                                   , [BrokerID]
                                   , [ClientContactID]
                                   , [ClientID]
                                   , [ClientDivisionID]
                                   , organizationname
                                   , organizationisactive
                                   , divisionname
                                   , [IndividualIdentifier]
                                   , [ContactType]
                                   , [Salutation]
                                   , [FirstName]
                                   , [LastName]
                                   , [email]
                                   , [Title]
                                   , [Department]
                                   , [Phone]
                                   , [Phone2]
                                   , [City]
                                   , [State]
                                   , [PostalCode]
                                   , [Country]
                                   , [Active]
                                   , [LoginStatus]
                                   , [RegistrationCode]
                                   , format( registrationdate , 'yyyy-MM-dd hh:mm:ss' ) registrationdate
                                   , [UserDisplayName]
                                   , [AllowSSO]
                                   , [SSOIdentifier]
                                   , [UserId]
                                   , [SSN]
                                   , [EmployeeID]
                                   , format( dob , 'yyyy-MM-dd' ) dob
                                   , employerid
                                 FROM
                                     [COBRApoint_portal_prod].dbo.allssousers
                                 where
                                     isnull( email , '' ) like isnull( @p_only_for_email , '%' )
                                 ORDER BY
                                     [OrderSeq] ASC
                                   , [entitytype]
                                   , [MemberID]
                                   , [BrokerID]
                                   , [ClientContactID]
                                   , [ClientID]
                                   , [ClientDivisionID];
    
    exec db_log_message 'exp_cp_AllSSOUsers_to_Portal' , ' OPENING CURSOR' , 'INFO';
    /**/
    OPEN db_cursor
    /**/
    FETCH NEXT FROM db_cursor INTO @orderseq, @entitytype, @memberid, @brokerid, @clientcontactid, @clientid, @clientdivisionid, @organizationname, @organizationisactive, @divisionname, @individualidentifier, @contacttype, @salutation, @firstname, @lastname, @email, @title, @department, @phone, @phone2, @city, @state, @postalcode, @country, @active, @loginstatus, @registrationcode, @registrationdate, @userdisplayname, @allowsso, @ssoidentifier, @userid, @ssn, @employeeid, @dob, @employerid;
    /**/
    set @upsertsql = '';
    if @usetransaction > 0
        begin
            EXEC ('SET autocommit = 0;') AT portal_prod;
        end
    else
        begin
            EXEC ('SET autocommit = 1;') AT portal_prod;
        end
    
    if @usetransaction > 0
        begin
            EXEC ('START TRANSACTION;') AT portal_prod;
        end
    
    /**/
    WHILE @@FETCH_STATUS = 0 BEGIN
        set @rowno = @rowno + 1;
        
        set @upsertsql = concat( @upsertsql , 'call cp.upsert_cp_all_sso_users(' , '' );
        /**/
        
        set @upsertsql = concat( @upsertsql , dbo.buildsqlforparam( @orderseq , 0 ) , ',' );
        set @upsertsql = concat( @upsertsql , dbo.buildsqlforparam( @entitytype , 0 ) , ',' );
        set @upsertsql = concat( @upsertsql , dbo.buildsqlforparam( @memberid , 1 ) , ',' );
        set @upsertsql = concat( @upsertsql , dbo.buildsqlforparam( @brokerid , 1 ) , ',' );
        set @upsertsql = concat( @upsertsql , dbo.buildsqlforparam( @clientcontactid , 1 ) , ',' );
        set @upsertsql = concat( @upsertsql , dbo.buildsqlforparam( @clientid , 1 ) , ',' );
        set @upsertsql = concat( @upsertsql , dbo.buildsqlforparam( @divisionname , 0 ) , ',' );
        set @upsertsql = concat( @upsertsql , dbo.buildsqlforparam( @organizationname , 0 ) , ',' );
        set @upsertsql = concat( @upsertsql , dbo.buildsqlforparam( @organizationisactive , 1 ) , ',' );
        set @upsertsql = concat( @upsertsql , dbo.buildsqlforparam( @clientdivisionid , 1 ) , ',' );
        set @upsertsql = concat( @upsertsql , dbo.buildsqlforparam( @individualidentifier , 0 ) , ',' );
        set @upsertsql = concat( @upsertsql , dbo.buildsqlforparam( @contacttype , 0 ) , ',' );
        set @upsertsql = concat( @upsertsql , dbo.buildsqlforparam( @salutation , 0 ) , ',' );
        set @upsertsql = concat( @upsertsql , dbo.buildsqlforparam( @firstname , 0 ) , ',' );
        set @upsertsql = concat( @upsertsql , dbo.buildsqlforparam( @lastname , 0 ) , ',' );
        set @upsertsql = concat( @upsertsql , dbo.buildsqlforparam( @email , 0 ) , ',' );
        set @upsertsql = concat( @upsertsql , dbo.buildsqlforparam( @title , 0 ) , ',' );
        set @upsertsql = concat( @upsertsql , dbo.buildsqlforparam( @department , 0 ) , ',' );
        set @upsertsql = concat( @upsertsql , dbo.buildsqlforparam( @phone , 0 ) , ',' );
        set @upsertsql = concat( @upsertsql , dbo.buildsqlforparam( @phone2 , 0 ) , ',' );
        set @upsertsql = concat( @upsertsql , dbo.buildsqlforparam( @city , 0 ) , ',' );
        set @upsertsql = concat( @upsertsql , dbo.buildsqlforparam( @state , 0 ) , ',' );
        set @upsertsql = concat( @upsertsql , dbo.buildsqlforparam( @postalcode , 0 ) , ',' );
        set @upsertsql = concat( @upsertsql , dbo.buildsqlforparam( @country , 0 ) , ',' );
        set @upsertsql = concat( @upsertsql , dbo.buildsqlforparam( @active , 1 ) , ',' );
        set @upsertsql = concat( @upsertsql , dbo.buildsqlforparam( @loginstatus , 0 ) , ',' );
        set @upsertsql = concat( @upsertsql , dbo.buildsqlforparam( @registrationcode , 0 ) , ',' );
        set @upsertsql = concat( @upsertsql , dbo.buildsqlforparam( @registrationdate , 0 ) , ',' );
        set @upsertsql = concat( @upsertsql , dbo.buildsqlforparam( @userdisplayname , 0 ) , ',' );
        set @upsertsql = concat( @upsertsql , dbo.buildsqlforparam( @allowsso , 1 ) , ',' );
        set @upsertsql = concat( @upsertsql , dbo.buildsqlforparam( @ssoidentifier , 0 ) , ',' );
        set @upsertsql = concat( @upsertsql , dbo.buildsqlforparam( @userid , 0 ) , ',' );
        set @upsertsql = concat( @upsertsql , dbo.buildsqlforparam( @ssn , 0 ) , ',' );
        set @upsertsql = concat( @upsertsql , dbo.buildsqlforparam( @employeeid , 0 ) , ',' );
        set @upsertsql = concat( @upsertsql , dbo.buildsqlforparam( @dob , 0 ) , ',' );
        set @upsertsql = concat( @upsertsql , dbo.buildsqlforparam( @employerid , 0 )/* , ',' */);
        
        /**/
        set @upsertsql = concat( @upsertsql , ');' , char( 13 ) , char( 10 ) );
        /**/
        if @rowno % @combinerows = 0
            begin
                BEGIN TRY
                    
                    /*   set @msg1 = concat( @rowno , ' - ' , 'EXECUTING ' , @upsertsql );
                       exec db_log_message 'exp_cp_AllSSOUsers_to_Portal' , @msg1 , 'INFO';*/
                    
                    EXEC (@upsertsql) AT portal_prod;
                    set @upsertsql = '';
                    /**/
                end try begin catch
                    set @msg1 = concat( @rowno , ' - ' , 'ERROR: ' , error_message( ) , ' FOR SQL ' , @upsertsql );
                    exec db_log_error 50001 , 'exp_cp_AllSSOUsers_to_Portal' , @msg1 , 'ERROR';
                end catch
            end
        
        /**/
        if @rowno % @batch = 0
            begin
                set @msg1 = concat( 'COMMITING AT ROW # ' , @rowno )
                exec db_log_message 'exp_cp_AllSSOUsers_to_Portal' , @msg1 , 'INFO';
                --
                if @usetransaction > 0
                    begin
                        EXEC ('COMMIT;') AT portal_prod;
                        EXEC ('START TRANSACTION;') AT portal_prod;
                    end
            end
        
        /**/
        FETCH NEXT FROM db_cursor INTO @orderseq, @entitytype, @memberid, @brokerid, @clientcontactid, @clientid, @clientdivisionid, @organizationname, @organizationisactive, @divisionname, @individualidentifier, @contacttype, @salutation, @firstname, @lastname, @email, @title, @department, @phone, @phone2, @city, @state, @postalcode, @country, @active, @loginstatus, @registrationcode, @registrationdate, @userdisplayname, @allowsso, @ssoidentifier, @userid, @ssn, @employeeid, @dob, @employerid;
    END
    /* execute any sqls not adding up to batch count*/
    if @upsertsql <> ''
        begin
            /* set @msg1 = concat( @rowno , ' - ' , 'EXECUTING ' , @upsertsql );
             exec db_log_message 'exp_cp_AllSSOUsers_to_Portal' , @msg1 , 'INFO';
            */
            EXEC (@upsertsql) AT portal_prod;
            set @upsertsql = '';
        end
    /**/
    if @usetransaction > 0
        begin
            set @msg1 = concat( 'COMMITING FINALLY AT ROW # ' , @rowno )
            exec db_log_message 'exp_cp_AllSSOUsers_to_Portal' , @msg1 , 'INFO';
            --
            EXEC ('COMMIT;') AT portal_prod;
        end
    
    /**/
    CLOSE db_cursor
    DEALLOCATE db_cursor
    
    /**/
    
    SET @msg1 = CONCAT( '**LOG** ' , 'exp_cp_AllSSOUsers_to_Portal' , ' FINISHED INSERTED ROW COUNT: ' , @rowno );
    RAISERROR (@msg1, 0, 1) WITH NOWAIT

END;
go

