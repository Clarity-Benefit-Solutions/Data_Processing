create VIEW [dbo].[AdminTPAUser]
AS
SELECT        UserID, UserName
FROM            [SalesForce_COBRA].dbo.AdminTPAUsers
go

