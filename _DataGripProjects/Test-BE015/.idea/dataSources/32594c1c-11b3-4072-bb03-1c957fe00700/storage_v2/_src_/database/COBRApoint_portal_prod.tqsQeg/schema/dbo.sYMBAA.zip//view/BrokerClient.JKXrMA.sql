



create VIEW [dbo].BrokerClient
AS
SELECT       *
FROM            [SalesForce_COBRA].dbo.BrokerClient


go

