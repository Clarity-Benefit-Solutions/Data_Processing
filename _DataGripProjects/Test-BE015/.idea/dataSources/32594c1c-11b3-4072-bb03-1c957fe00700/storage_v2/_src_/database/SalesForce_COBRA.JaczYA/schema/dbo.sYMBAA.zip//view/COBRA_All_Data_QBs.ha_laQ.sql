

CREATE VIEW [dbo].[COBRA_All_Data_QBs]
AS


SELECT        dbo.Client.ClientAlternate AS CompanyIdentifier, dbo.ClientDivision.DivisionName AS Division, dbo.QB.FirstName, dbo.QB.LastName, 
                         replace(dbo.QB.SSN,'-','') AS EmployeeID, replace(dbo.QB.SSN,'-','') as SSN, CASE WHEN qb.[Active] = 1 THEN 'Active' ELSE 'Termed' END AS EmploymentStatus, dbo.QB.Address1, 
                         dbo.QB.Address2, dbo.QB.City, dbo.QB.State,  ''+ dbo.QB.PostalCode + '' AS ZIP, dbo.QB.Phone, dbo.QB.Email, 
                         dbo.QB.DOB, 'True' AS CobraParticipant
FROM            dbo.QB INNER JOIN
                         dbo.Client ON dbo.QB.ClientID = dbo.Client.ClientID INNER JOIN
                         dbo.ClientDivision ON dbo.QB.ClientID = dbo.ClientDivision.ClientID AND 
                         dbo.QB.ClientDivisionID = dbo.ClientDivision.ClientDivisionID

where dbo.Client.ClientAlternate is not null


go

