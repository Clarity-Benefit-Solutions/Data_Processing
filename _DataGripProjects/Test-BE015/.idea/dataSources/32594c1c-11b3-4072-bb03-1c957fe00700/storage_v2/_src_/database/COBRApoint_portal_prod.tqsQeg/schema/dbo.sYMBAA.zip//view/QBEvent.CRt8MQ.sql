CREATE VIEW [dbo].[QBEvent]
AS
SELECT        *
FROM            SalesForce_COBRA.dbo.QBEvent
go

