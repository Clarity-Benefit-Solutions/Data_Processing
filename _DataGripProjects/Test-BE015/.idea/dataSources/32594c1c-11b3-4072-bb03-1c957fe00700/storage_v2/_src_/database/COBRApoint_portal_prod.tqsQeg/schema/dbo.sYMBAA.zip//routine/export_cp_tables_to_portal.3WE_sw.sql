CREATE
    PROCEDURE [dbo].[export_cp_tables_to_portal] AS
BEGIN
   exec dbo.exp_cp_AllSSOUsers_to_Portal '%';
END;
go

