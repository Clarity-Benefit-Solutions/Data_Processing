
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].FixBool
(
	-- Add the parameters for the function here
	@value DateTime
)
RETURNS integer
AS
BEGIN
	-- Declare the return variable here
	return isnull(abs(cast( @value as integer)),0);



END


go

