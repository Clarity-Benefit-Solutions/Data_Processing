create  PROCEDURE [dbo].[exp_cp_AllSSOUsers_to_Portal_PRV] AS
BEGIN
    DECLARE @msg1 nvarchar(max)
    
    SET @msg1 = CONCAT( '**LOG** ' , 'exp_AllSSOUsers' , ' starting cp.truncate_cp_all(1)' );
    RAISERROR (@msg1, 0, 1) WITH NOWAIT
    /*
    EXEC ('SET autocommit = 0;') AT portal_prod;
    EXEC ('START TRANSACTION;') AT portal_prod;
    EXEC ('COMMIT;') AT portal_prod;
*/
    EXEC ('call cp.truncate_cp_all(1);') AT portal_prod;
    
    SET @msg1 = CONCAT( '**LOG** ' , 'exp_AllSSOUsers' , ' CALLED cp.truncate_cp_all(1)' );
    RAISERROR (@msg1, 0, 1) WITH NOWAIT
    
    --
    DECLARE @iterator int = 0
    DECLARE @batch int = 200
    DECLARE @n int = (
                         SELECT
                             COUNT( * )
                         FROM
                             [COBRApoint_portal_prod].dbo.allssousers
                     )
    
    WHILE @iterator < @n BEGIN
        PRINT CONCAT( GETDATE( ) , ' -- ' , 'exp_AllSSOUsers: Batch ' , @batch , ', offset: ' , @iterator );
        
        -- BEGIN TRANSACTION;
        SET @msg1 = CONCAT( '**LOG** ' , 'exp_AllSSOUsers' , ' INSERTING ' , @batch , ' ROWS AT OFFSET' , @iterator );
        RAISERROR (@msg1, 0, 1) WITH NOWAIT
        
        INSERT INTO OPENQUERY (
                              portal_prod,
                              'Select
                                   OrderSeq
                                   ,entitytype
                                   ,MemberID
                                   ,BrokerID
                                   ,ClientContactID
                                   ,ClientID
                                   ,ClientDivisionID
                                   , OrganizationName ,OrganizationIsActive
                                   , DivisionName
                                   ,IndividualIdentifier
                                   ,ContactType
                                   ,Salutation
                                   ,FirstName
                                   ,LastName
                                   ,email
                                   ,Title
                                   ,Department
                                   ,Phone
                                   ,Phone2
                                   ,City
                                   ,State
                                   ,PostalCode
                                   ,Country
                                   ,Active
                                   ,LoginStatus
                                   ,RegistrationCode
                                   ,RegistrationDate
                                   ,UserDisplayName
                                   ,AllowSSO
                                   ,SSOIdentifier
                                   ,UserId
                                   ,SSN
                                   ,EmployeeID from cp.cp_all_sso_users'
        )
        SELECT
            [OrderSeq]
          , [entitytype]
          , [MemberID]
          , [BrokerID]
          , [ClientContactID]
          , [ClientID]
          , [ClientDivisionID]
          , organizationname
          , organizationisactive
          , divisionname
          , [IndividualIdentifier]
          , [ContactType]
          , [Salutation]
          , [FirstName]
          , [LastName]
          , [email]
          , [Title]
          , [Department]
          , [Phone]
          , [Phone2]
          , [City]
          , [State]
          , [PostalCode]
          , [Country]
          , [Active]
          , [LoginStatus]
          , [RegistrationCode]
          , [RegistrationDate]
          , [UserDisplayName]
          , [AllowSSO]
          , [SSOIdentifier]
          , [UserId]
          , [SSN]
          , [EmployeeID]
        FROM
            [COBRApoint_portal_prod].dbo.allssousers
        ORDER BY
            [OrderSeq] DESC
          , [entitytype]
          , [MemberID]
          , [BrokerID]
          , [ClientContactID]
          , [ClientID]
          , [ClientDivisionID]
        OFFSET @iterator ROWS FETCH NEXT @batch ROWS ONLY;
        
        SET @iterator += @batch;
        
        -- COMMIT;
    END;
    
    SET @msg1 = CONCAT( '**LOG** ' , 'exp_AllSSOUsers' , ' FINISHED INSERTED ALL ROWS' );
    RAISERROR (@msg1, 0, 1) WITH NOWAIT

END;
go

