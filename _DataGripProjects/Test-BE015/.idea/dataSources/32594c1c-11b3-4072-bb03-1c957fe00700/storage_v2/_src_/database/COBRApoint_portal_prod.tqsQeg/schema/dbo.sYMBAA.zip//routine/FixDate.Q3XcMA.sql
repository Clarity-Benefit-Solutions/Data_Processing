

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[FixDate]
(
	-- Add the parameters for the function here
	@value DateTime
)
RETURNS nvarchar(19)
AS
BEGIN
	-- Declare the return variable here
	return FORMAT (@value, 'yyyy-MM-dd hh:mm:ss')  



END


go

