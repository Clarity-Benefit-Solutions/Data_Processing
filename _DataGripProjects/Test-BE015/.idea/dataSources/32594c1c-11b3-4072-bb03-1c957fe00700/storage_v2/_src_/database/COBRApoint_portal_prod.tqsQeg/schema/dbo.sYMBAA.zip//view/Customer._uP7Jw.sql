


create VIEW [dbo].[Customer]
AS
SELECT       *
FROM            [SalesForce_COBRA].dbo.[Customer]
go

