

CREATE  VIEW [dbo].[QBPlan]
AS
SELECT      *
FROM            SalesForce_COBRA.dbo.QBPlan

go

