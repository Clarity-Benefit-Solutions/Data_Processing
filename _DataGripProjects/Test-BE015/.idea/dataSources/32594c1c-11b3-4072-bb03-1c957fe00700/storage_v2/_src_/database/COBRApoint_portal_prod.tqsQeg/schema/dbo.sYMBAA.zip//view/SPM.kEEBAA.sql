
CREATE VIEW [dbo].[SPM]
AS
SELECT        MemberID, ClientDivisionID, dbo.FixBool(Active) AS Active, EnteredDateTime, EnteredByUser, ClientID, Salutation, FirstName, MiddleInitial, LastName, IndividualID, Email, Phone, Phone2, Address1, Address2, City, State, PostalCode, 
                         Country, Gender, DOB, TobaccoUse, EmployeeType, PayrollType, YearsOfService, PremiumCouponType,  dbo.FixBool(CurrentlyHasCOBRARights) as CurrentlyHasCOBRARights,  dbo.FixBool(WillHaveCOBRARightsOnTermination) as WillHaveCOBRARightsOnTermination, dbo.FixDate(BillingStartDate) as BillingStartDate, dbo.FixDate(BillingEndDate) as BillingEndDate, 
                         BillingFrequency, BillingType,  dbo.FixBool(IsSPMLegacy) as IsSPMLegacy,  dbo.FixBool(Migrated)as Migrated, dbo.FixDate(HIPAAEnrollmentDate) as HIPAAEnrollmentDate, GracePeriodNumberOfDays, MethodEntered, dbo.FixDate(PaidThroughDate) as PaidThroughDate, BenefitGroup, AccountStructure, ClientCustomData, 
                         dbo.FixBool(AllowSSO) AS AllowSSO, SSOIdentifier, dbo.FixDate(LastModifiedDate) as LastModifiedDate, PlanCategory, dbo.FixDate(InitialGracePeriodDate) as InitialGracePeriodDate, InitialGracePeriodDays, SPMInitialGracePeriodOptionType, SSN
FROM            SalesForce_COBRA.dbo.SPM AS SPM_1

go

exec sp_addextendedproperty 'MS_DiagramPane1' , N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[40] 4[20] 2[20] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
         Begin Table = "SPM_1"
            Begin Extent = 
               Top = 6
               Left = 38
               Bottom = 136
               Right = 327
            End
            DisplayFlags = 280
            TopColumn = 0
         End
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 11
         Column = 1440
         Alias = 900
         Table = 1170
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
' , 'SCHEMA' , 'dbo' , 'VIEW' , 'SPM'
go

exec sp_addextendedproperty 'MS_DiagramPaneCount' , 1 , 'SCHEMA' , 'dbo', 'VIEW', 'SPM'
go

