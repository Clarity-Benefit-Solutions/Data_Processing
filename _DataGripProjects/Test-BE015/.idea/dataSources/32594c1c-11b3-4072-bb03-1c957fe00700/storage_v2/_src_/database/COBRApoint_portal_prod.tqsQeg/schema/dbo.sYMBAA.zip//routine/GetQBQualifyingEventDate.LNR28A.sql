-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
    CREATE FUNCTION [dbo].GetQBQualifyingEventDate(
    -- Add the parameters for the function here
    @memberId integer
    )
    RETURNS date
    AS
    BEGIN
        DECLARE @eventDate date;
        
        SELECT TOP 1
            @eventDate = EventDate
        FROM
            dbo.QBEvent
        WHERE
              MemberID = @memberId
        /*  AND EventType IN (
                            'DEATH',
                            'REDUCTIONINFORCE',
                            'REDUCTIONINHOURS-ENDOFLEAVE',
                            'REDUCTIONINHOURS-STATUSCHANGE',
                            'TERMINATION',
                            'TERMINATIONWITHSEVERANCE',
                            'USERRA-REDUCTIONINHOURS',
                            'USERRA-TERMINATION',
                            'DIVORCELEGALSEPARATION',
                            'INELIGIBLEDEPENDENT',
                            'INVOLUNTARYTERMINATION',
                            'LOSSOFELIGIBILITY',
                            'MEDICARE',
                            'RETIREMENT',
                            'STATECONTINUATION',
                            'WORKSTOPPAGE'
            )*/
       /* ORDER BY
            EventDate ASC*/;
        
        RETURN @eventDate;
    
    END
go

