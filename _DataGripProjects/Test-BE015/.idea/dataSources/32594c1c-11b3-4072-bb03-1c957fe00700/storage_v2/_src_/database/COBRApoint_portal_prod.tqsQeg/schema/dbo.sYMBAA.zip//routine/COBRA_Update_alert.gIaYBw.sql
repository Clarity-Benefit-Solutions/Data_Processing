

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[COBRA_Update_alert] 

AS


BEGIN
	declare @maxupdate as varchar(250) 	
	set @maxupdate = 'COBRA refresh Alert, latest date ' + (select cast(max(DateEntered) as varchar(50)) from [SalesForce_COBRA].dbo.NPM)
	select @maxupdate
	EXEC msdb.dbo.sp_send_dbmail  
    @profile_name = 'Email Alert System',  
    --@recipients = 'dkaelin@claritybenefitsolutions.com;jwendt@claritybenefitsolutions.com;lbujnowski@claritybenefitsolutions.com;KBeacham@claritybenefitsolutions.com;dkasperan@claritybenefitsolutions.com', 
	@recipients = 'dkaelin@claritybenefitsolutions.com',   
    @body = @maxupdate,  
    @subject = 'COBRA refresh Alert' ;  
END


go

