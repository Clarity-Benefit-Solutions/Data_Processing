create   view vw_statement_design_view
as
    select *
    from
        (
            /* dont show those lines that came from statement_details_add (broker_status = Appended*/
            select
                DETAIL_ID
              , HEADER_ID
              , INVOICE_DATE
              , INVOICE_NUM
              , QB_CLIENT_NAME
              , CLIENT_NAME
              , BROKER_ID
              , BROKER_NAME
              , QB_FEE
              , FEE_MEMO
              , QUANTITY
              , COMMISSION_RATE
              , UNIT
              , STATUS
              , SALES_PRICE
              , TOTAL_PRICE
              , START_DATE
              , BROKER_STATUS
              , OPEN_BALANCE
              , month
              , year
              , line_payment_status
              , created_at
              , created_by
            from
                dbo.STATEMENT_DETAILS
            where
                  BROKER_STATUS != 'Appended'
              and line_payment_status in ('paid', 'pending')
            union all
            /* showe all lines from statement_details_add*/
            select
                DETAIL_ID
              , HEADER_ID
              , START_DATE INVOICE_DATE
              , left( concat( BROKER_ID , '-' , DETAIL_ID , '-' , START_DATE ) , 49 ) INVOICE_NUM
              , QB_CLIENT_NAME
              , CLIENT_NAME
              , BROKER_ID
              , BROKER_NAME
              , QB_FEE
              , FEE_MEMO
              , QUANTITY
              , COMMISSION_RATE
              , UNIT
              , STATUS
              , SALES_PRICE
              , TOTAL_PRICE
              , START_DATE
              , BROKER_STATUS
              , 0
              , null month
              , null year
              , 'Appended' line_payment_status
              , created_at
              , created_by
            
            from
                dbo.STATEMENT_DETAILS_ADD
        
        ) t
go

