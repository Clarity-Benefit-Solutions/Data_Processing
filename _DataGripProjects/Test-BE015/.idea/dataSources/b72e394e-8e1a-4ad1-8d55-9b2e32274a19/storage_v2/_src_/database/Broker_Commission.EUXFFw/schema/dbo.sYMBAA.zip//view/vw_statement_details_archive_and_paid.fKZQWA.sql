create view vw_statement_details_archive_and_paid
as
    select
        da.*
      , si.OPEN_BALANCE as PaidOpenBalance
      , si.COMMISSION_PAID as PaidCommission
      , si.DATE_PAID as PaidDate
      , si.BROKER_ID as PaidBrokerId
      , si.month PaidMonth
      , si.year PaidYear
    from
        dbo.STATEMENT_DETAILS_ARCHIVE da
            left join SENT_INVOICE si on da.INVOICE_NUM = si.INVOICE_NUM
go

