CREATE VIEW dbo.RESwithnoMBIrecords
    AS
        SELECT DISTINCT TOP (100) PERCENT
            r.mbi_file_name
        FROM
            dbo.res_file_table AS r
                LEFT OUTER JOIN
                dbo.mbi_file_table AS m ON m.mbi_file_name = r.mbi_file_name
        WHERE
              (m.mbi_file_name IS NULL)
          AND (r.mbi_file_name IS NOT NULL)
go

