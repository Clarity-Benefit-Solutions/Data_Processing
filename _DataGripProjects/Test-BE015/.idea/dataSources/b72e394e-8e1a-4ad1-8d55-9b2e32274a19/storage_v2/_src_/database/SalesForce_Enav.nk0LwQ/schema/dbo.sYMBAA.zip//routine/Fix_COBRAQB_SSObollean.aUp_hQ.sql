-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[Fix_COBRAQB_SSObollean]

AS
BEGIN
	

  /****** Script for SelectTopNRows command from SSMS  ******/
    --SELECT [QB_data],case when len(substring(ltrim(rtrim([QB_data])),charindex('COUPONBOOK,',ltrim(rtrim([QB_data])),1),300)) < 23
	   --              then ltrim(rtrim([QB_data])) + ',FALSE' else [QB_data] end as test
    
	update  [dbo].[QB_file_data_fixtbl]
	  set [qb_data] = ltrim(rtrim([QB_data])) + ',TRUE'
	  FROM [dbo].[QB_file_data_fixtbl]
	  where [qb_data] like '%QB]%'
	    and len(substring(ltrim(rtrim([QB_data])),charindex('COUPONBOOK,',ltrim(rtrim([QB_data])),1),300)) < 23
END
go

