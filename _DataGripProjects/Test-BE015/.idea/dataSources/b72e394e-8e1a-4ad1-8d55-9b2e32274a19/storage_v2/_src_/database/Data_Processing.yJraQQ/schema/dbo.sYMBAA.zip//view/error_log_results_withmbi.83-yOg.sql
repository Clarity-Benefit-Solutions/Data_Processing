CREATE VIEW dbo.[error_log_results_withmbi]
    AS
        SELECT
            e.mbi_file_name
          , e.res_file_name
          , e.row_num error_row_num
          , m.row_num mbi_row_num
          , e.row_type
          , m.data_row mbi_line
          , e.error_row
          , e.error_code
          , e.error_message
          , e.EmployerId
          , e.EmployeeID
          , e.DependentID
          , e.PlanId
        FROM
            dbo.error_log_results
                AS e
                Left JOIN
                dbo.mbi_file_table AS m ON e.mbi_file_name = m.mbi_file_name
                    --                     AND (e.EmployerId = m.EmployerId and e.EmployeeID = m.EmployeeID and e.DependentID = m.DependentID)
                    and e.row_num = m.row_num
go

