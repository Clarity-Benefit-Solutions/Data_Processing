CREATE VIEW dbo.[CRM_Listview]
    AS
        SELECT distinct
            BENCODE
          , CRM
          , CRM_email
        FROM
            /*[Low_balance_reporting].dbo.[CRM_List_contacts]*/
            CRM_List
go

