CREATE 
 procedure dbo.SP_INSERT_SENT_INVOICE(
                                       @INVOICE_NUM varchar(500),
                                       @DATE_PAID datetime,
                                       @OPEN_BALANCE numeric(18, 2),
                                       @COMMISSION_PAID numeric(18, 2),
                                       @BROKER_ID int,
                                       @month varchar(50),
                                       @year int ) as
begin
    
    declare @id int;
    declare @msg varchar(max);
    
    SET NOCOUNT ON
    /* if fileLogId = 0 or processingTask = 'New', we will insert into main and detail tables
       else we will insert only into the detailed table
    */
    
    if isnull( @INVOICE_NUM , '' ) = ''
        begin
            THROW 51000, 'Invoice_Num Cannot be Empty', 1;
        end
    
    set @INVOICE_NUM = rtrim( ltrim( upper( @INVOICE_NUM ) ) );
    select top 1
        @id = id
    from
        dbo.SENT_INVOICE
    where
        INVOICE_NUM_FORMATTED = @INVOICE_NUM;
    
    if isnull( @id , 0 ) != 0
        begin
            set @msg = concat( 'Invoice_Num ' , @INVOICE_NUM , ' is already inserted in the table and marked as paid' );
            THROW 51000, @msg, 1;
        end
    
    insert into dbo.SENT_INVOICE(
                                INVOICE_NUM,
                                OPEN_BALANCE,
                                COMMISSION_PAID,
                                BROKER_ID,
                                month,
                                year,
                                DATE_PAID
    )
    values (
           @INVOICE_NUM,
           @OPEN_BALANCE,
           @COMMISSION_PAID,
           @BROKER_ID,
           @month,
           @year,
           @DATE_PAID
           );
    
    set @Id = SCOPE_IDENTITY( );
    /* return the header PK */
    select
        @id;
end;
go

