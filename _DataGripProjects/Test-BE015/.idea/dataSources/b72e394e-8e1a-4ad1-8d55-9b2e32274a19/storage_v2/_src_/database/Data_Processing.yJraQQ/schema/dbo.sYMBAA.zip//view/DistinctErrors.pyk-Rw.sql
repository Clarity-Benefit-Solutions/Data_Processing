CREATE VIEW dbo.DistinctErrors
    AS
        SELECT DISTINCT
            error_message
        FROM
            error_log_results
go

