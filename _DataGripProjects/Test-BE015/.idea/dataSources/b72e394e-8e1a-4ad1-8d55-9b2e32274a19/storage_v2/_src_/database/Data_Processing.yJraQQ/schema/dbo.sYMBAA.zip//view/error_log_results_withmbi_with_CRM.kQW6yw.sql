CREATE VIEW dbo.[error_log_results_withmbi_with_CRM]
    AS
        SELECT distinct
            dbo.CRM_Listview.CRM
          , dbo.CRM_Listview.CRM_email
          , mbi_file_name
          , res_file_name
          , row_type
          , error_row
          , error_code
          , error_message
          , EmployerId
          , EmployeeID
          , DependentID
          , PlanId
          , error_row_num
          , mbi_row_num
          , mbi_line
        FROM
            dbo.error_log_results_withmbi
                LEFT OUTER JOIN
                dbo.CRM_Listview ON dbo.error_log_results_withmbi.EmployerId = dbo.CRM_Listview.BENCODE
go

