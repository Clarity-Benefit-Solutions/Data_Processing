

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[Alegeus_ErrorLog_refreshsuccess_alert] 
	
AS
BEGIN
	EXEC msdb.dbo.sp_send_dbmail  
    @profile_name = 'Email Alert System',  
    --@recipients = 'dkaelin@claritybenefitsolutions.com;jwendt@claritybenefitsolutions.com;lbujnowski@claritybenefitsolutions.com;KBeacham@claritybenefitsolutions.com;dkasperan@claritybenefitsolutions.com', 
	@recipients = 'dkaelin@claritybenefitsolutions.com;dkasperan@claritybenefitsolutions.com',   
    @body = 'Alegeus error log daily refresh Successful',  
    @subject = 'Alegeus error log refresh Successful' ;  
END


go

