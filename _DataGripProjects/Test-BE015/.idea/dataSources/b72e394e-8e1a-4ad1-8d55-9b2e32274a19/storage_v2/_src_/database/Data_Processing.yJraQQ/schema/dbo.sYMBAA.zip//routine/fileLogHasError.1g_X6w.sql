create function fileLogHasError( @fileLogId int ) returns int
begin
    declare @cnt int = 0;
    select
        @cnt = count( * )
    from
        dbo.file_processing_tasks_log
    where
          fileLogId = @fileLogId
      and processingTaskOutcome = 'ERROR';
    
    return isnull( @cnt , 0 );
end
go

