create view Automated_Header_list as select * from FTP_Source_Folders;
go

