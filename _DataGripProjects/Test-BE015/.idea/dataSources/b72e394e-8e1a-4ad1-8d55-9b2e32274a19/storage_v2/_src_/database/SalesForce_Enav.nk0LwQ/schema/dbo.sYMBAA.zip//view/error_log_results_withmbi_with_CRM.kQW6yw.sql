CREATE VIEW dbo.[error_log_results_withmbi_with_CRM]
    AS
        SELECT distinct
            dbo.CRM_Listview.CRM
          , dbo.CRM_Listview.CRM_email
          , mbi_file_name
          , res_file_name
          , row_type
          , error_row
          , error_code
          , error_message
          , EmployerId
          , EmployeeID
          , DependentID
          , PlanId
          , error_row_num
          , mbi_row_num
          , mbi_line
        FROM
            dbo.error_log_results_withmbi
                LEFT OUTER JOIN
                dbo.CRM_Listview ON dbo.error_log_results_withmbi.EmployerId = dbo.CRM_Listview.BENCODE
go

declare @MS_DiagramPane_
Begin
    DesignProperties = = N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
exec sp_addextendedproperty 'MS_DiagramPane1', @MS_DiagramPane_, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi_with_CRM'
go

declare @___Begin_PaneConfigurations____         NumPanes = 4
=      Begin PaneConfiguration = 0
exec sp_addextendedproperty '
    Begin
        PaneConfigurations =
            ', @___Begin_PaneConfigurations____, ' SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi_with_CRM'
go

declare @_________Configuration_____H__________________________      Begin PaneConfiguration = 1
=      End
exec sp_addextendedproperty '         Configuration = "(H (1[40] 4[20] 2[20] 3) )"
', @_________Configuration_____H__________________________, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi_with_CRM'
go

declare @_________NumPanes_____      End
=         Configuration = "(H (1 [50] 4 [25] 3))"
exec sp_addextendedproperty '         NumPanes = 3
', @_________NumPanes_____, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi_with_CRM'
go

declare @______Begin_PaneConfiguration_____         Configuration = "(H (1 [50] 2 [25] 3))"
=         NumPanes = 3
exec sp_addextendedproperty '
        Begin
            PaneConfiguration = 2
', @______Begin_PaneConfiguration_____, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi_with_CRM'
go

declare @______End_         NumPanes = 3
=      Begin PaneConfiguration = 3
exec sp_addextendedproperty '
        End ', @______End_, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi_with_CRM'
go

declare @_________Configuration_____H_____________________      Begin PaneConfiguration = 4
=      End
exec sp_addextendedproperty '         Configuration = "(H (4 [30] 2 [40] 3))"
', @_________Configuration_____H_____________________, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi_with_CRM'
go

declare @_________NumPanes_____      End
=         Configuration = "(H (1 [56] 3))"
exec sp_addextendedproperty '         NumPanes = 2
', @_________NumPanes_____, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi_with_CRM'
go

declare @______Begin_PaneConfiguration_____         Configuration = "(H (2 [66] 3))"
=         NumPanes = 2
exec sp_addextendedproperty '
        Begin
            PaneConfiguration = 5
', @______Begin_PaneConfiguration_____, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi_with_CRM'
go

declare @______End_         NumPanes = 2
=      Begin PaneConfiguration = 6
exec sp_addextendedproperty '
        End ', @______End_, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi_with_CRM'
go

declare @_________Configuration_____H______________      Begin PaneConfiguration = 7
=      End
exec sp_addextendedproperty '         Configuration = "(H (4 [50] 3))"
', @_________Configuration_____H______________, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi_with_CRM'
go

declare @_________NumPanes_____      End
=         Configuration = "(V (3))"
exec sp_addextendedproperty '         NumPanes = 1
', @_________NumPanes_____, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi_with_CRM'
go

declare @______Begin_PaneConfiguration_____         Configuration = "(H (1[56] 4[18] 2) )"
=         NumPanes = 3
exec sp_addextendedproperty '
        Begin
            PaneConfiguration = 8
', @______Begin_PaneConfiguration_____, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi_with_CRM'
go

declare @______End_         NumPanes = 2
=      Begin PaneConfiguration = 9
exec sp_addextendedproperty '
        End ', @______End_, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi_with_CRM'
go

declare @_________Configuration_____H______________      Begin PaneConfiguration = 10
=      End
exec sp_addextendedproperty '         Configuration = "(H (1 [75] 4))"
', @_________Configuration_____H______________, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi_with_CRM'
go

declare @_________NumPanes_____      End
=         Configuration = "(H (1[66] 2) )"
exec sp_addextendedproperty '         NumPanes = 2
', @_________NumPanes_____, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi_with_CRM'
go

declare @______Begin_PaneConfiguration______         Configuration = "(H (4 [60] 2))"
=         NumPanes = 2
exec sp_addextendedproperty '
        Begin
            PaneConfiguration = 11
', @______Begin_PaneConfiguration______, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi_with_CRM'
go

declare @______End_         NumPanes = 1
=      Begin PaneConfiguration = 12
exec sp_addextendedproperty '
        End ', @______End_, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi_with_CRM'
go

declare @_________Configuration_____H________      Begin PaneConfiguration = 13
=      End
exec sp_addextendedproperty '         Configuration = "(H (1) )"
', @_________Configuration_____H________, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi_with_CRM'
go

declare @_________NumPanes_____      End
=         Configuration = "(V (4))"
exec sp_addextendedproperty '         NumPanes = 1
', @_________NumPanes_____, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi_with_CRM'
go

declare @______Begin_PaneConfiguration______         Configuration = "(V (2))"
=         NumPanes = 1
exec sp_addextendedproperty '
        Begin
            PaneConfiguration = 14
', @______Begin_PaneConfiguration______, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi_with_CRM'
go

declare @______End_   End
=      ActivePaneConfig = 0
exec sp_addextendedproperty '
        End ', @______End_, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi_with_CRM'
go

declare @___Begin_DiagramPane____         Top = 0
=      Begin Origin = 
exec sp_addextendedproperty '
        Begin
            DiagramPane =
                ', @___Begin_DiagramPane____, ' SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi_with_CRM'
go

declare @_________Left_____      Begin Tables = 
=      End
exec sp_addextendedproperty '         Left = 0
', @_________Left_____, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi_with_CRM'
go

declare @_________Begin_Table____CRM_Listview__               Top = 64
=            Begin Extent = 
exec sp_addextendedproperty '
            Begin
                Table = "CRM_Listview"
', @_________Begin_Table____CRM_Listview__, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi_with_CRM'
go

declare @_______________Left_______               Right = 806
=               Bottom = 160
exec sp_addextendedproperty '               Left = 636
', @_______________Left_______, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi_with_CRM'
go

declare @____________End_            TopColumn = 0
=            DisplayFlags = 280
exec sp_addextendedproperty '
            End ', @____________End_, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi_with_CRM'
go

declare @_________End_            Begin Extent = 
=         Begin Table = "error_log_results_withmbi"
exec sp_addextendedproperty '
        End ', @_________End_, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi_with_CRM'
go

declare @_______________Top_____               Bottom = 271
=               Left = 246
exec sp_addextendedproperty '               Top = 6
', @_______________Top_____, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi_with_CRM'
go

declare @_______________Right_______            DisplayFlags = 280
=            End
exec sp_addextendedproperty '               Right = 416
', @_______________Right_______, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi_with_CRM'
go

declare @____________TopColumn_____      End
=         End
exec sp_addextendedproperty '            TopColumn = 0
', @____________TopColumn_____, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi_with_CRM'
go

declare @___End_   End
=   Begin SQLPane = 
exec sp_addextendedproperty '
    End ', @___End_, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi_with_CRM'
go

declare @___Begin_DataPane____      End
=      Begin ParameterDefaults = ""
exec sp_addextendedproperty '
    Begin
        DataPane =
            ', @___Begin_DataPane____, ' SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi_with_CRM'
go

declare @______Begin_ColumnWidths______         Width = 1500
=         Width = 284
exec sp_addextendedproperty '
        Begin
            ColumnWidths = 10
', @______Begin_ColumnWidths______, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi_with_CRM'
go

declare @_________Width________         Width = 1500
=         Width = 1500
exec sp_addextendedproperty '         Width = 1500
', @_________Width________, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi_with_CRM'
go

declare @_________Width________         Width = 1500
=         Width = 1500
exec sp_addextendedproperty '         Width = 1500
', @_________Width________, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi_with_CRM'
go

declare @_________Width________      End
=         Width = 3885
exec sp_addextendedproperty '         Width = 6360
', @_________Width________, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi_with_CRM'
go

declare @___End_      Begin ColumnWidths = 11
=   Begin CriteriaPane = 
exec sp_addextendedproperty '
        End ', @___End_, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi_with_CRM'
go

declare @_________Column________         Table = 1170
=         Alias = 900
exec sp_addextendedproperty '         Column = 1440
', @_________Column________, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi_with_CRM'
go

declare @_________Output_______         NewValue = 1170
=         Append = 1400
exec sp_addextendedproperty '         Output = 720
', @_________Output_______, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi_with_CRM'
go

declare @_________SortType________         GroupBy = 1350
=         SortOrder = 1410
exec sp_addextendedproperty '         SortType = 1350
', @_________SortType________, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi_with_CRM'
go

declare @_________Filter________         Or = 1350
=         Or = 1350
exec sp_addextendedproperty '         Filter = 1350
', @_________Filter________, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi_with_CRM'
go

declare @_________Or________   End
=      End
exec sp_addextendedproperty '         Or = 1350
', @_________Or________, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi_with_CRM'
go

exec sp_addextendedproperty '
    End ', ', 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi_with_CRM'
go

exec sp_addextendedproperty 'MS_DiagramPaneCount' , 1 , 'SCHEMA' , 'dbo' , 'VIEW' , 'error_log_results_withmbi_with_CRM'
go

