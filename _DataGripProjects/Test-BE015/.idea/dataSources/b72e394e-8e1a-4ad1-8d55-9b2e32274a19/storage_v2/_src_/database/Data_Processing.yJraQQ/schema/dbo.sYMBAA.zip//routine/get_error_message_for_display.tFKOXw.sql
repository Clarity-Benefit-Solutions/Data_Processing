create 
 function get_error_message_for_display( @error_message nvarchar(max) ) returns nvarchar(max) as
begin
    set @error_message = ltrim( rtrim( isnull( @error_message , '' ) ) );
    
    if (len( @error_message ) = 0)
        begin
            return ' | OK';
        end
    
    if @error_message like 'IRRELEVANT_LINE:%'
        begin
            return ' | WARNING: This line was ignored. Please remove this line from future files';
        end
    
    return concat( ' | ERROR: ' , @error_message );

end
go

