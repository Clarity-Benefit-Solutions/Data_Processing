-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[Get_COBRA_QBs]

AS
BEGIN

--I think the QBs we are looking for are all QBs where a) Allow SSO is true or
--b) QB is registered AND user name does not match
--their email - I'm not sure if this is an effective filter... you may need to find registered QBs with a username beginning with 'ZZZ@'
Select distinct qb.*---,qe.*,qp.Status
  from [SalesForce_COBRA].[dbo].[QB] as qb
  join [SalesForce_COBRA].[dbo].[QBEvent] as qe
    on qb.MemberID = qe.MemberID
  join [SalesForce_COBRA].[dbo].[QBPlan] as qp
    on qb.MemberID = qp.MemberID
where AllowSSO = 1
  and active = 1
  and qp.Status in ('E','E45','P', 'PR')
  ---and eventdate >= '3/19/2018'




--Select *
--  from [SalesForce_COBRA].[dbo].[QB]
-- where LastName = 'nadler'

-- 3222
-- code = 'u2Ql2dcc' date '2/26/2021'

   --and active = 0
   






--select distinct '[BROKERCONTACTUPDATE],oBrokerName='+isnull(b.BrokerName,'')+',oContactType='+isnull(bc.ContactType,'')+',oFirstName='+isnull(bc.FirstName,'')+',oLastName='
--       +isnull(bc.LastName,'')+',FirstName='+isnull(bc.FirstName,'')+',LastName='+isnull(bc.LastName,'')+',Email='+isnull(bc.Email,'')+',AllowSSO=false,Active=false'
--  from [SalesForce_COBRA].[dbo].[BrokerContact] as bc
--  join [SalesForce_COBRA].[dbo].[Broker] as b
--    on b.BrokerID = bc.BrokerID
--  join [SalesForce_COBRA].[dbo].[BrokerClient] as cl
--    on b.BrokerID = cl.BrokerID
--  join [SalesForce_COBRA].[dbo].Client as c
--    on c.ClientID = cl.ClientID
-- where RegistrationDate is null---only for unregistered
--   --and RegistrationCode is not null---no date but have a code you are officially unregistered
--   --and cc.active = 1
--   --and [ClientDeactivationDate] is null
--   and lastname not like '%zINACTIVE%'



END
go

