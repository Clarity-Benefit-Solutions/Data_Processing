CREATE PROCEDURE [dbo].[proc_alegeus_AlterHeadersOwn]
AS
BEGIN
    INSERT INTO [dbo].[alegeus_file_final]
    (
        [file_row]
    ,   [folder_name]
    )
    select
        data_row
      , folder_name
    from
        [dbo].[alegeus_file_staging]
        /* exclude old maybe wrong headers*/
    where
        data_row not like 'IA,%'
    -- where left(ltrim(data_row),3) in( 'IC,','IB,','IZ,','IH,','ID,','IA,')
    
    -- 	select *,'Final' from  [dbo].[alegeus_file_final]
    
    ---write to ftp_auto_List
    exec [dbo].[insert_to_auto_ftp_list]

END
go

