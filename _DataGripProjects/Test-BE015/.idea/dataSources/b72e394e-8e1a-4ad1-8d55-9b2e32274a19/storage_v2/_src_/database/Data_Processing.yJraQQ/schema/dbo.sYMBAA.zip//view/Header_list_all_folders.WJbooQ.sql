create view Header_list_all_folders as select * from FTP_Source_Folders;
go

