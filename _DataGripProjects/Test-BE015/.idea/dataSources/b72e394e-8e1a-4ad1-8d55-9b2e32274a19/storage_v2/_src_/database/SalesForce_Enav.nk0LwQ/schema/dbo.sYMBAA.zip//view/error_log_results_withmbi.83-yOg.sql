CREATE VIEW dbo.[error_log_results_withmbi]
    AS
        SELECT
            e.mbi_file_name
          , e.res_file_name
          , e.row_num error_row_num
          , m.row_num mbi_row_num
          , e.row_type
          , m.data_row mbi_line
          , e.error_row
          , e.error_code
          , e.error_message
          , e.EmployerId
          , e.EmployeeID
          , e.DependentID
          , e.PlanId
        FROM
            dbo.error_log_results
                AS e
                Left JOIN
                dbo.mbi_file_table AS m ON e.mbi_file_name = m.mbi_file_name
                    --                     AND (e.EmployerId = m.EmployerId and e.EmployeeID = m.EmployeeID and e.DependentID = m.DependentID)
                    and e.row_num = m.row_num
go

declare @MS_DiagramPane_
Begin
    DesignProperties = = N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
exec sp_addextendedproperty 'MS_DiagramPane1', @MS_DiagramPane_, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi'
go

declare @___Begin_PaneConfigurations____         NumPanes = 4
=      Begin PaneConfiguration = 0
exec sp_addextendedproperty '
    Begin
        PaneConfigurations =
            ', @___Begin_PaneConfigurations____, ' SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi'
go

declare @_________Configuration_____H__________________________      Begin PaneConfiguration = 1
=      End
exec sp_addextendedproperty '         Configuration = "(H (1[40] 4[20] 2[20] 3) )"
', @_________Configuration_____H__________________________, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi'
go

declare @_________NumPanes_____      End
=         Configuration = "(H (1 [50] 4 [25] 3))"
exec sp_addextendedproperty '         NumPanes = 3
', @_________NumPanes_____, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi'
go

declare @______Begin_PaneConfiguration_____         Configuration = "(H (1 [50] 2 [25] 3))"
=         NumPanes = 3
exec sp_addextendedproperty '
        Begin
            PaneConfiguration = 2
', @______Begin_PaneConfiguration_____, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi'
go

declare @______End_         NumPanes = 3
=      Begin PaneConfiguration = 3
exec sp_addextendedproperty '
        End ', @______End_, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi'
go

declare @_________Configuration_____H_____________________      Begin PaneConfiguration = 4
=      End
exec sp_addextendedproperty '         Configuration = "(H (4 [30] 2 [40] 3))"
', @_________Configuration_____H_____________________, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi'
go

declare @_________NumPanes_____      End
=         Configuration = "(H (1 [56] 3))"
exec sp_addextendedproperty '         NumPanes = 2
', @_________NumPanes_____, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi'
go

declare @______Begin_PaneConfiguration_____         Configuration = "(H (2 [66] 3))"
=         NumPanes = 2
exec sp_addextendedproperty '
        Begin
            PaneConfiguration = 5
', @______Begin_PaneConfiguration_____, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi'
go

declare @______End_         NumPanes = 2
=      Begin PaneConfiguration = 6
exec sp_addextendedproperty '
        End ', @______End_, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi'
go

declare @_________Configuration_____H______________      Begin PaneConfiguration = 7
=      End
exec sp_addextendedproperty '         Configuration = "(H (4 [50] 3))"
', @_________Configuration_____H______________, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi'
go

declare @_________NumPanes_____      End
=         Configuration = "(V (3))"
exec sp_addextendedproperty '         NumPanes = 1
', @_________NumPanes_____, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi'
go

declare @______Begin_PaneConfiguration_____         Configuration = "(H (1[56] 4[18] 2) )"
=         NumPanes = 3
exec sp_addextendedproperty '
        Begin
            PaneConfiguration = 8
', @______Begin_PaneConfiguration_____, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi'
go

declare @______End_         NumPanes = 2
=      Begin PaneConfiguration = 9
exec sp_addextendedproperty '
        End ', @______End_, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi'
go

declare @_________Configuration_____H______________      Begin PaneConfiguration = 10
=      End
exec sp_addextendedproperty '         Configuration = "(H (1 [75] 4))"
', @_________Configuration_____H______________, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi'
go

declare @_________NumPanes_____      End
=         Configuration = "(H (1[66] 2) )"
exec sp_addextendedproperty '         NumPanes = 2
', @_________NumPanes_____, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi'
go

declare @______Begin_PaneConfiguration______         Configuration = "(H (4 [60] 2))"
=         NumPanes = 2
exec sp_addextendedproperty '
        Begin
            PaneConfiguration = 11
', @______Begin_PaneConfiguration______, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi'
go

declare @______End_         NumPanes = 1
=      Begin PaneConfiguration = 12
exec sp_addextendedproperty '
        End ', @______End_, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi'
go

declare @_________Configuration_____H________      Begin PaneConfiguration = 13
=      End
exec sp_addextendedproperty '         Configuration = "(H (1) )"
', @_________Configuration_____H________, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi'
go

declare @_________NumPanes_____      End
=         Configuration = "(V (4))"
exec sp_addextendedproperty '         NumPanes = 1
', @_________NumPanes_____, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi'
go

declare @______Begin_PaneConfiguration______         Configuration = "(V (2))"
=         NumPanes = 1
exec sp_addextendedproperty '
        Begin
            PaneConfiguration = 14
', @______Begin_PaneConfiguration______, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi'
go

declare @______End_   End
=      ActivePaneConfig = 0
exec sp_addextendedproperty '
        End ', @______End_, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi'
go

declare @___Begin_DiagramPane____         Top = 0
=      Begin Origin = 
exec sp_addextendedproperty '
        Begin
            DiagramPane =
                ', @___Begin_DiagramPane____, ' SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi'
go

declare @_________Left_____      Begin Tables = 
=      End
exec sp_addextendedproperty '         Left = 0
', @_________Left_____, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi'
go

declare @_________Begin_Table____e__               Top = 6
=            Begin Extent = 
exec sp_addextendedproperty '
            Begin
                Table = "e"
', @_________Begin_Table____e__, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi'
go

declare @_______________Left______               Right = 208
=               Bottom = 136
exec sp_addextendedproperty '               Left = 38
', @_______________Left______, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi'
go

declare @____________End_            TopColumn = 0
=            DisplayFlags = 280
exec sp_addextendedproperty '
            End ', @____________End_, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi'
go

declare @_________End_            Begin Extent = 
=         Begin Table = "m"
exec sp_addextendedproperty '
        End ', @_________End_, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi'
go

declare @_______________Top_____               Bottom = 119
=               Left = 246
exec sp_addextendedproperty '               Top = 6
', @_______________Top_____, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi'
go

declare @_______________Right_______            DisplayFlags = 280
=            End
exec sp_addextendedproperty '               Right = 416
', @_______________Right_______, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi'
go

declare @____________TopColumn_____      End
=         End
exec sp_addextendedproperty '            TopColumn = 0
', @____________TopColumn_____, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi'
go

declare @___End_   End
=   Begin SQLPane = 
exec sp_addextendedproperty '
    End ', @___End_, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi'
go

declare @___Begin_DataPane____      End
=      Begin ParameterDefaults = ""
exec sp_addextendedproperty '
    Begin
        DataPane =
            ', @___Begin_DataPane____, ' SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi'
go

declare @______Begin_ColumnWidths_____         Width = 1500
=         Width = 284
exec sp_addextendedproperty '
        Begin
            ColumnWidths = 9
', @______Begin_ColumnWidths_____, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi'
go

declare @_________Width________         Width = 1500
=         Width = 1500
exec sp_addextendedproperty '         Width = 1500
', @_________Width________, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi'
go

declare @_________Width________         Width = 1500
=         Width = 1500
exec sp_addextendedproperty '         Width = 1500
', @_________Width________, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi'
go

declare @_________Width________   End
=      End
exec sp_addextendedproperty '         Width = 1500
', @_________Width________, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi'
go

declare @___Begin_CriteriaPane____         Column = 1440
=      Begin ColumnWidths = 11
exec sp_addextendedproperty '
            Begin
                CriteriaPane =
                    ', @___Begin_CriteriaPane____, ' SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi'
go

declare @_________Alias_______         Output = 720
=         Table = 1170
exec sp_addextendedproperty '         Alias = 900
', @_________Alias_______, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi'
go

declare @_________Append________         SortType = 1350
=         NewValue = 1170
exec sp_addextendedproperty '         Append = 1400
', @_________Append________, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi'
go

declare @_________SortOrder________         Filter = 1350
=         GroupBy = 1350
exec sp_addextendedproperty '         SortOrder = 1410
', @_________SortOrder________, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi'
go

declare @_________Or________         Or = 1350
=         Or = 1350
exec sp_addextendedproperty '         Or = 1350
', @_________Or________, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi'
go

declare @______End_ End
=   End
exec sp_addextendedproperty '
            End ', @______End_, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi'
go

declare @_ MS_DiagramPaneCount = nvarchar
exec sp_addextendedproperty '''', @_, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi'
go

exec sp_addextendedproperty '1', int, 'SCHEMA', 'dbo', 'VIEW', 'error_log_results_withmbi'
go

