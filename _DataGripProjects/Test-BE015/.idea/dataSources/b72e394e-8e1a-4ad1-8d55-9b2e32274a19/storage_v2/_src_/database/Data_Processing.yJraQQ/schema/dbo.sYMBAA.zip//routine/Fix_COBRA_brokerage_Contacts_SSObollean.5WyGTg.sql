-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[Fix_COBRA_brokerage_Contacts_SSObollean]

AS
BEGIN



Select 0,'[VERSION],2.0'
 union
select  1,'[BROKERCONTACTUPDATE],oBrokerName='+isnull(b.BrokerName,'')+',oContactType='+isnull(bc.ContactType,'')+',oFirstName='+isnull(bc.FirstName,'')+',oLastName='
       +isnull(bc.LastName,'')+',FirstName='+isnull(bc.FirstName,'')+',LastName='+isnull(bc.LastName,'')+',ContactType='+isnull(bc.ContactType,'')+',Email='+isnull(bc.Email,'')+',AllowSSO=false,Active=false'
  from bfx_broker_extract as bc
  join [SalesForce_COBRA].[dbo].[Broker] as b
    on b.BrokerID = bc.BrokerID
 where  (RegistrationCode is not null and RegistrationCode <> 'NULL')---no date but have a code you are officially unregistered
   and lastname not like '%zINACTIVE%'
   and (RegistrationDate is null or RegistrationDate = 'NULL')---only for unregistered
   and bc.active = 1

 union
select  2,'[BROKERCONTACTINSERT],oBrokerName='+isnull(b.BrokerName,'')+',oContactType='+isnull(bc.ContactType,'')+',FirstName='+isnull(bc.FirstName,'')
       +',LastName='+isnull(bc.LastName,'')+',ContactType='+isnull(bc.ContactType,'')+',Email='+replace(isnull(bc.Email,''),'@','_9@')+',Phone='+isnull(bc.phone,'')+',Extension='+isnull(bc.PhoneExtension,'')
	   +',Phone2 ='+isnull(bc.Phone2,'')+',Extension2='+isnull(bc.Phone2Extension,'')+',Fax='+isnull(bc.fax,'')+',AddressSameAsPrimary=FALSE,Address1='+isnull(bc.Address1,'')
	   +',Address2='+isnull(bc.Address2,'')+',City='+isnull(bc.city,'')+',StateOrProvince='+isnull(bc.state,'')
	   +',PostalCode='+isnull(bc.PostalCode,'')+',AllowSSO=TRUE'
  from bfx_broker_extract as bc
  join [SalesForce_COBRA].[dbo].[Broker] as b
    on b.BrokerID = bc.BrokerID
where  (RegistrationCode is not null and RegistrationCode <> 'NULL')---no date but have a code you are officially unregistered
   and lastname not like '%zINACTIVE%'
   and (RegistrationDate is null or RegistrationDate = 'NULL')---only for unregistered
   and bc.active = 1

union
select   3,'[BROKERCONTACTUPDATE],oBrokerName='+isnull(b.BrokerName,'')+',oContactType='+isnull(bc.ContactType,'')+',oFirstName='+isnull(bc.FirstName,'')+',oLastName='
       +isnull(bc.LastName,'')+',FirstName='+isnull(bc.FirstName,'')+',LastName='+isnull(bc.LastName,'')+',oEmail='+replace(isnull(bc.Email,''),'@','_9@')+',ContactType='+isnull(bc.ContactType,'')+',Email='+isnull(bc.Email,'')+',AllowSSO=true,Active=true'
  from bfx_broker_extract as bc
  join [SalesForce_COBRA].[dbo].[Broker] as b
    on b.BrokerID = bc.BrokerID
 where  (RegistrationCode is not null and RegistrationCode <> 'NULL')---no date but have a code you are officially unregistered
   and lastname not like '%zINACTIVE%'
   and (RegistrationDate is null or RegistrationDate = 'NULL')---only for unregistered
   and bc.active = 1

order by 1,2 desc

--select  top 15 b.BrokerName,bc.FirstName,bc.LastName
-- from bfx_broker_extract as bc
--  join [SalesForce_COBRA].[dbo].[Broker] as b
--    on b.BrokerID = bc.BrokerID
-- where  (RegistrationCode is not null and RegistrationCode <> 'NULL')---no date but have a code you are officially unregistered
--   and lastname not like '%zINACTIVE%'
--   and (RegistrationDate is null or RegistrationDate = 'NULL')---only for unregistered
--   and bc.active = 1

-----this mornings query
--select *
--from [SalesForce_COBRA].[dbo].[BrokerContact] bc
--JOIN [SalesForce_COBRA].[dbo].[Broker] b
--ON bc.BrokerID = b.BrokerID
--WHERE bc.Active = 1
--  AND b.Active = 1
--  AND ContactType != 'Primary'
--  and RegistrationDate is null
--  and lastname not like '%zINACTIVE%'
--order by brokername


--select *
--  from [SalesForce_COBRA].[dbo].[BrokerContact] as bc
--  join [SalesForce_COBRA].[dbo].[Broker] as b
--    on b.BrokerID = bc.BrokerID
-- where  RegistrationDate is null---only for unregistered
--   --and RegistrationCode is not null---no date but have a code you are officially unregistered
--   --and cc.active = 1
--   --and [] is null
--   and lastname not like '%zINACTIVE%'





END
go

