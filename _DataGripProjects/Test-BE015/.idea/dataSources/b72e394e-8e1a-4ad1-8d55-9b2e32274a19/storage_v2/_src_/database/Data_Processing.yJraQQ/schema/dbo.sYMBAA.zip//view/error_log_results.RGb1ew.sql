CREATE VIEW dbo.error_log_results
    AS
        SELECT
            error_row
          , mbi_file_name
          , res_file_name
          , error_code
          , error_message
          , row_num
          , row_type
          , EmployerId
          , EmployeeID
          , DependentID
          , PlanId
        FROM
            dbo.res_file_table
        WHERE
            (
                    error_code IS NOT NULL
                    and (isnumeric( error_code ) = 1 and error_code > '0')
                )
go

