CREATE VIEW dbo.[CRM_Listview]
    AS
        SELECT distinct
            BENCODE
          , CRM
          , CRM_email
        FROM
            /*[Low_balance_reporting].dbo.[CRM_List_contacts]*/
            CRM_List
go

declare @MS_DiagramPane_
Begin
    DesignProperties = = N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
exec sp_addextendedproperty 'MS_DiagramPane1', @MS_DiagramPane_, 'SCHEMA', 'dbo', 'VIEW', 'CRM_Listview'
go

declare @___Begin_PaneConfigurations____         NumPanes = 4
=      Begin PaneConfiguration = 0
exec sp_addextendedproperty '
    Begin
        PaneConfigurations =
            ', @___Begin_PaneConfigurations____, ' SCHEMA', 'dbo', 'VIEW', 'CRM_Listview'
go

declare @_________Configuration_____H__________________________      Begin PaneConfiguration = 1
=      End
exec sp_addextendedproperty '         Configuration = "(H (1[40] 4[20] 2[20] 3) )"
', @_________Configuration_____H__________________________, 'SCHEMA', 'dbo', 'VIEW', 'CRM_Listview'
go

declare @_________NumPanes_____      End
=         Configuration = "(H (1 [50] 4 [25] 3))"
exec sp_addextendedproperty '         NumPanes = 3
', @_________NumPanes_____, 'SCHEMA', 'dbo', 'VIEW', 'CRM_Listview'
go

declare @______Begin_PaneConfiguration_____         Configuration = "(H (1 [50] 2 [25] 3))"
=         NumPanes = 3
exec sp_addextendedproperty '
        Begin
            PaneConfiguration = 2
', @______Begin_PaneConfiguration_____, 'SCHEMA', 'dbo', 'VIEW', 'CRM_Listview'
go

declare @______End_         NumPanes = 3
=      Begin PaneConfiguration = 3
exec sp_addextendedproperty '
        End ', @______End_, 'SCHEMA', 'dbo', 'VIEW', 'CRM_Listview'
go

declare @_________Configuration_____H_____________________      Begin PaneConfiguration = 4
=      End
exec sp_addextendedproperty '         Configuration = "(H (4 [30] 2 [40] 3))"
', @_________Configuration_____H_____________________, 'SCHEMA', 'dbo', 'VIEW', 'CRM_Listview'
go

declare @_________NumPanes_____      End
=         Configuration = "(H (1 [56] 3))"
exec sp_addextendedproperty '         NumPanes = 2
', @_________NumPanes_____, 'SCHEMA', 'dbo', 'VIEW', 'CRM_Listview'
go

declare @______Begin_PaneConfiguration_____         Configuration = "(H (2 [66] 3))"
=         NumPanes = 2
exec sp_addextendedproperty '
        Begin
            PaneConfiguration = 5
', @______Begin_PaneConfiguration_____, 'SCHEMA', 'dbo', 'VIEW', 'CRM_Listview'
go

declare @______End_         NumPanes = 2
=      Begin PaneConfiguration = 6
exec sp_addextendedproperty '
        End ', @______End_, 'SCHEMA', 'dbo', 'VIEW', 'CRM_Listview'
go

declare @_________Configuration_____H______________      Begin PaneConfiguration = 7
=      End
exec sp_addextendedproperty '         Configuration = "(H (4 [50] 3))"
', @_________Configuration_____H______________, 'SCHEMA', 'dbo', 'VIEW', 'CRM_Listview'
go

declare @_________NumPanes_____      End
=         Configuration = "(V (3))"
exec sp_addextendedproperty '         NumPanes = 1
', @_________NumPanes_____, 'SCHEMA', 'dbo', 'VIEW', 'CRM_Listview'
go

declare @______Begin_PaneConfiguration_____         Configuration = "(H (1[56] 4[18] 2) )"
=         NumPanes = 3
exec sp_addextendedproperty '
        Begin
            PaneConfiguration = 8
', @______Begin_PaneConfiguration_____, 'SCHEMA', 'dbo', 'VIEW', 'CRM_Listview'
go

declare @______End_         NumPanes = 2
=      Begin PaneConfiguration = 9
exec sp_addextendedproperty '
        End ', @______End_, 'SCHEMA', 'dbo', 'VIEW', 'CRM_Listview'
go

declare @_________Configuration_____H______________      Begin PaneConfiguration = 10
=      End
exec sp_addextendedproperty '         Configuration = "(H (1 [75] 4))"
', @_________Configuration_____H______________, 'SCHEMA', 'dbo', 'VIEW', 'CRM_Listview'
go

declare @_________NumPanes_____      End
=         Configuration = "(H (1[66] 2) )"
exec sp_addextendedproperty '         NumPanes = 2
', @_________NumPanes_____, 'SCHEMA', 'dbo', 'VIEW', 'CRM_Listview'
go

declare @______Begin_PaneConfiguration______         Configuration = "(H (4 [60] 2))"
=         NumPanes = 2
exec sp_addextendedproperty '
        Begin
            PaneConfiguration = 11
', @______Begin_PaneConfiguration______, 'SCHEMA', 'dbo', 'VIEW', 'CRM_Listview'
go

declare @______End_         NumPanes = 1
=      Begin PaneConfiguration = 12
exec sp_addextendedproperty '
        End ', @______End_, 'SCHEMA', 'dbo', 'VIEW', 'CRM_Listview'
go

declare @_________Configuration_____H________      Begin PaneConfiguration = 13
=      End
exec sp_addextendedproperty '         Configuration = "(H (1) )"
', @_________Configuration_____H________, 'SCHEMA', 'dbo', 'VIEW', 'CRM_Listview'
go

declare @_________NumPanes_____      End
=         Configuration = "(V (4))"
exec sp_addextendedproperty '         NumPanes = 1
', @_________NumPanes_____, 'SCHEMA', 'dbo', 'VIEW', 'CRM_Listview'
go

declare @______Begin_PaneConfiguration______         Configuration = "(V (2))"
=         NumPanes = 1
exec sp_addextendedproperty '
        Begin
            PaneConfiguration = 14
', @______Begin_PaneConfiguration______, 'SCHEMA', 'dbo', 'VIEW', 'CRM_Listview'
go

declare @______End_   End
=      ActivePaneConfig = 0
exec sp_addextendedproperty '
        End ', @______End_, 'SCHEMA', 'dbo', 'VIEW', 'CRM_Listview'
go

declare @___Begin_DiagramPane____         Top = 0
=      Begin Origin = 
exec sp_addextendedproperty '
        Begin
            DiagramPane =
                ', @___Begin_DiagramPane____, ' SCHEMA', 'dbo', 'VIEW', 'CRM_Listview'
go

declare @_________Left_____      Begin Tables = 
=      End
exec sp_addextendedproperty '         Left = 0
', @_________Left_____, 'SCHEMA', 'dbo', 'VIEW', 'CRM_Listview'
go

declare @_________Begin_Table____CRM_List__               Top = 6
=            Begin Extent = 
exec sp_addextendedproperty '
            Begin
                Table = "CRM_List"
', @_________Begin_Table____CRM_List__, 'SCHEMA', 'dbo', 'VIEW', 'CRM_Listview'
go

declare @_______________Left______               Right = 208
=               Bottom = 102
exec sp_addextendedproperty '               Left = 38
', @_______________Left______, 'SCHEMA', 'dbo', 'VIEW', 'CRM_Listview'
go

declare @____________End_            TopColumn = 0
=            DisplayFlags = 280
exec sp_addextendedproperty '
            End ', @____________End_, 'SCHEMA', 'dbo', 'VIEW', 'CRM_Listview'
go

declare @_________End_   End
=      End
exec sp_addextendedproperty '
        End ', @_________End_, 'SCHEMA', 'dbo', 'VIEW', 'CRM_Listview'
go

declare @___Begin_SQLPane____   Begin DataPane = 
=   End
exec sp_addextendedproperty '
        Begin
            SQLPane =
                ', @___Begin_SQLPane____, ' SCHEMA', 'dbo', 'VIEW', 'CRM_Listview'
go

declare @______Begin_ParameterDefaults______      Begin ColumnWidths = 9
=      End
exec sp_addextendedproperty '
            Begin
                ParameterDefaults = ""
                                    ', @______Begin_ParameterDefaults______, 'SCHEMA', 'dbo', 'VIEW', 'CRM_Listview'
go

declare @_________Width_______         Width = 1500
=         Width = 1500
exec sp_addextendedproperty '         Width = 284
', @_________Width_______, 'SCHEMA', 'dbo', 'VIEW', 'CRM_Listview'
go

declare @_________Width________         Width = 1500
=         Width = 1500
exec sp_addextendedproperty '         Width = 1500
', @_________Width________, 'SCHEMA', 'dbo', 'VIEW', 'CRM_Listview'
go

declare @_________Width________         Width = 1500
=         Width = 1500
exec sp_addextendedproperty '         Width = 1500
', @_________Width________, 'SCHEMA', 'dbo', 'VIEW', 'CRM_Listview'
go

declare @______End_   Begin CriteriaPane = 
=   End
exec sp_addextendedproperty '
            End ', @______End_, 'SCHEMA', 'dbo', 'VIEW', 'CRM_Listview'
go

declare @______Begin_ColumnWidths______         Alias = 900
=         Column = 1440
exec sp_addextendedproperty '
            Begin
                ColumnWidths = 11
', @______Begin_ColumnWidths______, 'SCHEMA', 'dbo', 'VIEW', 'CRM_Listview'
go

declare @_________Table________         Append = 1400
=         Output = 720
exec sp_addextendedproperty '         Table = 1170
', @_________Table________, 'SCHEMA', 'dbo', 'VIEW', 'CRM_Listview'
go

declare @_________NewValue________         SortOrder = 1410
=         SortType = 1350
exec sp_addextendedproperty '         NewValue = 1170
', @_________NewValue________, 'SCHEMA', 'dbo', 'VIEW', 'CRM_Listview'
go

declare @_________GroupBy________         Or = 1350
=         Filter = 1350
exec sp_addextendedproperty '         GroupBy = 1350
', @_________GroupBy________, 'SCHEMA', 'dbo', 'VIEW', 'CRM_Listview'
go

declare @_________Or________      End
=         Or = 1350
exec sp_addextendedproperty '         Or = 1350
', @_________Or________, 'SCHEMA', 'dbo', 'VIEW', 'CRM_Listview'
go

declare @___End_ ' =
            End
            exec sp_addextendedproperty '   End
' , @___End_ , 'SCHEMA' , 'dbo' , 'VIEW' , 'CRM_Listview'
go

declare @nvarchar 1 = MS_DiagramPaneCount
exec sp_addextendedproperty 'nvarchar' , @nvarchar , 'SCHEMA' , 'dbo' , 'VIEW' , 'CRM_Listview'
go

exec sp_addextendedproperty 'int' , , 'SCHEMA' , 'dbo' , 'VIEW' , 'CRM_Listview'
go

