create view Header_list_new as select * from FTP_Source_Folders;
go

