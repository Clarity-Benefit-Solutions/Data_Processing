CREATE DEFINER = root@`%` VIEW vw_tpa_participants
AS
    SELECT
        `misc`.`tpa_participants`.`email` `email`
      , `misc`.`ts_is_active_status`( `misc`.`tpa_participants`.`tpa_employee_id` ,
                                      `misc`.`tpa_participants`.`tpa_employer_id` ) `is_active`
      , '0 PARTICIPANT' `user_type`
      , `misc`.`tpa_participants`.`row_id` `row_id`
      , `misc`.`tpa_participants`.`tpa_employee_id` `tpa_employee_id`
      , `misc`.`tpa_participants`.`tpa_employer_id` `tpa_employer_id`
      , `misc`.`tpa_participants`.`first_name` `first_name`
      , `misc`.`tpa_participants`.`last_name` `last_name`
      , `misc`.`tpa_participants`.`ssn` `ssn`
      , `misc`.`tpa_participants`.`alegeus_key` `alegeus_key`
      , `misc`.`tpa_participants`.`wex_key` `wex_key`
      , `misc`.`tpa_participants`.`archived` `archived`
      , `misc`.`tpa_participants`.`can_make_claim_requests` `can_make_claim_requests`
      , `misc`.`tpa_participants`.`can_use_portal` `can_use_portal`
      , `misc`.`tpa_participants`.`phone_home` `phone_home`
      , `misc`.`tpa_participants`.`phone_mobile` `phone_mobile`
      , `misc`.`tpa_participants`.`unread_count` `unread_count`
      , `misc`.`tpa_participants`.`user_ids` `user_ids`
      , `misc`.`tpa_participants`.`created_at` `created_at`
      , `misc`.`tpa_participants`.`created_by` `created_by`
      , `misc`.`tpa_participants`.`updated_at` `updated_at`
      , `misc`.`tpa_participants`.`updated_by` `updated_by`
    FROM
        `misc`.`tpa_participants`;

