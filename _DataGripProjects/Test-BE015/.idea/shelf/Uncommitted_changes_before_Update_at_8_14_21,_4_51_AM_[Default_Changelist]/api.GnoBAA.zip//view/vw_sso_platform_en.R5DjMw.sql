CREATE DEFINER = admin@`%` VIEW vw_sso_platform_en
AS
    SELECT
        `t`.`email` `email`
      , CASE
            WHEN `t`.`row_id` = `api`.`sso_get_record_for_en`( `t`.`email` ) THEN 1
            ELSE 0
        END `is_sso_record`
      , `t`.`is_active` `is_active`
      , `t`.`user_type` `user_type`
      , `t`.`row_id` `row_id`
      , `t`.`companyidentifier` `companyidentifier`
      , `t`.`firstname` `firstname`
      , `t`.`lastname` `lastname`
      , `t`.`ssn` `ssn`
      , `t`.`employeeid` `employeeid`
      , `t`.`employeestatus` `employeestatus`
      , `t`.`address1` `address1`
      , `t`.`address2` `address2`
      , `t`.`city` `city`
      , `t`.`state` `state`
      , `t`.`zip` `zip`
      , `t`.`phone` `phone`
      , `t`.`dob` `dob`
      , `t`.`terminationdate` `terminationdate`
      , `t`.`enparticipant` `enparticipant`
      , `t`.`created_at` `created_at`
      , `t`.`created_by` `created_by`
      , `t`.`updated_at` `updated_at`
      , `t`.`updated_by` `updated_by`
    FROM
        `en`.`vw_en_employees` `t`;

