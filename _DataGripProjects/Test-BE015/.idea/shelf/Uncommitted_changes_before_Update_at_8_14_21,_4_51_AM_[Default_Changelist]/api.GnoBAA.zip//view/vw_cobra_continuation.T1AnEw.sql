CREATE DEFINER = root@`%` VIEW vw_cobra_continuation
AS
    SELECT
        `c`.`cobra_continuation_id` `cobra_continuation_id`
      , `c`.`status` `status`
      , `c`.`continuation_type` `continuation_type`
      , `c`.`memberid` `memberid`
      , `c`.`brokerid` `brokerid`
      , `c`.`clientid` `clientid`
      , `c`.`employerid` `employerid`
      , `c`.`clientname` `clientname`
      , `c`.`salutation` `salutation`
      , `c`.`firstname` `firstname`
      , `c`.`lastname` `lastname`
      , `c`.`email` `email`
      , `c`.`ssn` `ssn`
      , `c`.`dob` `dob`
      , `c`.`phone` `phone`
      , `c`.`cobra_event_date` `cobra_event_date`
      , `c`.`cobra_last_day_of_coverage` `cobra_last_day_of_coverage`
      , `c`.`event_type` `event_type`
      , `c`.`ae_2021_is_eligible` `ae_2021_is_eligible`
      , `c`.`submitted_on` `submitted_on`
      , `c`.`submitted_by` `submitted_by`
      , `c`.`uploaded_on` `uploaded_on`
      , `cc`.`contact_email` `contact_email`
      , `c`.`created_at` `created_at`
      , `c`.`created_by` `created_by`
      , `c`.`updated_at` `updated_at`
      , `c`.`updated_by` `updated_by`
    FROM
        (`api`.`cobra_continuation` `c`
            JOIN `api`.`cobra_continuation_contacts` `cc` ON (`c`.`clientid` = `cc`.`clientid`))
    WHERE
        `cc`.`contact_is_cobra_contact` = 1
    GROUP BY
        `c`.`cobra_continuation_id`
      , `c`.`status`
      , `c`.`continuation_type`
      , `c`.`memberid`
      , `c`.`brokerid`
      , `c`.`clientid`
      , `c`.`employerid`
      , `c`.`clientname`
      , `c`.`salutation`
      , `c`.`firstname`
      , `c`.`lastname`
      , `c`.`email`
      , `c`.`ssn`
      , `c`.`dob`
      , `c`.`phone`
      , `c`.`cobra_event_date`
      , `c`.`cobra_last_day_of_coverage`
      , `c`.`event_type`
      , `c`.`ae_2021_is_eligible`
      , `c`.`submitted_on`
      , `c`.`submitted_by`
      , `c`.`uploaded_on`
      , `c`.`created_at`
      , `c`.`created_by`
      , `c`.`updated_at`
      , `c`.`updated_by`;

