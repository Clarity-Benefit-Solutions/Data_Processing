CREATE DEFINER = root@`%` VIEW vw_platform_users_base2
AS
    SELECT
        `vw_platform_users_base`.`user_name` `user_name`
      , `vw_platform_users_base`.`email` `email`
      , `vw_platform_users_base`.`user_id` `user_id`
      , `vw_platform_users_base`.`first_name` `first_name`
      , `vw_platform_users_base`.`last_name` `last_name`
      , `vw_platform_users_base`.`ssn` `ssn`
      , `vw_platform_users_base`.`is_ready_for_sso_processing` `is_ready_for_sso_processing`
      , `vw_platform_users_base`.`is_invalid` `is_invalid`
      , `vw_platform_users_base`.`invited_as_user_type` `invited_as_user_type`
      , CASE
            WHEN (`vw_platform_users_base`.`is_cp_broker` <> 0 OR `vw_platform_users_base`.`is_cp_client` <> 0 OR
                  `vw_platform_users_base`.`is_cp_tpa_admin` <> 0 OR `vw_platform_users_base`.`is_cp_particpant` <> 0 OR
                  `vw_platform_users_base`.`is_bs_broker` <> 0 OR `vw_platform_users_base`.`is_bs_client` <> 0 OR
                  `vw_platform_users_base`.`is_bs_particpant` <> 0 OR `vw_platform_users_base`.`is_bs_tpa_admin` <> 0 OR
                  `vw_platform_users_base`.`is_en_broker` <> 0 OR `vw_platform_users_base`.`is_en_client` <> 0 OR
                  `vw_platform_users_base`.`is_en_particpant` <> 0 OR `vw_platform_users_base`.`is_en_tpa_admin` <> 0 OR
                  `vw_platform_users_base`.`is_wc_broker` <> 0 OR `vw_platform_users_base`.`is_wc_client` <> 0 OR
                  `vw_platform_users_base`.`is_wc_particpant` <> 0 OR `vw_platform_users_base`.`is_wc_tpa_admin` <> 0 OR
                  `vw_platform_users_base`.`is_el_broker` <> 0 OR `vw_platform_users_base`.`is_el_client` <> 0 OR
                  `vw_platform_users_base`.`is_el_particpant` <> 0 OR `vw_platform_users_base`.`is_el_tpa_admin` <> 0 OR
                  `vw_platform_users_base`.`is_sf_broker` <> 0 OR `vw_platform_users_base`.`is_sf_client` <> 0 OR
                  `vw_platform_users_base`.`is_sf_particpant` <> 0 OR `vw_platform_users_base`.`is_sf_tpa_admin` <> 0 OR
                  !`api_is_blank`( `vw_platform_users_base`.`invited_as_user_type` )) THEN 1
            ELSE 0
        END `is_active`
      , CASE
            WHEN (`vw_platform_users_base`.`is_cp_client` <> 0 OR `vw_platform_users_base`.`is_wc_client` <> 0 OR
                  `vw_platform_users_base`.`is_el_client` <> 0 OR `vw_platform_users_base`.`is_bs_client` <> 0 OR
                  `vw_platform_users_base`.`sf_is_client` <> 0 OR `vw_platform_users_base`.`en_is_manager` <> 0 OR
                  `vw_platform_users_base`.`invited_as_user_type` LIKE '%CLIENT%') THEN 1
            ELSE 0
        END `is_client`
      , CASE
            WHEN (`vw_platform_users_base`.`is_cp_broker` <> 0 OR `vw_platform_users_base`.`is_wc_broker` <> 0 OR
                  `vw_platform_users_base`.`is_el_broker` <> 0 OR `vw_platform_users_base`.`is_bs_broker` <> 0 OR
                  `vw_platform_users_base`.`sf_is_broker` <> 0 OR
                  `vw_platform_users_base`.`invited_as_user_type` LIKE '%BROKER%') THEN 1
            ELSE 0
        END `is_broker`
      , CASE
            WHEN (`vw_platform_users_base`.`is_cp_tpa_admin` <> 0 OR `vw_platform_users_base`.`is_wc_tpa_admin` <> 0 OR
                  `vw_platform_users_base`.`is_el_tpa_admin` <> 0 OR `vw_platform_users_base`.`is_bs_tpa_admin` <> 0 OR
                  `vw_platform_users_base`.`en_is_tpa_user` <> 0 OR
                  `vw_platform_users_base`.`invited_as_user_type` LIKE '%TPA%') THEN 1
            ELSE 0
        END `is_tpa_admin`
      , CASE
            WHEN (`vw_platform_users_base`.`is_cp_particpant` <> 0 OR
                  `vw_platform_users_base`.`is_wc_particpant` <> 0 OR
                  `vw_platform_users_base`.`is_el_particpant` <> 0 OR
                  `vw_platform_users_base`.`is_bs_particpant` <> 0 OR `vw_platform_users_base`.`is_en_particpant` <> 0)
                THEN 1
            ELSE 0
        END `is_particpant`
      , `vw_platform_users_base`.`is_cp_tpa_admin` `is_cp_tpa_admin`
      , `vw_platform_users_base`.`is_cp_broker` `is_cp_broker`
      , `vw_platform_users_base`.`is_cp_client` `is_cp_client`
      , `vw_platform_users_base`.`is_cp_particpant` `is_cp_particpant`
      , `vw_platform_users_base`.`is_wc_tpa_admin` `is_wc_tpa_admin`
      , `vw_platform_users_base`.`is_wc_broker` `is_wc_broker`
      , `vw_platform_users_base`.`is_wc_client` `is_wc_client`
      , `vw_platform_users_base`.`is_wc_particpant` `is_wc_particpant`
      , `vw_platform_users_base`.`is_el_tpa_admin` `is_el_tpa_admin`
      , `vw_platform_users_base`.`is_el_broker` `is_el_broker`
      , `vw_platform_users_base`.`is_el_client` `is_el_client`
      , `vw_platform_users_base`.`is_el_particpant` `is_el_particpant`
      , `vw_platform_users_base`.`is_bs_tpa_admin` `is_bs_tpa_admin`
      , `vw_platform_users_base`.`is_bs_broker` `is_bs_broker`
      , `vw_platform_users_base`.`is_bs_client` `is_bs_client`
      , `vw_platform_users_base`.`is_bs_particpant` `is_bs_particpant`
      , `vw_platform_users_base`.`is_en_tpa_admin` `is_en_tpa_admin`
      , `vw_platform_users_base`.`is_en_broker` `is_en_broker`
      , `vw_platform_users_base`.`is_en_client` `is_en_client`
      , `vw_platform_users_base`.`is_en_particpant` `is_en_particpant`
      , `vw_platform_users_base`.`is_sf_tpa_admin` `is_sf_tpa_admin`
      , `vw_platform_users_base`.`is_sf_broker` `is_sf_broker`
      , `vw_platform_users_base`.`is_sf_client` `is_sf_client`
      , `vw_platform_users_base`.`is_sf_particpant` `is_sf_particpant`
      , `vw_platform_users_base`.`is_ts_particpant` `is_ts_particpant`
      , `vw_platform_users_base`.`is_bt_user` `is_bt_user`
      , `vw_platform_users_base`.`is_rto_user` `is_rto_user`
      , `vw_platform_users_base`.`bt_user_is_active` `bt_user_is_active`
      , `vw_platform_users_base`.`rto_user_is_active` `rto_user_is_active`
      , `vw_platform_users_base`.`bt_user_type` `bt_user_type`
      , `vw_platform_users_base`.`rto_user_type` `rto_user_type`
      , `vw_platform_users_base`.`alternate_email` `alternate_email`
      , `vw_platform_users_base`.`title` `title`
      , `vw_platform_users_base`.`mobile_number` `mobile_number`
      , `vw_platform_users_base`.`dob` `dob`
      , `vw_platform_users_base`.`zip` `zip`
      , `vw_platform_users_base`.`employee_id` `employee_id`
      , `vw_platform_users_base`.`invite_token` `invite_token`
      , `vw_platform_users_base`.`last_invite_token_sent_date` `last_invite_token_sent_date`
      , `vw_platform_users_base`.`is_invited` `is_invited`
      , `vw_platform_users_base`.`is_verified` `is_verified`
      , `vw_platform_users_base`.`cp_client_id` `cp_client_id`
      , `vw_platform_users_base`.`cp_broker_id` `cp_broker_id`
      , `vw_platform_users_base`.`cp_client_contact_id` `cp_client_contact_id`
      , `vw_platform_users_base`.`cp_sso_identifier` `cp_sso_identifier`
      , `vw_platform_users_base`.`cp_customer_id` `cp_customer_id`
      , `vw_platform_users_base`.`cp_entity_type` `cp_entity_type`
      , `vw_platform_users_base`.`cp_user_id` `cp_user_id`
      , `vw_platform_users_base`.`cp_tpa_user_is_active` `cp_tpa_user_is_active`
      , `vw_platform_users_base`.`cp_broker_user_is_active` `cp_broker_user_is_active`
      , `vw_platform_users_base`.`cp_client_user_is_active` `cp_client_user_is_active`
      , `vw_platform_users_base`.`cp_member_id` `cp_member_id`
      , `vw_platform_users_base`.`cp_member_user_is_active` `cp_member_user_is_active`
      , `vw_platform_users_base`.`cp_allow_sso` `cp_allow_sso`
      , `vw_platform_users_base`.`cp_ssn` `cp_ssn`
      , `vw_platform_users_base`.`cp_email` `cp_email`
      , `vw_platform_users_base`.`cp_dob` `cp_dob`
      , `vw_platform_users_base`.`cp_zip` `cp_zip`
      , `vw_platform_users_base`.`wc_card_number` `wc_card_number`
      , `vw_platform_users_base`.`wc_dob` `wc_dob`
      , `vw_platform_users_base`.`wc_zip` `wc_zip`
      , `vw_platform_users_base`.`wc_ssn` `wc_ssn`
      , `vw_platform_users_base`.`wc_email` `wc_email`
      , `vw_platform_users_base`.`wca_tpa_id` `wca_tpa_id`
      , `vw_platform_users_base`.`wca_employer_id` `wca_employer_id`
      , `vw_platform_users_base`.`wca_data_partner_id` `wca_data_partner_id`
      , `vw_platform_users_base`.`wca_client_user_id` `wca_client_user_id`
      , `vw_platform_users_base`.`wca_user_is_active` `wca_user_is_active`
      , `vw_platform_users_base`.`wcp_tpa_id` `wcp_tpa_id`
      , `vw_platform_users_base`.`wcp_employer_id` `wcp_employer_id`
      , `vw_platform_users_base`.`wcp_employee_id` `wcp_employee_id`
      , `vw_platform_users_base`.`wcp_user_is_active` `wcp_user_is_active`
      , `vw_platform_users_base`.`wcp_employer_name` `wcp_employer_name`
      , `vw_platform_users_base`.`bs_user_id` `bs_user_id`
      , `vw_platform_users_base`.`bs_abbrev_url` `bs_abbrev_url`
      , `vw_platform_users_base`.`bs_import_user_id` `bs_import_user_id`
      , `vw_platform_users_base`.`bs_user_name` `bs_user_name`
      , `vw_platform_users_base`.`bs_user_is_active` `bs_user_is_active`
      , `vw_platform_users_base`.`bs_dob` `bs_dob`
      , `vw_platform_users_base`.`bs_zip` `bs_zip`
      , `vw_platform_users_base`.`bs_work_email` `bs_work_email`
      , `vw_platform_users_base`.`bs_payroll_id` `bs_payroll_id`
      , `vw_platform_users_base`.`bs_ssn` `bs_ssn`
      , `vw_platform_users_base`.`bs_email` `bs_email`
      , `vw_platform_users_base`.`bs_employer_id` `bs_employer_id`
      , `vw_platform_users_base`.`bs_is_employee` `bs_is_employee`
      , `vw_platform_users_base`.`bs_is_manager` `bs_is_manager`
      , `vw_platform_users_base`.`bs_is_topdog` `bs_is_topdog`
      , `vw_platform_users_base`.`en_ssn` `en_ssn`
      , `vw_platform_users_base`.`en_dob` `en_dob`
      , `vw_platform_users_base`.`en_zip` `en_zip`
      , `vw_platform_users_base`.`en_email` `en_email`
      , `vw_platform_users_base`.`en_user_is_active` `en_user_is_active`
      , `vw_platform_users_base`.`en_is_employee` `en_is_employee`
      , `vw_platform_users_base`.`en_is_manager` `en_is_manager`
      , `vw_platform_users_base`.`en_is_tpa_user` `en_is_tpa_user`
      , `vw_platform_users_base`.`sf_email` `sf_email`
      , `vw_platform_users_base`.`sf_row_id` `sf_row_id`
      , `vw_platform_users_base`.`sf_employer_id` `sf_employer_id`
      , `vw_platform_users_base`.`sf_dob` `sf_dob`
      , `vw_platform_users_base`.`sf_ssn` `sf_ssn`
      , `vw_platform_users_base`.`sf_user_is_active` `sf_user_is_active`
      , `vw_platform_users_base`.`sf_is_employee` `sf_is_employee`
      , `vw_platform_users_base`.`sf_is_client` `sf_is_client`
      , `vw_platform_users_base`.`sf_is_broker` `sf_is_broker`
      , `vw_platform_users_base`.`created_at` `created_at`
      , `vw_platform_users_base`.`created_by` `created_by`
      , `vw_platform_users_base`.`updated_at` `updated_at`
      , `vw_platform_users_base`.`updated_by` `updated_by`
      , `vw_platform_users_base`.`user_synced_to_mini_orange` `user_synced_to_mini_orange`
      , `vw_platform_users_base`.`cp_contact_registration_code` `cp_contact_registration_code`
      , `vw_platform_users_base`.`cp_contact_registration_date` `cp_contact_registration_date`
      , `vw_platform_users_base`.`ts_row_id` `ts_row_id`
      , `vw_platform_users_base`.`ts_employer_key` `ts_employer_key`
      , `vw_platform_users_base`.`ts_employer_name` `ts_employer_name`
      , `vw_platform_users_base`.`ts_employee_key` `ts_employee_key`
      , `vw_platform_users_base`.`ts_email` `ts_email`
      , `vw_platform_users_base`.`ts_first_name` `ts_first_name`
      , `vw_platform_users_base`.`ts_last_name` `ts_last_name`
      , `vw_platform_users_base`.`ts_phone` `ts_phone`
      , `vw_platform_users_base`.`ts_ssn` `ts_ssn`
      , `vw_platform_users_base`.`ts_user_is_active` `ts_user_is_active`
      , `vw_platform_users_base`.`if_user_is_active` `if_user_is_active`
      , `vw_platform_users_base`.`if_unique_id` `if_unique_id`
      , `vw_platform_users_base`.`if_reward_amount` `if_reward_amount`
      , `vw_platform_users_base`.`cp_st_entity_type` `cp_st_entity_type`
      , `vw_platform_users_base`.`cp_st_customer_id` `cp_st_customer_id`
      , `vw_platform_users_base`.`cp_st_client_id` `cp_st_client_id`
      , `vw_platform_users_base`.`cp_st_broker_id` `cp_st_broker_id`
      , `vw_platform_users_base`.`cp_st_broker_user_is_active` `cp_st_broker_user_is_active`
      , `vw_platform_users_base`.`cp_st_client_user_is_active` `cp_st_client_user_is_active`
      , `vw_platform_users_base`.`cp_st_sso_identifier` `cp_st_sso_identifier`
      , `vw_platform_users_base`.`cp_st_allow_sso` `cp_st_allow_sso`
      , `vw_platform_users_base`.`cp_st_tpa_user_is_active` `cp_st_tpa_user_is_active`
      , `vw_platform_users_base`.`cp_st_user_id` `cp_st_user_id`
      , `vw_platform_users_base`.`el_card_number` `el_card_number`
      , `vw_platform_users_base`.`el_dob` `el_dob`
      , `vw_platform_users_base`.`el_ssn` `el_ssn`
      , `vw_platform_users_base`.`el_email` `el_email`
      , `vw_platform_users_base`.`ela_row_id` `ela_row_id`
      , `vw_platform_users_base`.`ela_tpa_id` `ela_tpa_id`
      , `vw_platform_users_base`.`ela_employer_id` `ela_employer_id`
      , `vw_platform_users_base`.`ela_data_partner_id` `ela_data_partner_id`
      , `vw_platform_users_base`.`ela_client_user_id` `ela_client_user_id`
      , `vw_platform_users_base`.`ela_user_type` `ela_user_type`
      , `vw_platform_users_base`.`ela_user_is_active` `ela_user_is_active`
      , `vw_platform_users_base`.`elp_row_id` `elp_row_id`
      , `vw_platform_users_base`.`elp_tpa_id` `elp_tpa_id`
      , `vw_platform_users_base`.`elp_employer_id` `elp_employer_id`
      , `vw_platform_users_base`.`elp_employee_id` `elp_employee_id`
      , `vw_platform_users_base`.`elp_user_is_active` `elp_user_is_active`
      , `vw_platform_users_base`.`elp_employer_name` `elp_employer_name`
      , `vw_platform_users_base`.`el_zip` `el_zip`
    FROM
        `api`.`vw_platform_users_base`;

