CREATE DEFINER = root@`%` VIEW vw_find_form_entry_duplicates
AS
    SELECT
        `portal`.`cl_frm_items`.`id` `id`
      , `portal`.`cl_frm_items`.`name` `name`
      , `portal`.`cl_frm_items`.`is_duplicated` `is_duplicated`
      , `portal`.`cl_frm_items`.`item_key` `item_key`
      , `portal`.`cl_frm_items`.`form_id` `form_id`
      , `portal`.`cl_frm_items`.`created_at` `created_at`
      , `portal`.`cl_frm_items`.`is_draft` `is_draft`
      , `portal`.`cl_frm_items`.`user_id` `user_id`
      , `portal`.`cl_frm_items`.`parent_item_id` `parent_item_id`
      , `portal`.`cl_frm_items`.`updated_at` `updated_at`
    FROM
        `portal`.`cl_frm_items`
    WHERE
            `portal`.`cl_frm_items`.`name` IN (
                                                  SELECT
                                                      `portal`.`cl_frm_items`.`name`
                                                  FROM
                                                      `portal`.`cl_frm_items`
                                                  WHERE
                                                        `portal`.`cl_frm_items`.`form_id` = 61
                                                    AND (OCTET_LENGTH( `portal`.`cl_frm_items`.`item_key` ) = 32 OR
                                                         (OCTET_LENGTH( `portal`.`cl_frm_items`.`item_key` ) < 32 OR
                                                          OCTET_LENGTH( `portal`.`cl_frm_items`.`item_key` ) > 32) AND
                                                         `portal`.`cl_frm_items`.`created_at` >= '2020-12-18')
                                                    AND `portal`.`cl_frm_items`.`is_duplicated` = 0
                                                  GROUP BY
                                                      `portal`.`cl_frm_items`.`name`
                                                  HAVING
                                                      COUNT( 0 ) > 1
                                                  ORDER BY
                                                      `portal`.`cl_frm_items`.`name`
                                              )
      AND   (`portal`.`cl_frm_items`.`parent_item_id` IS NULL OR `portal`.`cl_frm_items`.`parent_item_id` = 0)
      AND   `portal`.`cl_frm_items`.`is_duplicated` = 0
      AND   (OCTET_LENGTH( `portal`.`cl_frm_items`.`item_key` ) <= 32 OR
             OCTET_LENGTH( `portal`.`cl_frm_items`.`item_key` ) > 32)
      AND   `portal`.`cl_frm_items`.`form_id` = 61
      AND   !`api`.`api_is_blank`( `portal`.`cl_frm_items`.`name` )
    ORDER BY
        `portal`.`cl_frm_items`.`name`
      , `portal`.`cl_frm_items`.`created_at` DESC;

