CREATE DEFINER = root@`%` VIEW vw_caa_spend_down_alert
AS
    SELECT
        `vw_platform_sso_users`.`user_name` `user_name`
      , `vw_platform_sso_users`.`email` `email`
      , `vw_platform_sso_users`.`user_id` `user_id`
      , `vw_platform_sso_users`.`first_name` `first_name`
      , `vw_platform_sso_users`.`last_name` `last_name`
      , `vw_platform_sso_users`.`ssn` `ssn`
      , `vw_platform_sso_users`.`is_ready_for_sso_processing` `is_ready_for_sso_processing`
      , `vw_platform_sso_users`.`is_invalid` `is_invalid`
      , `vw_platform_sso_users`.`invited_as_user_type` `invited_as_user_type`
      , `vw_platform_sso_users`.`is_client` `is_client`
      , `vw_platform_sso_users`.`is_broker` `is_broker`
      , `vw_platform_sso_users`.`is_tpa_admin` `is_tpa_admin`
      , `vw_platform_sso_users`.`is_admin_user` `is_admin_user`
      , `vw_platform_sso_users`.`is_particpant` `is_particpant`
      , `vw_platform_sso_users`.`is_cp_tpa_admin` `is_cp_tpa_admin`
      , `vw_platform_sso_users`.`is_cp_broker` `is_cp_broker`
      , `vw_platform_sso_users`.`is_cp_client` `is_cp_client`
      , `vw_platform_sso_users`.`is_cp_particpant` `is_cp_particpant`
      , `vw_platform_sso_users`.`is_wc_tpa_admin` `is_wc_tpa_admin`
      , `vw_platform_sso_users`.`is_wc_broker` `is_wc_broker`
      , `vw_platform_sso_users`.`is_wc_client` `is_wc_client`
      , `vw_platform_sso_users`.`is_wc_particpant` `is_wc_particpant`
      , `vw_platform_sso_users`.`is_bs_tpa_admin` `is_bs_tpa_admin`
      , `vw_platform_sso_users`.`is_bs_broker` `is_bs_broker`
      , `vw_platform_sso_users`.`is_bs_client` `is_bs_client`
      , `vw_platform_sso_users`.`is_bs_particpant` `is_bs_particpant`
      , `vw_platform_sso_users`.`is_en_tpa_admin` `is_en_tpa_admin`
      , `vw_platform_sso_users`.`is_en_broker` `is_en_broker`
      , `vw_platform_sso_users`.`is_en_client` `is_en_client`
      , `vw_platform_sso_users`.`is_en_particpant` `is_en_particpant`
      , `vw_platform_sso_users`.`is_sf_tpa_admin` `is_sf_tpa_admin`
      , `vw_platform_sso_users`.`is_sf_broker` `is_sf_broker`
      , `vw_platform_sso_users`.`is_sf_client` `is_sf_client`
      , `vw_platform_sso_users`.`is_sf_particpant` `is_sf_particpant`
      , `vw_platform_sso_users`.`is_ts_particpant` `is_ts_particpant`
      , `vw_platform_sso_users`.`is_bt_user` `is_bt_user`
      , `vw_platform_sso_users`.`is_rto_user` `is_rto_user`
      , `vw_platform_sso_users`.`bt_user_is_active` `bt_user_is_active`
      , `vw_platform_sso_users`.`rto_user_is_active` `rto_user_is_active`
      , `vw_platform_sso_users`.`bt_user_type` `bt_user_type`
      , `vw_platform_sso_users`.`rto_user_type` `rto_user_type`
      , `vw_platform_sso_users`.`is_active` `is_active`
      , `vw_platform_sso_users`.`alternate_email` `alternate_email`
      , `vw_platform_sso_users`.`title` `title`
      , `vw_platform_sso_users`.`mobile_number` `mobile_number`
      , `vw_platform_sso_users`.`dob` `dob`
      , `vw_platform_sso_users`.`zip` `zip`
      , `vw_platform_sso_users`.`employee_id` `employee_id`
      , `vw_platform_sso_users`.`invite_token` `invite_token`
      , `vw_platform_sso_users`.`last_invite_token_sent_date` `last_invite_token_sent_date`
      , `vw_platform_sso_users`.`is_invited` `is_invited`
      , `vw_platform_sso_users`.`is_verified` `is_verified`
      , `vw_platform_sso_users`.`cp_client_id` `cp_client_id`
      , `vw_platform_sso_users`.`cp_broker_id` `cp_broker_id`
      , `vw_platform_sso_users`.`cp_client_contact_id` `cp_client_contact_id`
      , `vw_platform_sso_users`.`cp_sso_identifier` `cp_sso_identifier`
      , `vw_platform_sso_users`.`cp_customer_id` `cp_customer_id`
      , `vw_platform_sso_users`.`cp_entity_type` `cp_entity_type`
      , `vw_platform_sso_users`.`cp_user_id` `cp_user_id`
      , `vw_platform_sso_users`.`cp_tpa_user_is_active` `cp_tpa_user_is_active`
      , `vw_platform_sso_users`.`cp_broker_user_is_active` `cp_broker_user_is_active`
      , `vw_platform_sso_users`.`cp_client_user_is_active` `cp_client_user_is_active`
      , `vw_platform_sso_users`.`cp_member_id` `cp_member_id`
      , `vw_platform_sso_users`.`cp_member_user_is_active` `cp_member_user_is_active`
      , `vw_platform_sso_users`.`cp_allow_sso` `cp_allow_sso`
      , `vw_platform_sso_users`.`cp_ssn` `cp_ssn`
      , `vw_platform_sso_users`.`cp_email` `cp_email`
      , `vw_platform_sso_users`.`cp_dob` `cp_dob`
      , `vw_platform_sso_users`.`cp_zip` `cp_zip`
      , `vw_platform_sso_users`.`wc_card_number` `wc_card_number`
      , `vw_platform_sso_users`.`wc_dob` `wc_dob`
      , `vw_platform_sso_users`.`wc_zip` `wc_zip`
      , `vw_platform_sso_users`.`wc_ssn` `wc_ssn`
      , `vw_platform_sso_users`.`wc_email` `wc_email`
      , `vw_platform_sso_users`.`wca_tpa_id` `wca_tpa_id`
      , `vw_platform_sso_users`.`wca_employer_id` `wca_employer_id`
      , `vw_platform_sso_users`.`wca_data_partner_id` `wca_data_partner_id`
      , `vw_platform_sso_users`.`wca_client_user_id` `wca_client_user_id`
      , `vw_platform_sso_users`.`wca_user_is_active` `wca_user_is_active`
      , `vw_platform_sso_users`.`wcp_tpa_id` `wcp_tpa_id`
      , `vw_platform_sso_users`.`wcp_employer_id` `wcp_employer_id`
      , `vw_platform_sso_users`.`wcp_employee_id` `wcp_employee_id`
      , `vw_platform_sso_users`.`wcp_user_is_active` `wcp_user_is_active`
      , `vw_platform_sso_users`.`bs_user_id` `bs_user_id`
      , `vw_platform_sso_users`.`bs_abbrev_url` `bs_abbrev_url`
      , `vw_platform_sso_users`.`bs_import_user_id` `bs_import_user_id`
      , `vw_platform_sso_users`.`bs_user_name` `bs_user_name`
      , `vw_platform_sso_users`.`bs_user_is_active` `bs_user_is_active`
      , `vw_platform_sso_users`.`bs_dob` `bs_dob`
      , `vw_platform_sso_users`.`bs_zip` `bs_zip`
      , `vw_platform_sso_users`.`bs_work_email` `bs_work_email`
      , `vw_platform_sso_users`.`bs_payroll_id` `bs_payroll_id`
      , `vw_platform_sso_users`.`bs_ssn` `bs_ssn`
      , `vw_platform_sso_users`.`bs_email` `bs_email`
      , `vw_platform_sso_users`.`bs_employer_id` `bs_employer_id`
      , `vw_platform_sso_users`.`bs_is_employee` `bs_is_employee`
      , `vw_platform_sso_users`.`bs_is_manager` `bs_is_manager`
      , `vw_platform_sso_users`.`bs_is_topdog` `bs_is_topdog`
      , `vw_platform_sso_users`.`en_email` `en_email`
      , `vw_platform_sso_users`.`en_ssn` `en_ssn`
      , `vw_platform_sso_users`.`en_dob` `en_dob`
      , `vw_platform_sso_users`.`en_zip` `en_zip`
      , `vw_platform_sso_users`.`en_user_is_active` `en_user_is_active`
      , `vw_platform_sso_users`.`en_is_employee` `en_is_employee`
      , `vw_platform_sso_users`.`en_is_manager` `en_is_manager`
      , `vw_platform_sso_users`.`en_is_tpa_user` `en_is_tpa_user`
      , `vw_platform_sso_users`.`sf_email` `sf_email`
      , `vw_platform_sso_users`.`sf_row_id` `sf_row_id`
      , `vw_platform_sso_users`.`sf_employer_id` `sf_employer_id`
      , `vw_platform_sso_users`.`sf_dob` `sf_dob`
      , `vw_platform_sso_users`.`sf_ssn` `sf_ssn`
      , `vw_platform_sso_users`.`sf_user_is_active` `sf_user_is_active`
      , `vw_platform_sso_users`.`sf_is_employee` `sf_is_employee`
      , `vw_platform_sso_users`.`sf_is_client` `sf_is_client`
      , `vw_platform_sso_users`.`sf_is_broker` `sf_is_broker`
      , `vw_platform_sso_users`.`created_at` `created_at`
      , `vw_platform_sso_users`.`created_by` `created_by`
      , `vw_platform_sso_users`.`updated_at` `updated_at`
      , `vw_platform_sso_users`.`updated_by` `updated_by`
      , `vw_platform_sso_users`.`user_synced_to_mini_orange` `user_synced_to_mini_orange`
      , `vw_platform_sso_users`.`cp_contact_registration_code` `cp_contact_registration_code`
      , `vw_platform_sso_users`.`cp_contact_registration_date` `cp_contact_registration_date`
      , `vw_platform_sso_users`.`ts_row_id` `ts_row_id`
      , `vw_platform_sso_users`.`ts_employer_key` `ts_employer_key`
      , `vw_platform_sso_users`.`ts_employer_name` `ts_employer_name`
      , `vw_platform_sso_users`.`ts_employee_key` `ts_employee_key`
      , `vw_platform_sso_users`.`ts_email` `ts_email`
      , `vw_platform_sso_users`.`ts_first_name` `ts_first_name`
      , `vw_platform_sso_users`.`ts_last_name` `ts_last_name`
      , `vw_platform_sso_users`.`ts_phone` `ts_phone`
      , `vw_platform_sso_users`.`ts_ssn` `ts_ssn`
      , `vw_platform_sso_users`.`ts_user_is_active` `ts_user_is_active`
      , `api`.`get_notification_log_count`( `vw_platform_sso_users`.`email` , 'alert' , 'caa_spent_down' ,
                                            '%' ) `notification_log_count`
      , `api`.`get_notification_log_last_sent_at`( `vw_platform_sso_users`.`email` , 'alert' , 'caa_spent_down' ,
                                                   '%' ) `notification_log_last_sent_at`
    FROM
        `api`.`vw_platform_sso_users`
    WHERE
          `vw_platform_sso_users`.`is_invalid` = 0
      AND `vw_platform_sso_users`.`is_verified` = 1
      AND `vw_platform_sso_users`.`email` IN (
                                                 SELECT
                                                     `t`.`email`
                                                 FROM
                                                     `wc`.`vw_wc_participants` `t`
                                                 WHERE
                                                         `t`.`employerid` IN (
                                                                                 SELECT
                                                                                     `vw_cases_forms`.`employer_id`
                                                                                 FROM
                                                                                     `api`.`vw_cases_forms`
                                                                                 WHERE
                                                                                     `vw_cases_forms`.`case_sub_type` = 'Covid2021Info'
                                                                             )
                                             )
    ORDER BY
        `vw_platform_sso_users`.`email`;

