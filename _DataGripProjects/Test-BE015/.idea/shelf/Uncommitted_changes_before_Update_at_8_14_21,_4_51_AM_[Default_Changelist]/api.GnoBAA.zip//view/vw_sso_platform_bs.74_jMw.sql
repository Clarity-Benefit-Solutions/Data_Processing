CREATE DEFINER = admin@`%` VIEW vw_sso_platform_bs
AS
    SELECT
        `t`.`eeemail` `eeemail`
      , CASE
            WHEN `t`.`row_id` = `api`.`sso_get_record_for_bs`( `t`.`eeemail` ) THEN 1
            ELSE 0
        END `is_sso_record`
      , `t`.`is_active` `is_active`
      , `t`.`user_type` `user_type`
      , `t`.`row_id` `row_id`
      , `t`.`eeclientbencode` `eeclientbencode`
      , `t`.`eedivision` `eedivision`
      , `t`.`eefirstname` `eefirstname`
      , `t`.`eelastname` `eelastname`
      , `t`.`eeemployeeid` `eeemployeeid`
      , `t`.`eessn` `eessn`
      , `t`.`eestatus` `eestatus`
      , `t`.`eeaddress1` `eeaddress1`
      , `t`.`eeaddress2` `eeaddress2`
      , `t`.`eecity` `eecity`
      , `t`.`eestate` `eestate`
      , `t`.`eezip` `eezip`
      , `t`.`eehomephone` `eehomephone`
      , `t`.`eedob` `eedob`
      , `t`.`eebswiftparticipant` `eebswiftparticipant`
      , `t`.`eealternateid` `eealternateid`
      , `t`.`eeimportuserid` `eeimportuserid`
      , `t`.`eepayrollid` `eepayrollid`
      , `t`.`eeuserroles` `eeuserroles`
      , `t`.`eeuserid` `eeuserid`
      , `t`.`eeusername` `eeusername`
      , `t`.`eeisemployee` `eeisemployee`
      , `t`.`eeismanager` `eeismanager`
      , `t`.`eeistopdog` `eeistopdog`
      , `t`.`abbrevurl` `abbrevurl`
      , `t`.`created_at` `created_at`
      , `t`.`created_by` `created_by`
      , `t`.`updated_at` `updated_at`
      , `t`.`updated_by` `updated_by`
    FROM
        `bs`.`vw_bs_employees` `t`;

