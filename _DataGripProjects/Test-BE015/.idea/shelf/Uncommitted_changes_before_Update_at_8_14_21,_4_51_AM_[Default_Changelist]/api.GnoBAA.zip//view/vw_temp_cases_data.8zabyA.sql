CREATE DEFINER = admin@`%` VIEW vw_temp_cases_data
AS
    SELECT
        `api`.`api_cases`.`case_id` `case_id`
      , `api`.`api_cases`.`case_status` `case_status`
      , `api`.`api_cases`.`case_type` `case_type`
      , `api`.`api_cases`.`case_sub_type` `case_sub_type`
      , `api`.`api_cases`.`employer_id` `employer_id`
      , `api`.`api_cases`.`employer_name` `employer_name`
      , `api`.`api_cases`.`employer_division_name` `employer_division_name`
      , `api`.`api_cases`.`sf_case_id` `sf_case_id`
      , `api`.`api_cases`.`sf_account_no` `sf_account_no`
      , `api`.`api_cases`.`legal_business_name` `legal_business_name`
      , `api`.`api_cases`.`dba` `dba`
      , `api`.`api_cases`.`street_physical_address` `street_physical_address`
      , `api`.`api_cases`.`street_line2` `street_line2`
      , `api`.`api_cases`.`city` `city`
      , `api`.`api_cases`.`state` `state`
      , `api`.`api_cases`.`zip` `zip`
      , `api`.`api_cases`.`phone` `phone`
      , `api`.`api_cases`.`fax` `fax`
      , `api`.`api_cases`.`web_address` `web_address`
      , `api`.`api_cases`.`incorporation_date` `incorporation_date`
      , `api`.`api_cases`.`laws_of_state` `laws_of_state`
    FROM
        `api`.`api_cases`
    ORDER BY
        `api`.`api_cases`.`employer_name`
      , `api`.`api_cases`.`case_id`;

