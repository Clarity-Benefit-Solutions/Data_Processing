CREATE DEFINER = root@`%` VIEW vw_cases_renewal_cons_ben_entered_values
AS
    SELECT
        `a`.`case_id` `case_id`
      , `a`.`employer_name` `employer_name`
      , `a`.`employer_id` `employer_id`
      , `a`.`case_sub_type` `case_sub_type`
      , `api`.`get_sf_case_owner_fullname`( `a`.`sf_case_owner_user_id` ) `sf_case_owner_fullname`
      , `a`.`is_ready_for_processing` `is_ready_for_processing`
      , SUBSTR( `a`.`last_rollout_error` , 1 , 150 ) `last_rollout_error`
      , `a`.`form_invite_token` `form_invite_token`
      , `a`.`case_status` `case_status`
      , CASE
            WHEN (`a`.`case_status` LIKE 'New%' OR `a`.`case_status` LIKE 'Ready For Entry%') THEN 'Waiting'
            WHEN `a`.`case_status` LIKE 'Cancelled%' THEN 'Cancelled'
            ELSE 'Rolled Out'
        END `major_case_status`
      , `portal`.`get_values_for_form_key`( `a`.`form_invite_token` , 0 , NULL , NULL , 'healthcare' ,
                                            1 ) `valuesof_carriers_healthcare`
      , `portal`.`get_values_for_form_key`( `a`.`form_invite_token` , 0 , NULL , NULL , 'pcvdo71f0845ede' ,
                                            1 ) `valuesof_carriers_dental`
      , `portal`.`get_values_for_form_key`( `a`.`form_invite_token` , 0 , NULL , NULL , '97rmg7999b9b9f8' ,
                                            1 ) `valuesof_carriers_vision`
    FROM
        `api`.`api_cases` `a`
    WHERE
          `a`.`case_type` = 'Renewal'
      AND `a`.`case_sub_type` = 'CONSUMER_BENEFIT'
    ORDER BY
        `a`.`employer_name`;

