CREATE DEFINER = admin@`%` TRIGGER au_audit_api_import_updates
    AFTER UPDATE
    ON api_import
    FOR EACH ROW
    INSERT INTO `api`.`api_import_audit`
                 (`auditAction`,`import_id`,`uploaded_by_user_id`,`file`,`file_orignal_name`,`file_converted_name`,`file_size`,`file_mime_type`,`created_at`,`updated_at`,`created_by`,`updated_by`)
                 VALUES
                 ('UPDATE',NEW.`import_id`,NEW.`uploaded_by_user_id`,NEW.`file`,NEW.`file_orignal_name`,NEW.`file_converted_name`,NEW.`file_size`,NEW.`file_mime_type`,NEW.`created_at`,NEW.`updated_at`,NEW.`created_by`,NEW.`updated_by`);

