CREATE DEFINER = admin@`%` TRIGGER au_audit_api_case_plans_cobra_deletes
    AFTER DELETE
    ON api_case_plans_cobra
    FOR EACH ROW
    INSERT INTO `api`.`api_case_plans_cobra_audit`
                 (`auditAction`, `case_plan_id`, `case_id`, `status`, `version_no`, `plan_type`, `plan_name`,
                  `plan_sub_type`, `plan_order`, `ben_term_type`, `new_ben_term_type`, `plan_year_start_date`,
                  `plan_year_end_date`, `plan_year_renewal_date`, `plan_should_terminate`, `plan_year_termination_date`,
                  `should_default_participants_to_different_plan`, `default_participants_to_different_plan_name`,
                  `plan_is_new`, `carrier_name`, `policygroup_number`, `is_fully_insured`, `is_self_funded`,
                  `insurance_type`, `plan_is_for_specific_division`, `division_name`, `coverage_termination`,
                  `plan_rate_type`, `is_currently_offering_subsidies`, `is_cap_dependents_age20`,
                  `pct_50_charge_disability_extension`, `new_pct_100_rate_for_coverage_level`, `created_at`,
                  `created_by`, `updated_at`, `updated_by`)
                 VALUES ('DELETE', OLD.`case_plan_id`, OLD.`case_id`, OLD.`status`, OLD.`version_no`, OLD.`plan_type`,
                         OLD.`plan_name`, OLD.`plan_sub_type`, OLD.`plan_order`, OLD.`ben_term_type`,
                         OLD.`new_ben_term_type`, OLD.`plan_year_start_date`, OLD.`plan_year_end_date`,
                         OLD.`plan_year_renewal_date`, OLD.`plan_should_terminate`, OLD.`plan_year_termination_date`,
                         OLD.`should_default_participants_to_different_plan`,
                         OLD.`default_participants_to_different_plan_name`, OLD.`plan_is_new`, OLD.`carrier_name`,
                         OLD.`policygroup_number`, OLD.`is_fully_insured`, OLD.`is_self_funded`, OLD.`insurance_type`,
                         OLD.`plan_is_for_specific_division`, OLD.`division_name`, OLD.`coverage_termination`,
                         OLD.`plan_rate_type`, OLD.`is_currently_offering_subsidies`, OLD.`is_cap_dependents_age20`,
                         OLD.`pct_50_charge_disability_extension`, OLD.`new_pct_100_rate_for_coverage_level`,
                         OLD.`created_at`, OLD.`created_by`, OLD.`updated_at`, OLD.`updated_by`);

