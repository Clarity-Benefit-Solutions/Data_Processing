CREATE DEFINER = root@`%` TRIGGER util_bu_cobra_continuation_contacts_set_updated_at_and_by
    BEFORE UPDATE
    ON cobra_continuation_contacts
    FOR EACH ROW
BEGIN
    SET new.updated_at = CURRENT_TIMESTAMP;
    SET new.updated_by = CURRENT_USER;
    
    SET new.clientname = api.get_cobra_client_name( new.clientid , NULL );

END;

