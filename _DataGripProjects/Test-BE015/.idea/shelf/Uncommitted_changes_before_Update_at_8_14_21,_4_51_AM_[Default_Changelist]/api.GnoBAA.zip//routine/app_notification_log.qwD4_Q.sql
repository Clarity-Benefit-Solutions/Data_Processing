CREATE
    DEFINER = admin@`%` PROCEDURE app_notification_log(
                                                      IN p_user_id varchar(200),
                                                      IN p_address varchar(200),
                                                      IN p_noti_type varchar(10),
                                                      IN p_noti_cate varchar(100),
                                                      IN p_noti_sub_cate varchar(200),
                                                      IN p_noti_content longtext,
                                                      IN p_case_id varchar(200),
                                                      IN p_case_owner_id longtext )
BEGIN
        DECLARE v_rollback BOOL DEFAULT 0;
        DECLARE v_label VARCHAR(2000) DEFAULT NULL;
        DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
            BEGIN
                GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE,
                    @errno = MYSQL_ERRNO,
                    @text = MESSAGE_TEXT;
                CALL db_log_error(@errno,
                                  'log_activity',
                                  @text,
                                  @sqlstate);
            END;

        IF p_noti_cate = 'Renewal Portal' THEN
            if p_noti_sub_cate = 'CONSUMER_BENEFIT Reminder1' THEN
                set v_label = 'Not in use';
            end if;
            if p_noti_sub_cate = 'CONSUMER_BENEFIT Reminder2' THEN
                set v_label = 'Cons Ben Renewal Reminder 60 d';
            end if;
            if p_noti_sub_cate = 'CONSUMER_BENEFIT Reminder3' THEN
                set v_label = 'Cons Ben Renewal Reminder 40 d';
            end if;
            if p_noti_sub_cate = 'CONSUMER_BENEFIT Reminder4' THEN
                set v_label = 'Cons Ben Renewal Reminder 23 d';
            end if;
            if p_noti_sub_cate = 'CONSUMER_BENEFIT Reminder5' THEN
                set v_label = 'Cons Ben Renewal Reminder 14 d';
            end if;
            if p_noti_sub_cate = 'COBRA Reminder1' THEN
                set v_label = 'Not in Use';
            end if;
            if p_noti_sub_cate = 'COBRA Reminder2' THEN
                set v_label = 'COBRA Renewal Reminder 60 d';
            end if;
            if p_noti_sub_cate = 'COBRA Reminder3' THEN
                set v_label = 'COBRA Renewal Reminder 40 d';
            end if;
            if p_noti_sub_cate = 'COBRA Reminder4' THEN
                set v_label = 'COBRA Renewal Reminder 23 d';
            end if;
            if p_noti_sub_cate = 'COBRA Reminder5' THEN
                set v_label = 'COBRA Renewal Reminder 14 d';
            end if;
            if p_noti_sub_cate = 'COBRA' THEN
                set v_label = 'COBRA Renewal Intimation';
            end if;
            if p_noti_sub_cate = 'CONSUMER_BENEFIT' THEN
                set v_label = 'Cons Ben Renewal Intimation';
            end if;
            if p_noti_sub_cate = 'CONSUMER_BENEFIT File upload reminder' THEN
                set v_label = 'CONSUMER file upload reminder';
            end if;
            if p_noti_sub_cate = 'COBRA File upload reminder' THEN
                set v_label = 'COBRA file upload reminder';
            end if;
            if p_noti_sub_cate = 'contact change' THEN
                set v_label = 'Contact Change Request';
            end if;
        end if;

        IF p_noti_cate = 'Forms' THEN
            if p_noti_sub_cate = 'Covid2021Info Reminder0' THEN
                set v_label = 'Form Intimation';
            end if;
            
            if p_noti_sub_cate = 'Covid2021Info Reminder1' THEN
                set v_label = 'Form Reminder 1';
            end if;
        end if;

        INSERT INTO api.api_notification_logs (
            user_id,
            destination_address,
            notification_type,
            notification_category,
            notification_sub_category,
            notification_content,
            case_id,
            case_owner_id,
            notification_label
        ) VALUES (
            p_user_id,
            p_address,
            p_noti_type,
            p_noti_cate,
            p_noti_sub_cate,
            p_noti_content,
            p_case_id,
            p_case_owner_id,
            v_label
        );
    END;

