CREATE
    DEFINER = root@`%` PROCEDURE get_fsa_store_items(
                                                    IN p_benefittype varchar(50),
                                                    IN p_coveragelevel varchar(50),
                                                    IN p_labelfirstchar varchar(50),
                                                    IN p_limit int )
BEGIN
    SET p_benefittype = api.api_nz( p_benefittype , 'fsaeligibilitytype' );
    SET p_coveragelevel = api.api_nz( p_coveragelevel , '%' );
    IF p_coveragelevel = 'All' THEN
        SET p_coveragelevel = '%';
    END IF;
    SET p_labelfirstchar = api.api_nz( p_labelfirstchar , '%' );
    IF p_limit <= 0 THEN
        SET p_limit = 500;
    END IF;
    
    SELECT
        CASE
            WHEN api.api_is_blank( benefittype ) THEN '(nc)'
            WHEN benefittype = 'Eligible' THEN '(c)'
            WHEN benefittype = 'Eligible w/LMN' THEN '(cl)'
            WHEN benefittype = 'Eligible w/Rx' THEN '(cp)'
            ELSE '(nc)'
        END coverage_level
      , t.benefittype
      , t.rowid
      , t.expensetypeid
      , t.label
      , t.labelfirstchar
      , t.isproduct
      , t.description
      , t.fsaeligibilitytype
      , t.limitedcarefsaeligibilitytype
      , t.dependentcarefsaeligibilitytype
      , t.hsaeligibilitytype
      , t.hraeligibilitytype
      , t.learnmorelinkurl
      , t.learnmorelinktext
      , t.shoppinglinkurl
      , t.shoppinglinktext
      , t.shoppinglinktype
      , t.url
      , t.created_at
      , t.created_by
      , t.updated_at
      , t.updated_by
        /* , t.fsaeligibile
         , t.hsaeligibile
         , t.hraeligibile
         , t.limitedcarefsaeligibile
         , t.dependentcarefsaeligibile*/
    FROM
        (
            SELECT
                CASE
                    WHEN p_benefittype = 'fsaeligibilitytype' THEN fsaeligibilitytype
                    WHEN p_benefittype = 'limitedcarefsaeligibilitytype' THEN limitedcarefsaeligibilitytype
                    WHEN p_benefittype = 'hraeligibilitytype' THEN hraeligibilitytype
                    WHEN p_benefittype = 'hsaeligibilitytype' THEN hsaeligibilitytype
                    WHEN p_benefittype = 'dependentcarefsaeligibilitytype' THEN dependentcarefsaeligibilitytype
                END
                    benefittype
              , rowid rowid
              , expensetypeid expensetypeid
              , label label
              , SUBSTR( label , 1 , 1 ) labelfirstchar
              , isproduct isproduct
              , description description
              , fsaeligibilitytype fsaeligibilitytype
              , limitedcarefsaeligibilitytype limitedcarefsaeligibilitytype
              , dependentcarefsaeligibilitytype dependentcarefsaeligibilitytype
              , hsaeligibilitytype hsaeligibilitytype
              , hraeligibilitytype hraeligibilitytype
              , shoppinglinkurl learnmorelinkurl
              , learnmorelinktext learnmorelinktext
              , shoppinglinkurl shoppinglinkurl
              , shoppinglinktext shoppinglinktext
              , shoppinglinktype shoppinglinktype
              , misc.get_fsa_store_url( shoppinglinkurl ,
                                        learnmorelinkurl ,
                                        shoppinglinktext ,
                                        learnmorelinktext ,
                                        shoppinglinktype ,
                                        label ,
                                        p_benefittype ) url
              , created_at created_at
              , created_by created_by
              , updated_at updated_at
              , updated_by updated_by
                /*    , CASE
                          WHEN fsaeligibilitytype LIKE 'Eligible%' THEN 1
                          ELSE 0
                      END fsaeligibile
                    , CASE
                          WHEN hsaeligibilitytype LIKE 'Eligible%' THEN 1
                          ELSE 0
                      END hsaeligibile
                    , CASE
                          WHEN hraeligibilitytype LIKE 'Eligible%' THEN 1
                          ELSE 0
                      END hraeligibile
                    , CASE
                          WHEN limitedcarefsaeligibilitytype LIKE 'Eligible%' THEN 1
                          ELSE 0
                      END limitedcarefsaeligibile
                    , CASE
                          WHEN dependentcarefsaeligibilitytype LIKE 'Eligible%' THEN 1
                          ELSE 0
                      END dependentcarefsaeligibile
                  */
            FROM
                misc.fsa_store_items
        ) t
    WHERE
          t.labelfirstchar LIKE p_labelfirstchar
      AND benefittype LIKE p_coveragelevel
    
    ORDER BY
        label
    
    LIMIT p_limit;

END;

