CREATE
    DEFINER = root@`%` FUNCTION get_cobra_continutation_counts(
                                                              p_client_id int,
                                                              p_is_submitted int,
                                                              p_continuation_type varchar(50) ) RETURNS int
BEGIN
    DECLARE v_count int(11);
    
    IF p_client_id = 0 OR p_is_submitted IS NULL THEN
        RETURN 0;
    END IF;
    
    IF p_is_submitted THEN
        SELECT
            COUNT( * )
        INTO v_count
        FROM
            api.cobra_continuation
        WHERE
              clientid = p_client_id
          AND continuation_type = p_continuation_type
          AND ae_2021_is_eligible IN (0, 1);
    ELSE
        SELECT
            COUNT( * )
        INTO v_count
        FROM
            api.cobra_continuation
        WHERE
              clientid = p_client_id
          AND continuation_type = p_continuation_type
          AND ae_2021_is_eligible is null;
    END IF;
    
    RETURN api.api_nz_int( v_count , 0 );
END;

