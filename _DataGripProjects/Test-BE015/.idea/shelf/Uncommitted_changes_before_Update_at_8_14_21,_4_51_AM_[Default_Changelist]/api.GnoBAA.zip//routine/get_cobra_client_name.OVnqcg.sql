CREATE
    DEFINER = root@`%` FUNCTION get_cobra_client_name(
                                                     p_client_id int,
                                                     p_client_name varchar(200) ) RETURNS varchar(200)
BEGIN
    DECLARE v_ret varchar(200);
    
    IF p_client_id = 0 THEN
        RETURN 'Invalid Client ID 0';
    END IF;
    
    IF NOT api.api_is_blank( p_client_name ) THEN
        RETURN p_client_name;
    END IF;
    
    SELECT
        clientname
    INTO v_ret
    FROM
        api.vw_cobra_continuation
    WHERE
        clientid = p_client_id
    LIMIT 1;
    
    if api.api_is_blank(v_ret) then
        set v_ret = 'ZZ No QBS For This Client';
    END IF;
    
    RETURN
        v_ret;
END;

