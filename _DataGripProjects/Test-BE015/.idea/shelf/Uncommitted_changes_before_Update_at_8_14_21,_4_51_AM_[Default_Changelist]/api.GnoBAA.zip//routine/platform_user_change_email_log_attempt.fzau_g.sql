CREATE
    DEFINER = root@`%` PROCEDURE platform_user_change_email_log_attempt(
                                                                       IN p_attempt_type varchar(200),
                                                                       IN p_search_for varchar(200),
                                                                       IN p_replace_with varchar(200),
                                                                       IN p_user_id int,
                                                                       IN p_prv_email varchar(200),
                                                                       IN p_new_email varchar(200),
                                                                       IN p_first_name varchar(200),
                                                                       IN p_last_name varchar(200),
                                                                       IN p_mobile_number varchar(200),
                                                                       IN p_ssn varchar(200),
                                                                       IN v_matched_user_ids text,
                                                                       IN v_matched_row_ids text,
                                                                       IN v_internal_messages text,
                                                                       IN v_user_messages text,
                                                                       IN v_status varchar(200),
                                                                       IN v_email_status longtext,
                                                                       IN v_error_message longtext )
full_proc:

BEGIN
    
    INSERT INTO api.change_email_log (
                                     attempt_type,
                                     search_for,
                                     replace_with,
                                     prv_email,
                                     new_email,
                                     first_name,
                                     last_name,
                                     mobile_number,
                                     ssn,
                                     matched_user_ids,
                                     matched_row_ids,
                                     internal_messages,
                                     user_messages,
                                     status,
                                     email_status,
                                     error_message,
                                     user_id
    )
    VALUES (
           p_attempt_type,
           p_search_for,
           p_replace_with,
           p_prv_email,
           p_new_email,
           p_first_name,
           p_last_name,
           p_mobile_number,
           p_ssn,
           v_matched_user_ids,
           v_matched_row_ids,
           v_internal_messages,
           v_user_messages,
           v_status,
           v_email_status,
           v_error_message,
           p_user_id
           );
    
    SELECT
        p_attempt_type
      , v_status
      , v_email_status
      , v_error_message
      , p_user_id
      , p_prv_email
      , p_new_email
      , p_first_name
      , p_last_name
      , p_mobile_number
      , p_ssn
      , v_matched_user_ids
      , v_matched_row_ids
      , v_internal_messages
      , v_user_messages;
    
    LEAVE full_proc;

END;

