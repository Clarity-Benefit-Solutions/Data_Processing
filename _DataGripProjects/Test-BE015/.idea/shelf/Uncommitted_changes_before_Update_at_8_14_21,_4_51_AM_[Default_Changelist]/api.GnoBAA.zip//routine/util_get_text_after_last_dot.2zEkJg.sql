CREATE
    DEFINER = admin@`%` FUNCTION util_get_text_after_last_dot(
    instring text ) RETURNS text
BEGIN
  DECLARE result      text;
  DECLARE v_pos_dot   integer;


  SET v_pos_dot = util_strposrev(
                    instring
                   ,'.');

  IF v_pos_dot <= 0
  THEN
    SET result = instring;
  ELSE
    SET result = substr(
                   instring
                  ,v_pos_dot + 1);
  END IF;

  RETURN result;
END;

