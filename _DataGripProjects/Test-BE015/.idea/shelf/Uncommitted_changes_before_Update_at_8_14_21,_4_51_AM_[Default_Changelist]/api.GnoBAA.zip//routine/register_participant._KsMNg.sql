CREATE
    DEFINER = root@`%` PROCEDURE register_participant(
                                                     IN p_invite_token varchar(200),
                                                     IN p_email varchar(200),
                                                     IN p_first_name varchar(200),
                                                     IN p_last_name varchar(200),
                                                     IN p_mobile_number varchar(200),
                                                     IN p_ssn varchar(200),
                                                     IN p_employer_id varchar(200),
                                                     IN p_employee_id varchar(200),
                                                     IN p_dob varchar(200),
                                                     IN p_zip varchar(200),
                                                     IN p_card_number varchar(200),
                                                     IN p_ignore_email_mismatch int,
                                                     IN v_matched_user_id int,
                                                     IN v_matched_row_ids text,
                                                     IN v_internal_messages text,
                                                     IN v_user_messages text,
                                                     IN v_status varchar(200),
                                                     IN v_email_status longtext )
full_proc:

BEGIN
    
    /* detect and usert matches from platforms where email was not aggregated*/
    CALL api.register_participant_internal( 'REGISTRATION' ,
                                            p_invite_token ,
                                            p_email ,
                                            p_first_name ,
                                            p_last_name ,
                                            p_mobile_number ,
                                            p_ssn ,
                                            p_employer_id ,
                                            p_employee_id ,
                                            p_dob ,
                                            p_zip ,
                                            p_card_number , p_ignore_email_mismatch ,
                                            v_matched_user_id ,
                                            v_matched_row_ids ,
                                            v_internal_messages ,
                                            v_user_messages ,
                                            v_status ,
                                            v_email_status );

END;

