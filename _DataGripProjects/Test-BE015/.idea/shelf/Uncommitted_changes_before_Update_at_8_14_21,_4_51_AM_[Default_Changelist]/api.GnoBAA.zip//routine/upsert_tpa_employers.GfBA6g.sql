CREATE
    DEFINER = root@`%` PROCEDURE upsert_tpa_employers(
                                                     IN p_row_id int,
                                                     IN p_tpa_id int,
                                                     IN p_name varchar(100),
                                                     IN p_slug varchar(50),
                                                     IN p_alegeus_key varchar(50),
                                                     IN p_wex_key varchar(50),
                                                     IN p_archived int,
                                                     IN p_can_make_claim_requests int,
                                                     IN p_can_use_portal int,
                                                     IN p_effective_date varchar(50),
                                                     IN p_onboard_url varchar(50),
                                                     IN p_support_email varchar(200),
                                                     IN p_support_email_derived varchar(200),
                                                     IN p_support_phone varchar(50),
                                                     IN p_support_phone_derived varchar(50),
                                                     IN p_unread_count int )
BEGIN
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN
        GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
        SET @text = CONCAT( @text , CONCAT( '
Called With Params: ' , ', row_id: ' , api.api_nz( `p_row_id` , '' ) , ', tpa_id: ' , api.api_nz( `p_tpa_id` , '' ) ,
                                            ', name: ' , api.api_nz( `p_name` , '' ) , ', slug: ' ,
                                            api.api_nz( `p_slug` , '' ) , ', alegeus_key: ' ,
                                            api.api_nz( `p_alegeus_key` , '' ) , ', wex_key: ' ,
                                            api.api_nz( `p_wex_key` , '' ) , ', archived: ' ,
                                            api.api_nz( `p_archived` , '' ) , ', can_make_claim_requests: ' ,
                                            api.api_nz( `p_can_make_claim_requests` , '' ) , ', can_use_portal: ' ,
                                            api.api_nz( `p_can_use_portal` , '' ) , ', effective_date: ' ,
                                            api.api_nz( `p_effective_date` , '' ) , ', onboard_url: ' ,
                                            api.api_nz( `p_onboard_url` , '' ) , ', support_email: ' ,
                                            api.api_nz( `p_support_email` , '' ) , ', support_email_derived: ' ,
                                            api.api_nz( `p_support_email_derived` , '' ) , ', support_phone: ' ,
                                            api.api_nz( `p_support_phone` , '' ) , ', support_phone_derived: ' ,
                                            api.api_nz( `p_support_phone_derived` , '' ) , ', unread_count: ' ,
                                            api.api_nz( `p_unread_count` , '' ) ) );
        CALL api.db_throw_error( @errno , 'upsert_tpa_employers' , @text );
    END;
    
    CALL api.db_log_message( 'upsert_tpa_employers' ,
                             CONCAT( 'Called With Params: ' , ', row_id: ' , api.api_nz( `p_row_id` , '' ) ,
                                     ', tpa_id: ' , api.api_nz( `p_tpa_id` , '' ) , ', name: ' ,
                                     api.api_nz( `p_name` , '' ) , ', slug: ' , api.api_nz( `p_slug` , '' ) ,
                                     ', alegeus_key: ' , api.api_nz( `p_alegeus_key` , '' ) , ', wex_key: ' ,
                                     api.api_nz( `p_wex_key` , '' ) , ', archived: ' , api.api_nz( `p_archived` , '' ) ,
                                     ', can_make_claim_requests: ' , api.api_nz( `p_can_make_claim_requests` , '' ) ,
                                     ', can_use_portal: ' , api.api_nz( `p_can_use_portal` , '' ) ,
                                     ', effective_date: ' , api.api_nz( `p_effective_date` , '' ) , ', onboard_url: ' ,
                                     api.api_nz( `p_onboard_url` , '' ) , ', support_email: ' ,
                                     api.api_nz( `p_support_email` , '' ) , ', support_email_derived: ' ,
                                     api.api_nz( `p_support_email_derived` , '' ) , ', support_phone: ' ,
                                     api.api_nz( `p_support_phone` , '' ) , ', support_phone_derived: ' ,
                                     api.api_nz( `p_support_phone_derived` , '' ) , ', unread_count: ' ,
                                     api.api_nz( `p_unread_count` , '' ) ) , 'WARN' );
    
    INSERT INTO `misc`.`tpa_employers` (
                                       `row_id`,
                                       `tpa_id`,
                                       `name`,
                                       `slug`,
                                       `alegeus_key`,
                                       `wex_key`,
                                       `archived`,
                                       `can_make_claim_requests`,
                                       `can_use_portal`,
                                       `effective_date`,
                                       `onboard_url`,
                                       `support_email`,
                                       `support_email_derived`,
                                       `support_phone`,
                                       `support_phone_derived`,
                                       `unread_count`
    )
    
    VALUES (
           `p_row_id`,
           `p_tpa_id`,
           `p_name`,
           `p_slug`,
           `p_alegeus_key`,
           `p_wex_key`,
           `p_archived`,
           `p_can_make_claim_requests`,
           `p_can_use_portal`,
           `p_effective_date`,
           `p_onboard_url`,
           `p_support_email`,
           `p_support_email_derived`,
           `p_support_phone`,
           `p_support_phone_derived`,
           `p_unread_count`
           )
    
    ON DUPLICATE KEY UPDATE
                         `row_id`                  = api.api_nz_int( `p_row_id` , `row_id` ),
                         `tpa_id`                  = api.api_nz_int( `p_tpa_id` , `tpa_id` ),
                         `name`                    = api.api_nz( `p_name` , `name` ),
                         `slug`                    = api.api_nz( `p_slug` , `slug` ),
                         `alegeus_key`             = api.api_nz( `p_alegeus_key` , `alegeus_key` ),
                         `wex_key`                 = api.api_nz( `p_wex_key` , `wex_key` ),
                         `archived`                = api.api_nz_int( `p_archived` , `archived` ),
                         `can_make_claim_requests` = api.api_nz_int( `p_can_make_claim_requests` ,
                                                                     `can_make_claim_requests` ),
                         `can_use_portal`          = api.api_nz_int( `p_can_use_portal` , `can_use_portal` ),
                         `effective_date`          = api.api_nz( `p_effective_date` , `effective_date` ),
                         `onboard_url`             = api.api_nz( `p_onboard_url` , `onboard_url` ),
                         `support_email`           = api.api_nz( `p_support_email` , `support_email` ),
                         `support_email_derived`   = api.api_nz( `p_support_email_derived` , `support_email_derived` ),
                         `support_phone`           = api.api_nz( `p_support_phone` , `support_phone` ),
                         `support_phone_derived`   = api.api_nz( `p_support_phone_derived` , `support_phone_derived` ),
                         `unread_count`            = api.api_nz_int( `p_unread_count` , `unread_count` );

END;

