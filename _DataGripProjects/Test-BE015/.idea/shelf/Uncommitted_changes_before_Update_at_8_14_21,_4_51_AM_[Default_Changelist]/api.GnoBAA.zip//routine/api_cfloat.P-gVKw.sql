CREATE
    DEFINER = admin@`%` FUNCTION api_cfloat(
    value varchar(200) ) RETURNS float
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;

            CALL api.db_log_error(@errno, 'api_cfloat', @text, @`sqlstate`);

            RETURN 0.0;
        END;

    IF api.api_is_blank(value) THEN
        RETURN 0;
    END IF;

    RETURN cast(value AS float);

END;

