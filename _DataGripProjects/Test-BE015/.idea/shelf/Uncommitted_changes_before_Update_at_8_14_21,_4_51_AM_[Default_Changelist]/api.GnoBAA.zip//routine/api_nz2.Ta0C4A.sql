CREATE
    DEFINER = root@`%` FUNCTION api_nz2(
    value text ) RETURNS text
BEGIN
    IF ifnull(
               value
           , '') = ''
    THEN
        RETURN '';
        /* sumeet: allow force setting a value to null by passing '<NULL>'*/
    ELSEIF ifnull(
                   value
               , '') = '<NULL>' THEN
        RETURN NULL;
    ELSE
        RETURN value;
    END IF;
END;

