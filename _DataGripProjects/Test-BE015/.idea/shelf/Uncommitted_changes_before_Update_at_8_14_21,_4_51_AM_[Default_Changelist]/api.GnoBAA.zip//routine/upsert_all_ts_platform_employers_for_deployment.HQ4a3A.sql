CREATE
    DEFINER = root@`%` PROCEDURE upsert_all_ts_platform_employers_for_deployment(
    IN p_only_employer_names_like varchar(200) )
full_proc:

BEGIN
    DECLARE v_email varchar(200) DEFAULT NULL;
    
    DECLARE v_finished int;
    DECLARE v_values_cursor CURSOR FOR
        SELECT DISTINCT
            email
        FROM
            misc.tpa_participants t
        WHERE
                t.tpa_employer_id IN (
                                         SELECT
                                             tpa_id
                                         FROM
                                             misc.vw_tpa_employers_for_deployment
                                     )
        ORDER BY
            email;
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND
        BEGIN
            SET v_finished = 1;
        END;
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
            CALL db_throw_error( @errno , 'upsert_all_ts_platform_employers_for_deployment' , @text );
        END;
    
    SET @@max_sp_recursion_depth = 12;
    
    CALL api.db_log_message( 'upsert_all_ts_platform_employers_for_deployment' ,
                             CONCAT(
                                     'Processing for Emails like : ' ,
                                     p_only_employer_names_like
                                 ) , 'WARN' );
    
    SET p_only_employer_names_like = api_nz( p_only_employer_names_like , '%' );
    
    OPEN v_values_cursor;
    
    getvalues
        :
    LOOP
        #
        FETCH v_values_cursor INTO v_email;
        
        IF v_finished = 1 THEN
            LEAVE getvalues;
        END IF;
        
        IF !api.api_is_blank( v_email ) THEN
            CALL api.upsert_all_ts_platform_employees_2( v_email );
        END IF;
    END LOOP getvalues;
END;

