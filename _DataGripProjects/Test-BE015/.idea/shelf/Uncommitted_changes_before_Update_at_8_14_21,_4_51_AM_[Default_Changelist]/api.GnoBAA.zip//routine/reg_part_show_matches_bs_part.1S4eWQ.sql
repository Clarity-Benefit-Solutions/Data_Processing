CREATE
    DEFINER = root@`%` PROCEDURE reg_part_show_matches_bs_part(
                                                              IN p_email varchar(200),
                                                              IN p_ssn varchar(200),
                                                              IN p_dob varchar(200),
                                                              IN p_zip varchar(200),
                                                              IN p_card_number varchar(200) )
full_proc:

BEGIN
    /* do we have a record in platform_users for the email?*/
    SELECT
        
        (/*t.is_active * 1 +*/
                t.matched_email + t.matched_ssn + t.matched_zip +
                t.matched_dob) matched_score
      , t.is_active
      , t.matched_email
      , t.matched_ssn
      , t.matched_dob
      , t.matched_zip
      , t.is_active
      , t.row_id
      , t.eeemail
      , t.eessn
      , t.eedob
      , t.eestatus
      , t.eezip
      , t.eeisemployee
      , t.eeclientbencode
      , t.eedivision
      , t.eefirstname
      , t.eelastname
      , t.eeemployeeid
    FROM
        (
            SELECT
                
                /* give 1 points to active records as it takes too long to do this in the where clause*/
                /* allow inactive employees whjo maycvh criteria to also register - as they need to do open enrollment*/
                
                CASE
                    /* returns 0, 0.5 (TI) or 1 - take 0.5 and 1 as 1*/
                    WHEN bs.bs_is_active_status( eestatus ) > 0 THEN 1
                    ELSE 0
                END
                    is_active
              , CASE
                    WHEN NOT api.api_is_blank( eeemail ) AND eeemail = p_email THEN 1
                    ELSE 0
                END matched_email
              
              , (CASE
                     WHEN NOT api.api_is_blank( p_ssn ) AND
                          (matched_ssn_emp_id_last = p_ssn OR
                           matched_ssn_emp_id_last = RIGHT( p_ssn , 4 )) THEN 1
                     ELSE 0
                 END)
                    matched_ssn
              
              , (CASE
                     WHEN NOT api.api_is_blank( p_dob ) AND
                          (eedob = p_dob)
                         THEN 1
                     ELSE 0
                 END) matched_dob
              , (CASE
                     WHEN NOT api.api_is_blank( p_zip ) AND
                          (matched_zip = p_zip) THEN 1
                     ELSE 0
                 END)
                    matched_zip
              , row_id
              , eeemail
              , eessn
              , eedob
              , eestatus
              , eezip
              , eeisemployee
              , eeclientbencode
              , eedivision
              , eefirstname
              , eelastname
              , eeemployeeid
              , created_at
            FROM
                bs.bs_employees
            WHERE
                (
                        eeemail LIKE CONCAT( p_email , '%' ) OR
                        (NOT api.api_is_blank( p_ssn ) AND
                         (eessn = p_ssn OR
                          matched_ssn_emp_id_last = RIGHT( p_ssn , 4 ))
                            )
                        OR (NOT api.api_is_blank( p_dob ) AND
                            (eedob = p_dob)
                            )
                        OR (NOT api.api_is_blank( p_zip ) AND
                            (matched_zip = p_zip))
                    )
        
        ) t
    
    ORDER BY
        (t.is_active * 1 +
         t.matched_email + t.matched_ssn + t.matched_zip +
         t.matched_dob + matched_email)
        DESC
      , t.created_at DESC
    LIMIT 10;

END;

