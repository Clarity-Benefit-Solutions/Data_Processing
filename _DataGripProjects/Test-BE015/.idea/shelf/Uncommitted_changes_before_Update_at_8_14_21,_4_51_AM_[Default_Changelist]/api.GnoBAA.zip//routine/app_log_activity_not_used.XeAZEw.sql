CREATE
    DEFINER = admin@`%` PROCEDURE app_log_activity_not_used(
                                                           IN p_user_id varchar(100),
                                                           IN p_ip_add varchar(50),
                                                           IN p_event_type varchar(100),
                                                           IN p_activity_details longtext,
                                                           IN p_error_source varchar(200) )
BEGIN
    DECLARE v_rollback BOOL DEFAULT 0;
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
        BEGIN
            GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE,
                @errno = MYSQL_ERRNO,
                @text = MESSAGE_TEXT;
            CALL db_log_error(@errno,
                              'log_activity',
                              @text,
                              @sqlstate);
        END;

    INSERT INTO logs.app_activity_log (user_id,
                                      ip_add,
                                      event_type,
                                      activity_details,
                                      event_source)
    VALUES (p_user_id,
            p_ip_add,
            p_event_type,
            p_activity_details,
            p_error_source);
END;

