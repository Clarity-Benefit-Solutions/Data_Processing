CREATE
    DEFINER = root@`%` PROCEDURE register_participant_no_email(
                                                              IN p_attempt_type varchar(200),
                                                              IN p_invite_token varchar(200),
                                                              INOUT p_email varchar(200),
                                                              IN p_first_name varchar(200),
                                                              IN p_last_name varchar(200),
                                                              IN p_mobile_number varchar(200),
                                                              IN p_ssn varchar(200),
                                                              IN p_employer_id varchar(200),
                                                              IN p_employee_id varchar(200),
                                                              IN p_dob varchar(200),
                                                              IN p_zip varchar(200),
                                                              IN p_card_number varchar(200),
                                                              IN p_ignore_email_mismatch int,
                                                              INOUT v_matched_user_id int,
                                                              INOUT v_matched_any_platforms int,
                                                              INOUT v_matched_row_ids text,
                                                              INOUT v_internal_messages text,
                                                              INOUT v_user_messages text,
                                                              INOUT v_status varchar(200),
                                                              INOUT v_email_status longtext )
full_proc:

BEGIN
    
    DECLARE v_bs_matched int;
    DECLARE v_cp_matched int;
    DECLARE v_en_matched int;
    DECLARE v_wc_matched int;
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN
        GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
        CALL db_throw_error( 50001 , 'register_participant_no_email' , @text );
    END;
    
    SET p_email = api.api_fix_email( p_email );
    SET p_mobile_number = api.api_fix_phone_number( p_mobile_number );
    SET p_ssn = api.api_fix_ssn( p_ssn );
    SET p_dob = api.api_fix_date( p_dob );
    /*    */
    SET v_matched_user_id = api.api_nz_int( v_matched_user_id , 0 );
    SET v_matched_row_ids = api.api_nz( v_matched_row_ids , '' );
    SET v_internal_messages = api.api_nz( v_internal_messages , '' );
    SET v_user_messages = api.api_nz( v_user_messages , '' );
    SET v_status = api.api_nz( v_status , '' );
    SET v_email_status = api.api_nz( v_email_status , '' );
    
    /**/
    CALL api.db_log_message( 'register_participant_no_email' ,
                             CONCAT( 'Processing user for '
                                 , ' p_attempt_type: ' , api.api_nz( p_attempt_type , '' ) , ' p_email: ' ,
                                     api.api_nz( p_email , '' )
                                 , ' p_first_name: ' , api.api_nz( p_first_name , '' )
                                 , ' p_last_name: ' , api.api_nz( p_last_name , '' )
                                 , ' p_ssn: ' , api.api_nz( p_ssn , '' )
                                 , ' p_employee_id: ' , api.api_nz( p_employee_id , '' )
                                 , ' p_employer_id: ' , api.api_nz( p_employer_id , '' )
                                 , ' p_dob: ' , api.api_nz( p_dob , '' )
                                 , ' p_zip: ' , api.api_nz( p_zip , '' )
                                 , ' p_card_number: ' , api.api_nz( p_card_number , '' )
                                 , ' p_ignore_email_mismatch: ' , api.api_nz( p_ignore_email_mismatch , '' )
                                 , ' p_mobile_number: ' , api.api_nz( p_mobile_number , '' )
                                 ) , 'WARN' );
    
    /*email MUST  be passed*/
    IF api.api_is_blank( p_email ) AND p_attempt_type IN ('REGISTRATION') THEN
        CALL db_throw_error( 50001 , 'register_participant_no_email' , 'EMAIL_IS_BLANK: Email MUST NOT be blank' );
    END IF;
    
    /**/
    CALL api.register_participant_no_email_wc( p_attempt_type ,
                                               p_invite_token ,
                                               p_email ,
                                               p_first_name ,
                                               p_last_name ,
                                               p_mobile_number ,
                                               p_ssn ,
                                               p_employer_id ,
                                               p_employee_id ,
                                               p_dob ,
                                               p_zip ,
                                               p_card_number , p_ignore_email_mismatch ,
                                               v_wc_matched ,
                                               v_matched_row_ids ,
                                               v_internal_messages ,
                                               v_user_messages , v_status , v_email_status );
    /*cp*/
    CALL api.register_participant_no_email_cp( p_attempt_type ,
                                               p_invite_token ,
                                               p_email ,
                                               p_first_name ,
                                               p_last_name ,
                                               p_mobile_number ,
                                               p_ssn ,
                                               p_employer_id ,
                                               p_employee_id ,
                                               p_dob ,
                                               p_zip ,
                                               p_card_number , p_ignore_email_mismatch ,
                                               v_cp_matched ,
                                               v_matched_row_ids ,
                                               v_internal_messages ,
                                               v_user_messages , v_status , v_email_status );
    /* bs*/
    CALL api.register_participant_no_email_bs( p_attempt_type ,
                                               p_invite_token ,
                                               p_email ,
                                               p_first_name ,
                                               p_last_name ,
                                               p_mobile_number ,
                                               p_ssn ,
                                               p_employer_id ,
                                               p_employee_id ,
                                               p_dob ,
                                               p_zip ,
                                               p_card_number , p_ignore_email_mismatch ,
                                               v_bs_matched ,
                                               v_matched_row_ids ,
                                               v_internal_messages ,
                                               v_user_messages , v_status , v_email_status );
    /* en*/
    CALL api.register_participant_no_email_en( p_attempt_type ,
                                               p_invite_token ,
                                               p_email ,
                                               p_first_name ,
                                               p_last_name ,
                                               p_mobile_number ,
                                               p_ssn ,
                                               p_employer_id ,
                                               p_employee_id ,
                                               p_dob ,
                                               p_zip ,
                                               p_card_number , p_ignore_email_mismatch ,
                                               v_en_matched ,
                                               v_matched_row_ids ,
                                               v_internal_messages ,
                                               v_user_messages , v_status , v_email_status );
    
    /**/
    #     select
    #         v_bs_matched
    #       , v_cp_matched
    #       , v_en_matched
    #       , v_wc_matched;
    
    #      if any platform matched
    IF (v_bs_matched OR v_cp_matched OR v_en_matched OR v_wc_matched) THEN
        SET v_matched_any_platforms = 1;
        #
        IF p_attempt_type IN ('REGISTRATION') THEN
            IF (
                    p_ignore_email_mismatch
                    OR v_email_status NOT LIKE '%EMAIL_DIFFERENT_ON_PLATFORM%') THEN
                /**/
                SELECT
                    api.api_nz_int( user_id , 0 )
                INTO v_matched_user_id
                FROM
                    api.platform_users
                WHERE
                    email = p_email;
            ELSE
                #                  return 0 as matched user id after upserts
                SET v_matched_user_id = 0;
            END IF;
        
        ELSEIF p_attempt_type NOT IN ('REGISTRATION') THEN
            -- we did not update any platform records so there will no matching user id from an upsert
            SET v_matched_user_id = 0;
        END IF;
        #
    ELSE
        SET v_matched_any_platforms = 0;
    END IF;
    
    LEAVE full_proc;

END;

