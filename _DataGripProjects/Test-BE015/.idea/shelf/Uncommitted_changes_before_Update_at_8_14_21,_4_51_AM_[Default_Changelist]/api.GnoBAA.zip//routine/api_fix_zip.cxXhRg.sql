CREATE
    DEFINER = root@`%` FUNCTION api_fix_zip(
    value varchar(200) ) RETURNS varchar(200)
BEGIN
    IF api.api_is_blank( value ) THEN
        RETURN NULL;
    END IF;
    
    SET value = lower( trim( value ) );
    SET value = replace( value , '-' , '' );
    SET value = replace( value , '.' , '' );
    SET value = replace( value , '(' , '' );
    SET value = replace( value , ')' , '' );
    SET value = api_strip_non_digit( value );
    
    SET value = left( value , 5 );
    
    RETURN value;
END;

