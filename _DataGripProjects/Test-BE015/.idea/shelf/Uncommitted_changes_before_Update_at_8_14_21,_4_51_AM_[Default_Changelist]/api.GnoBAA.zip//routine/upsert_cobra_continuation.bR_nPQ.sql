CREATE
    DEFINER = root@`%` PROCEDURE upsert_cobra_continuation(
                                                          IN p_cobra_continuation_id varchar(50),
                                                          IN p_status varchar(50),
                                                          IN p_continuation_type varchar(50),
                                                          IN p_memberid int,
                                                          IN p_brokerid int,
                                                          IN p_clientid int,
                                                          IN p_employerid varchar(50),
                                                          IN p_clientname varchar(200),
                                                          IN p_salutation varchar(50),
                                                          IN p_firstname varchar(50),
                                                          IN p_lastname varchar(50),
                                                          IN p_email varchar(100),
                                                          IN p_ssn varchar(50),
                                                          IN p_dob varchar(50),
                                                          IN p_phone varchar(50),
                                                          IN p_cobra_event_date timestamp,
                                                          IN p_cobra_last_day_of_coverage timestamp,
                                                          IN p_event_type varchar(75),
                                                          IN p_ae_2021_is_eligible int,
                                                          IN p_submitted_on timestamp,
                                                          IN p_submitted_by varchar(200),
                                                          IN p_uploaded_on timestamp )
BEGIN
    
    -- handle error that may happen as the table has a few unique keys which may conflict
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO,
                @text = MESSAGE_TEXT;
            SET @text = CONCAT( @text , CONCAT( '
Called With Params: ' , ', cobra_continuation_id: ' , api.api_nz( `p_cobra_continuation_id` , '' ) , ', status: ' ,
                                                api.api_nz( `p_status` , '' ) , ', continuation_type: ' ,
                                                api.api_nz( `p_continuation_type` , '' ) , ', memberid: ' ,
                                                api.api_nz( `p_memberid` , '' ) , ', brokerid: ' ,
                                                api.api_nz( `p_brokerid` , '' ) , ', clientid: ' ,
                                                api.api_nz( `p_clientid` , '' ) , ', employerid: ' ,
                                                api.api_nz( `p_employerid` , '' ) , ', clientname: ' ,
                                                api.api_nz( `p_clientname` , '' ) , ', salutation: ' ,
                                                api.api_nz( `p_salutation` , '' ) , ', firstname: ' ,
                                                api.api_nz( `p_firstname` , '' ) , ', lastname: ' ,
                                                api.api_nz( `p_lastname` , '' ) , ', email: ' ,
                                                api.api_nz( `p_email` , '' ) , ', ssn: ' , api.api_nz( `p_ssn` , '' ) ,
                                                ', dob: ' , api.api_nz( `p_dob` , '' ) , ', phone: ' ,
                                                api.api_nz( `p_phone` , '' ) , ', cobra_event_date: ' ,
                                                api.api_nz( `p_cobra_event_date` , '' ) ,
                                                ', cobra_last_day_of_coverage: ' ,
                                                api.api_nz( `p_cobra_last_day_of_coverage` , '' ) , ', event_type: ' ,
                                                api.api_nz( `p_event_type` , '' ) , ', ae_2021_is_eligible: ' ,
                                                api.api_nz( `p_ae_2021_is_eligible` , '' ) , ', submitted_on: ' ,
                                                api.api_nz( `p_submitted_on` , '' ) , ', submitted_by: ' ,
                                                api.api_nz( `p_submitted_by` , '' ) , ', uploaded_on: ' ,
                                                api.api_nz( `p_uploaded_on` , '' ) ) );
            CALL db_throw_error( @errno , 'upsert_cobra_continuation' , @text );
        END;
    
    CALL api.db_log_message( 'upsert_cobra_continuation' ,
                             CONCAT( 'Called With Params: ' , ', cobra_continuation_id: ' ,
                                     api.api_nz( `p_cobra_continuation_id` , '' ) , ', status: ' ,
                                     api.api_nz( `p_status` , '' ) , ', continuation_type: ' ,
                                     api.api_nz( `p_continuation_type` , '' ) , ', memberid: ' ,
                                     api.api_nz( `p_memberid` , '' ) , ', brokerid: ' ,
                                     api.api_nz( `p_brokerid` , '' ) , ', clientid: ' ,
                                     api.api_nz( `p_clientid` , '' ) , ', employerid: ' ,
                                     api.api_nz( `p_employerid` , '' ) , ', clientname: ' ,
                                     api.api_nz( `p_clientname` , '' ) , ', salutation: ' ,
                                     api.api_nz( `p_salutation` , '' ) , ', firstname: ' ,
                                     api.api_nz( `p_firstname` , '' ) , ', lastname: ' ,
                                     api.api_nz( `p_lastname` , '' ) , ', email: ' , api.api_nz( `p_email` , '' ) ,
                                     ', ssn: ' , api.api_nz( `p_ssn` , '' ) , ', dob: ' , api.api_nz( `p_dob` , '' ) ,
                                     ', phone: ' , api.api_nz( `p_phone` , '' ) , ', cobra_event_date: ' ,
                                     api.api_nz( `p_cobra_event_date` , '' ) , ', cobra_last_day_of_coverage: ' ,
                                     api.api_nz( `p_cobra_last_day_of_coverage` , '' ) , ', event_type: ' ,
                                     api.api_nz( `p_event_type` , '' ) , ', ae_2021_is_eligible: ' ,
                                     api.api_nz( `p_ae_2021_is_eligible` , '' ) , ', submitted_on: ' ,
                                     api.api_nz( `p_submitted_on` , '' ) , ', submitted_by: ' ,
                                     api.api_nz( `p_submitted_by` , '' ) , ', uploaded_on: ' ,
                                     api.api_nz( `p_uploaded_on` , '' ) ) , 'WARN' );
    
    INSERT INTO `api`.`cobra_continuation` (
                                           `cobra_continuation_id`,
                                           `status`,
                                           `continuation_type`,
                                           `memberid`,
                                           `brokerid`,
                                           `clientid`,
                                           `employerid`,
                                           `clientname`,
                                           `salutation`,
                                           `firstname`,
                                           `lastname`,
                                           `email`,
                                           `ssn`,
                                           `dob`,
                                           `phone`,
                                           `cobra_event_date`,
                                           `cobra_last_day_of_coverage`,
                                           `event_type`,
                                           `ae_2021_is_eligible`,
                                           `submitted_on`,
                                           `submitted_by`,
                                           `uploaded_on`
    )
    
    VALUES (
           `p_cobra_continuation_id`,
           `p_status`,
           `p_continuation_type`,
           `p_memberid`,
           `p_brokerid`,
           `p_clientid`,
           `p_employerid`,
           `p_clientname`,
           `p_salutation`,
           `p_firstname`,
           `p_lastname`,
           `p_email`,
           `p_ssn`,
           `p_dob`,
           `p_phone`,
           `p_cobra_event_date`,
           `p_cobra_last_day_of_coverage`,
           `p_event_type`,
           `p_ae_2021_is_eligible`,
           `p_submitted_on`,
           `p_submitted_by`,
           `p_uploaded_on`
           )
        
        /* use api_nz to avoid replacing previous value if new value is null or blank */
    ON DUPLICATE KEY
        UPDATE
            `cobra_continuation_id`      = api.api_nz( `p_cobra_continuation_id` , `cobra_continuation_id` ),
            `status`                     = api.api_nz( `p_status` , `status` ),
            `continuation_type`          = api.api_nz( `p_continuation_type` , `continuation_type` ),
            `memberid`                   = api.api_nz_int( `p_memberid` , `memberid` ),
            `brokerid`                   = api.api_nz_int( `p_brokerid` , `brokerid` ),
            `clientid`                   = api.api_nz_int( `p_clientid` , `clientid` ),
            `employerid`                 = api.api_nz( `p_employerid` , `employerid` ),
            `clientname`                 = api.api_nz( `p_clientname` , `clientname` ),
            `salutation`                 = api.api_nz( `p_salutation` , `salutation` ),
            `firstname`                  = api.api_nz( `p_firstname` , `firstname` ),
            `lastname`                   = api.api_nz( `p_lastname` , `lastname` ),
            `email`                      = api.api_nz( `p_email` , `email` ),
            `ssn`                        = api.api_nz( `p_ssn` , `ssn` ),
            `dob`                        = api.api_nz( `p_dob` , `dob` ),
            `phone`                      = api.api_nz( `p_phone` , `phone` ),
            `cobra_event_date`           = api.api_nz( `p_cobra_event_date` , `cobra_event_date` ),
            `cobra_last_day_of_coverage` = api.api_nz( `p_cobra_last_day_of_coverage` , `cobra_last_day_of_coverage` ),
            `event_type`                 = api.api_nz( `p_event_type` , `event_type` ),
            `ae_2021_is_eligible`        = api.api_nz_int( `p_ae_2021_is_eligible` , `ae_2021_is_eligible` ),
            `submitted_on`               = api.api_nz( `p_submitted_on` , `submitted_on` ),
            `submitted_by`               = api.api_nz( `p_submitted_by` , `submitted_by` ),
            `uploaded_on`                = api.api_nz( `p_uploaded_on` , `uploaded_on` );

END;

