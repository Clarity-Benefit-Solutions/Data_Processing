CREATE
    DEFINER = root@`%` PROCEDURE platform_user_change_email(
                                                           IN p_attempt_type varchar(200),
                                                           IN p_search_for varchar(200),
                                                           IN p_replace_with varchar(200),
                                                           IN v_matched_user_ids text,
                                                           IN v_matched_row_ids text,
                                                           IN v_internal_messages text,
                                                           IN v_user_messages text,
                                                           IN v_status varchar(200),
                                                           IN v_email_status varchar(200),
                                                           IN v_error_message longtext )
full_proc:

BEGIN
    DECLARE v_invite_token varchar(50) DEFAULT NULL;
    DECLARE v_user_id int DEFAULT NULL;
    DECLARE v_is_verified int DEFAULT NULL;
    DECLARE v_is_invalid int DEFAULT NULL;
    DECLARE v_no_of_matches int DEFAULT 0;
    DECLARE v_ssn varchar(200);
    DECLARE v_prv_email varchar(200);
    DECLARE v_new_email varchar(200) DEFAULT NULL;
    DECLARE v_message longtext;
    DECLARE v_first_name varchar(200);
    DECLARE v_last_name varchar(200);
    DECLARE v_mobile_number varchar(200);
    DECLARE v_employee_id varchar(200);
    DECLARE v_row_id varchar(200);
    #
    DECLARE v_bs_row_id varchar(200);
    DECLARE v_cp_row_id varchar(200);
    DECLARE v_en_row_id varchar(200);
    DECLARE v_wcp_row_id varchar(200);
    
    DECLARE v_matches varchar(1000) DEFAULT '';
    DECLARE v_matched_any_platforms int DEFAULT 0;
    
    DECLARE v_default_isolation_level varchar(200) DEFAULT 'READ-COMMITTED';
    DECLARE v_prc_isolation_level varchar(200) DEFAULT 'READ-UNCOMMITTED';
    
    /* what matching records do we have in platform_users for the email?*/
    DECLARE v_finished int;
    DECLARE v_values_cursor CURSOR FOR SELECT
                                           user_id
                                         , is_verified
                                         , is_invalid
                                         , email
                                         , invite_token
                                         , first_name
                                         , last_name
                                         , mobile_number
                                         , ssn
                                         , bs_row_id
                                         , cp_row_id
                                         , en_row_id
                                         , wcp_row_id
                                           #
    
                                       FROM
                                           api.platform_users
                                       WHERE
                                           email = /* LIKE */ p_search_for;
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_finished = 1;
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN
        GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
        /* for debugging*/
        IF api.api_is_blank( v_status ) THEN
            SET v_status = 'FAILED';
        ELSE
            SET v_status = CONCAT( 'FAILED' , ': ' , v_status );
        END IF;
        SET v_matched_user_ids = '';
        
        /**/
        CALL api.platform_user_change_email_log_attempt( p_attempt_type ,
                                                         p_search_for ,
                                                         p_replace_with ,
                                                         NULL ,
                                                         '' ,
                                                         '' ,
                                                         v_first_name ,
                                                         v_last_name ,
                                                         v_mobile_number ,
                                                         v_ssn ,
                                                         v_matched_user_ids ,
                                                         v_matched_row_ids ,
                                                         v_internal_messages ,
                                                         v_user_messages ,
                                                         v_status ,
                                                         v_email_status ,
                                                         @text );
    
    END;
    
    /* sumeet: 2021-04-02 to prevent  Lock wait timeout exceeded; try restarting transaction which happens frequentlym, we have set global [mysqld]
           transaction-isolation = READ-COMMITTED
           and we also set this update to use a potentially dirty row by using
           SET tx_isolation = 'READ-UNCOMMITTED';
    
        */
    #     SET tx_isolation = v_prc_isolation_level;
    
    /* sumeet - force ignore email mismatch */
    /**/
    SET p_search_for = api.api_fix_email( p_search_for );
    SET p_replace_with = api.api_fix_email( p_replace_with );
    /*    */
    SET v_matched_user_ids = '';
    SET v_matched_row_ids = '';
    SET v_internal_messages = '';
    SET v_user_messages = '';
    SET v_email_status = '';
    #
    CALL api.platform_user_change_email_log_attempt( CONCAT( p_attempt_type , ' - STARTING' ) ,
                                                     p_search_for ,
                                                     p_replace_with ,
                                                     NULL ,
                                                     '' ,
                                                     '' ,
                                                     v_first_name ,
                                                     v_last_name ,
                                                     v_mobile_number ,
                                                     v_ssn ,
                                                     v_matched_user_ids ,
                                                     v_matched_row_ids ,
                                                     v_internal_messages ,
                                                     v_user_messages ,
                                                     v_status ,
                                                     v_email_status ,
                                                     NULL );
    
    /*email MUST be passed*/
    IF (api.api_is_blank( p_search_for ) OR api.api_is_blank( p_replace_with )) AND
       p_attempt_type IN ('CHANGE_EMAIL', 'CHANGE_DOMAIN') THEN
        CALL db_throw_error( 50001 , 'platform_user_change_email' ,
                             'p_search_for or p_replace_with is blank' );
    END IF;
    
    /**/
    CALL api.db_log_message( 'platform_user_change_email' ,
                             CONCAT( 'Processing user for '
                                 , ' p_attempt_type: ' , api.api_nz( p_attempt_type , '' )
                                 , ' p_search_for: ' , api.api_nz( p_search_for , '' )
                                 , ' p_replace_with: ' , api.api_nz( p_replace_with , '' )
                                 , ' p_first_name: ' , api.api_nz( v_first_name , '' )
                                 , ' p_last_name: ' , api.api_nz( v_last_name , '' )
                                 , ' p_ssn: ' , api.api_nz( v_ssn , '' )
                                 , ' p_row_id: ' , api.api_nz( v_row_id , '' )
                                 , ' p_mobile_number: ' , api.api_nz( v_mobile_number , '' )
                                 ) , 'WARN' );
    
    SET @@max_sp_recursion_depth = 12;
    
    OPEN v_values_cursor;
    
    getvalues:
    LOOP
        FETCH v_values_cursor INTO v_user_id
            , v_is_verified
            , v_is_invalid
            , v_prv_email
            , v_invite_token
            , v_first_name
            , v_last_name
            , v_mobile_number
            , v_ssn
            , v_bs_row_id
            , v_cp_row_id
            , v_en_row_id
            , v_wcp_row_id;
        
        IF v_finished = 1 THEN
            LEAVE getvalues;
        END IF;
        
        /**/
        CALL api.db_log_message( 'platform_user_change_email' ,
                                 CONCAT( 'Matched existing user id  ' , v_user_id
                                     , ' For p_attempt_type: ' , p_attempt_type
                                     , ' For p_search_for: ' , p_search_for
                                     , ' For p_replace_with: ' , p_replace_with
                                     , ' email: ' , v_prv_email
                                     , ' user_id: ' , v_user_id
                                     ) , 'WARN' );
        
        /**/
        SET v_matched_user_ids = 0;
        
        /**/
        SET v_matched_user_ids = CONCAT( v_matched_user_ids , api.api_nz_int( v_user_id , 0 ) , CHAR( 13 ) );
        /*get new email*/
        SET v_new_email =
                api.api_get_new_email( p_attempt_type , p_search_for , p_replace_with , v_prv_email );
        
        /**/
        CALL api.platform_user_change_email_log_attempt( CONCAT( p_attempt_type , '-' , 'PROCESSING EMAIL' ) ,
                                                         p_search_for ,
                                                         p_replace_with ,
                                                         v_user_id ,
                                                         v_prv_email ,
                                                         v_new_email ,
                                                         v_first_name ,
                                                         v_last_name ,
                                                         v_mobile_number ,
                                                         v_ssn ,
                                                         v_matched_user_ids ,
                                                         v_matched_row_ids ,
                                                         v_internal_messages ,
                                                         v_user_messages ,
                                                         v_status ,
                                                         v_email_status ,
                                                         v_error_message );
        /* change email in PU*/
        UPDATE api.platform_users
        SET
            email     = v_new_email,
            user_name = v_new_email
        WHERE
            email = v_prv_email
        LIMIT 1;
        
        /* change in all platforms*/
        /* wcp*/
        IF v_wcp_row_id THEN
            SET v_matched_row_ids =
                    CONCAT( v_matched_row_ids , 'WCP Row ID: ' , api.api_nz_int( v_wcp_row_id , 0 ) , CHAR( 13 ) );
            #
            UPDATE wc.wc_participants
            SET
                email = v_new_email
            WHERE
                  row_id = v_wcp_row_id
              AND email = v_prv_email
              AND is_used_for_registration = 1
            LIMIT 1;
        END IF;
        
        /* cp*/
        IF v_cp_row_id THEN
            SET v_matched_row_ids =
                    CONCAT( v_matched_row_ids , 'CP Row ID: ' , api.api_nz_int( v_cp_row_id , 0 ) , CHAR( 13 ) );
            #
            UPDATE cp.cp_all_sso_users
            SET
                email = v_new_email
            WHERE
                  row_id = v_cp_row_id
              AND email = v_prv_email
              AND entitytype IN ('QB', 'SPM')
              AND is_used_for_registration = 1
            LIMIT 1;
        END IF;
        
        /* en*/
        IF v_en_row_id THEN
            SET v_matched_row_ids =
                    CONCAT( v_matched_row_ids , 'EN Row ID: ' , api.api_nz_int( v_en_row_id , 0 ) , CHAR( 13 ) );
            #
            UPDATE en.en_employees
            SET
                email = v_new_email
            WHERE
                  row_id = v_en_row_id
              AND email = v_prv_email
              AND is_used_for_registration = 1
            LIMIT 1;
        END IF;
        
        /* bs*/
        SET v_matched_row_ids =
                CONCAT( v_matched_row_ids , 'BS Row ID: ' , api.api_nz_int( v_bs_row_id , 0 ) , CHAR( 13 ) );
        #
        IF v_bs_row_id THEN
            UPDATE bs.bs_employees
            SET
                eeemail = v_new_email
            WHERE
                  row_id = v_bs_row_id
              AND eeemail = v_prv_email
              AND is_used_for_registration = 1
            LIMIT 1;
        END IF;
    
    END LOOP getvalues;
    #
    #
    CALL api.platform_user_change_email_log_attempt( CONCAT( p_attempt_type , ' - FINISHED' ) ,
                                                     p_search_for ,
                                                     p_replace_with ,
                                                     NULL ,
                                                     '' ,
                                                     '' ,
                                                     v_first_name ,
                                                     v_last_name ,
                                                     v_mobile_number ,
                                                     v_ssn ,
                                                     v_matched_user_ids ,
                                                     v_matched_row_ids ,
                                                     v_internal_messages ,
                                                     v_user_messages ,
                                                     v_status ,
                                                     v_email_status ,
                                                     NULL );
    
    #
    #     SET tx_isolation = v_default_isolation_level;
    #
    LEAVE full_proc;

END;

