CREATE
    DEFINER = root@`%` PROCEDURE upsert_all_wc_platform_participant_users_2(
    IN p_email varchar(200) )
full_proc:

BEGIN
    DECLARE v_email varchar(200);
    DECLARE v_is_active varchar(200);
    DECLARE v_is_active_employer int;
    DECLARE v_if_is_active int;
    DECLARE v_if_is_active_employer int;
    DECLARE v_if_unique_id varchar(200);
    DECLARE v_if_reward_amount varchar(200);
    DECLARE v_user_type varchar(200);
    DECLARE v_row_id varchar(200);
    DECLARE v_is_used_for_registration varchar(200);
    DECLARE v_employeeid varchar(200);
    DECLARE v_recordid varchar(200);
    DECLARE v_tpaid varchar(200);
    DECLARE v_employername varchar(200);
    DECLARE v_employerid varchar(200);
    DECLARE v_lastname varchar(200);
    DECLARE v_firstname varchar(200);
    DECLARE v_phone varchar(200);
    DECLARE v_addressline1 varchar(200);
    DECLARE v_addressline2 varchar(200);
    DECLARE v_city varchar(200);
    DECLARE v_state varchar(200);
    DECLARE v_zip varchar(200);
    DECLARE v_country varchar(200);
    DECLARE v_employeestatus varchar(200);
    DECLARE v_reimbursementmethod varchar(200);
    DECLARE v_birthdate varchar(200);
    DECLARE v_employeessn varchar(200);
    DECLARE v_cardnumber varchar(200);
    DECLARE v_mobilenumber varchar(200);
    DECLARE v_created_at varchar(200);
    DECLARE v_created_by varchar(200);
    DECLARE v_updated_at varchar(200);
    DECLARE v_updated_by varchar(200);
    
    DECLARE v_finished int;
    DECLARE v_values_cursor CURSOR FOR SELECT
                                           is_used_for_registration
                                         , email
                                         , is_active
                                         , is_active_employer
                                         , if_is_active
                                         , if_is_active_employer
                                         , t.if_reward_amount
                                         , user_type
                                         , row_id
                                         , employeeid
                                         , recordid
                                         , tpaid
                                         , employername
                                         , employerid
                                         , lastname
                                         , firstname
                                         , phone
                                         , addressline1
                                         , addressline2
                                         , city
                                         , state
                                         , zip
                                         , country
                                         , employeestatus
                                         , reimbursementmethod
                                         , birthdate
                                         , employeessn
                                         , cardnumber
                                         , mobilenumber
                                         , created_at
                                         , created_by
                                         , updated_at
                                         , updated_by
                                       FROM
                                           wc.vw_wc_participants t
                                       WHERE
                                           email = p_email
                                       ORDER BY
                                           email
                                         , user_type DESC
                                         , is_used_for_registration DESC
                                         , is_active DESC
                                       LIMIT 1;
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND BEGIN
        SET v_finished = 1;
    END;
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN
        GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
        CALL db_throw_error( @errno , 'upsert_all_wc_platform_participant_users_1' , @text );
    END;
    
    SET @@max_sp_recursion_depth = 12;
    
    OPEN v_values_cursor;
    
    getvalues
        :
    LOOP
        FETCH v_values_cursor INTO v_is_used_for_registration, v_email , v_is_active , v_is_active_employer, v_if_is_active, v_if_is_active_employer, v_if_reward_amount, v_user_type , v_row_id , v_employeeid , v_recordid , v_tpaid , v_employername , v_employerid , v_lastname , v_firstname , v_phone , v_addressline1 , v_addressline2 , v_city , v_state , v_zip , v_country , v_employeestatus , v_reimbursementmethod , v_birthdate , v_employeessn , v_cardnumber , v_mobilenumber , v_created_at , v_created_by , v_updated_at , v_updated_by;
        
        IF v_finished = 1 THEN
            LEAVE getvalues;
        END IF;
        
        IF !api.api_is_blank( v_email ) THEN
            CALL api.db_log_message( 'upsert_all_wc_platform_participant_users_2' ,
                                     CONCAT( 'Processing WC user for email: ' , p_email ,
                                             ' using record with row_id  ' , v_row_id , ' First name: ' , v_firstname ,
                                             ' and uselast namer_type ' , v_lastname ) , 'WARN' );
            #
            SET v_employeeid = api.api_nz( v_employeeid , '<NULL>' );
            
            # convert TEMP INACTIVE and TI to 2 - we took them as 0.5 so they will sort betyween inactive and active in selecting from viw
            IF v_is_active = '0.5' THEN
                SET v_is_active = '2';
                /* convert inactive to 3 so terminated employees with active employer will still see tiles but we can decide what to show them on the tile*/
            ELSEIF v_is_active = '0' AND v_is_active_employer > 0 THEN
                SET v_is_active = '3';
            END IF;
            
            #    incentfit status
            #             IF v_if_is_active = '0.5' THEN
            #                 SET v_if_is_active = '1';
            #                 /* convert inactive to 3 so terminated employees with active employer will still see tiles but we can decide what to show them on the tile*/
            #             ELSEIF v_if_is_active = '0' AND v_if_is_active_employer > 0 THEN
            #                 SET v_is_active = '3';
            #             END IF;
            #             #             set  platform user attributes
            IF api.api_cint( v_if_is_active ) THEN
                SET v_if_unique_id = CONCAT( v_employerid , '-' , v_employeeid );
            ELSE
                SET v_if_unique_id = '';
            END IF;
            
            CALL api.upsert_wc_platform_user( v_email , v_email , v_firstname , v_lastname , v_mobilenumber ,
                                              api.api_fix_ssn( api.api_nz( v_employeessn , v_employeeid ) ) , NULL ,
                                              NULL , NULL , NULL , v_tpaid , v_employerid , v_employeeid , v_birthdate ,
                                              v_cardnumber , NULL , (v_is_active) , NULL , v_row_id , NULL , v_zip ,
                                              v_is_used_for_registration , v_if_is_active , v_if_unique_id ,
                                              v_employername , v_if_reward_amount );
        
        END IF;
    END LOOP getvalues;
END;

