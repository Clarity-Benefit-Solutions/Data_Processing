CREATE
    DEFINER = root@`%` PROCEDURE upsert_el_platform_user(
                                                        IN p_user_name varchar(200),
                                                        IN p_email varchar(200),
                                                        IN p_first_name varchar(200),
                                                        IN p_last_name varchar(200),
                                                        IN p_mobile_number varchar(200),
                                                        IN p_ssn varchar(200),
                                                        IN p_ela_employer_id varchar(200),
                                                        IN p_ela_tpa_id varchar(200),
                                                        IN p_ela_client_user_id varchar(200),
                                                        IN p_ela_data_partner_id varchar(200),
                                                        IN p_elp_tpa_id varchar(200),
                                                        IN p_elp_employer_id varchar(200),
                                                        IN p_elp_employee_id varchar(200),
                                                        IN p_dob varchar(200),
                                                        IN p_el_card_number varchar(200),
                                                        IN p_ela_is_active int,
                                                        IN p_elp_is_active int,
                                                        IN p_ela_row_id int,
                                                        IN p_elp_row_id int,
                                                        IN p_ela_user_type varchar(50),
                                                        IN p_zip varchar(50),
                                                        IN p_is_used_for_registration varchar(200),
                                                        IN p_if_user_is_active int,
                                                        IN p_if_unique_id varchar(200),
                                                        IN p_elp_employer_name varchar(200),
                                                        IN p_if_reward_amount varchar(200) )
full_proc:

BEGIN
    DECLARE v_count varchar(50) DEFAULT NULL;
    DECLARE v_user_id int DEFAULT NULL;
    DECLARE v_user_id2 int DEFAULT NULL;
    DECLARE v_is_locked int DEFAULT NULL;
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN
        GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
        CALL db_log_error( @errno , 'upsert_el_platform_user' , @text , @sqlstate );
    END;
    
    CALL api.db_log_message( 'upsert_el_platform_user' ,
                             CONCAT( 'Processing for EMAIL: ' , p_email ) ,
                             'WARN' );
    
    SET p_email = api.api_fix_email( p_email );
    SET p_user_name = api.api_fix_email( p_user_name );
    SET p_mobile_number = api.api_fix_phone_number( p_mobile_number );
    SET p_ssn = api.api_fix_email( p_ssn );
    
    SET p_dob = api.api_fix_date( p_dob );
    SET p_zip = api.api_fix_zip( p_zip );
    
    IF api.api_is_blank( p_email ) AND api.api_is_blank( p_user_name ) THEN
        CALL api.db_log_message( 'upsert_el_platform_user' ,
                                 CONCAT( 'Not Inserting record as username, email is blank ' , 'ClientUserId: ' ,
                                         api.api_nz( p_ela_client_user_id , '' ) , ' EmployeeID: ' ,
                                         api.api_nz( p_elp_employee_id , '' ) )
            , 'WARN' );
        
        LEAVE full_proc;
    END IF;
    
    /* check for existing record using email*/
    SELECT
        COUNT( * )
      , user_id
      , CASE
            WHEN is_verified THEN 1
            ELSE 0
        END
    INTO v_count, v_user_id, v_is_locked
    FROM
        api.platform_users
    WHERE
        (email <=> p_email);
    
    SET v_user_id = api.api_nz_int( v_user_id , 0 );
    SET v_is_locked = api.api_nz_int( v_is_locked , 0 );
    
    CALL api.db_log_message( 'upsert_el_platform_user' ,
                             CONCAT( v_count , ' Records found for EMAIL: ' , api.api_nz( p_email , '' ) ) ,
                             'WARN' );
    
    /* sumeet: 2021-03-24  logic changed */
    /* if participant, proceed only if used for regn already or match for BOTH email and ssn*/
    IF (api.api_nz_int( p_ela_row_id , 0 ) = 0 AND
        api.api_is_blank( p_ela_tpa_id )) THEN
        
        /* platform data not used for regn yet?*/
        IF NOT p_is_used_for_registration THEN
            /* if blank ssn, cannot proceed*/
            IF api.api_is_blank( p_ssn ) THEN
                CALL api.db_log_message( 'upsert_el_platform_user' ,
                                         CONCAT(
                                                 'EXITING as Participant and not p_is_used_for_registration and SSN is blank ' ,
                                                 api.api_nz( p_email , '' ) , ', ' , api.api_nz( p_ssn , '' ) ) ,
                                         'WARN' );
                
                LEAVE full_proc;
            END IF;
            
            /*CHECK MATCH FOR BOTH SSN AND EMAIL*/
            SELECT
                user_id
            INTO v_user_id2
            FROM
                api.platform_users
            WHERE
                  (email = p_email)
              AND (api.api_fix_ssn( ssn ) = api.api_fix_ssn( p_ssn ));
            
            /* if did not find a match, exit*/
            IF NOT api.api_cbool( v_user_id2 ) THEN
                CALL api.db_log_message( 'upsert_el_platform_user' ,
                                         CONCAT(
                                                 'EXITING as Participant and not p_is_used_for_registration and no match for Email and SSN ' ,
                                                 api.api_nz( p_email , '' ) , ', ' , api.api_nz( p_ssn , '' ) ) ,
                                         'WARN' );
                
                LEAVE full_proc;
            END IF;
            
            /* if match found for email AND ssn, we will flag the source platform record and update the platform users record with source platform attributes*/
            CALL api.db_log_message( 'upsert_el_platform_user' ,
                                     CONCAT( v_count ,
                                             ' Records found for  EMAIL and SSN though Participant and not p_is_used_for_registration and not verified: ' ,
                                             api.api_nz( p_email , '' ) , ', ' , api.api_nz( p_ssn , '' ) ) ,
                                     'WARN' );
            
            /* mark is_used in origin table */
            UPDATE el.el_participants
            SET
                is_used_for_registration =1
            WHERE
                ROW_ID = p_elp_row_id;
            
            /* we will update the record for thsi user id*/
            SET v_user_id = v_user_id2;
        
        END IF;
    END IF;
    
    IF api.api_cbool( v_user_id ) THEN
        CALL api.db_log_message( 'upsert_el_platform_user' ,
                                 CONCAT( 'UPDATING existing ' , v_count , ' records for EMAIL: ' ,
                                         api.api_nz( p_email , '' ) ) , 'WARN' );
        
        UPDATE api.platform_users
        SET
            user_name           = api.api_if_true_else( v_is_locked , user_name ,
                                                        api.api_nz( p_user_name , user_name ) )
          , first_name          = api.api_if_true_else( v_is_locked , first_name ,
                                                        api.api_nz( p_first_name , first_name ) )
          , last_name           = api.api_if_true_else( v_is_locked , last_name ,
                                                        api.api_nz( p_last_name , last_name ) )
          , email               = api.api_if_true_else( v_is_locked , email , api.api_nz( p_email , email ) )
          , mobile_number       = api.api_if_true_else( v_is_locked , mobile_number ,
                                                        api.api_nz( p_mobile_number , mobile_number ) )
          , ssn                 = api.api_if_true_else( v_is_locked , ssn , api.api_nz( p_ssn , ssn ) )
          , dob                 = api.api_if_true_else( v_is_locked , dob , api.api_nz( p_dob , dob ) )
          , employee_id         = api.api_if_true_else( v_is_locked , employee_id ,
                                                        api.api_nz( p_elp_employee_id , employee_id ) )
          , ela_employer_id     = api.api_nz( p_ela_employer_id , ela_employer_id )
          , ela_tpa_id          = api.api_nz( p_ela_tpa_id , ela_tpa_id )
          , ela_client_user_id  = api.api_nz( p_ela_client_user_id , ela_client_user_id )
          , ela_data_partner_id = api.api_nz( p_ela_data_partner_id , ela_data_partner_id )
          , elp_employer_id     = api.api_nz( p_elp_employer_id , elp_employer_id )
          , elp_employer_name   = api.api_nz( p_elp_employer_name , elp_employer_name )
          , elp_tpa_id          = api.api_nz( p_elp_tpa_id , elp_tpa_id )
          , elp_employee_id     = api.api_nz( p_elp_employee_id , elp_employee_id )
          , el_dob              = api.api_nz( p_dob , el_dob )
          , el_card_number      = api.api_nz( p_el_card_number , el_card_number )
          , ela_user_is_active  = api.api_nz_int( p_ela_is_active , ela_user_is_active )
          , elp_user_is_active  = api.api_nz_int( p_elp_is_active , elp_user_is_active )
          , el_ssn              = api.api_nz( p_ssn , el_ssn )
          , el_email            = api.api_nz( p_email , el_email )
          , ela_row_id= IFNULL( p_ela_row_id , ela_row_id )
          , elp_row_id= IFNULL( p_elp_row_id , elp_row_id )
          , ela_user_type       = p_ela_user_type
          , zip                 = api.api_nz( p_zip , zip )
          , el_zip              = api.api_nz( p_zip , el_zip )
          , last_updated_from   = 'upsert_el_platform_user'
          , if_user_is_active   = api.api_nz_int( p_if_user_is_active , if_user_is_active )
          , if_unique_id        = api.api_nz( p_if_unique_id , if_unique_id )
          , if_reward_amount    = api.api_nz_float( p_if_reward_amount , if_reward_amount )
        
        WHERE
            (email <=> p_email);
        
        LEAVE full_proc;
    END IF;
    
    CALL api.db_log_message( 'upsert_el_platform_user' ,
                             CONCAT( 'UPSERTING record WCA UserID: ' , api.api_nz( p_ela_client_user_id , '' ) ,
                                     ' AND WCP EmployeeID: ' , api.api_nz( p_elp_employee_id , '' ) ) , 'WARN' );
    
    INSERT INTO api.platform_users(
                                    user_name
                                  , first_name
                                  , last_name
                                  , email
                                  , mobile_number
                                  , ela_employer_id
                                  , ela_tpa_id
                                  , ela_client_user_id
                                  , ela_data_partner_id
                                  , elp_employer_id
                                  , elp_employer_name
                                  , elp_tpa_id
                                  , elp_employee_id
                                  , el_dob
                                  , dob
                                  , ssn
                                  , employee_id
                                  , el_card_number
                                  , ela_user_is_active
                                  , elp_user_is_active
                                  , el_ssn
                                  , el_email
                                  , ela_row_id
                                  , elp_row_id
                                  , last_updated_from
                                  , ela_user_type
                                  , zip
                                  , el_zip
        /*  , if_user_is_active
          , if_unique_id
          , if_reward_amount*/
    )
    VALUES (
               p_user_name
           ,   p_first_name
           ,   p_last_name
           ,   p_email
           ,   p_mobile_number
           ,   p_ela_employer_id
           ,   p_ela_tpa_id
           ,   p_ela_client_user_id
           ,   p_ela_data_partner_id
           ,   p_elp_employer_id
           ,   p_elp_employer_name
           ,   p_elp_tpa_id
           ,   p_elp_employee_id
           ,   p_dob
           ,   p_dob
           ,   p_ssn
           ,   p_elp_employee_id
           ,   p_el_card_number
           ,   p_ela_is_active
           ,   p_elp_is_active
           ,   p_ssn
           ,   p_email
           ,   p_ela_row_id
           ,   p_elp_row_id
           ,   'upsert_el_platform_user'
           ,   p_ela_user_type
           ,   p_zip
           ,   p_zip
               /*  ,   p_if_user_is_active
                 ,   p_if_unique_id
                 ,   p_if_reward_amount*/
           )
    
    ON DUPLICATE KEY UPDATE
                         user_name           = api.api_if_true_else( v_is_locked , user_name ,
                                                                     api.api_nz( p_user_name , user_name ) )
                       , first_name          = api.api_if_true_else( v_is_locked , first_name ,
                                                                     api.api_nz( p_first_name , first_name ) )
                       , last_name           = api.api_if_true_else( v_is_locked , last_name ,
                                                                     api.api_nz( p_last_name , last_name ) )
                       , email               = api.api_if_true_else( v_is_locked , email ,
                                                                     api.api_nz( p_email , email ) )
                       , mobile_number       = api.api_if_true_else( v_is_locked , mobile_number ,
                                                                     api.api_nz( p_mobile_number , mobile_number ) )
                       , ssn                 = api.api_if_true_else( v_is_locked , ssn , api.api_nz( p_ssn , ssn ) )
                       , dob                 = api.api_if_true_else( v_is_locked , dob , api.api_nz( p_dob , dob ) )
                       , employee_id         = api.api_if_true_else( v_is_locked , employee_id ,
                                                                     api.api_nz( p_elp_employee_id , employee_id ) )
                       , ela_employer_id     = api.api_nz( p_ela_employer_id , ela_employer_id )
                       , ela_tpa_id          = api.api_nz( p_ela_tpa_id , ela_tpa_id )
                       , ela_client_user_id  = api.api_nz( p_ela_client_user_id , ela_client_user_id )
                       , ela_data_partner_id = api.api_nz( p_ela_data_partner_id , ela_data_partner_id )
                       , elp_employer_id     = api.api_nz( p_elp_employer_id , elp_employer_id )
                       , elp_employer_name   = api.api_nz( p_elp_employer_name , elp_employer_name )
                       , elp_tpa_id          = api.api_nz( p_elp_tpa_id , elp_tpa_id )
                       , elp_employee_id     = api.api_nz( p_elp_employee_id , elp_employee_id )
                       , el_dob              = api.api_nz( p_dob , el_dob )
                       , el_card_number      = api.api_nz( p_el_card_number , el_card_number )
                       , ela_user_is_active  = api.api_nz_int( p_ela_is_active , ela_user_is_active )
                       , elp_user_is_active  = api.api_nz_int( p_elp_is_active , elp_user_is_active )
                       , el_ssn              = api.api_nz( p_ssn , el_ssn )
                       , el_email            = api.api_nz( p_email , el_email )
                       , ela_row_id= IFNULL( p_ela_row_id , ela_row_id )
                       , elp_row_id= IFNULL( p_elp_row_id , elp_row_id )
                       , ela_user_type= IFNULL( p_ela_user_type , ela_user_type )
                       , zip                 = api.api_nz( p_zip , zip )
                       , el_zip              = api.api_nz( p_zip , el_zip )
                       , last_updated_from   = 'upsert_el_platform_user'
    /*   , if_user_is_active   = api.api_nz_int( p_if_user_is_active , if_user_is_active )
       , if_unique_id        = api.api_nz( p_if_unique_id , if_unique_id )
       , if_reward_amount    = api.api_nz_float( p_if_reward_amount , if_reward_amount )*/;
END;

