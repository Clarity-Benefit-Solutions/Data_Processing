CREATE DEFINER = root@`%` TRIGGER au_audit_en_employees_deletes
    AFTER DELETE
    ON en_employees
    FOR EACH ROW
    INSERT INTO `en`.`en_employees_audit`
                 (`auditAction`, `row_id`, `companyidentifier`, `firstname`, `lastname`, `ssn`, `employeeid`,
                  `employeestatus`, `address1`, `address2`, `city`, `state`, `zip`, `phone`, `email`, `dob`,
                  `terminationdate`, `enparticipant`, `created_at`, `created_by`, `updated_at`, `updated_by`,
                  `match_employeeid_last`, `match_ssn_last`, `match_dob_last`, `match_phone_last`, `matched_zip`,
                  `is_used_for_registration`, `matched_ssn_emp_id_last`)
                 VALUES ('DELETE', OLD.`row_id`, OLD.`companyidentifier`, OLD.`firstname`, OLD.`lastname`, OLD.`ssn`,
                         OLD.`employeeid`, OLD.`employeestatus`, OLD.`address1`, OLD.`address2`, OLD.`city`,
                         OLD.`state`, OLD.`zip`, OLD.`phone`, OLD.`email`, OLD.`dob`, OLD.`terminationdate`,
                         OLD.`enparticipant`, OLD.`created_at`, OLD.`created_by`, OLD.`updated_at`, OLD.`updated_by`,
                         OLD.`match_employeeid_last`, OLD.`match_ssn_last`, OLD.`match_dob_last`,
                         OLD.`match_phone_last`, OLD.`matched_zip`, OLD.`is_used_for_registration`,
                         OLD.`matched_ssn_emp_id_last`);

