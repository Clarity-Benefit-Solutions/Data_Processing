CREATE
    DEFINER = root@`%` PROCEDURE upsert_en_employees(
                                                    IN p_companyidentifier varchar(200),
                                                    IN p_firstname varchar(200),
                                                    IN p_lastname varchar(200),
                                                    IN p_employeeid varchar(200),
                                                    IN p_ssn varchar(200),
                                                    IN p_employeestatus varchar(200),
                                                    IN p_address1 varchar(200),
                                                    IN p_address2 varchar(200),
                                                    IN p_city varchar(200),
                                                    IN p_state varchar(200),
                                                    IN p_zip varchar(200),
                                                    IN p_phone varchar(200),
                                                    IN p_email varchar(200),
                                                    IN p_dob varchar(200),
                                                    IN p_enparticipant varchar(200),
                                                    IN p_terminationdate varchar(200) )
BEGIN
    
    -- handle error that may happen as the table has a few unique keys which may conflict
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO,
                @text = MESSAGE_TEXT;
            SET @text = CONCAT( @text , CONCAT( '
Called With Params: ' , ', companyidentifier: ' , api.api_nz( `p_companyidentifier` , '' ) , ', firstname: ' ,
                                                api.api_nz( `p_firstname` , '' ) , ', lastname: ' ,
                                                api.api_nz( `p_lastname` , '' ) , ', ssn: ' ,
                                                api.api_nz( `p_ssn` , '' ) , ', employeeid: ' ,
                                                api.api_nz( `p_employeeid` , '' ) , ', employeestatus: ' ,
                                                api.api_nz( `p_employeestatus` , '' ) , ', address1: ' ,
                                                api.api_nz( `p_address1` , '' ) , ', address2: ' ,
                                                api.api_nz( `p_address2` , '' ) , ', city: ' ,
                                                api.api_nz( `p_city` , '' ) , ', state: ' ,
                                                api.api_nz( `p_state` , '' ) , ', zip: ' , api.api_nz( `p_zip` , '' ) ,
                                                ', phone: ' , api.api_nz( `p_phone` , '' ) , ', email: ' ,
                                                api.api_nz( `p_email` , '' ) , ', dob: ' , api.api_nz( `p_dob` , '' ) ,
                                                ', terminationdate: ' , api.api_nz( `p_terminationdate` , '' ) ,
                                                ', enparticipant: ' , api.api_nz( `p_enparticipant` , '' ) /*,
                                                ', is_used_for_registration: ' ,
                                                api.api_nz( `p_is_used_for_registration` , '' ) */) );
            CALL api.db_log_message( 'upsert_en_employees' , @text , 'ERROR' );
        END;
    
    CALL api.db_log_message( 'upsert_en_employees' , CONCAT( 'Called With Params: ' , ', companyidentifier: ' ,
                                                             api.api_nz( `p_companyidentifier` , '' ) ,
                                                             ', firstname: ' , api.api_nz( `p_firstname` , '' ) ,
                                                             ', lastname: ' , api.api_nz( `p_lastname` , '' ) ,
                                                             ', ssn: ' , api.api_nz( `p_ssn` , '' ) , ', employeeid: ' ,
                                                             api.api_nz( `p_employeeid` , '' ) , ', employeestatus: ' ,
                                                             api.api_nz( `p_employeestatus` , '' ) , ', address1: ' ,
                                                             api.api_nz( `p_address1` , '' ) , ', address2: ' ,
                                                             api.api_nz( `p_address2` , '' ) , ', city: ' ,
                                                             api.api_nz( `p_city` , '' ) , ', state: ' ,
                                                             api.api_nz( `p_state` , '' ) , ', zip: ' ,
                                                             api.api_nz( `p_zip` , '' ) , ', phone: ' ,
                                                             api.api_nz( `p_phone` , '' ) , ', email: ' ,
                                                             api.api_nz( `p_email` , '' ) , ', dob: ' ,
                                                             api.api_nz( `p_dob` , '' ) , ', terminationdate: ' ,
                                                             api.api_nz( `p_terminationdate` , '' ) ,
                                                             ', enparticipant: ' ,
                                                             api.api_nz( `p_enparticipant` , '' ) /*,
                                                             ', is_used_for_registration: ' ,
                                                             api.api_nz( `p_is_used_for_registration` , '' )*/ ) ,
                             'WARN' );
    
    SET p_state = api.api_cbool( p_state );
    
    INSERT INTO en.en_employees(
                                 companyidentifier
                               , firstname
                               , lastname
                               , employeeid
                               , ssn
                               , employeestatus
                               , address1
                               , address2
                               , city
                               , state
                               , zip
                               , phone
                               , email
                               , dob
                               , enparticipant
                               , terminationdate
    )
    VALUES (
               p_companyidentifier
           ,   p_firstname
           ,   p_lastname
           ,   p_employeeid
           ,   p_ssn
           ,   p_employeestatus
           ,   p_address1
           ,   p_address2
           ,   p_city
           ,   p_state
           ,   p_zip
           ,   p_phone
           ,   p_email
           ,   p_dob
           ,   p_enparticipant
           ,   p_terminationdate
           )
    ON DUPLICATE KEY UPDATE
                         companyidentifier = p_companyidentifier
                       , firstname         = p_firstname
                       , lastname          = p_lastname
                       , employeeid        = p_employeeid
                       , ssn               = p_ssn
                       , employeestatus    = p_employeestatus
                       , address1          = p_address1
                       , address2          = p_address2
                       , city              = p_city
                       , state             = p_state
                       , zip               = p_zip
                       , phone             = p_phone
        /*            2021-03-16 - do not change email once that record (matched by employerid, employeeid has been used for registration by a participant - to ensure we can alwyas sync updated data for that part back to platform users
         if email has changed to become blank and is not yet is_used_for_registration, replace old email with new email even if new one blank */
        /*`email`               = api.api_nz( `p_email` , `email` ),*/
                       , `email`           = api.api_if_true_else( is_used_for_registration , email ,
                                                                   api.api_nz( p_email , '' ) )
        /* end*/
       
                       , dob               = p_dob
                       , enparticipant     = p_enparticipant
                       , terminationdate   = p_terminationdate;

END;

