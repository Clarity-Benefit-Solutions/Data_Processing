CREATE DEFINER = root@`%` VIEW vw_en_employees
AS
    SELECT
        `t`.`email` `email`
      , `en`.`en_is_active_status`( `t`.`employeestatus` ) `is_active`
      , CASE
            WHEN `t`.`enparticipant` LIKE '1' THEN '0 EMPLOYEE'
            ELSE '00'
        END `user_type`
      , `t`.`row_id` `row_id`
      , `t`.`companyidentifier` `companyidentifier`
      , `t`.`firstname` `firstname`
      , `t`.`lastname` `lastname`
      , `t`.`ssn` `ssn`
      , `t`.`employeeid` `employeeid`
      , `t`.`employeestatus` `employeestatus`
      , `t`.`address1` `address1`
      , `t`.`address2` `address2`
      , `t`.`city` `city`
      , `t`.`state` `state`
      , `t`.`zip` `zip`
      , `t`.`phone` `phone`
      , `t`.`dob` `dob`
      , `t`.`terminationdate` `terminationdate`
      , `t`.`enparticipant` `enparticipant`
      , `t`.`created_at` `created_at`
      , `t`.`created_by` `created_by`
      , `t`.`updated_at` `updated_at`
      , `t`.`updated_by` `updated_by`
      , `t`.`is_used_for_registration` `is_used_for_registration`
    FROM
        `en`.`en_employees` `t`
    WHERE
        !`api`.`upsert_ignore_this_email`( `t`.`email` , 'en' );

