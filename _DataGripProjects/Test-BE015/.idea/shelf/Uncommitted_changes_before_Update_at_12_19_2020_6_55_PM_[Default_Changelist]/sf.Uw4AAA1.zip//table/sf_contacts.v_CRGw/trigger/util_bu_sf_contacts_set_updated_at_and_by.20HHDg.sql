CREATE DEFINER = admin@`%` TRIGGER util_bu_sf_contacts_set_updated_at_and_by
    BEFORE UPDATE
    ON sf_contacts
    FOR EACH ROW
BEGIN
    SET new.updated_at = CURRENT_TIMESTAMP;
    SET new.updated_by = current_user;
END;

