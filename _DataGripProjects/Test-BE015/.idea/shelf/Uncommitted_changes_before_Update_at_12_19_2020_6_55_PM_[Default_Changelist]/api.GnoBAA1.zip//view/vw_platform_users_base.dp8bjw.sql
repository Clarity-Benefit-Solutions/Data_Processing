CREATE DEFINER = root@`%` VIEW vw_platform_users_base AS
SELECT api.platform_users.user_name                   AS user_name,
       api.platform_users.email                       AS email,
       api.platform_users.user_id                     AS user_id,
       api.platform_users.first_name                  AS first_name,
       api.platform_users.last_name                   AS last_name,
       api.platform_users.is_invalid                  AS is_invalid,
       api.platform_users.is_ready_for_sso_processing AS is_ready_for_sso_processing,
       api.platform_users.invited_as_user_type        AS invited_as_user_type,
       CASE
           WHEN !api.api_is_blank( api.platform_users.cp_user_id ) AND
                api.api_cbool( api.platform_users.cp_tpa_user_is_active )
               THEN 1
           ELSE 0
       END                                            AS is_cp_tpa_admin,
       CASE
           WHEN api.platform_users.cp_broker_id > '0' AND api.api_cbool( api.platform_users.cp_member_user_is_active )
               THEN 1
           ELSE 0
       END                                            AS is_cp_broker,
       CASE
           WHEN api.platform_users.cp_client_contact_id > '0' AND
                api.api_cbool( api.platform_users.cp_member_user_is_active )
               THEN 1
           ELSE 0
       END                                            AS is_cp_client,
       CASE
           WHEN api.platform_users.cp_member_id > '0' AND api.api_cbool( api.platform_users.cp_member_user_is_active )
               THEN 1
           ELSE 0
       END                                            AS is_cp_particpant,
       0                                              AS is_wc_tpa_admin,
       0                                              AS is_wc_broker,
       CASE
           WHEN !api.api_is_blank( api.platform_users.wca_client_user_id ) AND
                api.api_cbool( api.platform_users.wca_user_is_active )
               THEN 1
           ELSE 0
       END                                            AS is_wc_client,
       CASE
           WHEN !api.api_is_blank( api.platform_users.wcp_employee_id ) AND
                api.api_cbool( api.platform_users.wcp_user_is_active )
               THEN 1
           ELSE 0
       END                                            AS is_wc_particpant,
       CASE
           WHEN api.api_cbool( api.platform_users.bs_is_topdog ) AND
                api.api_cbool( api.platform_users.bs_user_is_active )
               THEN 1
           ELSE 0
       END                                            AS is_bs_tpa_admin,
       CASE
           WHEN api.api_cbool( api.platform_users.bs_is_topdog ) AND
                api.api_cbool( api.platform_users.bs_user_is_active )
               THEN 1
           ELSE 0
       END                                            AS is_bs_broker,
       CASE
           WHEN (api.api_cbool( api.platform_users.bs_is_manager ) OR
                 api.api_cbool( api.platform_users.bs_is_topdog )) AND
                api.api_cbool( api.platform_users.bs_user_is_active )
               THEN 1
           ELSE 0
       END                                            AS is_bs_client,
       CASE
           WHEN api.api_cbool( api.platform_users.bs_is_employee ) AND
                api.api_cbool( api.platform_users.bs_user_is_active )
               THEN 1
           ELSE 0
       END                                            AS is_bs_particpant,
       CASE
           WHEN api.api_cbool( api.platform_users.en_is_tpa_user ) AND
                api.api_cbool( api.platform_users.en_user_is_active )
               THEN 1
           ELSE 0
       END                                            AS is_en_tpa_admin,
       CASE
           WHEN api.api_cbool( api.platform_users.en_is_tpa_user ) AND
                api.api_cbool( api.platform_users.en_user_is_active )
               THEN 1
           ELSE 0
       END                                            AS is_en_broker,
       CASE
           WHEN (api.api_cbool( api.platform_users.en_is_manager ) OR
                 api.api_cbool( api.platform_users.en_is_tpa_user )) AND
                api.api_cbool( api.platform_users.en_user_is_active )
               THEN 1
           ELSE 0
       END                                            AS is_en_client,
       CASE
           WHEN api.api_cbool( api.platform_users.en_is_employee ) AND
                api.api_cbool( api.platform_users.en_user_is_active )
               THEN 1
           ELSE 0
       END                                            AS is_en_particpant,
       CASE
           WHEN api.api_cbool( api.platform_users.cp_tpa_user_is_active ) OR
                api.api_cbool( api.platform_users.cp_member_user_is_active ) OR
                api.api_cbool( api.platform_users.wca_user_is_active ) OR
                api.api_cbool( api.platform_users.wcp_user_is_active ) OR
                api.api_cbool( api.platform_users.en_user_is_active ) OR
                api.api_cbool( api.platform_users.bs_user_is_active )
               THEN 1
           ELSE 0
       END                                            AS is_active,
       api.platform_users.alternate_email             AS alternate_email,
       api.platform_users.title                       AS title,
       api.platform_users.mobile_number               AS mobile_number,
       api.platform_users.ssn                         AS ssn,
       api.platform_users.dob                         AS dob,
       api.platform_users.employee_id                 AS employee_id,
       api.platform_users.invite_token                AS invite_token,
       api.platform_users.last_invite_token_sent_date AS last_invite_token_sent_date,
       api.platform_users.is_invited                  AS is_invited,
       api.platform_users.is_verified                 AS is_verified,
       api.platform_users.cp_client_id                AS cp_client_id,
       api.platform_users.cp_broker_id                AS cp_broker_id,
       api.platform_users.cp_client_contact_id        AS cp_client_contact_id,
       api.platform_users.cp_sso_identifier           AS cp_sso_identifier,
       api.platform_users.cp_customer_id              AS cp_customer_id,
       api.platform_users.cp_entity_type              AS cp_entity_type,
       api.platform_users.cp_user_id                  AS cp_user_id,
       api.platform_users.cp_tpa_user_is_active       AS cp_tpa_user_is_active,
       api.platform_users.cp_member_id                AS cp_member_id,
       api.platform_users.cp_member_user_is_active    AS cp_member_user_is_active,
       api.platform_users.cp_allow_sso                AS cp_allow_sso,
       api.platform_users.cp_ssn                      AS cp_ssn,
       api.platform_users.cp_email                    AS cp_email,
       api.platform_users.cp_dob                      AS cp_dob,
       api.platform_users.wc_card_number              AS wc_card_number,
       api.platform_users.wc_dob                      AS wc_dob,
       api.platform_users.wc_ssn                      AS wc_ssn,
       api.platform_users.wc_email                    AS wc_email,
       api.platform_users.wca_tpa_id                  AS wca_tpa_id,
       api.platform_users.wca_employer_id             AS wca_employer_id,
       api.platform_users.wca_data_partner_id         AS wca_data_partner_id,
       api.platform_users.wca_client_user_id          AS wca_client_user_id,
       api.platform_users.wca_user_is_active          AS wca_user_is_active,
       api.platform_users.wcp_tpa_id                  AS wcp_tpa_id,
       api.platform_users.wcp_employer_id             AS wcp_employer_id,
       api.platform_users.wcp_employee_id             AS wcp_employee_id,
       api.platform_users.wcp_user_is_active          AS wcp_user_is_active,
       api.platform_users.bs_user_id                  AS bs_user_id,
       api.platform_users.bs_import_user_id           AS bs_import_user_id,
       api.platform_users.bs_user_name                AS bs_user_name,
       api.platform_users.bs_user_is_active           AS bs_user_is_active,
       api.platform_users.bs_dob                      AS bs_dob,
       api.platform_users.bs_work_email               AS bs_work_email,
       api.platform_users.bs_payroll_id               AS bs_payroll_id,
       api.platform_users.bs_abbrev_url               AS bs_abbrev_url,
       api.platform_users.bs_ssn                      AS bs_ssn,
       api.platform_users.bs_email                    AS bs_email,
       api.platform_users.bs_employer_id              AS bs_employer_id,
       api.platform_users.bs_is_employee              AS bs_is_employee,
       api.platform_users.bs_is_manager               AS bs_is_manager,
       api.platform_users.bs_is_topdog                AS bs_is_topdog,
       api.platform_users.en_email                    AS en_email,
       api.platform_users.en_user_is_active           AS en_user_is_active,
       api.platform_users.en_is_employee              AS en_is_employee,
       api.platform_users.en_is_manager               AS en_is_manager,
       api.platform_users.en_is_tpa_user              AS en_is_tpa_user,
       api.platform_users.sf_email                    AS sf_email,
       api.platform_users.sf_row_id                   AS sf_row_id,
       api.platform_users.sf_employer_id              AS sf_employer_id,
       api.platform_users.sf_dob                      AS sf_dob,
       api.platform_users.sf_ssn                      AS sf_ssn,
       api.platform_users.sf_user_is_active           AS sf_user_is_active,
       api.platform_users.sf_is_employee              AS sf_is_employee,
       api.platform_users.sf_is_client                AS sf_is_client,
       api.platform_users.sf_is_broker                AS sf_is_broker,
       api.platform_users.created_at                  AS created_at,
       api.platform_users.created_by                  AS created_by,
       api.platform_users.updated_at                  AS updated_at,
       api.platform_users.updated_by                  AS updated_by
FROM api.platform_users;

