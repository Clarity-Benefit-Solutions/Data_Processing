CREATE DEFINER = root@`%` VIEW vw_platform_users_base2 AS
SELECT vw_platform_users_base.user_name                   AS user_name,
       vw_platform_users_base.email                       AS email,
       vw_platform_users_base.user_id                     AS user_id,
       vw_platform_users_base.first_name                  AS first_name,
       vw_platform_users_base.last_name                   AS last_name,
       vw_platform_users_base.ssn                         AS ssn,
       vw_platform_users_base.is_ready_for_sso_processing AS is_ready_for_sso_processing,
       vw_platform_users_base.is_invalid                  AS is_invalid,
       vw_platform_users_base.invited_as_user_type        AS invited_as_user_type,
       CASE
           WHEN vw_platform_users_base.is_cp_client <> 0 OR vw_platform_users_base.is_wc_client <> 0 OR
                vw_platform_users_base.is_bs_client <> 0 OR vw_platform_users_base.invited_as_user_type = 'CLIENT'
               THEN 1
           ELSE 0
       END                                                AS is_client,
       CASE
           WHEN vw_platform_users_base.is_cp_broker <> 0 OR vw_platform_users_base.is_wc_broker <> 0 OR
                vw_platform_users_base.is_bs_broker <> 0 OR vw_platform_users_base.invited_as_user_type = 'BROKER'
               THEN 1
           ELSE 0
       END                                                AS is_broker,
       CASE
           WHEN vw_platform_users_base.is_cp_tpa_admin <> 0 OR vw_platform_users_base.is_wc_tpa_admin <> 0 OR
                vw_platform_users_base.is_bs_tpa_admin <> 0 OR vw_platform_users_base.invited_as_user_type = 'TPA_ADMIN'
               THEN 1
           ELSE 0
       END                                                AS is_tpa_admin,
       CASE
           WHEN vw_platform_users_base.is_cp_particpant <> 0 OR vw_platform_users_base.is_wc_particpant <> 0 OR
                vw_platform_users_base.is_bs_particpant <> 0
               THEN 1
           ELSE 0
       END                                                AS is_particpant,
       vw_platform_users_base.is_cp_tpa_admin             AS is_cp_tpa_admin,
       vw_platform_users_base.is_cp_broker                AS is_cp_broker,
       vw_platform_users_base.is_cp_client                AS is_cp_client,
       vw_platform_users_base.is_cp_particpant            AS is_cp_particpant,
       vw_platform_users_base.is_wc_tpa_admin             AS is_wc_tpa_admin,
       vw_platform_users_base.is_wc_broker                AS is_wc_broker,
       vw_platform_users_base.is_wc_client                AS is_wc_client,
       vw_platform_users_base.is_wc_particpant            AS is_wc_particpant,
       vw_platform_users_base.is_bs_tpa_admin             AS is_bs_tpa_admin,
       vw_platform_users_base.is_bs_broker                AS is_bs_broker,
       vw_platform_users_base.is_bs_client                AS is_bs_client,
       vw_platform_users_base.is_bs_particpant            AS is_bs_particpant,
       vw_platform_users_base.is_en_tpa_admin             AS is_en_tpa_admin,
       vw_platform_users_base.is_en_broker                AS is_en_broker,
       vw_platform_users_base.is_en_client                AS is_en_client,
       vw_platform_users_base.is_en_particpant            AS is_en_particpant,
       vw_platform_users_base.is_active                   AS is_active,
       vw_platform_users_base.alternate_email             AS alternate_email,
       vw_platform_users_base.title                       AS title,
       vw_platform_users_base.mobile_number               AS mobile_number,
       vw_platform_users_base.dob                         AS dob,
       vw_platform_users_base.employee_id                 AS employee_id,
       vw_platform_users_base.invite_token                AS invite_token,
       vw_platform_users_base.last_invite_token_sent_date AS last_invite_token_sent_date,
       vw_platform_users_base.is_invited                  AS is_invited,
       vw_platform_users_base.is_verified                 AS is_verified,
       vw_platform_users_base.cp_client_id                AS cp_client_id,
       vw_platform_users_base.cp_broker_id                AS cp_broker_id,
       vw_platform_users_base.cp_client_contact_id        AS cp_client_contact_id,
       vw_platform_users_base.cp_sso_identifier           AS cp_sso_identifier,
       vw_platform_users_base.cp_customer_id              AS cp_customer_id,
       vw_platform_users_base.cp_entity_type              AS cp_entity_type,
       vw_platform_users_base.cp_user_id                  AS cp_user_id,
       vw_platform_users_base.cp_tpa_user_is_active       AS cp_tpa_user_is_active,
       vw_platform_users_base.cp_member_id                AS cp_member_id,
       vw_platform_users_base.cp_member_user_is_active    AS cp_member_user_is_active,
       vw_platform_users_base.cp_allow_sso                AS cp_allow_sso,
       vw_platform_users_base.cp_ssn                      AS cp_ssn,
       vw_platform_users_base.cp_email                    AS cp_email,
       vw_platform_users_base.cp_dob                      AS cp_dob,
       vw_platform_users_base.wc_card_number              AS wc_card_number,
       vw_platform_users_base.wc_dob                      AS wc_dob,
       vw_platform_users_base.wc_ssn                      AS wc_ssn,
       vw_platform_users_base.wc_email                    AS wc_email,
       vw_platform_users_base.wca_tpa_id                  AS wca_tpa_id,
       vw_platform_users_base.wca_employer_id             AS wca_employer_id,
       vw_platform_users_base.wca_data_partner_id         AS wca_data_partner_id,
       vw_platform_users_base.wca_client_user_id          AS wca_client_user_id,
       vw_platform_users_base.wca_user_is_active          AS wca_user_is_active,
       vw_platform_users_base.wcp_tpa_id                  AS wcp_tpa_id,
       vw_platform_users_base.wcp_employer_id             AS wcp_employer_id,
       vw_platform_users_base.wcp_employee_id             AS wcp_employee_id,
       vw_platform_users_base.wcp_user_is_active          AS wcp_user_is_active,
       vw_platform_users_base.bs_user_id                  AS bs_user_id,
       vw_platform_users_base.bs_abbrev_url               AS bs_abbrev_url,
       vw_platform_users_base.bs_import_user_id           AS bs_import_user_id,
       vw_platform_users_base.bs_user_name                AS bs_user_name,
       vw_platform_users_base.bs_user_is_active           AS bs_user_is_active,
       vw_platform_users_base.bs_dob                      AS bs_dob,
       vw_platform_users_base.bs_work_email               AS bs_work_email,
       vw_platform_users_base.bs_payroll_id               AS bs_payroll_id,
       vw_platform_users_base.bs_ssn                      AS bs_ssn,
       vw_platform_users_base.bs_email                    AS bs_email,
       vw_platform_users_base.bs_employer_id              AS bs_employer_id,
       vw_platform_users_base.bs_is_employee              AS bs_is_employee,
       vw_platform_users_base.bs_is_manager               AS bs_is_manager,
       vw_platform_users_base.bs_is_topdog                AS bs_is_topdog,
       vw_platform_users_base.en_email                    AS en_email,
       vw_platform_users_base.en_user_is_active           AS en_user_is_active,
       vw_platform_users_base.en_is_employee              AS en_is_employee,
       vw_platform_users_base.en_is_manager               AS en_is_manager,
       vw_platform_users_base.en_is_tpa_user              AS en_is_tpa_user,
       vw_platform_users_base.sf_email                    AS sf_email,
       vw_platform_users_base.sf_row_id                   AS sf_row_id,
       vw_platform_users_base.sf_employer_id              AS sf_employer_id,
       vw_platform_users_base.sf_dob                      AS sf_dob,
       vw_platform_users_base.sf_ssn                      AS sf_ssn,
       vw_platform_users_base.sf_user_is_active           AS sf_user_is_active,
       vw_platform_users_base.sf_is_employee              AS sf_is_employee,
       vw_platform_users_base.sf_is_client                AS sf_is_client,
       vw_platform_users_base.sf_is_broker                AS sf_is_broker,
       vw_platform_users_base.created_at                  AS created_at,
       vw_platform_users_base.created_by                  AS created_by,
       vw_platform_users_base.updated_at                  AS updated_at,
       vw_platform_users_base.updated_by                  AS updated_by
FROM api.vw_platform_users_base;

