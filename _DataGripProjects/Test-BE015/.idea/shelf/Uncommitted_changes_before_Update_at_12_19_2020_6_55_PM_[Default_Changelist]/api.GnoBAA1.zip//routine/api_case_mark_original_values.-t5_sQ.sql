CREATE
    DEFINER = admin@`%` PROCEDURE api_case_mark_original_values( IN p_case_id varchar(50) )
BEGIN

    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
            SET @text = CONCAT(@text, Concat('
Called With Params: ', ', p_case_id: ', api.api_nz(`p_case_id`, '')));
            CALL db_throw_error(@errno, 'api_case_form_save_original_values', @text);
        END;

    CALL api.db_log_message('api_case_form_save_original_values',
                            Concat('Called With Params: ', 'case_id: ', api.api_nz(`p_case_id`, '')),
                            'WARN');

END;

