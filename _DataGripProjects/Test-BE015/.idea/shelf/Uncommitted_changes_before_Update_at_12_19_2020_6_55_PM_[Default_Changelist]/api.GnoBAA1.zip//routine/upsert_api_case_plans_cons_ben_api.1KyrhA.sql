CREATE
    DEFINER = admin@`%` PROCEDURE upsert_api_case_plans_cons_ben_api(
                                                                      IN p_case_plan_id varchar(50)
                                                                    , IN p_case_id varchar(50)
                                                                    , IN p_status varchar(50)
                                                                    , IN p_version_no int
                                                                    , IN p_plan_type varchar(50)
                                                                    , IN p_plan_sub_type varchar(50)
                                                                    , IN p_plan_name varchar(50)
                                                                    , IN p_plan_order int
                                                                    , IN p_plan_year_start_date date
                                                                    , IN p_plan_year_end_date date
                                                                    , IN p_plan_year_renewal_date date
                                                                    , IN p_min_annual_election_amount float
                                                                    , IN p_max_annual_election_amount float
                                                                    , IN p_employer_contribution_amount float
                                                                    , IN p_employee_contribution_amounts float
                                                                    , IN p_employee_child_contribution_amounts float
                                                                    , IN p_employee_spouse_contribution_amounts float
                                                                    , IN p_family_contribution_amounts float
                                                                    , IN p_runout_period date
                                                                    , IN p_runout_period_terminated_employees int
                                                                    , IN p_add_limited_purpose varchar(70)
                                                                    , IN p_recommended_feature varchar(70)
                                                                    , IN p_remove_grace_period int
                                                                    , IN p_add_grace_period int
                                                                    , IN p_add_clarity_convenience_card int
                                                                    , IN p_contribution_amounts float
                                                                    , IN p_who_will_pay_first varchar(100)
                                                                    , IN p_participant_responsible_pay_eligible_expenses int
                                                                    , IN p_funding_frequency varchar(50)
                                                                    , IN p_eligible_expense_categories varchar(200)
                                                                    , IN p_will_the_HRA_reimburse_same_expenses_as_current_plan_year int(1)
                                                                    , IN p_HRA_reimburse_same_expenses_as_current_plan_year_if_no varchar(50)
                                                                    , IN p_HRA_participant_responsible_pay_eligible_expenses_if_yes varchar(50)
                                                                    , IN p_max_annual_election_amount_is_changed varchar(10)
                                                                    , IN p_carry_over_features varchar(500)
                                                                    , IN p_additional_plan_details text
                                                                    , IN p_runout_period_terminated_employees_end_date varchar(10)
                                                                    , IN p_plan_should_auto_renew varchar(10) )
BEGIN


    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO,
                @text = MESSAGE_TEXT;
            SET @text = CONCAT( @text, Concat( '
Called With Params: ', ', case_plan_id: ', api.api_nz( `p_case_plan_id`, '' ), ', case_id: ',
                                               api.api_nz( `p_case_id`, '' ),
                                               ', status: ', api.api_nz( `p_status`, '' ), ', version_no: ',
                                               api.api_nz( `p_version_no`, '' ), ', plan_type: ',
                                               api.api_nz( `p_plan_type`, '' ), ', plan_sub_type: ',
                                               api.api_nz( `p_plan_sub_type`, '' ), ', plan_name: ',
                                               api.api_nz( `p_plan_name`, '' ), ', plan_order: ',
                                               api.api_nz( `p_plan_order`, '' ), ', plan_year_start_date: ',
                                               api.api_nz( `p_plan_year_start_date`, '' ), ', plan_year_end_date: ',
                                               api.api_nz( `p_plan_year_end_date`, '' ), ', plan_year_renewal_date: ',
                                               api.api_nz( `p_plan_year_renewal_date`, '' ),
                                               ', min_annual_election_amount: ',
                                               api.api_nz( `p_min_annual_election_amount`, '' ),
                                               ', max_annual_election_amount: ',
                                               api.api_nz( `p_max_annual_election_amount`, '' ),
                                               ', employer_contribution_amount: ',
                                               api.api_nz( `p_employer_contribution_amount`, '' ),
                                               ', employee_contribution_amounts: ',
                                               api.api_nz( `p_employee_contribution_amounts`, '' ),
                                               ', employee_child_contribution_amounts: ',
                                               api.api_nz( `p_employee_child_contribution_amounts`, '' ),
                                               ', employee_spouse_contribution_amounts: ',
                                               api.api_nz( `p_employee_spouse_contribution_amounts`, '' ),
                                               ', family_contribution_amounts: ',
                                               api.api_nz( `p_family_contribution_amounts`, '' ), ', runout_period: ',
                                               api.api_nz( `p_runout_period`, '' ),
                                               ', runout_period_terminated_employees: ',
                                               api.api_nz( `p_runout_period_terminated_employees`, '' ),
                                               ', add_limited_purpose: ', api.api_nz( `p_add_limited_purpose`, '' ),
                                               ', recommended_feature: ', api.api_nz( `p_recommended_feature`, '' ),
                                               ', remove_grace_period: ', api.api_nz( `p_remove_grace_period`, '' ),
                                               ', add_grace_period: ', api.api_nz( `p_add_grace_period`, '' ),
                                               ', add_clarity_convenience_card: ',
                                               api.api_nz( `p_add_clarity_convenience_card`, '' ),
                                               ', contribution_amounts: ', api.api_nz( `p_contribution_amounts`, '' ),
                                               ', who_will_pay_first: ', api.api_nz( `p_who_will_pay_first`, '' ),
                                               ', participant_responsible_pay_eligible_expenses: ',
                                               api.api_nz( `p_participant_responsible_pay_eligible_expenses`, '' ),
                                               ', funding_frequency: ', api.api_nz( `p_funding_frequency`, '' ),
                                               ', eligible_expense_categories: ',
                                               api.api_nz( `p_eligible_expense_categories`, '' ),
                                               ', will_the_HRA_reimburse_same_expenses_as_current_plan_year: ',
                                               api.api_nz(
                                                       `p_will_the_HRA_reimburse_same_expenses_as_current_plan_year`,
                                                       '' ),
                                               ', HRA_reimburse_same_expenses_as_current_plan_year_if_no: ',
                                               api.api_nz( `p_HRA_reimburse_same_expenses_as_current_plan_year_if_no`,
                                                           '' ),
                                               ', HRA_participant_responsible_pay_eligible_expenses_if_yes: ',
                                               api.api_nz( `p_HRA_participant_responsible_pay_eligible_expenses_if_yes`,
                                                           '' ), ', max_annual_election_amount_is_changed: ',
                                               api.api_nz( `p_max_annual_election_amount_is_changed`, '' ),
                                               ', carry_over_features: ', api.api_nz( `p_carry_over_features`, '' ),
                                               ', additional_plan_details: ',
                                               api.api_nz( `p_additional_plan_details`, '' ),
                                               ', runout_period_terminated_employees_end_date: ',
                                               api.api_nz( `p_runout_period_terminated_employees_end_date`, '' ),
                                               ', plan_should_auto_renew: ',
                                               api.api_nz( `p_plan_should_auto_renew`, '' ) ) );
            CALL db_throw_error( @errno, 'upsert_api_case_plans_cons_ben', @text );
        END;


    CALL api.db_log_message( 'upsert_api_case_plans_cons_ben',
                             Concat( 'Called With Params: ', ', case_plan_id: ', api.api_nz( `p_case_plan_id`, '' ),
                                     ', case_id: ', api.api_nz( `p_case_id`, '' ), ', status: ',
                                     api.api_nz( `p_status`, '' ),
                                     ', version_no: ', api.api_nz( `p_version_no`, '' ), ', plan_type: ',
                                     api.api_nz( `p_plan_type`, '' ), ', plan_sub_type: ',
                                     api.api_nz( `p_plan_sub_type`, '' ), ', plan_name: ',
                                     api.api_nz( `p_plan_name`, '' ),
                                     ', plan_order: ', api.api_nz( `p_plan_order`, '' ), ', plan_year_start_date: ',
                                     api.api_nz( `p_plan_year_start_date`, '' ), ', plan_year_end_date: ',
                                     api.api_nz( `p_plan_year_end_date`, '' ), ', plan_year_renewal_date: ',
                                     api.api_nz( `p_plan_year_renewal_date`, '' ), ', min_annual_election_amount: ',
                                     api.api_nz( `p_min_annual_election_amount`, '' ), ', max_annual_election_amount: ',
                                     api.api_nz( `p_max_annual_election_amount`, '' ),
                                     ', employer_contribution_amount: ',
                                     api.api_nz( `p_employer_contribution_amount`, '' ),
                                     ', employee_contribution_amounts: ',
                                     api.api_nz( `p_employee_contribution_amounts`, '' ),
                                     ', employee_child_contribution_amounts: ',
                                     api.api_nz( `p_employee_child_contribution_amounts`, '' ),
                                     ', employee_spouse_contribution_amounts: ',
                                     api.api_nz( `p_employee_spouse_contribution_amounts`, '' ),
                                     ', family_contribution_amounts: ',
                                     api.api_nz( `p_family_contribution_amounts`, '' ),
                                     ', runout_period: ', api.api_nz( `p_runout_period`, '' ),
                                     ', runout_period_terminated_employees: ',
                                     api.api_nz( `p_runout_period_terminated_employees`, '' ),
                                     ', add_limited_purpose: ',
                                     api.api_nz( `p_add_limited_purpose`, '' ), ', recommended_feature: ',
                                     api.api_nz( `p_recommended_feature`, '' ), ', remove_grace_period: ',
                                     api.api_nz( `p_remove_grace_period`, '' ), ', add_grace_period: ',
                                     api.api_nz( `p_add_grace_period`, '' ), ', add_clarity_convenience_card: ',
                                     api.api_nz( `p_add_clarity_convenience_card`, '' ), ', contribution_amounts: ',
                                     api.api_nz( `p_contribution_amounts`, '' ), ', who_will_pay_first: ',
                                     api.api_nz( `p_who_will_pay_first`, '' ),
                                     ', participant_responsible_pay_eligible_expenses: ',
                                     api.api_nz( `p_participant_responsible_pay_eligible_expenses`, '' ),
                                     ', funding_frequency: ', api.api_nz( `p_funding_frequency`, '' ),
                                     ', eligible_expense_categories: ',
                                     api.api_nz( `p_eligible_expense_categories`, '' ),
                                     ', will_the_HRA_reimburse_same_expenses_as_current_plan_year: ',
                                     api.api_nz( `p_will_the_HRA_reimburse_same_expenses_as_current_plan_year`, '' ),
                                     ', HRA_reimburse_same_expenses_as_current_plan_year_if_no: ',
                                     api.api_nz( `p_HRA_reimburse_same_expenses_as_current_plan_year_if_no`, '' ),
                                     ', HRA_participant_responsible_pay_eligible_expenses_if_yes: ',
                                     api.api_nz( `p_HRA_participant_responsible_pay_eligible_expenses_if_yes`, '' ),
                                     ', max_annual_election_amount_is_changed: ',
                                     api.api_nz( `p_max_annual_election_amount_is_changed`, '' ),
                                     ', carry_over_features: ',
                                     api.api_nz( `p_carry_over_features`, '' ), ', additional_plan_details: ',
                                     api.api_nz( `p_additional_plan_details`, '' ),
                                     ', runout_period_terminated_employees_end_date: ',
                                     api.api_nz( `p_runout_period_terminated_employees_end_date`, '' ),
                                     ', plan_should_auto_renew: ', api.api_nz( `p_plan_should_auto_renew`, '' ) ),
                             'WARN' );


    INSERT
    INTO
        `api`.`api_case_plans_cons_ben`
    (
        `case_plan_id`
    ,   `case_id`
    ,   `status`
    ,   `version_no`
    ,   `plan_type`
    ,   `plan_sub_type`
    ,   `plan_name`
    ,   `plan_order`
    ,   `plan_year_start_date`
    ,   `plan_year_end_date`
    ,   `plan_year_renewal_date`
    ,   `min_annual_election_amount`
    ,   `max_annual_election_amount`
    ,   `employer_contribution_amount`
    ,   `employee_contribution_amounts`
    ,   `employee_child_contribution_amounts`
    ,   `employee_spouse_contribution_amounts`
    ,   `family_contribution_amounts`
    ,   `runout_period`
    ,   `runout_period_terminated_employees`
    ,   `add_limited_purpose`
    ,   `recommended_feature`
    ,   `remove_grace_period`
    ,   `add_grace_period`
    ,   `add_clarity_convenience_card`
    ,   `contribution_amounts`
    ,   `who_will_pay_first`
    ,   `participant_responsible_pay_eligible_expenses`
    ,   `funding_frequency`
    ,   `eligible_expense_categories`
    ,   `will_the_HRA_reimburse_same_expenses_as_current_plan_year`
    ,   `HRA_reimburse_same_expenses_as_current_plan_year_if_no`
    ,   `HRA_participant_responsible_pay_eligible_expenses_if_yes`
    ,   `max_annual_election_amount_is_changed`
    ,   `carry_over_features`
    ,   `additional_plan_details`
    ,   `runout_period_terminated_employees_end_date`
    ,   `plan_should_auto_renew`
    )


    VALUES
    (
        `p_case_plan_id`
    ,   `p_case_id`
    ,   `p_status`
    ,   `p_version_no`
    ,   `p_plan_type`
    ,   `p_plan_sub_type`
    ,   `p_plan_name`
    ,   `p_plan_order`
    ,   `p_plan_year_start_date`
    ,   `p_plan_year_end_date`
    ,   `p_plan_year_renewal_date`
    ,   `p_min_annual_election_amount`
    ,   `p_max_annual_election_amount`
    ,   `p_employer_contribution_amount`
    ,   `p_employee_contribution_amounts`
    ,   `p_employee_child_contribution_amounts`
    ,   `p_employee_spouse_contribution_amounts`
    ,   `p_family_contribution_amounts`
    ,   `p_runout_period`
    ,   `p_runout_period_terminated_employees`
    ,   `p_add_limited_purpose`
    ,   `p_recommended_feature`
    ,   `p_remove_grace_period`
    ,   `p_add_grace_period`
    ,   `p_add_clarity_convenience_card`
    ,   `p_contribution_amounts`
    ,   `p_who_will_pay_first`
    ,   `p_participant_responsible_pay_eligible_expenses`
    ,   `p_funding_frequency`
    ,   `p_eligible_expense_categories`
    ,   `p_will_the_HRA_reimburse_same_expenses_as_current_plan_year`
    ,   `p_HRA_reimburse_same_expenses_as_current_plan_year_if_no`
    ,   `p_HRA_participant_responsible_pay_eligible_expenses_if_yes`
    ,   `p_max_annual_election_amount_is_changed`
    ,   `p_carry_over_features`
    ,   `p_additional_plan_details`
    ,   `p_runout_period_terminated_employees_end_date`
    ,   `p_plan_should_auto_renew`
    )


    ON DUPLICATE KEY
        UPDATE
            `case_plan_id`                                              = api.api_nz( `p_case_plan_id`, `case_plan_id` )
          , `case_id`                                                   = api.api_nz( `p_case_id`, `case_id` )
          , `status`                                                    = api.api_nz( `p_status`, `status` )
          , `version_no`                                                = api.api_nz_int( `p_version_no`, `version_no` )
          , `plan_type`                                                 = api.api_nz( `p_plan_type`, `plan_type` )
          , `plan_sub_type`                                             = api.api_nz( `p_plan_sub_type`, `plan_sub_type` )
          , `plan_name`                                                 = api.api_nz( `p_plan_name`, `plan_name` )
          , `plan_order`                                                = api.api_nz_int( `p_plan_order`, `plan_order` )
          , `plan_year_start_date`                                      = api.api_nz_date( `p_plan_year_start_date`, `plan_year_start_date` )
          , `plan_year_end_date`                                        = api.api_nz_date( `p_plan_year_end_date`, `plan_year_end_date` )
          , `plan_year_renewal_date`                                    = api.api_nz_date( `p_plan_year_renewal_date`, `plan_year_renewal_date` )
          , `min_annual_election_amount`                                = api.api_nz_float(
                `p_min_annual_election_amount`, `min_annual_election_amount` )
          , `max_annual_election_amount`                                = api.api_nz_float(
                `p_max_annual_election_amount`, `max_annual_election_amount` )
          , `employer_contribution_amount`                              = api.api_nz_float(
                `p_employer_contribution_amount`, `employer_contribution_amount` )
          , `employee_contribution_amounts`                             = api.api_nz_float(
                `p_employee_contribution_amounts`, `employee_contribution_amounts` )
          , `employee_child_contribution_amounts`                       = api.api_nz_float(
                `p_employee_child_contribution_amounts`, `employee_child_contribution_amounts` )
          , `employee_spouse_contribution_amounts`                      = api.api_nz_float(
                `p_employee_spouse_contribution_amounts`, `employee_spouse_contribution_amounts` )
          , `family_contribution_amounts`                               = api.api_nz_float(
                `p_family_contribution_amounts`, `family_contribution_amounts` )
          , `runout_period`                                             = api.api_nz_date( `p_runout_period`, `runout_period` )
          , `runout_period_terminated_employees`                        = api.api_nz_int(
                `p_runout_period_terminated_employees`, `runout_period_terminated_employees` )
          , `add_limited_purpose`                                       = api.api_nz( `p_add_limited_purpose`, `add_limited_purpose` )
          , `recommended_feature`                                       = api.api_nz( `p_recommended_feature`, `recommended_feature` )
          , `remove_grace_period`                                       = api.api_nz_int( `p_remove_grace_period`, `remove_grace_period` )
          , `add_grace_period`                                          = api.api_nz_int( `p_add_grace_period`, `add_grace_period` )
          , `add_clarity_convenience_card`                              = api.api_nz_int(
                `p_add_clarity_convenience_card`, `add_clarity_convenience_card` )
          , `contribution_amounts`                                      = api.api_nz_float( `p_contribution_amounts`, `contribution_amounts` )
          , `who_will_pay_first`                                        = api.api_nz( `p_who_will_pay_first`, `who_will_pay_first` )
          , `participant_responsible_pay_eligible_expenses`             = api.api_nz_int(
                `p_participant_responsible_pay_eligible_expenses`,
                `participant_responsible_pay_eligible_expenses` )
          , `funding_frequency`                                         = api.api_nz( `p_funding_frequency`, `funding_frequency` )
          , `eligible_expense_categories`                               = api.api_nz( `p_eligible_expense_categories`,
                                                                                      `eligible_expense_categories` )
          , `will_the_HRA_reimburse_same_expenses_as_current_plan_year` = api.api_nz_int(
                `p_will_the_HRA_reimburse_same_expenses_as_current_plan_year`,
                `will_the_HRA_reimburse_same_expenses_as_current_plan_year` )
          , `HRA_reimburse_same_expenses_as_current_plan_year_if_no`    = api.api_nz(
                `p_HRA_reimburse_same_expenses_as_current_plan_year_if_no`,
                `HRA_reimburse_same_expenses_as_current_plan_year_if_no` )
          , `HRA_participant_responsible_pay_eligible_expenses_if_yes`  = api.api_nz(
                `p_HRA_participant_responsible_pay_eligible_expenses_if_yes`,
                `HRA_participant_responsible_pay_eligible_expenses_if_yes` )
          , `max_annual_election_amount_is_changed`                     = api.api_nz(
                `p_max_annual_election_amount_is_changed`, `max_annual_election_amount_is_changed` )
          , `carry_over_features`                                       = api.api_nz( `p_carry_over_features`, `carry_over_features` )
          , `additional_plan_details`                                   = api.api_nz( `p_additional_plan_details`, `additional_plan_details` )
          , `runout_period_terminated_employees_end_date`               = api.api_nz(
                `p_runout_period_terminated_employees_end_date`, `runout_period_terminated_employees_end_date` )
          , `plan_should_auto_renew`                                    = api.api_nz( `p_plan_should_auto_renew`, `plan_should_auto_renew` );


END;

