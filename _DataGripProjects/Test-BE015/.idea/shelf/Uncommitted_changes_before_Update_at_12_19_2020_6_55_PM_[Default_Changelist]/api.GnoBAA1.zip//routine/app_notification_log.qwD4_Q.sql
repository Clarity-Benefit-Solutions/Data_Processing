CREATE
    DEFINER = admin@`%` PROCEDURE app_notification_log(
                                                        IN p_user_id varchar(200)
                                                      , IN p_address varchar(200)
                                                      , IN p_noti_type varchar(10)
                                                      , IN p_noti_cate varchar(100)
                                                      , IN p_noti_sub_cate varchar(200)
                                                      , IN p_noti_content longtext
                                                      , IN p_case_id varchar(200)
                                                      , IN p_case_owner_id longtext )
BEGIN
    DECLARE v_rollback BOOL DEFAULT 0;
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
        BEGIN
            GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE,
                @errno = MYSQL_ERRNO,
                @text = MESSAGE_TEXT;
            CALL db_log_error(@errno,
                              'log_activity',
                              @text,
                              @sqlstate);
        END;

    INSERT INTO api.api_notification_logs (
		user_id,
		destination_address,
		notification_type,
		notification_category,
        notification_sub_category,
		notification_content,
        case_id,
        case_owner_id
	) VALUES (
		p_user_id,
		p_address,
		p_noti_type,
		p_noti_cate,
        p_noti_sub_cate,
		p_noti_content,
	    p_case_id,
	    p_case_owner_id
	);
END;

