CREATE
    DEFINER = admin@`%` FUNCTION get_api_cases_new_prv_field_value(p_row_id varchar(50),
                                                                   p_field_page_label varchar(100),
                                                                   p_field_label varchar(100),
                                                                   p_field_name varchar(100), p_prv_version_no int,
                                                                   p_new_version_no int,
                                                                   p_only_if_changed int) RETURNS text
BEGIN

    DECLARE v_prv_value text;
    DECLARE v_new_value text;
    DECLARE v_text text;
    DECLARE v_is_changed int;

    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
        BEGIN
            GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
            CALL db_log_error(@errno, 'get_api_cases_new_prv_field_value', @text, @sqlstate);
        END;

    --
    SELECT prv_field_value,
           new_field_value
           INTO v_prv_value, v_new_value
    FROM api.api_temp_case_field_changes
    WHERE row_id = p_row_id
      AND field_name = p_field_name
      AND prv_version_no = p_prv_version_no
      AND new_version_no = p_new_version_no
    ORDER BY updated_at DESC
    LIMIT 1;

    SET v_new_value = api_quote_csv_field_value(v_new_value);
    SET v_prv_value = api_quote_csv_field_value(v_prv_value);
    IF v_new_value <> v_prv_value THEN
        SET v_is_changed = 1;
    ELSE
        SET v_is_changed = 0;
    END IF;

    IF (p_only_if_changed > 0 AND v_is_changed = 0) THEN
        RETURN '';
    END IF;

    --
    SET v_text = CONCAT(QT(), p_field_page_label, QT(), ',',
                        QT(), p_field_label, QT(), ',',
                        QT(), v_prv_value, QT(), ',',
                        QT(), v_new_value, QT(), ',',
                        QT(),
                        CASE v_is_changed
                            WHEN 1 THEN
                                'Yes'
                            ELSE
                                'No'
                            END,
                        QT());

    RETURN v_text;

END;

