CREATE DEFINER = admin@`%` TRIGGER bd_platform_users_NO_deletes
    BEFORE DELETE
    ON platform_users
    FOR EACH ROW
BEGIN
   CALL api.db_throw_error(50001, 'api.bd_platform_users_NO_deletes', 'Cannot delete records from api.platform_users');
END;

