CREATE DEFINER = admin@`%` TRIGGER bd_api_cases_new_NO_deletes
    BEFORE DELETE
    ON api_cases
    FOR EACH ROW
BEGIN
   
END;

