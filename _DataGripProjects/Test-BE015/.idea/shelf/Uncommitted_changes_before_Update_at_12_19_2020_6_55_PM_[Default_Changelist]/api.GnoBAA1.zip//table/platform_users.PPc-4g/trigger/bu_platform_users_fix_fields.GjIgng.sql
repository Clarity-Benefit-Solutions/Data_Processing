CREATE DEFINER = admin@`%` TRIGGER bu_platform_users_fix_fields
    BEFORE UPDATE
    ON platform_users
    FOR EACH ROW
BEGIN
    SET new.email = api.api_fix_email(new.email);
    set new.user_name = new.email;
    SET new.user_name = api.api_fix_email(new.user_name);
    --
    SET new.ssn = api.api_fix_ssn(new.ssn);
    SET new.employee_id = api.api_fix_ssn(new.employee_id);

    SET new.cp_ssn = api.api_fix_ssn(new.cp_ssn);
    SET new.wc_ssn = api.api_fix_ssn(new.wc_ssn);
    SET new.bs_ssn = api.api_fix_ssn(new.bs_ssn);
    --
    SET new.dob = api.api_fix_date(new.dob);
    SET new.cp_dob = api.api_fix_date(new.cp_dob);
    SET new.bs_dob = api.api_fix_date(new.bs_dob);
    SET new.wc_dob = api.api_fix_date(new.wc_dob);
    --
    SET new.is_invalid = api.api_cbool(new.is_invalid);
    SET new.is_ready_for_sso_processing = api.api_cbool(new.is_ready_for_sso_processing);
    SET new.is_invited = api.api_cbool(new.is_invited);
    SET new.is_verified = api.api_cbool(new.is_verified);
    --
    SET new.bs_user_is_active = api.api_cbool(new.bs_user_is_active);
    SET new.cp_allow_sso = api.api_cbool(new.cp_allow_sso);
    SET new.cp_member_user_is_active = api.api_cbool(new.cp_member_user_is_active);
    SET new.cp_tpa_user_is_active = api.api_cbool(new.cp_tpa_user_is_active);
    SET new.wca_user_is_active = api.api_cbool(new.wca_user_is_active);
    SET new.wcp_user_is_active = api.api_cbool(new.wcp_user_is_active);

    if api.api_is_blank(new.invite_token) and (new.is_verified = 0 or new.is_ready_for_sso_processing) then
        SET new.invite_token = api.api_uuid();
    end if;


END;

