CREATE DEFINER = admin@`%` TRIGGER au_audit_platform_users_updates
    AFTER UPDATE
    ON platform_users_Dec06
    FOR EACH ROW
    INSERT INTO `api`.`platform_users_audit`
                 (`auditAction`, `user_id`, `user_name`, `first_name`, `last_name`, `email`, `alternate_email`, `title`,
                  `mobile_number`, `ssn`, `dob`, `employee_id`, `invite_token`, `is_invalid`,
                  `last_invite_token_sent_date`, `is_ready_for_sso_processing`, `is_invited`, `is_verified`,
                  `cp_row_id`, `cp_client_id`, `cp_broker_id`, `cp_client_contact_id`, `cp_sso_identifier`,
                  `cp_customer_id`, `cp_entity_type`, `cp_user_id`, `cp_tpa_user_is_active`, `cp_member_id`,
                  `cp_member_user_is_active`, `cp_allow_sso`, `cp_ssn`, `cp_email`, `cp_dob`, `wc_card_number`,
                  `wc_dob`, `wc_ssn`, `wc_email`, `wca_row_id`, `wca_tpa_id`, `wca_employer_id`, `wca_data_partner_id`,
                  `wca_client_user_id`, `wca_user_is_active`, `wcp_row_id`, `wcp_tpa_id`, `wcp_employer_id`,
                  `wcp_employee_id`, `wcp_user_is_active`, `bs_row_id`, `bs_abbrev_url`, `bs_user_id`,
                  `bs_import_user_id`, `bs_user_name`, `bs_user_is_active`, `bs_dob`, `bs_work_email`, `bs_payroll_id`,
                  `bs_ssn`, `bs_email`, `bs_employer_id`, `bs_is_employee`, `bs_is_manager`, `bs_is_topdog`, `en_email`,
                  `en_row_id`, `en_employee_id`, `en_employer_id`, `en_dob`, `en_ssn`, `en_user_is_active`,
                  `en_is_employee`, `en_is_manager`, `en_is_tpa_user`, `sf_email`, `sf_row_id`, `sf_employer_id`,
                  `sf_dob`, `sf_ssn`, `sf_user_is_active`, `sf_is_employee`, `sf_is_client`, `sf_is_broker`,
                  `created_at`, `created_by`, `updated_at`, `updated_by`, `email_error`)
                 VALUES ('UPDATE', NEW.`user_id`, NEW.`user_name`, NEW.`first_name`, NEW.`last_name`, NEW.`email`,
                         NEW.`alternate_email`, NEW.`title`, NEW.`mobile_number`, NEW.`ssn`, NEW.`dob`,
                         NEW.`employee_id`, NEW.`invite_token`, NEW.`is_invalid`, NEW.`last_invite_token_sent_date`,
                         NEW.`is_ready_for_sso_processing`, NEW.`is_invited`, NEW.`is_verified`, NEW.`cp_row_id`,
                         NEW.`cp_client_id`, NEW.`cp_broker_id`, NEW.`cp_client_contact_id`, NEW.`cp_sso_identifier`,
                         NEW.`cp_customer_id`, NEW.`cp_entity_type`, NEW.`cp_user_id`, NEW.`cp_tpa_user_is_active`,
                         NEW.`cp_member_id`, NEW.`cp_member_user_is_active`, NEW.`cp_allow_sso`, NEW.`cp_ssn`,
                         NEW.`cp_email`, NEW.`cp_dob`, NEW.`wc_card_number`, NEW.`wc_dob`, NEW.`wc_ssn`, NEW.`wc_email`,
                         NEW.`wca_row_id`, NEW.`wca_tpa_id`, NEW.`wca_employer_id`, NEW.`wca_data_partner_id`,
                         NEW.`wca_client_user_id`, NEW.`wca_user_is_active`, NEW.`wcp_row_id`, NEW.`wcp_tpa_id`,
                         NEW.`wcp_employer_id`, NEW.`wcp_employee_id`, NEW.`wcp_user_is_active`, NEW.`bs_row_id`,
                         NEW.`bs_abbrev_url`, NEW.`bs_user_id`, NEW.`bs_import_user_id`, NEW.`bs_user_name`,
                         NEW.`bs_user_is_active`, NEW.`bs_dob`, NEW.`bs_work_email`, NEW.`bs_payroll_id`, NEW.`bs_ssn`,
                         NEW.`bs_email`, NEW.`bs_employer_id`, NEW.`bs_is_employee`, NEW.`bs_is_manager`,
                         NEW.`bs_is_topdog`, NEW.`en_email`, NEW.`en_row_id`, NEW.`en_employee_id`,
                         NEW.`en_employer_id`, NEW.`en_dob`, NEW.`en_ssn`, NEW.`en_user_is_active`,
                         NEW.`en_is_employee`, NEW.`en_is_manager`, NEW.`en_is_tpa_user`, NEW.`sf_email`,
                         NEW.`sf_row_id`, NEW.`sf_employer_id`, NEW.`sf_dob`, NEW.`sf_ssn`, NEW.`sf_user_is_active`,
                         NEW.`sf_is_employee`, NEW.`sf_is_client`, NEW.`sf_is_broker`, NEW.`created_at`,
                         NEW.`created_by`, NEW.`updated_at`, NEW.`updated_by`, NEW.`email_error`);

