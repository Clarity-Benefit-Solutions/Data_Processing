CREATE DEFINER = admin@`%` TRIGGER util_bi_api_file_uploads_new_set_file_upload_id
    BEFORE INSERT
    ON api_file_uploads
    FOR EACH ROW
BEGIN
    IF api.api_is_blank(new.file_upload_id) THEN
        SET new.file_upload_id = api.api_uuid();
    END IF;


END;

