CREATE DEFINER = admin@`%` TRIGGER au_audit_api_case_plans_cons_ben_deletes
    AFTER DELETE
    ON api_case_plans_cons_ben
    FOR EACH ROW
    INSERT INTO `api`.`api_case_plans_cons_ben_audit`
                 (`auditAction`, `case_plan_id`, `case_id`, `status`, `version_no`, `plan_type`, `plan_sub_type`,
                  `plan_name`, `plan_order`, `plan_year_start_date`, `plan_year_end_date`, `plan_year_renewal_date`,
                  `min_annual_election_amount`, `max_annual_election_amount`, `employer_contribution_amount`,
                  `employee_contribution_amounts`, `employee_child_contribution_amounts`,
                  `employee_spouse_contribution_amounts`, `family_contribution_amounts`, `runout_period`,
                  `runout_period_terminated_employees`, `add_limited_purpose`, `recommended_feature`,
                  `remove_grace_period`, `add_grace_period`, `grace_period_end_date`, `add_clarity_convenience_card`,
                  `contribution_amounts`, `who_will_pay_first`, `participant_responsible_pay_eligible_expenses`,
                  `funding_frequency`, `eligible_expense_categories`,
                  `will_the_HRA_reimburse_same_expenses_as_current_plan_year`,
                  `HRA_reimburse_same_expenses_as_current_plan_year_if_no`,
                  `HRA_participant_responsible_pay_eligible_expenses_if_yes`, `max_annual_election_amount_is_changed`,
                  `carry_over_features`, `additional_plan_details`, `runout_period_terminated_employees_end_date`,
                  `plan_should_auto_renew`, `created_at`, `created_by`, `updated_at`, `updated_by`)
                 VALUES ('DELETE', OLD.`case_plan_id`, OLD.`case_id`, OLD.`status`, OLD.`version_no`, OLD.`plan_type`,
                         OLD.`plan_sub_type`, OLD.`plan_name`, OLD.`plan_order`, OLD.`plan_year_start_date`,
                         OLD.`plan_year_end_date`, OLD.`plan_year_renewal_date`, OLD.`min_annual_election_amount`,
                         OLD.`max_annual_election_amount`, OLD.`employer_contribution_amount`,
                         OLD.`employee_contribution_amounts`, OLD.`employee_child_contribution_amounts`,
                         OLD.`employee_spouse_contribution_amounts`, OLD.`family_contribution_amounts`,
                         OLD.`runout_period`, OLD.`runout_period_terminated_employees`, OLD.`add_limited_purpose`,
                         OLD.`recommended_feature`, OLD.`remove_grace_period`, OLD.`add_grace_period`,
                         OLD.`grace_period_end_date`, OLD.`add_clarity_convenience_card`, OLD.`contribution_amounts`,
                         OLD.`who_will_pay_first`, OLD.`participant_responsible_pay_eligible_expenses`,
                         OLD.`funding_frequency`, OLD.`eligible_expense_categories`,
                         OLD.`will_the_HRA_reimburse_same_expenses_as_current_plan_year`,
                         OLD.`HRA_reimburse_same_expenses_as_current_plan_year_if_no`,
                         OLD.`HRA_participant_responsible_pay_eligible_expenses_if_yes`,
                         OLD.`max_annual_election_amount_is_changed`, OLD.`carry_over_features`,
                         OLD.`additional_plan_details`, OLD.`runout_period_terminated_employees_end_date`,
                         OLD.`plan_should_auto_renew`, OLD.`created_at`, OLD.`created_by`, OLD.`updated_at`,
                         OLD.`updated_by`);

