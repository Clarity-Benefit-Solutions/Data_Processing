CREATE DEFINER = admin@`%` TRIGGER util_bu_cl_frm_item_metas_set_org_values
    BEFORE INSERT
    ON cl_frm_item_metas
    FOR EACH ROW
BEGIN
    SET new.org_meta_value = api.api_nz(new.org_meta_value, new.meta_value);
    SET new.org_meta_values_updated_at = now();
    SET new.created_at = now();
    SET new.updated_at = now();
END;

