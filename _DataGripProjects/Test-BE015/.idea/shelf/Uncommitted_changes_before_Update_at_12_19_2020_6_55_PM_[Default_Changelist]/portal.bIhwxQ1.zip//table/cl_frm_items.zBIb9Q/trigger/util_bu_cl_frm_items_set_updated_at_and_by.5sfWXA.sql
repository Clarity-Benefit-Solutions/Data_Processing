CREATE DEFINER = admin@`%` TRIGGER util_bu_cl_frm_items_set_updated_at_and_by
    BEFORE UPDATE
    ON cl_frm_items
    FOR EACH ROW
BEGIN
    SET new.created_at = old.created_at;
    SET new.created_by = old.created_by;
    SET new.updated_at = NOW();
    SET new.updated_by = current_user;
END;

