CREATE DEFINER = admin@`%` VIEW vw_get_all_fields_for_form_prv AS
SELECT t.form_id             AS form_id,
       t.form_name           AS form_name,
       CASE
           WHEN (t.field_type LIKE 'html' AND t.field_description LIKE '%heading%')
               THEN t.field_name
           ELSE ''
       END                   AS page_name,
       t.field_name          AS field_name,
       CASE
           WHEN t.field_type = 'divider'
               THEN t.field_name
           ELSE ''
       END                   AS repeater_name,
       t.field_order         AS field_order,
       t.field_key           AS field_key,
       t.field_id            AS field_id,
       t.field_description   AS field_description,
       t.field_default_value AS field_default_value,
       t.fl_options          AS fl_options,
       t.field_options       AS field_options,
       t.field_required      AS field_required,
       t.field_type          AS field_type
FROM (SELECT f.id             AS form_id,
             f.name           AS form_name,
             fl.id            AS field_id,
             fl.field_key     AS field_key,
             fl.name          AS field_name,
             fl.description   AS field_description,
             fl.type          AS field_type,
             fl.default_value AS field_default_value,
             fl.options       AS fl_options,
             fl.field_order   AS field_order,
             fl.required      AS field_required,
             fl.field_options AS field_options
      FROM ( portal.cl_frm_fields fl
               JOIN portal.cl_frm_forms f ON (f.id = fl.form_id))
      WHERE fl.type <> 'hidden') t;

