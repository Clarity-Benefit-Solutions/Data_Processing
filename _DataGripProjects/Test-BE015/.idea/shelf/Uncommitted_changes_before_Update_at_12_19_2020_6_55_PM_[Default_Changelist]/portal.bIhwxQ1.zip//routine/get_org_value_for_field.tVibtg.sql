CREATE
    DEFINER = admin@`%` FUNCTION get_org_value_for_field(
                                                          p_item_id int
                                                        , p_field_id int ) RETURNS text
BEGIN
    DECLARE v_value text;
#
    SELECT api.api_nz(m.org_meta_value, '')
    INTO v_value
    FROM portal.cl_frm_item_metas_audit m
             JOIN portal.cl_frm_fields f ON m.field_id = f.id
             JOIN portal.cl_frm_forms fr ON f.form_id = fr.id
    WHERE m.item_id = p_item_id
      AND m.field_id = p_field_id
      AND m.auditAction = 'INSERT'
    ORDER BY f.created_at ASC
    LIMIT 1;

    RETURN v_value;

END;

