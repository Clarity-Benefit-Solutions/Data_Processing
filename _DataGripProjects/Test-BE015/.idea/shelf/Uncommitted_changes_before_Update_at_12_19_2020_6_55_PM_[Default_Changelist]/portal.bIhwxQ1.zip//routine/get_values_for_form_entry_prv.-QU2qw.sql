CREATE
    DEFINER = admin@`%` PROCEDURE get_values_for_form_entry_prv(IN p_form_item_id int, IN p_add_header int,
                                                                IN p_page_name varchar(200),
                                                                IN p_repeater_field_name varchar(200), OUT v_CSV text)
BEGIN

    DECLARE v_item_id varchar(100);
    DECLARE v_form_id varchar(100);
    DECLARE v_form_name varchar(200);
    DECLARE v_page_name varchar(200);
    DECLARE v_curr_page_name varchar(200);
    DECLARE v_field_order int;
    DECLARE v_field_name varchar(100);

    DECLARE v_value_has_changed varchar(10);
    DECLARE v_current_value text;
    DECLARE v_original_value text;
    DECLARE v_field_key varchar(100);
    DECLARE v_field_id varchar(100);
    DECLARE v_field_type varchar(100);

    DECLARE v_repeater_entry_id varchar(15);
    DECLARE v_repeater_entry_csv text;

    DECLARE v_finished int;

    DECLARE v_rowCsv text;

    DECLARE v_row_no int;
    DECLARE v_counter int;

    DECLARE v_values_cursor CURSOR FOR SELECT api.api_nz(item_id, '')
                                            , api.api_nz(form_id, '')
                                            , api.api_nz(form_name, '')
                                            , api.api_nz(page_name, '')
                                            , api.api_nz(field_order, '')
                                            , api.api_nz(field_name, '')
                                            , api.api_nz(value_has_changed, '')
                                            , api.api_nz(current_value, '')
                                            , api.api_nz(original_value, '')
                                            , api.api_nz(field_key, '')
                                            , api.api_nz(field_id, '')
                                            , api.api_nz(field_type, '')
                                       FROM vw_get_values_for_form_entry
                                       WHERE item_id = p_form_item_id
                                       ORDER BY form_id, field_order;

    DECLARE CONTINUE HANDLER FOR NOT FOUND BEGIN
        SET v_finished = 1;

    END;

    #     DECLARE CONTINUE HANDLER FOR SQLEXCEPTION BEGIN
#         GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
#         CALL api.db_log_error(@errno, 'get_values_for_all_fields_for_form_entry', @text, @sqlstate);
#     END;

    SET @@max_sp_recursion_depth = 12;

    SET v_CSV = '';

    IF p_add_header THEN
        SET v_CSV =
                CONCAT(api.QT(), 'Item Id', api.QT(), ',', api.QT(), 'Form Id', api.QT(), ',', api.QT(), 'Form Name',
                       api.QT(), ',', api.QT(), 'Page Name', api.QT(), ',', api.QT(), 'Repeater Name', api.QT(), ',',
                       api.QT(), 'Field Name', api.QT(), ',', api.QT(), 'Is Repeater Field', api.QT(), ',', api.QT(),
                       'Field Id', api.QT(), ',', api.QT(), 'Field Key', api.QT(), ',', api.QT(), 'Field Type',
                       api.QT(), ',', api.QT(), 'Has Changed', api.QT(), ',', api.QT(), 'Original Value', api.QT(), ',',
                       api.QT(), 'Current Value', api.QT(), char(13));
    END IF;

    OPEN v_values_cursor;

    CALL api.db_log_message('get_values_for_all_fields_for_form_entry',
                            concat('Processing Form Entry ID:  ', p_form_item_id), 'INFO');
    getValues
    :
    LOOP
        SET v_rowCsv = '';
--
        FETCH v_values_cursor INTO v_item_id, v_form_id, v_form_name, v_page_name, v_field_order, v_field_name, v_value_has_changed, v_current_value, v_original_value, v_field_key, v_field_id, v_field_type;

        IF v_finished = 1 THEN LEAVE getValues; END IF;

        SET v_page_name =
                api.api_nz(api.api_nz(p_page_name, portal.get_page_heading_for_field(v_form_id, v_field_order)), '');

        IF v_value_has_changed = '1' THEN SET v_value_has_changed = 'Yes'; ELSE SET v_value_has_changed = 'No'; END IF;

        if v_current_value = 'undefined' then
            set v_current_value ='';
        END IF;

        if v_original_value = 'undefined' then
            set v_original_value ='';
        END IF;

        IF v_field_type <> 'divider' THEN
            SET v_original_value = replace(v_original_value, '"', '""');

            SET v_current_value = replace(v_current_value, '"', '""');

            SET v_rowCsv = CONCAT(v_rowCsv, api.QT(), api.api_nz(v_item_id, ''), api.QT(), ',', api.QT(),
                                  api.api_nz(v_form_id, ''), api.QT(), ',', api.QT(), api.api_nz(v_form_name, ''),
                                  api.QT(), ',', api.QT(), api.api_nz(v_page_name, ''), api.QT(), ',', api.QT(),
                                  api.api_nz(p_repeater_field_name, ''), api.QT(), ',', api.QT(),
                                  api.api_nz(v_field_name, ''), api.QT(), ',', api.QT(),
                                  NOT api.api_is_blank(p_repeater_field_name), api.QT(), ',', api.QT(),
                                  api.api_nz(v_field_id, ''), api.QT(), ',', api.QT(), api.api_nz(v_field_key, ''),
                                  api.QT(), ',', api.QT(), api.api_nz(v_field_type, ''), api.QT(), ',', api.QT(),
                                  api.api_nz(v_value_has_changed, ''), api.QT(), ',', api.QT(),
                                  api.api_nz(v_original_value, ''), api.QT(), ',', api.QT(),
                                  api.api_nz(v_current_value, ''), api.QT(), ',', char(13));

        ELSE

            CALL api.db_log_message('get_values_for_all_fields_for_form_entry',
                                    concat(' -- Processing Repeater Field: ', v_field_name, ' , SubEntries: ',
                                           v_current_value), 'INFO');

            SET v_counter = 0;
            SET v_repeater_entry_id = 0;

            WHILE v_counter <= 20 AND v_repeater_entry_id IS NOT NULL
                DO
                    CALL api.db_log_message('get_values_for_all_fields_for_form_entry',
                                            concat(' -- Processing Repeater Field: ', v_field_name, ', value: ',
                                                   v_current_value, ' , Entry AT index: ', v_counter), 'INFO');

                    SET v_repeater_entry_id = api.api_getPhpSerializedArrayValueByIndex(v_current_value, v_counter);

                    CALL api.db_log_message('get_values_for_all_fields_for_form_entry',
                                            concat(' -- Processing Repeater Field: ', v_field_name, ', value: ',
                                                   v_current_value, ' , Entry AT index: ', v_counter, ' = ',
                                                   v_repeater_entry_id), 'INFO');

                    IF v_repeater_entry_id IS NOT NULL THEN

                        SET v_repeater_entry_csv = '';

                        --
                        CALL get_values_for_form_entry(v_repeater_entry_id, 0, v_page_name, v_field_name,
                                                       v_repeater_entry_csv);
                        --

                        SET v_rowCsv = concat(v_rowCsv, v_repeater_entry_csv, char(13));
                    END IF;
                    SET v_counter = v_counter + 1;
                END WHILE;
            SET v_rowCsv = concat(v_rowCsv, v_repeater_entry_csv);
        END IF;

        CALL api.db_log_message('get_values_for_all_fields_for_form_entry',
                                concat(' -- Field: ', v_field_name, ' , FieldKey: ', v_field_key, ', CSV:', char(13),
                                       v_rowCsv), 'INFO');

        IF api.api_nz(v_rowCsv, '') <> '' THEN SET v_CSV = concat(v_CSV, v_rowCsv); END IF;

    END LOOP getValues;

END
;

