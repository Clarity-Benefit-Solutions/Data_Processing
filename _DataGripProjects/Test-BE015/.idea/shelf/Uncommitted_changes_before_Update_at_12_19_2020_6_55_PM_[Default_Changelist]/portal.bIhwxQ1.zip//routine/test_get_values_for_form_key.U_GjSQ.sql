CREATE
    DEFINER = admin@`%` PROCEDURE test_get_values_for_form_key( IN p_token varchar(50) )
BEGIN
    DECLARE v_CSV longtext;
    CALL portal.get_values_for_form_key(p_token, 1, NULL, NULL, v_CSV);
    SELECT v_CSV, length(v_CSV);
END;

