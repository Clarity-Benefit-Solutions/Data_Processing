CREATE DEFINER = rdsadmin@localhost EVENT ev_rds_gsh_collector ON SCHEDULE EVERY '5' MINUTE STARTS '2019-06-26 20:18:13' ON COMPLETION PRESERVE DISABLE DO CALL rds_collect_global_status_history();

