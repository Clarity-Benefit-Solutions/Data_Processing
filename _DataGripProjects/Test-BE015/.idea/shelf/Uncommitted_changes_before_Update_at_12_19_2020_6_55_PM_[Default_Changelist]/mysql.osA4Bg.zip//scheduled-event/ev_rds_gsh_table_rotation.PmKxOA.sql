CREATE DEFINER = rdsadmin@localhost EVENT ev_rds_gsh_table_rotation ON SCHEDULE EVERY '7' DAY STARTS '2019-07-03 20:18:13' ON COMPLETION PRESERVE DISABLE DO CALL rds_rotate_global_status_history();

