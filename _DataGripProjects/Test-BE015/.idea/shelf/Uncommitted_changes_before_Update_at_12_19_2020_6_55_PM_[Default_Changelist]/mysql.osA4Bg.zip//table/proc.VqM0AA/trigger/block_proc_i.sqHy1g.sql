CREATE DEFINER = rdsadmin@localhost TRIGGER block_proc_i
    BEFORE INSERT
    ON proc
    FOR EACH ROW
BEGIN
   IF new.Definer = 'rdsadmin@localhost' THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'CANNOT MODIFY RDSADMIN OBJECT';
   END IF;
END;

