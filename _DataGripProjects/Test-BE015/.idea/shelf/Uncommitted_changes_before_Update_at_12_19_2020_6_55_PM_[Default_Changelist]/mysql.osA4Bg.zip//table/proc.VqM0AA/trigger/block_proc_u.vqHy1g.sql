CREATE DEFINER = rdsadmin@localhost TRIGGER block_proc_u
    BEFORE UPDATE
    ON proc
    FOR EACH ROW
BEGIN
   IF old.Definer = 'rdsadmin@localhost' OR (old.Definer <> 'rdsadmin@localhost' AND new.Definer = 'rdsadmin@localhost') THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'CANNOT MODIFY RDSDMIN OBJECT';
   END IF;
END;

