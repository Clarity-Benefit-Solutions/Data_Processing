CREATE
    DEFINER = rdsadmin@localhost PROCEDURE rds_kill_query_id(IN query bigint)
BEGIN
  DECLARE l_user VARCHAR(16);
  DECLARE l_host VARCHAR(64);
  DECLARE foo VARCHAR(255);
 
  SELECT USER, host INTO l_user, l_host
  FROM information_schema.processlist
  WHERE query_id = query;
 
  IF l_user = "rdsadmin" AND l_host LIKE "localhost%" THEN
    SELECT `ERROR (RDS): CANNOT KILL RDSADMIN QUERY` INTO foo;
  ELSEIF l_user = "rdsrepladmin" THEN
    SELECT `ERROR (RDS): CANNOT KILL RDSREPLADMIN QUERY` INTO foo;
  ELSE
    KILL QUERY ID query;
  END IF;
END;

