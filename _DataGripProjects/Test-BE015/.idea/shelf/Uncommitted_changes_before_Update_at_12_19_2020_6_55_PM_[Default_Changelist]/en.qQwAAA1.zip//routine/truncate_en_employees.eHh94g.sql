CREATE
    DEFINER = admin@`%` PROCEDURE truncate_en_employees( IN dummy int(1) )
BEGIN

    CALL api.db_show_message( 'truncate_en_employees', 'STARTING' );

    TRUNCATE TABLE en.en_employees;


    CALL api.db_show_message( 'truncate_en_employees', 'FINISHED' );


END;

