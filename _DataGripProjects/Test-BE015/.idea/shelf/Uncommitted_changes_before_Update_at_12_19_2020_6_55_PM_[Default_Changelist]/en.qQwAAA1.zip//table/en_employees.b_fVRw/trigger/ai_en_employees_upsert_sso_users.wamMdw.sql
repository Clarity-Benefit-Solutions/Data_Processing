CREATE DEFINER = admin@`%` TRIGGER ai_en_employees_upsert_sso_users
    AFTER INSERT
    ON en_employees
    FOR EACH ROW
BEGIN
    CALL api.upsert_en_platform_user(api.api_fix_email(new.email), api.api_fix_email(new.email), new.firstname,
                                     new.lastname, new.phone, api.api_fix_ssn(new.ssn), new.employeeid,
                                     new.dob, api.api_cbool(new.employeestatus), api.api_cbool(new.enparticipant), 0,
                                     0
        , new.row_id
        , new.companyidentifier);

END;

