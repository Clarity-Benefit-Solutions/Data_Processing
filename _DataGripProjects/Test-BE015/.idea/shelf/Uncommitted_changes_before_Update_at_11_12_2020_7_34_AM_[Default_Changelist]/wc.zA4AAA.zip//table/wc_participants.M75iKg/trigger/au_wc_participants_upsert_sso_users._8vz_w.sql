create definer = admin@`%` trigger au_wc_participants_upsert_sso_users
    after update
    on wc_participants
    for each row
BEGIN
    CALL api.upsert_wc_platform_user(
            new.Email
        , new.Email
        , new.FirstName
        , new.LastName
        , new.MobileNumber
        , api.api_fix_ssn(api.api_nz(new.EmployeeSSN, new.EmployeeID))
        , NULL -- p_wca_employer_id
        , NULL -- p_wca_tpa_id
        , NULL -- p_wca_client_user_id
        , NULL -- p_wca_data_partner_id
        , NEW.TPAID -- p_wcp_tpa_id
        , NEW.EmployerID -- p_wcp_employer_id
        , NEW.EmployeeID -- employee_id
        , NEW.BirthDate -- p_wc_dob
        , NEW.CardNumber -- p_wc_card_number
        , 0 -- p_wca_is_active
        , api.api_cbool(NEW.EmployeeStatus) -- p_wcp_is_active
        , 0
        , new.row_id
        );

END;

