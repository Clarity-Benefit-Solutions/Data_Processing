create definer = admin@`%` trigger au_wc_employer_users_upsert_sso_users
    after update
    on wc_employer_users
    for each row
BEGIN
    CALL api.upsert_wc_platform_user(
            new.email,
            new.email,
            new.first_name,
            new.last_name,
            new.phone,
            NULL -- ssn
        , new.employer_id -- p_wca_employer_id
        , new.tpa_id -- p_wca_tpa_id
        , new.user_id -- p_wca_client_user_id
        , NULL -- p_wca_data_partner_id
        , NULL -- p_wcp_tpa_id
        , NULL -- p_wcp_employer_id
        , NULL -- -- p_wcp_employee_id
        , NULL -- p_wc_dob
        , NULL -- p_wc_card_number
        , CASE WHEN new.STATUS = 'ACTIVE' THEN 1 ELSE 0 END -- p_wca_is_active
        , NULL -- p_wcp_is_active
        , new.row_id -- p_wca_row_id
        , NULL
        );
END;

