create
    definer = admin@`%` procedure upsert_adp_credentials(IN p_client_id varchar(200), IN p_client_secret varchar(200),
                                                         IN p_token varchar(200), IN p_org_id varchar(200),
                                                         IN p_last_update varchar(200))
BEGIN
    /*DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
        BEGIN
            GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
            CALL api.db_log_error( @errno , 'upsert_adp_credentials' , @text , @sqlstate );
        END;*/

    -- show message
    INSERT INTO adp.adp_api_log (direction, endpoint, method, request_body, action, status_code, status_message)
    VALUES ('IN', 'upsert_adp_credentials', 'PUT',
            concat('client_id: ', p_client_id, ', client_secret:', p_client_secret, ', token:', p_token, ',org_id:',
                   p_org_id,
                   ', last_update', p_last_update), 'client creds', '200', 'OK');


    INSERT INTO adp.adp_credentials_table( client_id
                                         , client_secret
                                         , token
                                         , org_id
                                         , last_update)
    VALUES ( p_client_id
           , p_client_secret
           , p_token
           , p_org_id
           , p_last_update)
    ON DUPLICATE KEY UPDATE client_id     = ifnull(p_client_id, client_id)
                       , client_secret = ifnull(p_client_secret, client_secret)
                       , token         = ifnull(p_token, token)
                       , org_id        = ifnull(p_org_id, org_id)
                       , last_update   = ifnull(p_last_update, last_update);
END;

