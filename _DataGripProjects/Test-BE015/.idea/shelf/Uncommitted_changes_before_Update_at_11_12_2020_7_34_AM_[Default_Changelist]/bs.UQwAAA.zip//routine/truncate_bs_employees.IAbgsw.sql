create
    definer = admin@`%` procedure truncate_bs_employees(IN dummy int(1))
BEGIN
    -- show message
    CALL api.db_show_message('truncate_bs_employees', 'STARTING');
    --
    truncate table bs.bs_employees;

    -- show message
    CALL api.db_show_message('truncate_bs_employees', 'FINISHED');
    --

END;

