create
    definer = admin@`%` function util_strposrev(instring text, insubstring text) returns int
BEGIN
  DECLARE result   INTEGER;

  IF POSITION(insubstring IN instring) = 0
  THEN
    -- no match
    SET result = 0;
  ELSEIF LENGTH(insubstring) = 1
  THEN
    -- add one to get the correct position from the left.
    SET result =
          1 + LENGTH(instring) - POSITION(insubstring IN REVERSE(instring));
  ELSE
    -- add two minus the legth of the search string
    SET result =
          2 +
          LENGTH(instring) -
          LENGTH(insubstring) -
          POSITION(REVERSE(insubstring) IN REVERSE(instring));
  END IF;

  RETURN result;
END;

