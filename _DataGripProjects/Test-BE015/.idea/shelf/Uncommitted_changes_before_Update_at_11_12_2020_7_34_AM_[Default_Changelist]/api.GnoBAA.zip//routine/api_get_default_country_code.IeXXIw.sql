create
    definer = admin@`%` function api_get_default_country_code() returns varchar(5)
BEGIN
    RETURN '1';
END;

