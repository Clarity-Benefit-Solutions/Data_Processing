create
    definer = admin@`%` function api_is_blank(value text) returns tinyint(1)
BEGIN
  RETURN ifnull(
           trim(value)
          ,'') = '';
END;

