create
    definer = admin@`%` function QT() returns varchar(1)
BEGIN
    RETURN '"';
END;

