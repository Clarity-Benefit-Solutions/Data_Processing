create
    definer = admin@`%` procedure upsert_sso_user_after_registration(IN p_row_id varchar(100),
                                                                     IN p_user_name varchar(200),
                                                                     IN p_email varchar(200))
BEGIN
      DECLARE v_row_id VARCHAR(100);
      DECLARE v_first_name VARCHAR(100);
      DECLARE v_last_name VARCHAR(100);
        DECLARE v_title VARCHAR(100);
        DECLARE v_employee_id VARCHAR(100);
        DECLARE v_mobile_number VARCHAR(100);
        DECLARE v_alternate_email VARCHAR(100);
        DECLARE v_is_registration_complete VARCHAR(100);
        DECLARE v_is_active VARCHAR(100);
        DECLARE v_cp_client_id VARCHAR(100);
        DECLARE v_cp_broker_id VARCHAR(100);
        DECLARE v_cp_client_contact_id VARCHAR(100);
        DECLARE v_cp_sso_identifier VARCHAR(100);
        DECLARE v_cp_customer_id VARCHAR(100);
        DECLARE v_cp_entity_type VARCHAR(100);
        DECLARE v_cp_member_id VARCHAR(100);
        DECLARE v_cp_user_id VARCHAR(100);
        DECLARE v_ssn VARCHAR(100);
        DECLARE v_cp_allow_sso VARCHAR(100);
        DECLARE v_wca_tpa_id VARCHAR(100);
        DECLARE v_wca_employer_id VARCHAR(100);
        DECLARE v_wca_data_partner_id VARCHAR(100);
        DECLARE v_wca_client_user_id VARCHAR(100);
        DECLARE v_wcp_tpa_id VARCHAR(100);
        DECLARE v_wcp_employer_id VARCHAR(100);
        DECLARE v_wcp_employee_id VARCHAR(100);
        DECLARE v_bs_user_id VARCHAR(100);
        DECLARE v_wc_card_number VARCHAR(100);
        DECLARE v_wc_dob VARCHAR(100);
        DECLARE v_bs_import_user_id VARCHAR(100);
        DECLARE v_bs_user_name VARCHAR(100);
        DECLARE v_bs_dob VARCHAR(100);
        DECLARE v_bs_work_email VARCHAR(100);
        DECLARE v_bs_payroll_id VARCHAR(100);
        DECLARE v_dob VARCHAR(100);

      DECLARE v_rollback BOOL DEFAULT 0;
      DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
      BEGIN
      SET v_rollback = 1;
            GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE,
                                  @errno = MYSQL_ERRNO,
                                  @text = MESSAGE_TEXT;
      CALL db_log_error(@errno,
                     'upsert_sso_user_after_registration',
                     @text,
                     @sqlstate);


      END;

   -- select row from sso_invited_users for record to insert
   SELECT row_id,
          first_name,
          last_name,
          title,
          dob,
          employee_id,
          mobile_number,
          alternate_email,
          is_registration_complete,
          is_active,
          cp_client_id,
          cp_broker_id,
          cp_client_contact_id,
          cp_sso_identifier,
          cp_customer_id,
          cp_entity_type,
          cp_member_id,
          cp_user_id,
          ssn,
          cp_allow_sso,
          wca_tpa_id,
          wca_employer_id,
          wca_data_partner_id,
          wca_client_user_id,
          wcp_tpa_id,
          wcp_employer_id,
          wcp_employee_id,
          bs_user_id,
          wc_card_number,
          wc_dob,
          bs_import_user_id,
          bs_user_name,
          bs_dob,
          bs_work_email,
          bs_payroll_id
     INTO v_row_id,
          v_first_name,
          v_last_name,
          v_title,
          v_dob,
          v_employee_id,
          v_mobile_number,
          v_alternate_email,
          v_is_registration_complete,
          v_is_active,
          v_cp_client_id,
          v_cp_broker_id,
          v_cp_client_contact_id,
          v_cp_sso_identifier,
          v_cp_customer_id,
          v_cp_entity_type,
          v_cp_member_id,
          v_cp_user_id,
          v_ssn,
          v_cp_allow_sso,
          v_wca_tpa_id,
          v_wca_employer_id,
          v_wca_data_partner_id,
          v_wca_client_user_id,
          v_wcp_tpa_id,
          v_wcp_employer_id,
          v_wcp_employee_id,
          v_bs_user_id,
          v_wc_card_number,
          v_wc_dob,
          v_bs_import_user_id,
          v_bs_user_name,
          v_bs_dob,
          v_bs_work_email,
          v_bs_payroll_id
      FROM api.sso_invited_users
    WHERE row_id = p_row_id
    LIMIT 1;

  -- check we got a row
   IF api.api_is_blank(v_row_id)
   THEN
      CALL api.throw_error(
              '10000',
              'upsert_sso_user_after_registration',
              Concat(
                 p_row_id,
                 ' No record found for Row ID in "sso_invited_users table"'));
   END IF;

   -- upsert cp details into sso_user
   CALL api.upsert_cp_sso_user(
							p_user_name,
                              p_email,
                              v_row_id,
                              v_first_name,
                              v_last_name,
                              v_title,
                              v_employee_id,
                              v_mobile_number,
                              v_alternate_email,
                              v_is_registration_complete,
                              v_is_active,
                              v_cp_client_id,
                              v_cp_broker_id,
                              v_cp_client_contact_id,
                              v_cp_sso_identifier,
                              v_cp_customer_id,
                              v_cp_entity_type,
                              v_cp_member_id,
                              v_cp_user_id,
                              v_ssn,
                              v_cp_allow_sso,
                              v_wca_tpa_id,
                              v_wca_employer_id,
                              v_wca_data_partner_id,
                              v_wca_client_user_id,
                              v_wcp_tpa_id,
                              v_wcp_employer_id,
                              v_wcp_employee_id,
                              v_bs_user_id,
                              v_wc_card_number,
                              v_wc_dob,
                              v_bs_import_user_id,
                              v_bs_user_name,
                              v_bs_dob,
                              v_bs_work_email,
                              v_bs_payroll_id,
                              v_dob);
END;

