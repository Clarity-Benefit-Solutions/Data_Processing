create
    definer = admin@`%` procedure upsert_bs_platform_user(IN p_user_name varchar(200), IN p_email varchar(200),
                                                          IN p_first_name varchar(200), IN p_last_name varchar(200),
                                                          IN p_mobile_number varchar(200), IN p_ssn varchar(200),
                                                          IN p_bs_user_id varchar(200),
                                                          IN p_bs_import_user_id varchar(200),
                                                          IN p_bs_user_name varchar(200),
                                                          IN p_bs_employee_id varchar(200),
                                                          IN p_bs_work_email varchar(200),
                                                          IN p_bs_payroll_id varchar(200), IN p_dob varchar(50),
                                                          IN p_bs_is_active int(1), IN p_bs_is_employee int(1),
                                                          IN p_bs_is_manager int(1), IN p_bs_is_topdog int(1),
                                                          IN p_bs_abbrev_url varchar(200), IN p_bs_row_id int,
                                                          IN p_bs_employer_id varchar(200))
full_proc:
BEGIN
    DECLARE v_count varchar(50) DEFAULT NULL;
    DECLARE v_user_id varchar(50) DEFAULT NULL;
    DECLARE v_is_locked varchar(5) DEFAULT NULL;

    --
    -- handle error that may happen as the table has a few unique keys which may conflict
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
            CALL db_log_error( @errno , 'upsert_bs_platform_user' , @text , @sqlstate );
        END;

    -- fix args
    SET p_email = api.api_fix_email( p_email );
    SET p_user_name = api.api_fix_email( p_user_name );
    SET p_ssn = api.api_fix_email( p_ssn );
    SET p_bs_employee_id = api.api_fix_email( p_bs_employee_id );
    SET p_mobile_number = api.api_fix_phone_number( p_mobile_number );
    SET p_dob = api.api_fix_date( p_dob );

    -- sumeet: we have many record with blank email and ssn - check via SSoID before inserting. else update. We cannot have a UK on ssoID as other platforms dont have this column!     -- ensure we have a valid ssoid or userid - else user cannot id in
    IF api.api_is_blank( p_bs_import_user_id ) OR api.api_is_blank( p_bs_user_name ) /*AND api.api_is_blank(p_ssn) AND
       api.api_is_blank(p_email)*/ THEN
        CALL api.db_log_message( 'upsert_bs_platform_user' ,
                              CONCAT( 'Not Inserting record as either p_bs_import_user_id or p_bs_user_name is blank' ,
                                      'Import User ID: ' , api.api_nz( p_bs_import_user_id , '' ) , ' AND UserName: ' ,
                                      api.api_nz( p_bs_user_name , '' ) ) , 'WARN' );

        /* EXIT PROC*/
        LEAVE full_proc;
    END IF;

    -- dont insert inactive records
    IF !api.api_cbool( p_bs_is_active ) THEN
        CALL api.db_log_message( 'upsert_bs_platform_user' ,
                              CONCAT( 'Not Inserting record as record is NOT active' , 'Import User ID: ' ,
                                      api.api_nz( p_bs_import_user_id , '' ) , ' AND UserName: ' ,
                                      api.api_nz( p_bs_user_name , '' ) ) , 'WARN' );

        /* EXIT PROC*/
        LEAVE full_proc;
    END IF;

    /* upsert by ssn - can combine acros platforms*/
    IF !api.api_is_blank( p_ssn ) THEN

        -- see if we already have a record for this ssn
        SELECT
            count( * )
          , user_id
          , CASE
                WHEN is_verified OR is_ready_for_sso_processing THEN 1
                ELSE 0
            END INTO v_count, v_user_id, v_is_locked
        FROM
            api.platform_users
        WHERE
            (ssn = p_ssn);

        SET v_user_id = api.api_nz( v_user_id , '' );
        --
        CALL api.db_log_message( 'upsert_bs_platform_user' ,
                              CONCAT( v_count , ' Records found for SSN: ' , api.api_nz( p_ssn , '' ) ) , 'WARN' );

        IF api.api_cbool( v_user_id ) THEN
            CALL api.db_log_message( 'upsert_bs_platform_user' ,
                                  CONCAT( 'UPDATING existing ' , v_count , ' records for SSN ID: ' ,
                                          api.api_nz( p_ssn , '' ) ) , 'WARN' );

            -- just update by ssn
            UPDATE api.platform_users
            SET
                user_name         = api_if_true_else( v_is_locked , user_name , api_nz( p_user_name , user_name ) )
              , first_name        = api_if_true_else( v_is_locked , first_name , api_nz( p_first_name , first_name ) )
              , last_name         = api_if_true_else( v_is_locked , last_name , api_nz( p_last_name , last_name ) )
              , email             = api_if_true_else( v_is_locked , email , api_nz( p_email , email ) )
              , mobile_number     = api_if_true_else( v_is_locked , mobile_number ,
                                                      api_nz( p_mobile_number , mobile_number ) )
              , ssn               = api_if_true_else( v_is_locked , ssn , api_nz( p_ssn , ssn ) )
              , dob               = api_if_true_else( v_is_locked , dob , api_nz( p_dob , dob ) )
              , employee_id       = api_if_true_else( v_is_locked , employee_id ,
                                                      api_nz( p_bs_employee_id , employee_id ) )
              , bs_user_id        = api_nz( p_bs_user_id , bs_user_id )
              , bs_import_user_id = api_nz( p_bs_import_user_id , bs_import_user_id )
              , bs_user_name      = api_nz( p_bs_user_name , bs_user_name )
              , bs_payroll_id     = api_nz( p_bs_payroll_id , bs_payroll_id )
              , bs_dob            = api_nz( p_dob , bs_dob )
              , bs_ssn            = api_nz( p_ssn , bs_ssn )
              , bs_email          = api_nz( p_email , bs_email )
              , bs_user_is_active = api_cbool( api_nz( p_bs_is_active , bs_user_is_active ) )
              , bs_employer_id= api_nz( p_bs_employer_id , bs_employer_id )
              , bs_is_employee    = api_cbool( api_nz( p_bs_is_employee , bs_is_employee ) )
              , bs_is_manager= api_cbool( api_nz( p_bs_is_manager , bs_is_manager ) )
              , bs_is_topdog= api_cbool( api_nz( p_bs_is_topdog , bs_is_topdog ) )
              , bs_abbrev_url= api_cbool( api_nz( p_bs_abbrev_url , bs_abbrev_url ) )
              , bs_row_id= api_nz( p_bs_row_id , bs_row_id )
            WHERE
                (ssn = p_ssn);

            /* EXIT PROC*/
            LEAVE full_proc;
        END IF;
    END IF;

    /* upsert by email only if ssn is blank - else we will cause same email across 2 ssn - can combine across platforms - however CP users usually have their personal email recorded, not their work email*/
    IF api.api_is_blank( p_ssn ) AND !api.api_is_blank( p_email ) THEN

        -- see if we already have a record for this ssn
        SELECT
            count( * )
          , user_id
          , CASE
                WHEN is_verified OR is_ready_for_sso_processing THEN 1
                ELSE 0
            END INTO v_count, v_user_id, v_is_locked
        FROM
            api.platform_users
        WHERE
            (email = p_email);

        SET v_user_id = api.api_nz( v_user_id , '' );
        --
        CALL api.db_log_message( 'upsert_bs_platform_user' ,
                              CONCAT( v_count , ' Records found for EMAIL: ' , api.api_nz( p_email , '' ) ) , 'WARN' );
        IF api.api_cbool( v_user_id ) THEN
            CALL api.db_log_message( 'upsert_bs_platform_user' ,
                                  CONCAT( 'UPDATING existing ' , v_count , ' records for EMAIL: ' ,
                                          api.api_nz( p_email , '' ) ) , 'WARN' );

            -- just update by ssn
            UPDATE api.platform_users
            SET
                user_name         = api_if_true_else( v_is_locked , user_name , api_nz( p_user_name , user_name ) )
              , first_name        = api_if_true_else( v_is_locked , first_name , api_nz( p_first_name , first_name ) )
              , last_name         = api_if_true_else( v_is_locked , last_name , api_nz( p_last_name , last_name ) )
              , email             = api_if_true_else( v_is_locked , email , api_nz( p_email , email ) )
              , mobile_number     = api_if_true_else( v_is_locked , mobile_number ,
                                                      api_nz( p_mobile_number , mobile_number ) )
              , ssn               = api_if_true_else( v_is_locked , ssn , api_nz( p_ssn , ssn ) )
              , dob               = api_if_true_else( v_is_locked , dob , api_nz( p_dob , dob ) )
              , employee_id       = api_if_true_else( v_is_locked , employee_id ,
                                                      api_nz( p_bs_employee_id , employee_id ) )
              , bs_user_id        = api_nz( p_bs_user_id , bs_user_id )
              , bs_import_user_id = api_nz( p_bs_import_user_id , bs_import_user_id )
              , bs_user_name      = api_nz( p_bs_user_name , bs_user_name )
              , bs_payroll_id     = api_nz( p_bs_payroll_id , bs_payroll_id )
              , bs_dob            = api_nz( p_dob , bs_dob )
              , bs_ssn            = api_nz( p_ssn , bs_ssn )
              , bs_email          = api_nz( p_email , bs_email )
              , bs_user_is_active = api_cbool( api_nz( p_bs_is_active , bs_user_is_active ) )
              , bs_employer_id= api_nz( p_bs_employer_id , bs_employer_id )
              , bs_is_employee    = api_cbool( api_nz( p_bs_is_employee , bs_is_employee ) )
              , bs_is_manager= api_cbool( api_nz( p_bs_is_manager , bs_is_manager ) )
              , bs_is_topdog= api_cbool( api_nz( p_bs_is_topdog , bs_is_topdog ) )
              , bs_abbrev_url= api_cbool( api_nz( p_bs_abbrev_url , bs_abbrev_url ) )
              , bs_row_id= api_nz( p_bs_row_id , bs_row_id )
            WHERE
                (email = p_email);

            /* EXIT PROC*/
            LEAVE full_proc;
        END IF;
    END IF;

    /* check by unique keys for this platform*/
    IF !api.api_is_blank( p_bs_import_user_id ) AND !api.api_is_blank( p_bs_user_name ) THEN

        /* upsert by p_bs_import_user_id and p_bs_user_name - can combine across subsequent loads of cp_users even if ssn and email change*/
        SELECT
            count( * )
          , user_id
          , CASE
                WHEN is_verified OR is_ready_for_sso_processing THEN 1
                ELSE 0
            END INTO v_count, v_user_id, v_is_locked
        FROM
            api.platform_users
        WHERE
              bs_import_user_id = p_bs_import_user_id
          AND bs_user_name = p_bs_user_name;

        SET v_user_id = api.api_nz( v_user_id , '' );

        CALL api.db_log_message( 'upsert_bs_platform_user' , CONCAT( v_count , ' Records found for Import User ID: ' ,
                                                                  api.api_nz( p_bs_import_user_id , '' ) ,
                                                                  ' AND UserName: ' ,
                                                                  api.api_nz( p_bs_user_name , '' ) ) , 'WARN' );
        --
        IF api.api_cbool( v_user_id ) THEN
            CALL api.db_log_message( 'upsert_bs_platform_user' ,
                                  CONCAT( 'UPDATING existing ' , v_count , ' records for Import User ID: ' ,
                                          api.api_nz( p_bs_import_user_id , '' ) , ' AND UserName: ' ,
                                          api.api_nz( p_bs_user_name , '' ) ) , 'WARN' );

            UPDATE api.platform_users
            SET
                user_name         = api_if_true_else( v_is_locked , user_name , api_nz( p_user_name , user_name ) )
              , first_name        = api_if_true_else( v_is_locked , first_name , api_nz( p_first_name , first_name ) )
              , last_name         = api_if_true_else( v_is_locked , last_name , api_nz( p_last_name , last_name ) )
              , email             = api_if_true_else( v_is_locked , email , api_nz( p_email , email ) )
              , mobile_number     = api_if_true_else( v_is_locked , mobile_number ,
                                                      api_nz( p_mobile_number , mobile_number ) )
              , ssn               = api_if_true_else( v_is_locked , ssn , api_nz( p_ssn , ssn ) )
              , dob               = api_if_true_else( v_is_locked , dob , api_nz( p_dob , dob ) )
              , employee_id       = api_if_true_else( v_is_locked , employee_id ,
                                                      api_nz( p_bs_employee_id , employee_id ) )
              , bs_user_id        = api_nz( p_bs_user_id , bs_user_id )
              , bs_import_user_id = api_nz( p_bs_import_user_id , bs_import_user_id )
              , bs_user_name      = api_nz( p_bs_user_name , bs_user_name )
              , bs_payroll_id     = api_nz( p_bs_payroll_id , bs_payroll_id )
              , bs_dob            = api_nz( p_dob , bs_dob )
              , bs_ssn            = api_nz( p_ssn , bs_ssn )
              , bs_email          = api_nz( p_email , bs_email )
              , bs_user_is_active = api_cbool( api_nz( p_bs_is_active , bs_user_is_active ) )
              , bs_employer_id= api_nz( p_bs_employer_id , bs_employer_id )
              , bs_is_employee    = api_cbool( api_nz( p_bs_is_employee , bs_is_employee ) )
              , bs_is_manager= api_cbool( api_nz( p_bs_is_manager , bs_is_manager ) )
              , bs_is_topdog= api_cbool( api_nz( p_bs_is_topdog , bs_is_topdog ) )
              , bs_abbrev_url= api_cbool( api_nz( p_bs_abbrev_url , bs_abbrev_url ) )
              , bs_row_id= api_nz( p_bs_row_id , bs_row_id )
            WHERE
                  bs_import_user_id = p_bs_import_user_id
              AND bs_user_name = p_bs_user_name;
            /* EXIT PROC*/
            LEAVE full_proc;
        END IF;
    END IF;

    /* sumeet - we should not continue after this .... but left for uniformity*/

    /* upsert by any PK/UK violations across all inserted fields*/
    CALL api.db_log_message( 'upsert_bs_platform_user' ,
                          CONCAT( 'UPSERTING record for Import User ID: ' , api.api_nz( p_bs_import_user_id , '' ) ,
                                  ' AND UserName: ' , api.api_nz( p_bs_user_name , '' ) ) , 'WARN' );

    INSERT INTO api.platform_users(
                                    user_name
                                  , first_name
                                  , last_name
                                  , email
                                  , mobile_number
                                  , bs_user_id
                                  , bs_import_user_id
                                  , bs_user_name
                                  , bs_work_email
                                  , bs_payroll_id
                                  , bs_dob
                                  , dob
                                  , ssn
                                  , employee_id
                                  , bs_user_is_active
                                  , bs_employer_id
                                  , bs_ssn
                                  , bs_email
                                  , bs_is_employee
                                  , bs_is_manager
                                  , bs_is_topdog
                                  , bs_abbrev_url
                                  , bs_row_id
    )
    VALUES (
               p_user_name
           ,   p_first_name
           ,   p_last_name
           ,   p_email
           ,   p_mobile_number
           ,   p_bs_user_id
           ,   p_bs_import_user_id
           ,   p_bs_user_name
           ,   p_bs_work_email
           ,   p_bs_payroll_id
           ,   p_dob
           ,   p_dob
           ,   p_ssn
           ,   p_bs_employee_id
           ,   api_cbool( p_bs_is_active )
           ,   p_bs_employer_id
           ,   p_ssn
           ,   p_email
           ,   api_cbool( p_bs_is_employee )
           ,   api_cbool( p_bs_is_manager )
           ,   api_cbool( p_bs_is_topdog )
           ,   p_bs_abbrev_url
           ,   p_bs_row_id
           )
        /* use api_nz to avoid replacing previous value if new value is null or blank */
    ON DUPLICATE KEY UPDATE
                         user_name         = api_if_true_else( v_is_locked , user_name ,
                                                               api_nz( p_user_name , user_name ) )
                       , first_name        = api_if_true_else( v_is_locked , first_name ,
                                                               api_nz( p_first_name , first_name ) )
                       , last_name         = api_if_true_else( v_is_locked , last_name ,
                                                               api_nz( p_last_name , last_name ) )
                       , email             = api_if_true_else( v_is_locked , email , api_nz( p_email , email ) )
                       , mobile_number     = api_if_true_else( v_is_locked , mobile_number ,
                                                               api_nz( p_mobile_number , mobile_number ) )
                       , ssn               = api_if_true_else( v_is_locked , ssn , api_nz( p_ssn , ssn ) )
                       , dob               = api_if_true_else( v_is_locked , dob , api_nz( p_dob , dob ) )
                       , employee_id       = api_if_true_else( v_is_locked , employee_id ,
                                                               api_nz( p_bs_employee_id , employee_id ) )
                       , bs_user_id        = api_nz( p_bs_user_id , bs_user_id )
                       , bs_import_user_id = api_nz( p_bs_import_user_id , bs_import_user_id )
                       , bs_user_name      = api_nz( p_bs_user_name , bs_user_name )
                       , bs_payroll_id     = api_nz( p_bs_payroll_id , bs_payroll_id )
                       , bs_dob            = api_nz( p_dob , bs_dob )
                       , bs_ssn            = api_nz( p_ssn , bs_ssn )
                       , bs_email          = api_nz( p_email , bs_email )
                       , bs_user_is_active = api_cbool( api_nz( p_bs_is_active , bs_user_is_active ) )
                       , bs_employer_id= api_nz( p_bs_employer_id , bs_employer_id )
                       , bs_is_employee    = api_cbool( api_nz( p_bs_is_employee , bs_is_employee ) )
                       , bs_is_manager= api_cbool( api_nz( p_bs_is_manager , bs_is_manager ) )
                       , bs_is_topdog= api_cbool( api_nz( p_bs_is_topdog , bs_is_topdog ) )
                       , bs_abbrev_url= api_cbool( api_nz( p_bs_abbrev_url , bs_abbrev_url ) )
                       , bs_row_id= api_nz( p_bs_row_id , bs_row_id );

END;

