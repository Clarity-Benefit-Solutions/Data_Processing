create
    definer = admin@`%` function api_nz_int(value varchar(200), valueifnullorempty varchar(200)) returns int
BEGIN
    IF ifnull( value , '' ) = '' THEN
        RETURN api_cint( valueifnullorempty );
    ELSE
        RETURN api_cint( value );
    END IF;
END;

