create
    definer = admin@`%` function api_fix_id(value varchar(200)) returns varchar(200)
BEGIN
    return api_fix_ssn(value);
END;

