create
    definer = admin@`%` procedure db_show_message(IN p_msg_source varchar(200), IN p_msg text)
BEGIN
    -- SELECT concat('INFO ', p_msg_source, ' : ', p_msg);
    call api.db_log_message(p_msg_source, p_msg, 'INFO');
END;

