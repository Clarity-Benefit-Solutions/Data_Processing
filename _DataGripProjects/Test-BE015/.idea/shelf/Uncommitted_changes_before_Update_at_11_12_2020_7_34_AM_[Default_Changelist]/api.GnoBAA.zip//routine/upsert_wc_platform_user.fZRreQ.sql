create
    definer = admin@`%` procedure upsert_wc_platform_user(IN p_user_name varchar(200), IN p_email varchar(200),
                                                          IN p_first_name varchar(200), IN p_last_name varchar(200),
                                                          IN p_mobile_number varchar(200), IN p_ssn varchar(200),
                                                          IN p_wca_employer_id varchar(200),
                                                          IN p_wca_tpa_id varchar(200),
                                                          IN p_wca_client_user_id varchar(200),
                                                          IN p_wca_data_partner_id varchar(200),
                                                          IN p_wcp_tpa_id varchar(200),
                                                          IN p_wcp_employer_id varchar(200),
                                                          IN p_wcp_employee_id varchar(200), IN p_dob varchar(200),
                                                          IN p_wc_card_number varchar(200), IN p_wca_is_active int(1),
                                                          IN p_wcp_is_active int(1), IN p_wca_row_id int,
                                                          IN p_wcp_row_id int)
full_proc:

BEGIN
    DECLARE v_count varchar(50) DEFAULT NULL;
    DECLARE v_user_id varchar(50) DEFAULT NULL;
    DECLARE v_is_locked varchar(5) DEFAULT NULL;
    
    -- handle error that may happen as the table has a few unique keys which may conflict
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
            CALL db_log_error( @errno , 'upsert_wc_sso_user' , @text , @sqlstate );
        END;
    
    -- fix args
    SET p_email = api.api_fix_email( p_email );
    SET p_user_name = api.api_fix_email( p_user_name );
    SET p_mobile_number = api.api_fix_phone_number( p_mobile_number );
    SET p_ssn = api.api_fix_email( p_ssn );
    -- SET p_cp_employee_id = api.api_fix_email(p_cp_employee_id);
    SET p_dob = api.api_fix_date( p_dob );
    SET p_wca_is_active = api.api_cbool( p_wca_is_active );
    SET p_wcp_is_active = api.api_cbool( p_wcp_is_active );
    
    -- sumeet: we have many record with blank email and ssn - check via SSoID before inserting. else update. We cannot have a UK on ssoID as other platforms dont have this column!     -- ensure we have a valid ssoid or userid - else user cannot id in
    IF api.api_is_blank( p_wca_client_user_id ) AND api.api_is_blank( p_wcp_employee_id ) /*AND api.api_is_blank(p_ssn) AND
       api.api_is_blank(p_email)*/ THEN
        CALL api.db_log_message( 'upsert_wc_platform_user' , CONCAT(
                'Not Inserting record as p_wca_client_user_id, p_wcp_employee_id are all blank' ) , 'WARN' );
        
        /* EXIT PROC*/
        LEAVE full_proc;
    END IF;
    
    -- dont insert if not active
    IF !api.api_cbool( p_wca_is_active ) AND !api.api_cbool( p_wcp_is_active ) /*AND api.api_is_blank(p_ssn) AND
       api.api_is_blank(p_email)*/ THEN
        CALL api.db_log_message( 'upsert_wc_platform_user' ,
                              CONCAT( 'Not Inserting record as it is NOT active. ClientUserId: ' ,
                                      api_nz( p_wca_client_user_id , '' ) , ' EmployeeID: ' ,
                                      api_nz( p_wcp_employee_id , '' ) ) , 'WARN' );
        
        /* EXIT PROC*/
        LEAVE full_proc;
    END IF;
    
    /* upsert by ssn - can combine acros platforms*/
    IF !api.api_is_blank( p_ssn ) THEN
        
        -- see if we already have a record for this ssn
        SELECT
            count( * )
          , user_id
          , CASE
                WHEN is_verified OR is_ready_for_sso_processing THEN 1
                ELSE 0
            END INTO v_count, v_user_id, v_is_locked
        FROM
            api.platform_users
        WHERE
            (ssn <=> p_ssn);
        
        SET v_user_id = api.api_nz( v_user_id , '' );
        --
        CALL api.db_log_message( 'upsert_wc_platform_user' ,
                              CONCAT( v_count , ' Records found for SSN: ' , api.api_nz( p_ssn , '' ) ) , 'WARN' );
        IF api.api_cbool( v_user_id ) THEN
            CALL api.db_log_message( 'upsert_wc_platform_user' ,
                                  CONCAT( 'UPDATING existing ' , v_count , ' records for SSN ID: ' ,
                                          api.api_nz( p_ssn , '' ) ) , 'WARN' );
            
            -- just update by ssn
            UPDATE api.platform_users
            SET
                user_name           = api_if_true_else( v_is_locked , user_name , api_nz( p_user_name , user_name ) )
              , first_name          = api_if_true_else( v_is_locked , first_name , api_nz( p_first_name , first_name ) )
              , last_name           = api_if_true_else( v_is_locked , last_name , api_nz( p_last_name , last_name ) )
              , email               = api_if_true_else( v_is_locked , email , api_nz( p_email , email ) )
              , mobile_number       = api_if_true_else( v_is_locked , mobile_number ,
                                                        api_nz( p_mobile_number , mobile_number ) )
              , ssn                 = api_if_true_else( v_is_locked , ssn , api_nz( p_ssn , ssn ) )
              , dob                 = api_if_true_else( v_is_locked , dob , api_nz( p_dob , dob ) )
              , employee_id         = api_if_true_else( v_is_locked , employee_id ,
                                                        api_nz( p_wcp_employee_id , employee_id ) )
              , ssn                 = api_nz( p_ssn , ssn )
              , employee_id         = api_nz( p_wcp_employee_id , employee_id )
              , wca_employer_id     = api_nz( p_wca_employer_id , wca_employer_id )
              , wca_tpa_id          = api_nz( p_wca_tpa_id , wca_tpa_id )
              , wca_client_user_id  = api_nz( p_wca_client_user_id , wca_client_user_id )
              , wca_data_partner_id = api_nz( p_wca_data_partner_id , wca_data_partner_id )
              , wcp_employer_id     = api_nz( p_wcp_employer_id , wcp_employer_id )
              , wcp_tpa_id          = api_nz( p_wcp_tpa_id , wcp_tpa_id )
              , wcp_employee_id     = api_nz( p_wcp_employee_id , wcp_employee_id )
              , wc_dob              = api_nz( p_dob , wc_dob )
              , wc_card_number      = api_nz( p_wc_card_number , wc_card_number )
              , wca_user_is_active  = api_nz( p_wca_is_active , wca_user_is_active )
              , wcp_user_is_active  = api_nz( p_wcp_is_active , wcp_user_is_active )
              , wc_ssn              = api_nz( p_ssn , wc_ssn )
              , wc_email            = api_nz( p_email , wc_email )
              , wca_row_id= ifnull( p_wca_row_id , wca_row_id )
              , wcp_row_id= ifnull( p_wcp_row_id , wcp_row_id )
            WHERE
                (ssn <=> p_ssn);
            
            /* EXIT PROC*/
            LEAVE full_proc;
        END IF;
    END IF;
    
    /* upsert by email only if ssn is blank - else we will cause same email across 2 ssn - can combine across platforms - however CP users usually have their personal email recorded, not their work email*/
    IF api.api_is_blank( p_ssn ) AND !api.api_is_blank( p_email ) THEN
        
        -- see if we already have a record for this ssn
        SELECT
            count( * )
          , user_id
          , CASE
                WHEN is_verified OR is_ready_for_sso_processing THEN 1
                ELSE 0
            END INTO v_count, v_user_id, v_is_locked
        FROM
            api.platform_users
        WHERE
            (email <=> p_email);
        
        SET v_user_id = api.api_nz( v_user_id , '' );
        --
        CALL api.db_log_message( 'upsert_wc_platform_user' ,
                              CONCAT( v_count , ' Records found for EMAIL: ' , api.api_nz( p_email , '' ) ) , 'WARN' );
        IF api.api_cbool( v_user_id ) THEN
            CALL api.db_log_message( 'upsert_wc_platform_user' ,
                                  CONCAT( 'UPDATING existing ' , v_count , ' records for EMAIL: ' ,
                                          api.api_nz( p_email , '' ) ) , 'WARN' );
            
            -- just update by ssn
            UPDATE api.platform_users
            SET
                user_name           = api_if_true_else( v_is_locked , user_name , api_nz( p_user_name , user_name ) )
              , first_name          = api_if_true_else( v_is_locked , first_name , api_nz( p_first_name , first_name ) )
              , last_name           = api_if_true_else( v_is_locked , last_name , api_nz( p_last_name , last_name ) )
              , email               = api_if_true_else( v_is_locked , email , api_nz( p_email , email ) )
              , mobile_number       = api_if_true_else( v_is_locked , mobile_number ,
                                                        api_nz( p_mobile_number , mobile_number ) )
              , ssn                 = api_if_true_else( v_is_locked , ssn , api_nz( p_ssn , ssn ) )
              , dob                 = api_if_true_else( v_is_locked , dob , api_nz( p_dob , dob ) )
              , employee_id         = api_if_true_else( v_is_locked , employee_id ,
                                                        api_nz( p_wcp_employee_id , employee_id ) )
              , wca_employer_id     = api_nz( p_wca_employer_id , wca_employer_id )
              , wca_tpa_id          = api_nz( p_wca_tpa_id , wca_tpa_id )
              , wca_client_user_id  = api_nz( p_wca_client_user_id , wca_client_user_id )
              , wca_data_partner_id = api_nz( p_wca_data_partner_id , wca_data_partner_id )
              , wcp_employer_id     = api_nz( p_wcp_employer_id , wcp_employer_id )
              , wcp_tpa_id          = api_nz( p_wcp_tpa_id , wcp_tpa_id )
              , wcp_employee_id     = api_nz( p_wcp_employee_id , wcp_employee_id )
              , wc_dob              = api_nz( p_dob , wc_dob )
              , wc_card_number      = api_nz( p_wc_card_number , wc_card_number )
              , wca_user_is_active  = api_nz( p_wca_is_active , wca_user_is_active )
              , wcp_user_is_active  = api_nz( p_wcp_is_active , wcp_user_is_active )
              , wc_ssn              = api_nz( p_ssn , wc_ssn )
              , wc_email            = api_nz( p_email , wc_email )
              , wca_row_id= ifnull( p_wca_row_id , wca_row_id )
              , wcp_row_id= ifnull( p_wcp_row_id , wcp_row_id )
            WHERE
                (email <=> p_email);
            
            /* EXIT PROC*/
            LEAVE full_proc;
        END IF;
    END IF;
    
    /* check by unique keys for this platform*/
    IF !api.api_is_blank( p_wca_client_user_id ) THEN
        
        /* upsert by p_cp_sso_identifier and p_cp_user_id - can combine across subsequent loads of cp_users*/
        SELECT
            count( * )
          , user_id
          , CASE
                WHEN is_verified OR is_ready_for_sso_processing THEN 1
                ELSE 0
            END INTO v_count, v_user_id, v_is_locked
        FROM
            api.platform_users
        WHERE
            wca_client_user_id = p_wca_client_user_id;
        
        SET v_user_id = api.api_nz( v_user_id , '' );
        
        CALL api.db_log_message( 'upsert_wc_platform_user' , CONCAT( v_count , ' Records found WCA UserID: ' ,
                                                                  api.api_nz( p_wca_client_user_id , '' ) ) , 'WARN' );
        --
        IF api.api_cbool( v_user_id ) THEN
            CALL api.db_log_message( 'upsert_wc_platform_user' ,
                                  CONCAT( 'UPDATING existing ' , v_count , ' records WCA UserID: ' ,
                                          api.api_nz( p_wca_client_user_id , '' ) ) , 'WARN' );
            -- just update
            -- sumeet: keep & update all columns in sso_users also for now for testing SSO
            UPDATE api.platform_users
            SET
                user_name           = api_if_true_else( v_is_locked , user_name , api_nz( p_user_name , user_name ) )
              , first_name          = api_if_true_else( v_is_locked , first_name , api_nz( p_first_name , first_name ) )
              , last_name           = api_if_true_else( v_is_locked , last_name , api_nz( p_last_name , last_name ) )
              , email               = api_if_true_else( v_is_locked , email , api_nz( p_email , email ) )
              , mobile_number       = api_if_true_else( v_is_locked , mobile_number ,
                                                        api_nz( p_mobile_number , mobile_number ) )
              , ssn                 = api_if_true_else( v_is_locked , ssn , api_nz( p_ssn , ssn ) )
              , dob                 = api_if_true_else( v_is_locked , dob , api_nz( p_dob , dob ) )
              , employee_id         = api_if_true_else( v_is_locked , employee_id ,
                                                        api_nz( p_wcp_employee_id , employee_id ) )
              , wca_employer_id     = api_nz( p_wca_employer_id , wca_employer_id )
              , wca_tpa_id          = api_nz( p_wca_tpa_id , wca_tpa_id )
              , wca_client_user_id  = api_nz( p_wca_client_user_id , wca_client_user_id )
              , wca_data_partner_id = api_nz( p_wca_data_partner_id , wca_data_partner_id )
              , wcp_employer_id     = api_nz( p_wcp_employer_id , wcp_employer_id )
              , wcp_tpa_id          = api_nz( p_wcp_tpa_id , wcp_tpa_id )
              , wcp_employee_id     = api_nz( p_wcp_employee_id , wcp_employee_id )
              , wc_dob              = api_nz( p_dob , wc_dob )
              , wc_card_number      = api_nz( p_wc_card_number , wc_card_number )
              , wca_user_is_active  = api_nz( p_wca_is_active , wca_user_is_active )
              , wcp_user_is_active  = api_nz( p_wcp_is_active , wcp_user_is_active )
              , wc_ssn              = api_nz( p_ssn , wc_ssn )
              , wc_email            = api_nz( p_email , wc_email )
              , wca_row_id= ifnull( p_wca_row_id , wca_row_id )
              , wcp_row_id= ifnull( p_wcp_row_id , wcp_row_id )
            WHERE
                wca_client_user_id = p_wca_client_user_id;
            
            /* EXIT PROC*/
            LEAVE full_proc;
        END IF;
    END IF;
    
    IF !api.api_is_blank( p_wcp_employee_id ) THEN
        
        /* upsert by p_cp_sso_identifier and p_cp_user_id - can combine across subsequent loads of cp_users*/
        
        SELECT
            count( * )
          , user_id
          , CASE
                WHEN is_verified OR is_ready_for_sso_processing THEN 1
                ELSE 0
            END INTO v_count, v_user_id, v_is_locked
        FROM
            api.platform_users
        WHERE
            wcp_employee_id = p_wcp_employee_id;
        
        SET v_user_id = api.api_nz( v_user_id , '' );
        
        CALL api.db_log_message( 'upsert_wc_platform_user' , CONCAT( v_count , ' Records found WCP EmployeeID: ' ,
                                                                  api.api_nz( p_wcp_employee_id , '' ) ) , 'WARN' );
        --
        IF api.api_cbool( v_user_id ) THEN
            CALL api.db_log_message( 'upsert_wc_platform_user' ,
                                  CONCAT( 'UPDATING existing ' , v_count , ' records WCP EmployeeID: ' ,
                                          api.api_nz( p_wcp_employee_id , '' ) ) , 'WARN' );
            -- just update
            -- sumeet: keep & update all columns in sso_users also for now for testing SSO
            UPDATE api.platform_users
            SET
                user_name           = api_if_true_else( v_is_locked , user_name , api_nz( p_user_name , user_name ) )
              , first_name          = api_if_true_else( v_is_locked , first_name , api_nz( p_first_name , first_name ) )
              , last_name           = api_if_true_else( v_is_locked , last_name , api_nz( p_last_name , last_name ) )
              , email               = api_if_true_else( v_is_locked , email , api_nz( p_email , email ) )
              , mobile_number       = api_if_true_else( v_is_locked , mobile_number ,
                                                        api_nz( p_mobile_number , mobile_number ) )
              , ssn                 = api_if_true_else( v_is_locked , ssn , api_nz( p_ssn , ssn ) )
              , dob                 = api_if_true_else( v_is_locked , dob , api_nz( p_dob , dob ) )
              , employee_id         = api_if_true_else( v_is_locked , employee_id ,
                                                        api_nz( p_wcp_employee_id , employee_id ) )
              , wca_employer_id     = api_nz( p_wca_employer_id , wca_employer_id )
              , wca_tpa_id          = api_nz( p_wca_tpa_id , wca_tpa_id )
              , wca_client_user_id  = api_nz( p_wca_client_user_id , wca_client_user_id )
              , wca_data_partner_id = api_nz( p_wca_data_partner_id , wca_data_partner_id )
              , wcp_employer_id     = api_nz( p_wcp_employer_id , wcp_employer_id )
              , wcp_tpa_id          = api_nz( p_wcp_tpa_id , wcp_tpa_id )
              , wcp_employee_id     = api_nz( p_wcp_employee_id , wcp_employee_id )
              , wc_dob              = api_nz( p_dob , wc_dob )
              , wc_card_number      = api_nz( p_wc_card_number , wc_card_number )
              , wca_user_is_active  = api_nz( p_wca_is_active , wca_user_is_active )
              , wcp_user_is_active  = api_nz( p_wcp_is_active , wcp_user_is_active )
              , wc_ssn              = api_nz( p_ssn , wc_ssn )
              , wc_email            = api_nz( p_email , wc_email )
              , wca_row_id= ifnull( p_wca_row_id , wca_row_id )
              , wcp_row_id= ifnull( p_wcp_row_id , wcp_row_id )
            WHERE
                wcp_employee_id = p_wcp_employee_id;
            
            /* EXIT PROC*/
            LEAVE full_proc;
        END IF;
    END IF;
    
    /* sumeet - we should not continue after this .... but left for uniformity*/
    
    /* upsert by any PK/UK violations across all inserted fields*/
    CALL api.db_log_message( 'upsert_wc_platform_user' ,
                          CONCAT( 'UPSERTING record WCA UserID: ' , api.api_nz( p_wca_client_user_id , '' ) ,
                                  ' AND WCP EmployeeID: ' , api.api_nz( p_wcp_employee_id , '' ) ) , 'WARN' );
    
    INSERT INTO api.platform_users(
                                    user_name
                                  , first_name
                                  , last_name
                                  , email
                                  , mobile_number
                                  , wca_employer_id
                                  , wca_tpa_id
                                  , wca_client_user_id
                                  , wca_data_partner_id
                                  , wcp_employer_id
                                  , wcp_tpa_id
                                  , wcp_employee_id
                                  , wc_dob
                                  , dob
                                  , ssn
                                  , employee_id
                                  , wc_card_number
                                  , wca_user_is_active
                                  , wcp_user_is_active
                                  , wc_ssn
                                  , wc_email
                                  , wca_row_id
                                  , wcp_row_id
    )
    VALUES (
               p_user_name
           ,   p_first_name
           ,   p_last_name
           ,   p_email
           ,   p_mobile_number
           ,   p_wca_employer_id
           ,   p_wca_tpa_id
           ,   p_wca_client_user_id
           ,   p_wca_data_partner_id
           ,   p_wcp_employer_id
           ,   p_wcp_tpa_id
           ,   p_wcp_employee_id
           ,   p_dob
           ,   p_dob
           ,   p_ssn
           ,   p_wcp_employee_id
           ,   p_wc_card_number
           ,   p_wca_is_active
           ,   p_wcp_is_active
           ,   p_ssn
           ,   p_email
           ,   p_wca_row_id
           ,   p_wcp_row_id
           )
        /* use api_nz to avoid replacing previous value if new value is null or blank */
    ON DUPLICATE KEY UPDATE
                         user_name           = api_if_true_else( v_is_locked , user_name ,
                                                                 api_nz( p_user_name , user_name ) )
                       , first_name          = api_if_true_else( v_is_locked , first_name ,
                                                                 api_nz( p_first_name , first_name ) )
                       , last_name           = api_if_true_else( v_is_locked , last_name ,
                                                                 api_nz( p_last_name , last_name ) )
                       , email               = api_if_true_else( v_is_locked , email , api_nz( p_email , email ) )
                       , mobile_number       = api_if_true_else( v_is_locked , mobile_number ,
                                                                 api_nz( p_mobile_number , mobile_number ) )
                       , ssn                 = api_if_true_else( v_is_locked , ssn , api_nz( p_ssn , ssn ) )
                       , dob                 = api_if_true_else( v_is_locked , dob , api_nz( p_dob , dob ) )
                       , employee_id         = api_if_true_else( v_is_locked , employee_id ,
                                                                 api_nz( p_wcp_employee_id , employee_id ) )
                       , wca_employer_id     = api_nz( p_wca_employer_id , wca_employer_id )
                       , wca_tpa_id          = api_nz( p_wca_tpa_id , wca_tpa_id )
                       , wca_client_user_id  = api_nz( p_wca_client_user_id , wca_client_user_id )
                       , wca_data_partner_id = api_nz( p_wca_data_partner_id , wca_data_partner_id )
                       , wcp_employer_id     = api_nz( p_wcp_employer_id , wcp_employer_id )
                       , wcp_tpa_id          = api_nz( p_wcp_tpa_id , wcp_tpa_id )
                       , wcp_employee_id     = api_nz( p_wcp_employee_id , wcp_employee_id )
                       , wc_dob              = api_nz( p_dob , wc_dob )
                       , wc_card_number      = api_nz( p_wc_card_number , wc_card_number )
                       , wca_user_is_active  = api_nz( p_wca_is_active , wca_user_is_active )
                       , wcp_user_is_active  = api_nz( p_wcp_is_active , wcp_user_is_active )
                       , wc_ssn              = api_nz( p_ssn , wc_ssn )
                       , wc_email            = api_nz( p_email , wc_email )
                       , wca_row_id= ifnull( p_wca_row_id , wca_row_id )
                       , wcp_row_id= ifnull( p_wcp_row_id , wcp_row_id );
END;

