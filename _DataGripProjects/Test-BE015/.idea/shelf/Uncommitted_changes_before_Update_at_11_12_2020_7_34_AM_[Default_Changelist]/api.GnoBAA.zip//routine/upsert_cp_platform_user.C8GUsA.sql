create
    definer = admin@`%` procedure upsert_cp_platform_user(IN p_user_name varchar(200), IN p_email varchar(200),
                                                          IN p_first_name varchar(200), IN p_last_name varchar(200),
                                                          IN p_alternate_email varchar(200), IN p_title varchar(200),
                                                          IN p_mobile_number varchar(200), IN p_ssn varchar(200),
                                                          IN p_employee_id varchar(200), IN p_cp_client_id varchar(200),
                                                          IN p_cp_broker_id varchar(200),
                                                          IN p_cp_client_contact_id varchar(200),
                                                          IN p_cp_sso_identifier varchar(200),
                                                          IN p_cp_customer_id varchar(200),
                                                          IN p_cp_entity_type varchar(200),
                                                          IN p_cp_user_id varchar(200), IN p_cp_member_id varchar(200),
                                                          IN p_cp_allow_sso varchar(200), IN p_dob varchar(50),
                                                          IN p_cp_tpa_user_is_active varchar(6),
                                                          IN p_cp_member_user_is_active varchar(6), IN p_cp_row_id int)
full_proc:
BEGIN

    DECLARE v_count varchar(50) DEFAULT NULL;
    DECLARE v_user_id varchar(50) DEFAULT NULL;
    DECLARE v_is_locked varchar(5) DEFAULT NULL;
    --
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
        BEGIN
            GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
            CALL db_log_error( @errno , 'upsert_cp_platform_user' , @text , @sqlstate );
        END;

    /*
        if true then
            LEAVE full_proc;
        end if;
    */ -- dont insert if not active
    IF !api.api_cbool( p_cp_tpa_user_is_active ) AND !api.api_cbool( p_cp_member_user_is_active ) THEN
        CALL api.db_log_message( 'upsert_cp_platform_user' ,
                              CONCAT( 'Not Inserting record as record is NOT active. ' , 'p_cp_tpa_user_is_active: ' ,
                                      api_cbool( p_cp_tpa_user_is_active ) , ', ' , 'p_cp_member_user_is_active: ' ,
                                      api_cbool( p_cp_member_user_is_active ) , ', SSOID: ' ,
                                      api_nz( p_cp_sso_identifier , '' ) , ', UserID: ' ,
                                      api_nz( p_cp_user_id , '' ) ) , 'WARN' );

        /* EXIT PROC*/
        LEAVE full_proc;
    END IF;

    -- sumeet: we have many record with blank email and ssn - check via SSoID before inserting. else update. We cannot have a UK on ssoID as other platforms dont have this column!     -- ensure we have a valid ssoid or userid - else user cannot id in
    IF api.api_is_blank( p_cp_sso_identifier ) AND api.api_is_blank( p_cp_user_id ) /*AND api.api_is_blank(p_ssn) AND
       api.api_is_blank(p_email)*/ THEN
        CALL api.db_log_message( 'upsert_cp_platform_user' ,
                              CONCAT( 'Not Inserting record as p_cp_sso_identifier, p_cp_user_id are all blank' ) ,
                              'WARN' );

        /* EXIT PROC*/
        LEAVE full_proc;
    END IF;

    /* upsert by ssn - can combine acros platforms*/
    IF !api.api_is_blank( p_ssn ) THEN

        -- see if we already have a record for this ssn
        SELECT
            count( * )
          , user_id
          , CASE
                WHEN is_verified OR is_ready_for_sso_processing THEN 1
                ELSE 0
            END INTO v_count, v_user_id, v_is_locked
        FROM
            api.platform_users
        WHERE
            (ssn <=> p_ssn);

        SET v_user_id = api.api_nz( v_user_id , '' );
        --
        CALL api.db_log_message( 'upsert_cp_platform_user' ,
                              CONCAT( v_count , ' Records found for SSN: ' , api.api_nz( p_ssn , '' ) ) , 'WARN' );
        --
        IF api.api_cbool( v_user_id ) THEN
            CALL api.db_log_message( 'upsert_cp_platform_user' ,
                                  CONCAT( 'UPDATING existing ' , v_count , ' records for SSN ID: ' ,
                                          api.api_nz( p_ssn , '' ) ) , 'WARN' );

            -- just update by ssn
            UPDATE api.platform_users
            SET
                user_name                = api_if_true_else( v_is_locked , user_name ,
                                                             api_nz( p_user_name , user_name ) ),
                first_name               = api_if_true_else( v_is_locked , first_name ,
                                                             api_nz( p_first_name , first_name ) ),
                last_name                = api_if_true_else( v_is_locked , last_name ,
                                                             api_nz( p_last_name , last_name ) ),
                email                    = api_if_true_else( v_is_locked , email , api_nz( p_email , email ) ),
                title                    = api_if_true_else( v_is_locked , title , api_nz( p_title , title ) ),
                mobile_number            = api_if_true_else( v_is_locked , mobile_number ,
                                                             api_nz( p_mobile_number , mobile_number ) ),
                ssn                      = api_if_true_else( v_is_locked , ssn , api_nz( p_ssn , ssn ) ),
                dob                      = api_if_true_else( v_is_locked , dob , api_nz( p_dob , dob ) ),
                employee_id              = api_if_true_else( v_is_locked , employee_id ,
                                                             api_nz( p_employee_id , employee_id ) ),
                alternate_email          = api_if_true_else( v_is_locked , alternate_email ,
                                                             api_nz( p_alternate_email , alternate_email ) ),
                cp_client_id             = api_nz( p_cp_client_id , cp_client_id ),
                cp_broker_id             = api_nz( p_cp_broker_id , cp_broker_id ),
                cp_client_contact_id     = api_nz( p_cp_client_contact_id , cp_client_contact_id ),
                cp_sso_identifier        = api_nz( p_cp_sso_identifier , cp_sso_identifier ),
                cp_customer_id           = api_nz( p_cp_customer_id , cp_customer_id ),
                cp_entity_type           = api_nz( p_cp_entity_type , cp_entity_type ),
                cp_user_id               = api_nz( p_cp_user_id , cp_user_id ),
                cp_member_id             = api_nz( p_cp_member_id , cp_member_id ),
                cp_allow_sso             = api_nz( p_cp_allow_sso , cp_allow_sso ),
                cp_tpa_user_is_active    = api_cbool( api_nz( p_cp_tpa_user_is_active , cp_tpa_user_is_active ) ),
                cp_member_user_is_active = api_cbool( api_nz( p_cp_member_user_is_active , cp_member_user_is_active ) ),
                cp_dob                   = api_nz( p_dob , cp_dob ),
                cp_ssn                   = api_nz( p_ssn , cp_ssn ),
                cp_email                 = api_nz( p_email , cp_email ),
                cp_row_id                = api_nz( p_cp_row_id , cp_row_id )
            WHERE
                (ssn <=> p_ssn);

            /* EXIT PROC*/
            LEAVE full_proc;
        END IF;
    END IF;

    /* upsert by email only if ssn is blank - else we will cause same email across 2 ssn - can combine across platforms - however CP users usually have their personal email recorded, not their work email*/
    IF api.api_is_blank( p_ssn ) AND !api.api_is_blank( p_email ) THEN

        -- see if we already have a record for this ssn
        SELECT
            count( * )
          , user_id
          , CASE
                WHEN is_verified OR is_ready_for_sso_processing THEN 1
                ELSE 0
            END INTO v_count, v_user_id, v_is_locked
        FROM
            api.platform_users
        WHERE
            (email <=> p_email);

        SET v_user_id = api.api_nz( v_user_id , '' );
        --
        CALL api.db_log_message( 'upsert_cp_platform_user' ,
                              CONCAT( v_count , ' Records found for EMAIL: ' , api.api_nz( p_email , '' ) ) , 'WARN' );

        IF api.api_cbool( v_user_id ) THEN
            --
            CALL api.db_log_message( 'upsert_cp_platform_user' ,
                                  CONCAT( 'UPDATING existing ' , v_count , ' records for EMAIL: ' ,
                                          api.api_nz( p_email , '' ) ) , 'WARN' );

            -- just update by ssn
            UPDATE api.platform_users
            SET
                user_name                = api_if_true_else( v_is_locked , user_name ,
                                                             api_nz( p_user_name , user_name ) ),
                first_name               = api_if_true_else( v_is_locked , first_name ,
                                                             api_nz( p_first_name , first_name ) ),
                last_name                = api_if_true_else( v_is_locked , last_name ,
                                                             api_nz( p_last_name , last_name ) ),
                email                    = api_if_true_else( v_is_locked , email , api_nz( p_email , email ) ),
                title                    = api_if_true_else( v_is_locked , title , api_nz( p_title , title ) ),
                mobile_number            = api_if_true_else( v_is_locked , mobile_number ,
                                                             api_nz( p_mobile_number , mobile_number ) ),
                ssn                      = api_if_true_else( v_is_locked , ssn , api_nz( p_ssn , ssn ) ),
                dob                      = api_if_true_else( v_is_locked , dob , api_nz( p_dob , dob ) ),
                employee_id              = api_if_true_else( v_is_locked , employee_id ,
                                                             api_nz( p_employee_id , employee_id ) ),
                alternate_email          = api_if_true_else( v_is_locked , alternate_email ,
                                                             api_nz( p_alternate_email , alternate_email ) ),
                cp_client_id             = api_nz( p_cp_client_id , cp_client_id ),
                cp_broker_id             = api_nz( p_cp_broker_id , cp_broker_id ),
                cp_client_contact_id     = api_nz( p_cp_client_contact_id , cp_client_contact_id ),
                cp_sso_identifier        = api_nz( p_cp_sso_identifier , cp_sso_identifier ),
                cp_customer_id           = api_nz( p_cp_customer_id , cp_customer_id ),
                cp_entity_type           = api_nz( p_cp_entity_type , cp_entity_type ),
                cp_user_id               = api_nz( p_cp_user_id , cp_user_id ),
                cp_member_id             = api_nz( p_cp_member_id , cp_member_id ),
                cp_allow_sso             = api_nz( p_cp_allow_sso , cp_allow_sso ),
                cp_tpa_user_is_active    = api_cbool( api_nz( p_cp_tpa_user_is_active , cp_tpa_user_is_active ) ),
                cp_member_user_is_active = api_cbool( api_nz( p_cp_member_user_is_active , cp_member_user_is_active ) ),
                cp_dob                   = api_nz( p_dob , cp_dob ),
                cp_ssn                   = api_nz( p_ssn , cp_ssn ),
                cp_email                 = api_nz( p_email , cp_email ),
                cp_row_id                = api_nz( p_cp_row_id , cp_row_id )
            WHERE
                (email <=> p_email);

            /* EXIT PROC*/
            LEAVE full_proc;
        END IF;
    END IF;

    /* check by unique keys for this platform*/
    IF !api.api_is_blank( p_cp_user_id ) THEN

        /* upsert by p_cp_sso_identifier and p_cp_user_id - can combine across subsequent loads of cp_users*/
        SELECT
            count( * )
          , user_id
          , CASE
                WHEN is_verified OR is_ready_for_sso_processing THEN 1
                ELSE 0
            END INTO v_count, v_user_id, v_is_locked
        FROM
            api.platform_users
        WHERE
            cp_user_id = p_cp_user_id;

        SET v_user_id = api.api_nz( v_user_id , '' );

        CALL api.db_log_message( 'upsert_cp_platform_user' ,
                              CONCAT( v_count , ' Records found for CP User_id: ' , api.api_nz( p_cp_user_id , '' ) ) ,
                              'WARN' );
        --
        IF api.api_cbool( v_user_id ) THEN
            CALL api.db_log_message( 'upsert_cp_platform_user' ,
                                  CONCAT( 'UPDATING existing ' , v_count , ' records for CP user_id: ' ,
                                          api.api_nz( p_cp_user_id , '' ) ) , 'WARN' );

            -- just update
            UPDATE api.platform_users
            SET
                user_name                = api_if_true_else( v_is_locked , user_name ,
                                                             api_nz( p_user_name , user_name ) ),
                first_name               = api_if_true_else( v_is_locked , first_name ,
                                                             api_nz( p_first_name , first_name ) ),
                last_name                = api_if_true_else( v_is_locked , last_name ,
                                                             api_nz( p_last_name , last_name ) ),
                email                    = api_if_true_else( v_is_locked , email , api_nz( p_email , email ) ),
                title                    = api_if_true_else( v_is_locked , title , api_nz( p_title , title ) ),
                mobile_number            = api_if_true_else( v_is_locked , mobile_number ,
                                                             api_nz( p_mobile_number , mobile_number ) ),
                ssn                      = api_if_true_else( v_is_locked , ssn , api_nz( p_ssn , ssn ) ),
                dob                      = api_if_true_else( v_is_locked , dob , api_nz( p_dob , dob ) ),
                employee_id              = api_if_true_else( v_is_locked , employee_id ,
                                                             api_nz( p_employee_id , employee_id ) ),
                alternate_email          = api_if_true_else( v_is_locked , alternate_email ,
                                                             api_nz( p_alternate_email , alternate_email ) ),
                cp_client_id             = api_nz( p_cp_client_id , cp_client_id ),
                cp_broker_id             = api_nz( p_cp_broker_id , cp_broker_id ),
                cp_client_contact_id     = api_nz( p_cp_client_contact_id , cp_client_contact_id ),
                cp_sso_identifier        = api_nz( p_cp_sso_identifier , cp_sso_identifier ),
                cp_customer_id           = api_nz( p_cp_customer_id , cp_customer_id ),
                cp_entity_type           = api_nz( p_cp_entity_type , cp_entity_type ),
                cp_user_id               = api_nz( p_cp_user_id , cp_user_id ),
                cp_member_id             = api_nz( p_cp_member_id , cp_member_id ),
                cp_allow_sso             = api_nz( p_cp_allow_sso , cp_allow_sso ),
                cp_tpa_user_is_active    = api_cbool( api_nz( p_cp_tpa_user_is_active , cp_tpa_user_is_active ) ),
                cp_member_user_is_active = api_cbool( api_nz( p_cp_member_user_is_active , cp_member_user_is_active ) ),
                cp_dob                   = api_nz( p_dob , cp_dob ),
                cp_ssn                   = api_nz( p_ssn , cp_ssn ),
                cp_email                 = api_nz( p_email , cp_email ),
                cp_row_id                = api_nz( p_cp_row_id , cp_row_id )
            WHERE
                cp_user_id = p_cp_user_id;

            /* EXIT PROC*/
            LEAVE full_proc;
        END IF;

    END IF;

    IF !api.api_is_blank( p_cp_sso_identifier ) THEN

        /* upsert by p_cp_sso_identifier and p_cp_user_id - can combine across subsequent loads of cp_users*/
        SELECT
            count( * )
          , user_id
          , CASE
                WHEN is_verified OR is_ready_for_sso_processing THEN 1
                ELSE 0
            END INTO v_count, v_user_id, v_is_locked
        FROM
            api.platform_users
        WHERE
            cp_sso_identifier = p_cp_sso_identifier;

        SET v_user_id = api.api_nz( v_user_id , '' );

        CALL api.db_log_message( 'upsert_cp_platform_user' , CONCAT( v_count , ' Records found for SSO ID: ' ,
                                                                  api.api_nz( p_cp_sso_identifier , '' ) ) , 'WARN' );
        --
        IF api.api_cbool( v_user_id ) THEN
            CALL api.db_log_message( 'upsert_cp_platform_user' ,
                                  CONCAT( 'UPDATING existing ' , v_count , ' records for SSO ID: ' ,
                                          api.api_nz( p_cp_sso_identifier , '' ) ) , 'WARN' );

            -- just update
            UPDATE api.platform_users
            SET
                user_name                = api_if_true_else( v_is_locked , user_name ,
                                                             api_nz( p_user_name , user_name ) ),
                first_name               = api_if_true_else( v_is_locked , first_name ,
                                                             api_nz( p_first_name , first_name ) ),
                last_name                = api_if_true_else( v_is_locked , last_name ,
                                                             api_nz( p_last_name , last_name ) ),
                email                    = api_if_true_else( v_is_locked , email , api_nz( p_email , email ) ),
                title                    = api_if_true_else( v_is_locked , title , api_nz( p_title , title ) ),
                mobile_number            = api_if_true_else( v_is_locked , mobile_number ,
                                                             api_nz( p_mobile_number , mobile_number ) ),
                ssn                      = api_if_true_else( v_is_locked , ssn , api_nz( p_ssn , ssn ) ),
                dob                      = api_if_true_else( v_is_locked , dob , api_nz( p_dob , dob ) ),
                employee_id              = api_if_true_else( v_is_locked , employee_id ,
                                                             api_nz( p_employee_id , employee_id ) ),
                alternate_email          = api_if_true_else( v_is_locked , alternate_email ,
                                                             api_nz( p_alternate_email , alternate_email ) ),
                cp_client_id             = api_nz( p_cp_client_id , cp_client_id ),
                cp_broker_id             = api_nz( p_cp_broker_id , cp_broker_id ),
                cp_client_contact_id     = api_nz( p_cp_client_contact_id , cp_client_contact_id ),
                cp_sso_identifier        = api_nz( p_cp_sso_identifier , cp_sso_identifier ),
                cp_customer_id           = api_nz( p_cp_customer_id , cp_customer_id ),
                cp_entity_type           = api_nz( p_cp_entity_type , cp_entity_type ),
                cp_user_id               = api_nz( p_cp_user_id , cp_user_id ),
                cp_member_id             = api_nz( p_cp_member_id , cp_member_id ),
                cp_allow_sso             = api_nz( p_cp_allow_sso , cp_allow_sso ),
                cp_tpa_user_is_active    = api_cbool( api_nz( p_cp_tpa_user_is_active , cp_tpa_user_is_active ) ),
                cp_member_user_is_active = api_cbool( api_nz( p_cp_member_user_is_active , cp_member_user_is_active ) ),
                cp_dob                   = api_nz( p_dob , cp_dob ),
                cp_ssn                   = api_nz( p_ssn , cp_ssn ),
                cp_email                 = api_nz( p_email , cp_email ),
                cp_row_id                = api_nz( p_cp_row_id , cp_row_id )
            WHERE
                cp_sso_identifier = p_cp_sso_identifier;

            /* EXIT PROC*/
            LEAVE full_proc;
        END IF;

    END IF;

    /* sumeet - we should not continue after this .... but left for uniformity*/

    /* upsert by any PK/UK violations across all inserted fields*/
    CALL api.db_log_message( 'upsert_cp_platform_user' ,
                          CONCAT( 'UPSERTING record for SSO ID: ' , api.api_nz( p_cp_sso_identifier , '' ) ,
                                  ' AND user_id: ' , api.api_nz( p_cp_user_id , '' ) ) , 'WARN' );

    INSERT INTO api.platform_users(
                                    user_name
                                  , first_name
                                  , last_name
                                  , email
                                  , title
                                  , mobile_number
                                  , cp_client_id
                                  , cp_broker_id
                                  , cp_client_contact_id
                                  , cp_sso_identifier
                                  , cp_customer_id
                                  , cp_entity_type
                                  , cp_user_id
                                  , cp_member_id
                                  , cp_allow_sso
                                  , cp_tpa_user_is_active
                                  , cp_member_user_is_active
                                  , ssn
                                  , dob
                                  , employee_id
                                  , alternate_email
                                  , cp_dob
                                  , cp_ssn
                                  , cp_email
                                  , cp_row_id
    )
    VALUES (
               p_user_name
           ,   p_first_name
           ,   p_last_name
           ,   p_email
           ,   p_title
           ,   p_mobile_number
           ,   p_cp_client_id
           ,   p_cp_broker_id
           ,   p_cp_client_contact_id
           ,   p_cp_sso_identifier
           ,   p_cp_customer_id
           ,   p_cp_entity_type
           ,   p_cp_user_id
           ,   p_cp_member_id
           ,   p_cp_allow_sso
           ,   api_cbool( p_cp_tpa_user_is_active )
           ,   api_cbool( p_cp_member_user_is_active )
           ,   p_ssn
           ,   p_dob
           ,   p_employee_id
           ,   p_alternate_email
           ,   p_dob
           ,   p_ssn
           ,   p_email
           ,   p_cp_row_id
           )
        /* use api_nz to avoid replacing previous value if new value is null or blank */
    ON DUPLICATE KEY UPDATE
                         user_name                = api_if_true_else( v_is_locked , user_name ,
                                                                      api_nz( p_user_name , user_name ) ),
                         first_name               = api_if_true_else( v_is_locked , first_name ,
                                                                      api_nz( p_first_name , first_name ) ),
                         last_name                = api_if_true_else( v_is_locked , last_name ,
                                                                      api_nz( p_last_name , last_name ) ),
                         email                    = api_if_true_else( v_is_locked , email , api_nz( p_email , email ) ),
                         title                    = api_if_true_else( v_is_locked , title , api_nz( p_title , title ) ),
                         mobile_number            = api_if_true_else( v_is_locked , mobile_number ,
                                                                      api_nz( p_mobile_number , mobile_number ) ),
                         ssn                      = api_if_true_else( v_is_locked , ssn , api_nz( p_ssn , ssn ) ),
                         dob                      = api_if_true_else( v_is_locked , dob , api_nz( p_dob , dob ) ),
                         employee_id              = api_if_true_else( v_is_locked , employee_id ,
                                                                      api_nz( p_employee_id , employee_id ) ),
                         alternate_email          = api_if_true_else( v_is_locked , alternate_email ,
                                                                      api_nz( p_alternate_email , alternate_email ) ),
                         cp_client_id             = api_nz( p_cp_client_id , cp_client_id ),
                         cp_broker_id             = api_nz( p_cp_broker_id , cp_broker_id ),
                         cp_client_contact_id     = api_nz( p_cp_client_contact_id , cp_client_contact_id ),
                         cp_sso_identifier        = api_nz( p_cp_sso_identifier , cp_sso_identifier ),
                         cp_customer_id           = api_nz( p_cp_customer_id , cp_customer_id ),
                         cp_entity_type           = api_nz( p_cp_entity_type , cp_entity_type ),
                         cp_user_id               = api_nz( p_cp_user_id , cp_user_id ),
                         cp_member_id             = api_nz( p_cp_member_id , cp_member_id ),
                         cp_allow_sso             = api_nz( p_cp_allow_sso , cp_allow_sso ),
                         cp_tpa_user_is_active    = api_cbool( api_nz( p_cp_tpa_user_is_active , cp_tpa_user_is_active ) ),
                         cp_member_user_is_active = api_cbool(
                                 api_nz( p_cp_member_user_is_active , cp_member_user_is_active ) ),
                         cp_dob                   = api_nz( p_dob , cp_dob ),
                         cp_ssn                   = api_nz( p_ssn , cp_ssn ),
                         cp_email                 = api_nz( p_email , cp_email ),
                         cp_row_id                = api_nz( p_cp_row_id , cp_row_id );

END;

