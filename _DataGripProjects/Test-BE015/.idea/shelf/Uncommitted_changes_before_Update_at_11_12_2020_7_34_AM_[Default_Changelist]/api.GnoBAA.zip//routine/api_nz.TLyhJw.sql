create
    definer = admin@`%` function api_nz(value varchar(200), valueifnullorempty varchar(200)) returns varchar(200)
BEGIN
  IF ifnull(
       trim(value)
      ,'') = ''
  THEN
    RETURN ifnull(valueIfNullOrEmpty, '');
  ELSE
    RETURN value;
  END IF;
END;

