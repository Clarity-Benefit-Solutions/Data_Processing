create
    definer = jitendra@`%` procedure api_get_employer_for_user(IN p_employer_ids varchar(200))
BEGIN

    --
   DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
        BEGIN
           GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
             CALL log_error(@errno, 'api_get_employer_for_user', @text, @sqlstate);
       END;

            SELECT distinct clientid,clientname,user_id,first_name,last_name
            , is_cp_particpant, is_cp_client, is_cp_broker, is_cp_tpa_admin
            , is_wc_particpant, is_wc_client, is_wc_broker, is_wc_tpa_admin
            , is_bs_particpant, is_bs_client, is_bs_broker, is_bs_tpa_admin
            FROM
            (
            -- fetch bs data
                SELECT cl.clientid,cl.clientname,vpu.user_id,vpu.first_name,vpu.last_name
                        , vpu.is_cp_particpant, vpu.is_cp_client, vpu.is_cp_broker, vpu.is_cp_tpa_admin
                        , vpu.is_wc_particpant, vpu.is_wc_client, vpu.is_wc_broker, vpu.is_wc_tpa_admin
                        , vpu.is_bs_particpant, vpu.is_bs_client, vpu.is_bs_broker, vpu.is_bs_tpa_admin
                FROM vw_platform_users vpu inner join bs.bs_employees b
                ON (vpu.bs_import_user_id=b.eeimportuserid) inner join cp.cp_client cl
                ON b.eeclientbencode = cl.clientalternate
                WHERE api_is_blank(vpu.bs_import_user_id) <> '1' and  vpu.is_active <> '0'
                            AND vpu.is_active <> '0' AND api_is_blank(vpu.email)='1'
                            AND vpu.is_invited <> '1'
            UNION
            -- fetch wc data
                SELECT   cl.clientid,cl.clientname,vpu.user_id,vpu.first_name,vpu.last_name
                        , vpu.is_cp_particpant, vpu.is_cp_client, vpu.is_cp_broker, vpu.is_cp_tpa_admin
                        , vpu.is_wc_particpant, vpu.is_wc_client, vpu.is_wc_broker, vpu.is_wc_tpa_admin
                        , vpu.is_bs_particpant, vpu.is_bs_client, vpu.is_bs_broker, vpu.is_bs_tpa_admin
                FROM vw_platform_users vpu inner join cp.cp_client cl
                ON vpu.wcp_employer_id = cl.clientalternate
                where api_is_blank(vpu.wcp_employer_id) <> '1'
                            AND vpu.is_active <> '0' AND api_is_blank(vpu.email)='1'
                            AND vpu.is_invited <> '1'
            UNION
            -- fetch cobra point data
                SELECT cl.clientid,cl.clientname,vpu.user_id,vpu.first_name,vpu.last_name
                        , vpu.is_cp_particpant, vpu.is_cp_client, vpu.is_cp_broker, vpu.is_cp_tpa_admin
                        , vpu.is_wc_particpant, vpu.is_wc_client, vpu.is_wc_broker, vpu.is_wc_tpa_admin
                        , vpu.is_bs_particpant, vpu.is_bs_client, vpu.is_bs_broker, vpu.is_bs_tpa_admin
                FROM vw_platform_users vpu INNER JOIN  cp.cp_client cl
                ON vpu.cp_client_id = cl.clientid
                WHERE vpu.is_active <> '0' AND api_is_blank(vpu.email)='1'
                            AND vpu.is_invited <> '1') u

            WHERE IF(p_employer_ids<>'All',find_in_set(u.clientid,p_employer_ids) ,1=1)
            GROUP BY u.clientid, u.clientname
            ORDER BY u.clientid, u.clientname;


END;

