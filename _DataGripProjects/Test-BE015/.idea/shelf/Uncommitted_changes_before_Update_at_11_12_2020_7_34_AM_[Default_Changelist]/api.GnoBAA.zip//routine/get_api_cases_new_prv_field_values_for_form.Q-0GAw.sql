create
    definer = admin@`%` procedure get_api_cases_new_prv_field_values_for_form(IN p_form_name varchar(100),
                                                                              IN p_row_id varchar(50),
                                                                              IN p_prv_version_no int,
                                                                              IN p_new_version_no int,
                                                                              IN p_only_if_changed int, OUT r_CSV text)
BEGIN
    DECLARE v_field_id varchar(100);
    DECLARE v_field_label varchar(100);
    DECLARE v_db_field_name varchar(100);
    DECLARE v_field_page_label varchar(100);
    DECLARE v_field_tooltip text;
    DECLARE v_finished int;

    DECLARE v_CSV text;
    DECLARE v_rowCsv text;

    DECLARE v_fields_cursor CURSOR FOR
        SELECT field_id,
               field_label,
               db_field_name,
               field_page_label,
               field_tooltip
        FROM api_form_fields
        WHERE form_name = p_form_name
          AND field_is_active = 1
        ORDER BY field_page_no, field_row_no, field_col_no;

    DECLARE CONTINUE HANDLER
        FOR NOT FOUND SET v_finished = 1;

    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
        BEGIN
            GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
            CALL db_log_error(@errno, 'get_api_cases_new_prv_field_values_for_form', @text, @sqlstate);
        END;

    -- header row
    SET v_CSV = CONCAT(QT(), 'Page Title', QT(), ',',
                       QT(), 'Field Title', QT(), ',',
                       QT(), 'Previous Value', QT(), ',',
                       QT(), 'New Value', QT(), ',',
                       QT(), 'Has Changed', QT(),
                       char(13), char(10));

    -- loop thru all fields
    OPEN v_fields_cursor;

    CALL api.db_log_message('get_api_cases_new_prv_field_values_for_form',
                            concat('Processing Form: ', p_form_name, ' , Field: ', v_field_label,
                                   ', prv version: ', p_prv_version_no, ', new version: ', p_new_version_no),
                            'INFO');
    getFields:
        LOOP
            FETCH v_fields_cursor INTO v_field_id,
                v_field_label,
                v_db_field_name,
                v_field_page_label,
                v_field_tooltip;
            --
            IF v_finished = 1 THEN
                LEAVE getFields;
            END IF;


            -- dump prv values for field into temp table
            CALL api.api_compare_api_cases_field_values(p_row_id, v_db_field_name, p_prv_version_no, p_new_version_no);

            -- get csv
            SET v_rowCsv =
                    api.get_api_cases_new_prv_field_value(
                            p_row_id, v_field_page_label, v_field_label, v_db_field_name, p_prv_version_no,
                            p_new_version_no, p_only_if_changed);
            --
            CALL api.db_log_message('get_api_cases_new_prv_field_values_for_form',
                                    concat(' -- Field: ', v_field_label, ' , DbField: ', v_db_field_name,
                                           ', CSV:', char(13), char(10), v_rowCsv),
                                    'INFO');


            -- if got blank data, there were no changes and p_only_if_changed was 1
            IF api_nz(v_rowCsv, '') <> '' THEN
                SET v_CSV = concat(v_CSV,
                                   v_rowCsv,
                                   char(13), char(10)
                    );
            END IF;
            --
        END LOOP getFields;


    SET r_CSV = v_CSV;

    SELECT r_CSV;

END;

