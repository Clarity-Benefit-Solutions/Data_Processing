create definer = admin@`%` trigger util_bi_api_cases_fix_fields
    before update
    on api_cases
    for each row
BEGIN
    if api.api_is_blank(new.legal_business_name) then
        set new.legal_business_name = new.employer_name;
    end if;
END;

