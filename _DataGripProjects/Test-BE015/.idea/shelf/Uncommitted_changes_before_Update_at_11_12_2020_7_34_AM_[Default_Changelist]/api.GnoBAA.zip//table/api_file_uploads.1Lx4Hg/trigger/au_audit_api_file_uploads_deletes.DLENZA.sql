create definer = admin@`%` trigger au_audit_api_file_uploads_deletes
    after delete
    on api_file_uploads
    for each row
    INSERT INTO `api`.`api_file_uploads_audit`
                 (`auditAction`, `case_id`, `uploaded_by_user_id`, `platform_name`, `platform_template_name`,
                  `file_status`, `file_name`, `checker_results`, `upload_results`, `upload_errors`, `created_at`,
                  `created_by`, `updated_at`, `updated_by`, `file_upload_id`, `sf_new_task_id`)
                 VALUES ('DELETE', OLD.`case_id`, OLD.`uploaded_by_user_id`, OLD.`platform_name`,
                         OLD.`platform_template_name`, OLD.`file_status`, OLD.`file_name`, OLD.`checker_results`,
                         OLD.`upload_results`, OLD.`upload_errors`, OLD.`created_at`, OLD.`created_by`,
                         OLD.`updated_at`, OLD.`updated_by`, OLD.`file_upload_id`, OLD.`sf_new_task_id`);

