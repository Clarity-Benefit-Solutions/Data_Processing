create definer = admin@`%` trigger au_audit_platform_users_deletes
    after delete
    on platform_users
    for each row
    INSERT INTO `api`.`platform_users_audit`
                 (`auditAction`, `user_id`, `user_name`, `first_name`, `last_name`, `email`, `alternate_email`, `title`,
                  `mobile_number`, `ssn`, `dob`, `employee_id`, `invite_token`, `is_invalid`,
                  `last_invite_token_sent_date`, `is_ready_for_sso_processing`, `is_invited`, `is_verified`,
                  `cp_row_id`, `cp_client_id`, `cp_broker_id`, `cp_client_contact_id`, `cp_sso_identifier`,
                  `cp_customer_id`, `cp_entity_type`, `cp_user_id`, `cp_tpa_user_is_active`, `cp_member_id`,
                  `cp_member_user_is_active`, `cp_allow_sso`, `cp_ssn`, `cp_email`, `cp_dob`, `wc_card_number`,
                  `wc_dob`, `wc_ssn`, `wc_email`, `wca_row_id`, `wca_tpa_id`, `wca_employer_id`, `wca_data_partner_id`,
                  `wca_client_user_id`, `wca_user_is_active`, `wcp_row_id`, `wcp_tpa_id`, `wcp_employer_id`,
                  `wcp_employee_id`, `wcp_user_is_active`, `bs_row_id`, `bs_abbrev_url`, `bs_user_id`,
                  `bs_import_user_id`, `bs_user_name`, `bs_user_is_active`, `bs_dob`, `bs_work_email`, `bs_payroll_id`,
                  `bs_ssn`, `bs_email`, `bs_employer_id`, `bs_is_employee`, `bs_is_manager`, `bs_is_topdog`, `en_email`,
                  `en_row_id`, `en_employee_id`, `en_employer_id`, `en_dob`, `en_ssn`, `en_user_is_active`,
                  `en_is_employee`, `en_is_manager`, `en_is_tpa_user`, `sf_email`, `sf_row_id`, `sf_employer_id`,
                  `sf_dob`, `sf_ssn`, `sf_user_is_active`, `sf_is_employee`, `sf_is_client`, `sf_is_broker`,
                  `created_at`, `created_by`, `updated_at`, `updated_by`, `email_error`)
                 VALUES ('DELETE', OLD.`user_id`, OLD.`user_name`, OLD.`first_name`, OLD.`last_name`, OLD.`email`,
                         OLD.`alternate_email`, OLD.`title`, OLD.`mobile_number`, OLD.`ssn`, OLD.`dob`,
                         OLD.`employee_id`, OLD.`invite_token`, OLD.`is_invalid`, OLD.`last_invite_token_sent_date`,
                         OLD.`is_ready_for_sso_processing`, OLD.`is_invited`, OLD.`is_verified`, OLD.`cp_row_id`,
                         OLD.`cp_client_id`, OLD.`cp_broker_id`, OLD.`cp_client_contact_id`, OLD.`cp_sso_identifier`,
                         OLD.`cp_customer_id`, OLD.`cp_entity_type`, OLD.`cp_user_id`, OLD.`cp_tpa_user_is_active`,
                         OLD.`cp_member_id`, OLD.`cp_member_user_is_active`, OLD.`cp_allow_sso`, OLD.`cp_ssn`,
                         OLD.`cp_email`, OLD.`cp_dob`, OLD.`wc_card_number`, OLD.`wc_dob`, OLD.`wc_ssn`, OLD.`wc_email`,
                         OLD.`wca_row_id`, OLD.`wca_tpa_id`, OLD.`wca_employer_id`, OLD.`wca_data_partner_id`,
                         OLD.`wca_client_user_id`, OLD.`wca_user_is_active`, OLD.`wcp_row_id`, OLD.`wcp_tpa_id`,
                         OLD.`wcp_employer_id`, OLD.`wcp_employee_id`, OLD.`wcp_user_is_active`, OLD.`bs_row_id`,
                         OLD.`bs_abbrev_url`, OLD.`bs_user_id`, OLD.`bs_import_user_id`, OLD.`bs_user_name`,
                         OLD.`bs_user_is_active`, OLD.`bs_dob`, OLD.`bs_work_email`, OLD.`bs_payroll_id`, OLD.`bs_ssn`,
                         OLD.`bs_email`, OLD.`bs_employer_id`, OLD.`bs_is_employee`, OLD.`bs_is_manager`,
                         OLD.`bs_is_topdog`, OLD.`en_email`, OLD.`en_row_id`, OLD.`en_employee_id`,
                         OLD.`en_employer_id`, OLD.`en_dob`, OLD.`en_ssn`, OLD.`en_user_is_active`,
                         OLD.`en_is_employee`, OLD.`en_is_manager`, OLD.`en_is_tpa_user`, OLD.`sf_email`,
                         OLD.`sf_row_id`, OLD.`sf_employer_id`, OLD.`sf_dob`, OLD.`sf_ssn`, OLD.`sf_user_is_active`,
                         OLD.`sf_is_employee`, OLD.`sf_is_client`, OLD.`sf_is_broker`, OLD.`created_at`,
                         OLD.`created_by`, OLD.`updated_at`, OLD.`updated_by`, OLD.`email_error`);

