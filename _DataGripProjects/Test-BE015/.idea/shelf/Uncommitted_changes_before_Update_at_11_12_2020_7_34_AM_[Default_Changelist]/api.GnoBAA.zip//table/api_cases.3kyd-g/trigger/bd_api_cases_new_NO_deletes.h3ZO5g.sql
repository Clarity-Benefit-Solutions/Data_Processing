create definer = admin@`%` trigger bd_api_cases_new_NO_deletes
    before delete
    on api_cases
    for each row
BEGIN
   -- CALL api.db_throw_error(50001, 'api.bd_api_cases_new_NO_deletes', 'Cannot delete records from api.api_cases_new');
END;

