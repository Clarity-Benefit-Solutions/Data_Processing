create definer = admin@`%` trigger au_audit_api_case_plan_cobra_divisions_deletes
    after delete
    on api_case_plan_cobra_divisions
    for each row
    INSERT INTO `api`.`api_case_plan_cobra_divisions_audit`
                 (`auditAction`, `case_plan_division_id`, `case_plan_id`, `status`, `version_no`, `division_sort_order`,
                  `division_name`, `created_at`, `created_by`, `updated_at`, `updated_by`)
                 VALUES ('DELETE', OLD.`case_plan_division_id`, OLD.`case_plan_id`, OLD.`status`, OLD.`version_no`,
                         OLD.`division_sort_order`, OLD.`division_name`, OLD.`created_at`, OLD.`created_by`,
                         OLD.`updated_at`, OLD.`updated_by`);

