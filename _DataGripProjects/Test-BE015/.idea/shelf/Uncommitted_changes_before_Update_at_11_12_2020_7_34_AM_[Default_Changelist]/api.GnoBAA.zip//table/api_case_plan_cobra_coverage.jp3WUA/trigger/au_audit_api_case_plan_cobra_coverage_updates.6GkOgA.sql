create definer = admin@`%` trigger au_audit_api_case_plan_cobra_coverage_updates
    after update
    on api_case_plan_cobra_coverage
    for each row
    INSERT INTO `api`.`api_case_plan_cobra_coverage_audit`
                 (`auditAction`, `case_plan_coverage_id`, `case_plan_id`, `status`, `version_no`, `ben_term_type`,
                  `plan_coverage_level`, `plan_coverage_level_is_new`, `plan_coverage_level_order`,
                  `pct_100_rate_for_coverage_level`, `new_pct_100_rate_for_coverage_level`, `created_at`, `created_by`,
                  `updated_at`, `updated_by`)
                 VALUES ('UPDATE', NEW.`case_plan_coverage_id`, NEW.`case_plan_id`, NEW.`status`, NEW.`version_no`,
                         NEW.`ben_term_type`, NEW.`plan_coverage_level`, NEW.`plan_coverage_level_is_new`,
                         NEW.`plan_coverage_level_order`, NEW.`pct_100_rate_for_coverage_level`,
                         NEW.`new_pct_100_rate_for_coverage_level`, NEW.`created_at`, NEW.`created_by`,
                         NEW.`updated_at`, NEW.`updated_by`);

