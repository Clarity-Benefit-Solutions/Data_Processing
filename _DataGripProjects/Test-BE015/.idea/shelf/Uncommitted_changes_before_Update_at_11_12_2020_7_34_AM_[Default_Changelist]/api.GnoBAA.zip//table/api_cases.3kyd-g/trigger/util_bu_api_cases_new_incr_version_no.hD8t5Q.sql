create definer = admin@`%` trigger util_bu_api_cases_new_incr_version_no
    before update
    on api_cases
    for each row
BEGIN
    -- incr only if case status changes - this ensure version no will remain 0 = baseline till status is changed from New to something else
    IF api.api_nz(new.case_status, '') <> api.api_nz(old.case_status, '') THEN
        SET new.version_no = api.api_nz(new.version_no, 0) + 1;
    END IF;

    -- incr only if case status changes - this ensure version no will remain 0 = baseline till status is changed from New to something else
    IF new.case_status IN ('New', 'Client Notified', 'In Progress', 'Contact Changed') THEN
        SET new.wizard_curr_step_no = 1;
    END IF;


END;

