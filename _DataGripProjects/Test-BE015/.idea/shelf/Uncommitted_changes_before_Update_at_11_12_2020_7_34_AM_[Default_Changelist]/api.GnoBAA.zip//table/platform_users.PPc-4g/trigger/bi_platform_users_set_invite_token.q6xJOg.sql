create definer = admin@`%` trigger bi_platform_users_set_invite_token
    before insert
    on platform_users
    for each row
BEGIN
    if api.api_is_blank(new.invite_token) then
        SET new.invite_token = api.api_uuid();
    end if;

    set new.user_name = lower(new.email);
END;

