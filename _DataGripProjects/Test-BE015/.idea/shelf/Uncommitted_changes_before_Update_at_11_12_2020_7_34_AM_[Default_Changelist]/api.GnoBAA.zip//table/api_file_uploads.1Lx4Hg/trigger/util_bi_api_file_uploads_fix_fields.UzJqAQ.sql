create definer = admin@`%` trigger util_bi_api_file_uploads_fix_fields
    before update
    on api_file_uploads
    for each row
BEGIN
   /* if api.api_is_blank(new.legal_business_name) then
        set new.legal_business_name = new.employer_name;
    end if;*/
   IF api.api_is_blank(new.row_id) THEN
       SET new.row_id = api.api_uuid();
   END IF;
END;

