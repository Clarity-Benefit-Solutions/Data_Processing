create
    definer = root@`%` function get_cp_registration_code( p_row_id varchar(50) ) returns varchar(100)
BEGIN
    
    DECLARE v_ret varchar(100) DEFAULT '';
    
    SET p_row_id = api.api_cint( p_row_id );
    IF p_row_id <= 0 THEN
        RETURN '';
    END IF;
    
    SELECT
        registrationcode
    INTO v_ret
    FROM
        cp.cp_all_sso_users
    WHERE
        row_id = p_row_id;
    
    RETURN api.api_nz( v_ret , '' );
END;

