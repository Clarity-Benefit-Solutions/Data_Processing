create
    definer = root@`%` function get_cases_forms_covide2021infofieldvalue(
                                                                        p_item_key varchar(50),
                                                                        p_field_key varchar(50) ) returns varchar(200)
begin
    declare v_ret varchar(200) default '';
    select
        
        
        
        
        api.api_title_case(
                replace( substr( m.meta_value , 1 , position( '</b>' in m.meta_value ) - 1 ) , '<b>' , '' ) )
    into v_ret
        
        
    from
        portal.cl_frm_items i
            inner join portal.cl_frm_item_metas m on i.id = m.item_id
            inner join portal.cl_frm_fields f on m.field_id = f.id
    where
          i.form_id = 274
      and f.field_key like p_field_key
      and i.item_key = p_item_key
    order by
        f.updated_at desc
    limit 1;
    
    return v_ret;

end;

