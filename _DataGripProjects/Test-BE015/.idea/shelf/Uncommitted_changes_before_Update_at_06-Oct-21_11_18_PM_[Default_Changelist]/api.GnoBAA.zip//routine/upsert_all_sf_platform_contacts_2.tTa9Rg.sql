create
    definer = root@`%` procedure upsert_all_sf_platform_contacts_2( IN p_email varchar(200) )
full_proc:

BEGIN
    DECLARE v_email varchar(200);
    DECLARE v_is_active varchar(200);
    DECLARE v_user_type varchar(200);
    
    DECLARE v_row_id varchar(200);
    DECLARE v_entitytype varchar(200);
    DECLARE v_clientcode varchar(200);
    DECLARE v_clientname varchar(200);
    DECLARE v_fullname varchar(200);
    DECLARE v_ssn varchar(200);
    DECLARE v_contactid varchar(200);
    DECLARE v_contactstatus varchar(200);
    DECLARE v_is_in_wc varchar(200);
    DECLARE v_is_in_cp varchar(200);
    DECLARE v_is_in_bs varchar(200);
    DECLARE v_is_in_en varchar(200);
    DECLARE v_phone varchar(200);
    DECLARE v_employeeid varchar(200);
    DECLARE v_isprimarycontact varchar(200);
    DECLARE v_created_at varchar(200);
    DECLARE v_created_by varchar(200);
    DECLARE v_updated_at varchar(200);
    DECLARE v_updated_by varchar(200);
    
    DECLARE v_client_has_enav_plan int;
    
    DECLARE v_finished int;
    DECLARE v_values_cursor CURSOR FOR SELECT
                                           email
                                         , is_active
                                         , user_type
                                         , row_id
                                         , entitytype
                                         , clientcode
                                         , clientname
                                         , fullname
                                         , ssn
                                         , contactid
                                         , contactstatus
                                         , is_in_wc
                                         , is_in_cp
                                         , is_in_bs
                                         , is_in_en
                                         , phone
                                         , employeeid
                                         , isprimarycontact
                                         , created_at
                                         , created_by
                                         , updated_at
                                         , updated_by
                                       FROM
                                           sf.vw_sf_contacts t
                                       WHERE
                                           email = p_email
                                       ORDER BY
                                           email
                                         , user_type DESC
                                         , is_active DESC
                                         , isprimarycontact DESC
                                       LIMIT 1;
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND BEGIN
        SET v_finished = 1;
    END;
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN
        GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
        CALL db_throw_error( @errno , 'upsert_all_sf_platform_contacts_1' , @text );
    END;
    
    SET @@max_sp_recursion_depth = 12;
    
    OPEN v_values_cursor;
    
    getvalues
    :
    LOOP
        FETCH v_values_cursor INTO v_email, v_is_active, v_user_type , v_row_id , v_entitytype , v_clientcode , v_clientname , v_fullname , v_ssn , v_contactid , v_contactstatus , v_is_in_wc , v_is_in_cp , v_is_in_bs , v_is_in_en , v_phone , v_employeeid , v_isprimarycontact , v_created_at , v_created_by , v_updated_at , v_updated_by;
        
        IF v_finished = 1 THEN
            LEAVE getvalues;
        END IF;
        
        IF !api.api_is_blank( v_email ) THEN
            CALL api.db_log_message( 'upsert_all_sf_platform_contacts_2' ,
                                     CONCAT( 'Processing SF user for email: ' , p_email ,
                                             ' using record with row_id  ' , v_row_id , ' Full name: ' , v_fullname ,
                                             ' and user_type ' , v_user_type ) , 'WARN' );
            
            SELECT
                COUNT( * )
            INTO v_client_has_enav_plan
            FROM
                sf.sf_account_plans
            WHERE
                  clientcode = v_clientcode
              AND platform LIKE 'ENav%'
              AND planyear = 'Current'
              AND productstatus = 'Current';
            
            IF v_client_has_enav_plan > 0 THEN
                SET v_is_in_en = 1;
            END IF;
            
            CALL api.upsert_sf_platform_user( v_email , v_email , api.api_get_first_name_from_fullname( v_fullname ) ,
                                              api.api_get_last_name_from_fullname( v_fullname ) , v_phone , v_ssn ,
                                              v_employeeid , NULL , v_is_active , v_user_type LIKE '%EMPLOYEE%' ,
                                              v_user_type LIKE '%CLIENT%' , v_user_type LIKE '%BROKER%' , v_row_id ,
                                              v_clientcode , v_is_in_bs , v_is_in_cp , v_is_in_en , v_is_in_wc );
        END IF;
    END LOOP getvalues;
END;

