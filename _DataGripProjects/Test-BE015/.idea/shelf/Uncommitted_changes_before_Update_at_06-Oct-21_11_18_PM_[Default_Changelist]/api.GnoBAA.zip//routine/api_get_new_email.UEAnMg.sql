CREATE
    DEFINER = root@`%` FUNCTION api_get_new_email(
                                                 p_attempt_type varchar(200),
                                                 p_search_for varchar(200),
                                                 p_replace_with varchar(200),
                                                 p_prv_email varchar(200),
                                                 p_new_email varchar(200) ) RETURNS varchar(200)
BEGIN
    IF p_attempt_type = 'CHANGE-EMAIL' THEN
        RETURN p_new_email;
    END IF;
    
    IF p_attempt_type = 'CHANGE-DOMAIN' THEN
        RETURN p_prv_email;
    END IF;

END;

