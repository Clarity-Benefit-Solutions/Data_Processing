create
    definer = root@`%` function get_registration_invite_count( p_email varchar(200) ) returns int
BEGIN
    RETURN api.get_notification_log_count( p_email , 'email' , 'Registration' , '%' );
END;

