create
    definer = root@`%` function api_cdate( value varchar(200) ) returns date
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
            
            CALL api.db_log_error( @errno , 'api_cdate' , @text , @`sqlstate` );
            
            RETURN NULL;
        END;
    
    IF api.api_is_blank( value ) THEN
        RETURN NULL;
    END IF;
    
    
    SET value = api.api_split_str( value , ' ' , 1 );
    
    
    RETURN CAST( value AS date );

END;

