CREATE
    DEFINER = root@`%` PROCEDURE register_participant_internal(
                                                              IN p_invite_token varchar(200),
                                                              IN p_email varchar(200),
                                                              IN p_first_name varchar(200),
                                                              IN p_last_name varchar(200),
                                                              IN p_mobile_number varchar(200),
                                                              IN p_ssn varchar(200),
                                                              IN p_employer_id varchar(200),
                                                              IN p_employee_id varchar(200),
                                                              IN p_dob varchar(200),
                                                              IN p_zip varchar(200),
                                                              IN p_card_number varchar(200),
                                                              IN p_ignore_email_mismatch int,
                                                              IN p_make_changes int,
                                                              IN v_matched_user_id int,
                                                              IN v_matched_row_ids text,
                                                              IN v_internal_messages text,
                                                              IN v_user_messages text,
                                                              IN v_status varchar(200),
                                                              IN v_email_status longtext )
full_proc:

BEGIN
    DECLARE v_invite_token varchar(50) DEFAULT NULL;
    DECLARE v_user_id int DEFAULT NULL;
    DECLARE v_platform_row_id int DEFAULT NULL;
    DECLARE v_is_locked int DEFAULT NULL;
    DECLARE v_is_verified int DEFAULT NULL;
    DECLARE v_is_invalid int DEFAULT NULL;
    DECLARE v_no_of_matches int DEFAULT 0;
    DECLARE v_email varchar(200);
    DECLARE v_has_email_mismatch int DEFAULT 0;
    DECLARE v_message longtext;
    DECLARE v_first_name varchar(200);
    DECLARE v_last_name varchar(200);
    DECLARE v_mobile_number varchar(200);
    DECLARE v_employee_id varchar(200);
    DECLARE v_dob varchar(200);
    #
    DECLARE v_bs_dob varchar(200);
    DECLARE v_cp_dob varchar(200);
    DECLARE v_en_dob varchar(200);
    DECLARE v_wc_dob varchar(200);
    #
    DECLARE v_bs_email varchar(200);
    DECLARE v_cp_email varchar(200);
    DECLARE v_en_email varchar(200);
    DECLARE v_wc_email varchar(200);
    #
    DECLARE v_bs_employer_id varchar(200);
    DECLARE v_wcp_employer_id varchar(200);
    DECLARE v_employer_id varchar(200);
    #
    DECLARE v_ssn varchar(200);
    DECLARE v_bs_ssn varchar(200);
    DECLARE v_cp_ssn varchar(200);
    DECLARE v_en_ssn varchar(200);
    DECLARE v_wc_ssn varchar(200);
    #
    DECLARE v_zip varchar(200);
    DECLARE v_bs_zip varchar(200);
    DECLARE v_cp_zip varchar(200);
    DECLARE v_en_zip varchar(200);
    DECLARE v_wc_zip varchar(200);
    #
    DECLARE v_wc_card_number varchar(200);
    DECLARE v_wcp_employee_id varchar(200);
    DECLARE v_matches varchar(1000) DEFAULT '';
    
    DECLARE v_default_isolation_level varchar(200) DEFAULT 'READ-COMMITTED';
    DECLARE v_prc_isolation_level varchar(200) DEFAULT 'READ-UNCOMMITTED';
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN
        GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
        /* for debugging*/
        IF api.api_is_blank( v_status ) THEN
            SET v_status = 'FAILED';
        ELSE
            SET v_status = CONCAT( 'FAILED' , ': ' , v_status );
        END IF;
        SET v_matched_user_id = 0;
        
        /**/
        CALL api.register_participant_log_attempt( p_invite_token ,
                                                   p_email ,
                                                   p_first_name ,
                                                   p_last_name ,
                                                   p_mobile_number ,
                                                   p_ssn ,
                                                   p_employer_id ,
                                                   p_employee_id ,
                                                   p_dob ,
                                                   p_zip ,
                                                   p_card_number , p_ignore_email_mismatch ,
                                                   v_matched_user_id ,
                                                   v_matched_row_ids ,
                                                   v_internal_messages ,
                                                   v_user_messages ,
                                                   v_status ,
                                                   v_email_status ,
                                                   @text );
        
        /* dont throw error so caller can examine details of matches/nomatches*/
        /*   call api.db_throw_error( 50001 , 'register_participant' , @text );*/
    END;
    
    /* sumeet: 2021-04-02 to prevent  Lock wait timeout exceeded; try restarting transaction which happens frequentlym, we have set global [mysqld]
           transaction-isolation = READ-COMMITTED
           and we also set this update to use a potentially dirty row by using
           SET tx_isolation = 'READ-UNCOMMITTED';
    
        */
    SET tx_isolation = v_prc_isolation_level;
    
    /* sumeet - force ignore email mismatch */
    SET p_ignore_email_mismatch = 1;
    /**/
    SET p_email = api.api_fix_email( p_email );
    SET p_mobile_number = api.api_fix_phone_number( p_mobile_number );
    SET p_ssn = api.api_fix_ssn( p_ssn );
    SET p_dob = api.api_fix_date( p_dob );
    SET p_ignore_email_mismatch = api.api_nz_int( p_ignore_email_mismatch , 0 );
    /*    */
    SET v_matched_user_id = 0;
    SET v_matched_row_ids = '';
    SET v_internal_messages = '';
    SET v_user_messages = '';
    SET v_email_status = '';
    
    /**/
    CALL api.db_log_message( 'register_participant' ,
                             CONCAT( 'Processing user for '
                                 , ' p_email: ' , api.api_nz( p_email , '' )
                                 , ' p_first_name: ' , api.api_nz( p_first_name , '' )
                                 , ' p_last_name: ' , api.api_nz( p_last_name , '' )
                                 , ' p_ssn: ' , api.api_nz( p_ssn , '' )
                                 , ' p_employee_id: ' , api.api_nz( p_employee_id , '' )
                                 , ' p_employer_id: ' , api.api_nz( p_employer_id , '' )
                                 , ' p_dob: ' , api.api_nz( p_dob , '' )
                                 , ' p_zip: ' , api.api_nz( p_zip , '' )
                                 , ' p_card_number: ' , api.api_nz( p_card_number , '' )
                                 , ' p_ignore_email_mismatch: ' , api.api_nz( p_ignore_email_mismatch , '' )
                                 , ' p_mobile_number: ' , api.api_nz( p_mobile_number , '' )
                                 ) , 'WARN' );
    
    /*email MUST be passed*/
    IF api.api_is_blank( p_email ) THEN
        CALL db_throw_error( 50001 , 'register_participant' , 'EMAIL_IS_BLANK: Email cannot be blank' );
    END IF;
    
    /* do we have a record in platform_users for the email?*/
    SELECT
        user_id
      , is_verified
      , is_invalid
      , email
      , invite_token
      , first_name
      , last_name
      , mobile_number
      , employee_id
      , dob
      , bs_dob
      , cp_dob
      , en_dob
      , wc_dob
        #
      , bs_email
      , cp_email
      , en_email
      , wc_email
        #
      , bs_employer_id
      , wcp_employer_id
        #
      , ssn
      , bs_ssn
      , cp_ssn
      , en_ssn
      , wc_ssn
        #
      , zip
      , bs_zip
      , cp_zip
      , en_zip
      , wc_zip
    INTO v_user_id
        , v_is_verified
        , v_is_invalid
        , v_email
        , v_invite_token
        , v_first_name
        , v_last_name
        , v_mobile_number
        , v_employee_id
        , v_dob
        , v_bs_dob
        , v_cp_dob
        , v_en_dob
        , v_wc_dob
        #
        , v_bs_email
        , v_cp_email
        , v_en_email
        , v_wc_email
        #
        , v_bs_employer_id
        , v_wcp_employer_id
        #
        , v_ssn
        , v_bs_ssn
        , v_cp_ssn
        , v_en_ssn
        , v_wc_ssn
        #
        , v_zip
        , v_bs_zip
        , v_cp_zip
        , v_en_zip
        , v_wc_zip
    FROM
        api.platform_users
    WHERE
        CASE
            WHEN NOT api.api_is_blank( p_invite_token ) THEN invite_token = p_invite_token
            ELSE email = p_email
        END
    LIMIT 1;
    
    #      select
    #          p_email
    #        , v_user_id;
    
    /* do we have a record?*/
    IF api.api_nz_int( v_user_id , 0 ) > 0 THEN
        /**/
        CALL api.db_log_message( 'register_participant' ,
                                 CONCAT( 'Found existing user id  ' , v_user_id
                                     , 'For p_email: ' , p_email
                                     ) , 'WARN' );
        /**/
        IF v_is_verified THEN
            SET v_status = 'ALREADY_REGISTERED';
            /*already registered, throw error */
            CALL api.db_throw_error( 50001 , 'register_participant' ,
                                     CONCAT( 'ALREADY_REGISTERED: Sorry, a user with email: ' , p_email ,
                                             ' is already registered' ) );
        END IF;
        
        IF v_is_invalid THEN
            SET v_status = 'USER_IS_MARKED_AS_INVALID';
            /*invalid, throw error */
            CALL api.db_throw_error( 50001 , 'register_participant' ,
                                     CONCAT( 'USER_IS_MARKED_AS_INVALID: Sorry, your account with email: ' ,
                                             p_email ,
                                             ' is marked as invalid' ) );
        END IF;
        
        /* check email and token match*/
        IF !api.api_is_blank( p_invite_token ) AND p_email <> v_email THEN
            SET v_status = 'TOKEN_EMAIL_MISMATCH';
            /*already registered, throw error */
            CALL api.db_throw_error( 50001 , 'register_participant' ,
                                     CONCAT( 'TOKEN_EMAIL_MISMATCH: Sorry, your account with invite_token : ' ,
                                             p_invite_token ,
                                             ' is associated with email ' , v_email , ' instead of the passed ' ,
                                             p_email ) );
        END IF;
        
        /* try the matches */
        /*invitetoken OR email */
        IF (!api.api_is_blank( p_invite_token ) AND
            (p_invite_token = v_invite_token)) THEN
            SET v_no_of_matches = v_no_of_matches + 1;
            SET v_matches =
                    CONCAT( v_matches , 'platform_users: invite_token ' , p_invite_token , ' -> MATCHED' ,
                            CHAR( 13 ) );
        ELSEIF (!api.api_is_blank( p_email ) AND
                (p_email = v_email)) THEN
            SET v_no_of_matches = v_no_of_matches + 1;
            SET v_matches = CONCAT( v_matches , 'platform_users: email ' , p_email , ' -> MATCHED' , CHAR( 13 ) );
        ELSE
            SET v_matches = CONCAT( v_matches , 'platform_users: email ' , p_dob , ' -> NO match' , CHAR( 13 ) );
        END IF;
        
        /* dob*/
        IF (!api.api_is_blank( p_dob ) AND
            (p_dob = api.api_fix_date( v_dob ) OR p_dob = api.api_fix_date( v_bs_dob ) OR
             p_dob = api.api_fix_date( v_cp_dob ) OR p_dob = api.api_fix_date( v_en_dob ) OR
             p_dob = api.api_fix_date( v_wc_dob ))
            ) THEN
            SET v_no_of_matches = v_no_of_matches + 1;
            SET v_matches = CONCAT( v_matches , 'platform_users: DOB ' , p_dob , ' -> MATCHED' , CHAR( 13 ) );
        ELSE
            SET v_matches = CONCAT( v_matches , 'platform_users: DOB ' , p_dob , ' -> NO match' , CHAR( 13 ) );
        END IF;
        
        /* ssn or last 4 of ssn*/
        IF (!api.api_is_blank( p_ssn ) AND
            (
                /**/
                    p_ssn = v_ssn OR p_ssn = v_bs_ssn OR p_ssn = v_cp_ssn OR p_ssn = v_en_ssn OR p_ssn = v_wc_ssn
                    /**/
                    OR RIGHT( p_ssn , 4 ) = RIGHT( v_ssn , 4 ) OR RIGHT( p_ssn , 4 ) = RIGHT( v_bs_ssn , 4 ) OR
                    RIGHT( p_ssn , 4 ) = RIGHT( v_cp_ssn , 4 ) OR RIGHT( p_ssn , 4 ) = RIGHT( v_en_ssn , 4 ) OR
                    RIGHT( p_ssn , 4 ) = RIGHT( v_wc_ssn , 4 ))) THEN
            SET v_no_of_matches = v_no_of_matches + 1;
            SET v_matches = CONCAT( v_matches , 'platform_users: SSN ' , p_ssn , ' -> MATCHED' , CHAR( 13 ) );
        ELSE
            SET v_matches = CONCAT( v_matches , 'platform_users: SSN ' , p_dob , ' -> NO match' , CHAR( 13 ) );
        END IF;
        
        /* zip or first 5 of zip*/
        IF (!api.api_is_blank( p_zip ) AND
            (
                /**/
                    p_zip = v_zip OR p_zip = v_bs_zip OR p_zip = v_cp_zip OR p_zip = v_en_zip OR p_zip = v_wc_zip
                    /**/
                    OR LEFT( p_zip , 5 ) = LEFT( v_zip , 5 ) OR LEFT( p_zip , 5 ) = LEFT( v_bs_zip , 5 ) OR
                    LEFT( p_zip , 5 ) = LEFT( v_cp_zip , 5 ) OR LEFT( p_zip , 5 ) = LEFT( v_en_zip , 5 ) OR
                    LEFT( p_zip , 5 ) = LEFT( v_wc_zip , 5 ))) THEN
            SET v_no_of_matches = v_no_of_matches + 1;
            SET v_matches = CONCAT( v_matches , 'platform_users: zip ' , p_zip , ' -> MATCHED' , CHAR( 13 ) );
        ELSE
            SET v_matches = CONCAT( v_matches , 'platform_users: zip ' , p_dob , ' -> NO match' , CHAR( 13 ) );
        END IF;
        
        /* p_card_number or last 4 of p_card_number*/
        IF (!api.api_is_blank( p_card_number ) AND
            (
                /**/
                    p_card_number = v_wc_card_number
                    /**/
                    OR RIGHT( p_card_number , 4 ) = RIGHT( v_wc_card_number , 4 ))) THEN
            SET v_no_of_matches = v_no_of_matches + 1;
            SET v_matches =
                    CONCAT( v_matches , 'platform_users: cardnum ' , p_card_number , ' -> MATCHED' , CHAR( 13 ) );
        ELSE
            SET v_matches = CONCAT( v_matches , 'platform_users: cardnum ' , p_dob , ' -> NO match' , CHAR( 13 ) );
        END IF;
        
        #         /* employer id*/
        #         if (!api.api_is_blank( p_employer_id ) and
        #             (p_employer_id = v_employer_id or p_employer_id = v_wcp_employer_id)) then
        #             set v_no_of_matches = v_no_of_matches + 1;
        #             set v_matches = concat( v_matches , 'employer_id ' , p_employer_id , ' -> MATCHED' , char( 13 ) );
        #         end if;
        
        #         /* employee_id or last 4 of employee_id*/
        #         if (!api.api_is_blank( p_employee_id ) and
        #             (
        #                 /**/
        #                     p_employee_id = v_employee_id or p_employee_id = v_wcp_employee_id
        #                     /**/
        #                     or right( p_employee_id , 4 ) = right( v_employee_id , 4 ) or
        #                     right( p_employee_id , 4 ) = right( v_wcp_employee_id , 4 ))) then
        #             set v_no_of_matches = v_no_of_matches + 1;
        #             set v_matches = concat( v_matches , 'employee_id ' , p_employee_id , ' -> MATCHED' , char( 13 ) );
        #         end if;
        
        #         select
        #             p_email
        #           , v_user_id
        #           , v_no_of_matches
        #           , v_matches;
        
        /* if matched enough great!*/
        IF v_no_of_matches >= 3 THEN
            SET v_internal_messages =
                    CONCAT( v_internal_messages , 'register_participant: ' , 'Matched existing user id  ' ,
                            v_user_id
                        , ' For p_email: ' , p_email
                        , ' match count: ' , v_no_of_matches
                        , CHAR( 13 ) );
            /**/
            CALL api.db_log_message( 'register_participant' ,
                                     CONCAT( 'Matched existing user id  ' , v_user_id
                                         , ' For p_email: ' , p_email
                                         , ' match count: ' , v_no_of_matches
                                         ) , 'WARN' );
            /**/
            SET v_matched_user_id = v_user_id;
        ELSE
            SET v_internal_messages =
                    CONCAT( v_internal_messages , 'register_participant: ' , 'NO MATCH existing user id  '
                        , ' For p_email: ' , p_email
                        , ' match count: ' , v_no_of_matches
                        , CHAR( 13 )
                        );
            
            CALL api.db_log_message( 'register_participant' ,
                                     CONCAT( 'NO MATCH existing user id  '
                                         , ' For p_email: ' , p_email
                                         , ' match count: ' , v_no_of_matches ) , 'WARN' );
        
        END IF;
        
        /* no such email in platform_users*/
    END IF;
    /*if v_user_id > 0 then*/
    
    /**/
    SET v_matched_user_id = 0;
    
    /* detect and usert matches from platforms where email was not aggregated*/
    CALL api.register_participant_no_email( p_invite_token ,
                                            p_email ,
                                            p_first_name ,
                                            p_last_name ,
                                            p_mobile_number ,
                                            p_ssn ,
                                            p_employer_id ,
                                            p_employee_id ,
                                            p_dob ,
                                            p_zip ,
                                            p_card_number , p_ignore_email_mismatch ,
                                            v_matched_user_id ,
                                            v_matched_row_ids ,
                                            v_internal_messages ,
                                            v_user_messages , v_status , v_email_status );
    
    /**/
    SET v_matched_user_id = api.api_nz_int( v_matched_user_id , 0 );
    
    /* if we have a match and either ignore diff email or dont have that email mismtach status*/
    IF v_matched_user_id > 0 AND
       (p_ignore_email_mismatch OR v_email_status NOT LIKE '%EMAIL_DIFFERENT_ON_PLATFORM%') THEN
        /**/
        SET v_status = 'SUCCESS';
        IF api.api_is_blank( v_email_status ) THEN
            SET v_email_status = 'SUCCESS';
        END IF;
        
        /**/
        CALL api.register_participant_log_attempt( p_invite_token ,
                                                   p_email ,
                                                   p_first_name ,
                                                   p_last_name ,
                                                   p_mobile_number ,
                                                   p_ssn ,
                                                   p_employer_id ,
                                                   p_employee_id ,
                                                   p_dob ,
                                                   p_zip ,
                                                   p_card_number , p_ignore_email_mismatch ,
                                                   v_matched_user_id ,
                                                   v_matched_row_ids ,
                                                   v_internal_messages ,
                                                   v_user_messages ,
                                                   v_status ,
                                                   v_email_status ,
                                                   '' );
        #
        SET tx_isolation = v_default_isolation_level;
        #
        LEAVE full_proc;
    
    ELSE /* there was an error */
        IF v_email_status LIKE '%EMAIL_DIFFERENT_ON_PLATFORM%' THEN
            SET v_status = 'EMAIL_DIFFERENT_ON_PLATFORM';
        ELSE
            SET v_status = 'NO_MATCHES';
            SET v_email_status = 'NO_MATCHES';
        END IF;
        #
        SET v_message = CONCAT( v_status , ': ' ,
                                'Sorry, we could not find a match in our records for the information you provided' );
        
        /**/
        SET v_user_messages = CONCAT( v_user_messages , v_message );
        
        /* throw error - it will be logged and select returned */
        CALL api.db_throw_error( 50001 , 'register_participant' ,
                                 CONCAT( v_message ) );
    
    END IF;
    #
    SET tx_isolation = v_default_isolation_level;
    #
    LEAVE full_proc;

END;

