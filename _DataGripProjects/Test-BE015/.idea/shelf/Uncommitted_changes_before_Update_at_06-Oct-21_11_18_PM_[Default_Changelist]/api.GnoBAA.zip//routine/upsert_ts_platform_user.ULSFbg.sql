CREATE
    DEFINER = admin@`%` PROCEDURE upsert_ts_platform_user(
                                                         IN p_user_name varchar(200),
                                                         IN p_email varchar(200),
                                                         IN p_first_name varchar(200),
                                                         IN p_last_name varchar(200),
                                                         IN p_mobile_number varchar(200),
                                                         IN p_ssn varchar(200),
                                                         IN p_ts_employer_key varchar(200),
                                                         IN p_ts_employee_key varchar(200),
                                                         IN p_alegeus_key varchar(200),
                                                         IN p_ts_is_active int,
                                                         IN p_ts_row_id int )
full_proc:

BEGIN
    DECLARE v_count varchar(50) DEFAULT NULL;
    DECLARE v_user_id varchar(50) DEFAULT NULL;
    DECLARE v_is_locked varchar(5) DEFAULT NULL;
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN
        GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
        CALL db_log_error( @errno , 'upsert_ts_sso_user' , @text , @sqlstate );
    END;
    
    SET p_email = api.api_fix_email( p_email );
    SET p_user_name = api.api_fix_email( p_user_name );
    SET p_mobile_number = api.api_fix_phone_number( p_mobile_number );
    SET p_ssn = api.api_fix_email( p_ssn );
    
    IF api.api_is_blank( p_email ) AND api.api_is_blank( p_user_name ) THEN
        CALL api.db_log_message( 'upsert_ts_platform_user' ,
                                 CONCAT( 'Not Inserting record as username, email is blank ' , 'EmployerId: ' ,
                                         api_nz( p_ts_employer_key , '' ) , ' EmployeeID: ' ,
                                         api_nz( p_ts_employee_key , '' ) ) , 'WARN' );
        
        LEAVE full_proc;
    END IF;
    
    IF api.api_is_blank( p_ts_employer_key ) OR api.api_is_blank( p_ts_employee_key ) THEN
        CALL api.db_log_error( 50001 , 'upsert_ts_platform_user' , CONCAT(
                'Not Inserting record as either p_ts_employer_key, p_ts_employee_key is blank ' , 'EmployerId: ' ,
                api_nz( p_ts_employer_key , '' ) , ' EmployeeID: ' , api_nz( p_ts_employee_key , '' ) ) , 'WARN' );
        
        LEAVE full_proc;
    END IF;
    
    IF !api.api_is_blank( p_email ) THEN
        
        SELECT
            COUNT( * )
          , user_id
          , CASE
                WHEN is_verified OR is_ready_for_sso_processing THEN 1
                ELSE 0
            END
        INTO v_count, v_user_id, v_is_locked
        FROM
            api.platform_users
        WHERE
            (email <=> p_email);
        
        SET v_user_id = api.api_nz( v_user_id , '' );
        
        CALL api.db_log_message( 'upsert_ts_platform_user' ,
                                 CONCAT( v_count , ' Records found for EMAIL: ' , api.api_nz( p_email , '' ) ) ,
                                 'WARN' );
        
        IF api.api_cbool( v_user_id ) THEN
            CALL api.db_log_message( 'upsert_ts_platform_user' ,
                                     CONCAT( 'UPDATING existing ' , v_count , ' records for EMAIL: ' ,
                                             api.api_nz( p_email , '' ) ) , 'WARN' );
            
            UPDATE api.platform_users
            SET
                #                 user_name         = api_if_true_else( v_is_locked , user_name , api_nz( p_user_name , user_name ) )
                #               , first_name        = api_if_true_else( v_is_locked , first_name , api_nz( p_first_name , first_name ) )
                #               , last_name         = api_if_true_else( v_is_locked , last_name , api_nz( p_last_name , last_name ) )
                #               , email             = api_if_true_else( v_is_locked , email , api_nz( p_email , email ) )
                #               , mobile_number     = api_if_true_else( v_is_locked , mobile_number ,
                #                                                       api_nz( p_mobile_number , mobile_number ) )
                #               , ssn               = api_if_true_else( v_is_locked , ssn , api_nz( p_ssn , ssn ) )
                #
                ts_employer_key   = api_nz( p_ts_employer_key , ts_employer_key )
              , ts_employee_key   = api_nz( p_ts_employee_key , ts_employee_key )
              , ts_user_is_active = api_nz( p_ts_is_active , ts_user_is_active )
              , ts_ssn            = api_nz( p_ssn , ts_ssn )
              , ts_email          = api_nz( p_email , ts_email )
              , ts_row_id= IFNULL( p_ts_row_id , ts_row_id )
              , last_updated_from = 'upsert_ts_platform_user'
            WHERE
                (email <=> p_email);
            
            LEAVE full_proc;
        END IF;
    END IF;
    
    /* sumeet: we dont insert a new record if not match from another platform by email */
    
    CALL api.db_log_message( 'upsert_ts_platform_user' ,
                             CONCAT( 'NOT UPSERTING new record for Email ' , p_email , ' TS Employer Key ' ,
                                     api.api_nz( p_ts_employer_key , '' ) ,
                                     ' AND TS Employee Key: ' , api.api_nz( p_ts_employee_key , '' ) ) , 'WARN' );
    LEAVE full_proc;
    /* //////////// /*/
    
    CALL api.db_log_message( 'upsert_ts_platform_user' ,
                             CONCAT( 'UPSERTING record TS Employer Key ' , api.api_nz( p_ts_employer_key , '' ) ,
                                     ' AND TS Employee Key: ' , api.api_nz( p_ts_employee_key , '' ) ) , 'WARN' );
    
    INSERT INTO api.platform_users(
                                    user_name
                                  , first_name
                                  , last_name
                                  , email
                                  , mobile_number
                                  , ts_employer_key
                                  , ts_employee_key
                                  , ssn
                                  , ts_user_is_active
                                  , ts_ssn
                                  , ts_email
                                  , ts_row_id
                                  , last_updated_from
    
    )
    VALUES (
               user_name
           ,   p_first_name
           ,   p_last_name
           ,   p_email
           ,   p_mobile_number
           ,   p_ts_employer_key
           ,   p_ts_employee_key
           ,   p_ssn
           ,   p_ts_is_active
           ,   p_ssn
           ,   p_email
           ,   p_ts_row_id
           ,   'upsert_ts_platform_user'
           )
    
    ON DUPLICATE KEY UPDATE
                         #                          user_name         = api_if_true_else( v_is_locked , user_name ,
                         #                                                                api_nz( p_user_name , user_name ) )
                         #                        , first_name        = api_if_true_else( v_is_locked , first_name ,
                         #                                                                api_nz( p_first_name , first_name ) )
                         #                        , last_name         = api_if_true_else( v_is_locked , last_name ,
                         #                                                                api_nz( p_last_name , last_name ) )
                         #                        , email             = api_if_true_else( v_is_locked , email , api_nz( p_email , email ) )
                         #                        , mobile_number     = api_if_true_else( v_is_locked , mobile_number ,
                         #                                                                api_nz( p_mobile_number , mobile_number ) )
                         #                        , ssn               = api_if_true_else( v_is_locked , ssn , api_nz( p_ssn , ssn ) )
        /*, */ts_employer_key              = api_nz( p_ts_employer_key , ts_employer_key )
                       , ts_employee_key   = api_nz( p_ts_employee_key , ts_employee_key )
                       , ts_user_is_active = api_nz( p_ts_is_active , ts_user_is_active )
                       , ts_ssn            = api_nz( p_ssn , ts_ssn )
                       , ts_email          = api_nz( p_email , ts_email )
                       , ts_row_id= IFNULL( p_ts_row_id , ts_row_id )
                       , last_updated_from = 'upsert_ts_platform_user';

END;

