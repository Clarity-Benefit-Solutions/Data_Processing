create
    definer = root@`%` function api_nz(
                                      value text,
                                      valueifnullorempty text ) returns text
BEGIN
    IF ifnull(
               value
           , '') = ''
    THEN
        RETURN ifnull(valueIfNullOrEmpty, '');
        
    ELSEIF ifnull(
                   value
               , '') = '<NULL>' THEN
        RETURN NULL;
    ELSE
        RETURN value;
    END IF;
END;

