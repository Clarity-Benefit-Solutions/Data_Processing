create
    definer = root@`%` procedure temp_fix_api_cases_data_1( IN p_limit int )
BEGIN

    DECLARE v_case_id varchar(200) DEFAULT NULL;
    DECLARE v_audit_id int(11);

    DECLARE v_finished int;
    DECLARE v_values_cursor CURSOR FOR
        SELECT DISTINCT case_id, api_get_last_update_audit_it_for_case( case_id )
        FROM api.api_cases
        LIMIT p_limit;

    DECLARE CONTINUE HANDLER FOR NOT FOUND BEGIN
        SET v_finished = 1;
    END;

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
            CALL db_throw_error( @errno, 'upsert_all_wc_platform_employer_users_1', @text, @sqlstate );
        END;

    SET @@max_sp_recursion_depth = 12;

    OPEN v_values_cursor;

    getValues
    :
    LOOP
        
        FETCH v_values_cursor INTO v_case_id, v_audit_id;

        IF v_finished = 1 THEN
            LEAVE getValues;
        END IF;

        IF !api.api_is_blank( v_audit_id ) THEN
            CALL api.temp_fix_api_cases_data_2( v_case_id, v_audit_id );
        END IF;
    END LOOP getValues;
END;

