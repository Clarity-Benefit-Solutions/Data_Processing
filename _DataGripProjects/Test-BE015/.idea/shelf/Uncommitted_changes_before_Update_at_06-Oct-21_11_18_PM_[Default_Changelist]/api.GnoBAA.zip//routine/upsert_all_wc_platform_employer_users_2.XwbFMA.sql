create
    definer = root@`%` procedure upsert_all_wc_platform_employer_users_2( IN p_email varchar(200) )
full_proc:

BEGIN
    DECLARE v_email varchar(200);
    DECLARE v_is_active varchar(200);
    DECLARE v_user_type varchar(200);
    DECLARE v_tpa_id varchar(200);
    DECLARE v_user_id varchar(200);
    DECLARE v_profile_name varchar(200);
    DECLARE v_middle_initial varchar(200);
    DECLARE v_name_prefix varchar(200);
    DECLARE v_phone varchar(200);
    DECLARE v_row_id varchar(200);
    DECLARE v_employer_id varchar(200);
    DECLARE v_first_name varchar(200);
    DECLARE v_last_name varchar(200);
    DECLARE v_allow_get_current_sessions varchar(200);
    DECLARE v_allow_to_uplod_a_payroll_file varchar(200);
    DECLARE v_status varchar(200);
    DECLARE v_finished int;
    DECLARE v_values_cursor CURSOR FOR SELECT
                                           email
                                         , is_active
                                         , user_type
                                         , tpa_id
                                         , user_id
                                         , profile_name
                                         , middle_initial
                                         , name_prefix
                                         , phone
                                         , row_id
                                         , employer_id
                                         , first_name
                                         , last_name
                                         , allow_get_current_sessions
                                         , allow_to_uplod_a_payroll_file
                                         , status
                                       FROM
                                           wc.vw_wc_employer_users t
                                       WHERE
                                           email = p_email
                                       ORDER BY
                                           email
                                           
                                         , CASE
                                               WHEN is_active > 0 THEN 1
                                               ELSE 0
                                           END
                                           DESC
                                           
                                         , user_type DESC
                                       LIMIT 1;
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND BEGIN
        SET v_finished = 1;
    END;
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN
        GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
        CALL db_throw_error( @errno , 'upsert_all_wc_platform_employer_users_1' , @text );
    END;
    
    SET @@max_sp_recursion_depth = 12;
    
    OPEN v_values_cursor;
    
    getvalues
        :
    LOOP
        FETCH v_values_cursor INTO v_email, v_is_active, v_user_type, v_tpa_id, v_user_id, v_profile_name, v_middle_initial, v_name_prefix, v_phone, v_row_id, v_employer_id, v_first_name, v_last_name, v_allow_get_current_sessions, v_allow_to_uplod_a_payroll_file, v_status;
        
        IF v_finished = 1 THEN
            LEAVE getvalues;
        END IF;
        
        
        IF api.api_is_blank( v_employer_id ) THEN
            SET v_employer_id = '<NULL>';
        END IF;
        
        IF !api.api_is_blank( v_email ) THEN
            CALL api.db_log_message( 'upsert_all_wc_platform_employer_users_2' ,
                                     CONCAT( 'Processing WC user for email: ' , p_email ,
                                             ' using record with row_id  ' , v_row_id , ' Profile: ' , v_profile_name ,
                                             ' and user_type ' , v_user_type ) , 'WARN' );
            SET v_employer_id = api.api_nz( v_employer_id , '<NULL>' );
            
            IF v_is_active = '0.5' THEN
                SET v_is_active = '2';
            END IF;
            
            CALL api.upsert_wc_platform_user( v_email , v_email , v_first_name , v_last_name , v_phone , NULL ,
                                              v_employer_id , v_tpa_id , v_user_id , NULL , NULL , NULL , NULL , NULL ,
                                              NULL , v_is_active , NULL , v_row_id , NULL , v_user_type , NULL , 1 , NULL ,
                                              NULL , NULL,NULL );
        END IF;
    END LOOP getvalues;
END;

