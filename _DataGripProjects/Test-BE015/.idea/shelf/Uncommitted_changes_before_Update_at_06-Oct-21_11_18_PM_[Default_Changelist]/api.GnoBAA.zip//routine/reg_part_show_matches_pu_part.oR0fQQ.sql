create
    definer = root@`%` procedure reg_part_show_matches_pu_part(
                                                              IN p_email varchar(200),
                                                              IN p_ssn varchar(200),
                                                              IN p_dob varchar(200),
                                                              IN p_zip varchar(200),
                                                              IN p_card_number varchar(200) )
full_proc:

BEGIN
    
    
    SELECT
        email
        
      , CASE
            WHEN NOT api.api_is_blank( email ) AND wc_email = p_email THEN 1
            ELSE 0
        END matched_wc_email
      , (CASE
             WHEN NOT api.api_is_blank( p_card_number ) AND
                  (wc_card_number = p_card_number OR
                   RIGHT( wc_card_number , 4 ) = RIGHT( p_card_number , 4 )) THEN 1
             ELSE 0
         END
            ) matched_wc_cardnumber
      , (CASE
             WHEN NOT api.api_is_blank( p_ssn ) AND
                  (wc_ssn = p_ssn OR
                   RIGHT( wc_ssn , 4 ) = RIGHT( p_ssn , 4 )) THEN 1
             ELSE 0
         END)
            matched_wc_ssn
      
      , (CASE
             WHEN NOT api.api_is_blank( p_dob ) AND
                  (wc_dob = p_dob)
                 THEN 1
             ELSE 0
         END) matched_wc_dob
      , (CASE
             WHEN NOT api.api_is_blank( p_zip ) AND
                  (LEFT( wc_zip , 5 ) = LEFT( p_zip , 5 )) THEN 1
             ELSE 0
         END)
            matched_wc_zip
        
      , CASE
            WHEN NOT api.api_is_blank( cp_email ) AND cp_email = p_email THEN 1
            ELSE 0
        END matched_cp_email
      , (CASE
             WHEN NOT api.api_is_blank( p_ssn ) AND
                  (cp_ssn = p_ssn OR
                   RIGHT( cp_ssn , 4 ) = RIGHT( p_ssn , 4 )) THEN 1
             ELSE 0
         END)
            matched_cp_ssn
      
      , (CASE
             WHEN NOT api.api_is_blank( p_dob ) AND
                  (cp_dob = p_dob)
                 THEN 1
             ELSE 0
         END) matched_cp_dob
      , (CASE
             WHEN NOT api.api_is_blank( p_zip ) AND
                  (LEFT( cp_zip , 5 ) = LEFT( p_zip , 5 )) THEN 1
             ELSE 0
         END)
            matched_cp_zip
        
      , CASE
            WHEN NOT api.api_is_blank( bs_email ) AND bs_email = p_email THEN 1
            ELSE 0
        END matched_bs_email
      , (CASE
             WHEN NOT api.api_is_blank( p_ssn ) AND
                  (bs_ssn = p_ssn OR
                   RIGHT( bs_ssn , 4 ) = RIGHT( p_ssn , 4 )) THEN 1
             ELSE 0
         END)
            matched_bs_ssn
      
      , (CASE
             WHEN NOT api.api_is_blank( p_dob ) AND
                  (bs_dob = p_dob)
                 THEN 1
             ELSE 0
         END) matched_bs_dob
      , (CASE
             WHEN NOT api.api_is_blank( p_zip ) AND
                  (LEFT( bs_zip , 5 ) = LEFT( p_zip , 5 )) THEN 1
             ELSE 0
         END)
            matched_bs_zip
        
      , CASE
            WHEN NOT api.api_is_blank( en_email ) AND en_email = p_email THEN 1
            ELSE 0
        END matched_en_email
      , (CASE
             WHEN NOT api.api_is_blank( p_ssn ) AND
                  (en_ssn = p_ssn OR
                   RIGHT( en_ssn , 4 ) = RIGHT( p_ssn , 4 )) THEN 1
             ELSE 0
         END)
            matched_en_ssn
      
      , (CASE
             WHEN NOT api.api_is_blank( p_dob ) AND
                  (en_dob = p_dob)
                 THEN 1
             ELSE 0
         END) matched_en_dob
      , (CASE
             WHEN NOT api.api_is_blank( p_zip ) AND
                  (LEFT( en_zip , 5 ) = LEFT( p_zip , 5 )) THEN 1
             ELSE 0
         END)
            matched_en_zip
      , is_verified
      , is_invalid
      , invite_token
      , first_name
      , last_name
      , mobile_number
      , employee_id
      , dob
      , bs_dob
      , cp_dob
      , en_dob
      , wc_dob
        
      , bs_email
      , cp_email
      , en_email
      , wc_email
        
      , bs_employer_id
      , wcp_employer_id
        
      , ssn
      , bs_ssn
      , cp_ssn
      , en_ssn
      , wc_ssn
        
      , zip
      , bs_zip
      , cp_zip
      , en_zip
      , wc_zip
        
      , if_user_is_active
      , if_unique_id
    FROM
        api.platform_users
    WHERE
        email LIKE CONCAT( p_email , '%' )
    
    LIMIT 1;

END;

