create
    definer = admin@`%` procedure api_compare_api_cases_field_values(
                                                                    IN p_row_id varchar(50),
                                                                    IN p_field_name varchar(100),
                                                                    IN p_prv_version_no int,
                                                                    IN p_new_version_no int )
BEGIN

    DECLARE v_sql text;

    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
        BEGIN
            GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
            CALL db_log_error(@errno, 'api_compare_api_cases_field_values', @text, @sqlstate);
        END;

    
    DELETE
    FROM api_temp_case_field_changes
    WHERE row_id = p_row_id
      AND field_name = p_field_name
      AND prv_version_no = p_prv_version_no
      AND new_version_no = p_new_version_no;


    SET v_sql =
            CONCAT(
                    'INSERT into api_temp_case_field_changes (row_id, field_name, prv_version_no, new_version_no,  prv_field_value, new_field_value) ',
                    'VALUES ( ',
                    SQT(), p_row_id, SQT(), ',',
                    SQT(), p_field_name, SQT(), ',',
                    p_prv_version_no, ',',
                    p_new_version_no, ',',
                    ' ( ',
                    ' SELECT ', p_field_name,
                    ' FROM api.api_cases_audit ',
                    ' WHERE ',
                    ' row_id = ', char(39), p_row_id, char(39),
                    ' AND version_no = ', p_prv_version_no,
                    ' ORDER BY updated_at ASC ',
                    ' LIMIT 1',
                    ')',
                    ',',
                    ' ( ',
                    'SELECT ',
                    p_field_name,
                    ' FROM api.api_cases_audit WHERE ',
                    ' row_id = ', char(39), p_row_id, char(39),
                    ' AND version_no = ', p_new_version_no,
                    ' ORDER BY updated_at DESC ',
                    ' LIMIT 1',
                    ')',
                    ')',
                    ';'
                );

    
    

    EXECUTE immediate v_sql;
    

END;

