CREATE
    DEFINER = root@`%` FUNCTION get_cobra_continutation_counts(
                                                              p_client_id int,
                                                              p_is_submitted int ) RETURNS int
BEGIN
    DECLARE v_count int(11);
    
    IF p_client_id = 0 OR p_is_submitted IS NULL THEN
        RETURN 0;
    END IF;
    
    IF p_is_submitted THEN
        SELECT
            COUNT( * )
        INTO v_count
        FROM
            api.vw_cobra_continuation
        WHERE
              clientid = p_client_id
          AND ae_2021_is_eligible IS NOT NULL;
    ELSE
        SELECT
            COUNT( * )
        INTO v_count
        FROM
            api.vw_cobra_continuation
        WHERE
              clientid = p_client_id
          AND ae_2021_is_eligible IS NULL;
    END IF;
    
    RETURN api.api_nz_int( v_count , 0 );
END;

