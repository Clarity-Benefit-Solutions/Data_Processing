create
    definer = admin@`%` function qt( ) returns varchar(1)
BEGIN
    RETURN '"';
END;

