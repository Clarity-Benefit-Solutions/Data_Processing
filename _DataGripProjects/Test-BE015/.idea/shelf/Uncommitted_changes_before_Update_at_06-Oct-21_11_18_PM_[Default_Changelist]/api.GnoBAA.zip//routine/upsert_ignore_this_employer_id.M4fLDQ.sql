create
    definer = root@`%` function upsert_ignore_this_employer_id(
                                                              p_employer_id varchar(200),
                                                              p_platform varchar(50) ) returns int(1)
BEGIN
    
    IF api.api_is_blank( p_employer_id ) THEN
        RETURN 0;
    END IF;
    
    SET p_platform = LOWER( TRIM( api_nz( p_platform , '' ) ) );
    
    
    
    
    
    
    
    
    
    IF p_employer_id IN ('BENTESTX2') THEN
        RETURN 1;
    END IF;
    
    RETURN 0;

END;

