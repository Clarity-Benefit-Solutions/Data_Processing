create
    definer = admin@`%` function api_if_true_else(
                                                 is_locked int(1),
                                                 valueIfLocked varchar(200),
                                                 valueIfNotLocked varchar(200) ) returns varchar(200)
BEGIN
    IF api.api_cbool(is_locked)
    THEN
        RETURN valueIfLocked;
    ELSE
        RETURN valueIfNotLocked;
    END IF;
END;

