create
    definer = admin@`%` procedure app_log_event(
                                               IN p_user_id varchar(100),
                                               IN p_user_event_type varchar(200),
                                               IN p_user_event_status varchar(200),
                                               IN p_user_event_notes varchar(200) )
BEGIN
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
        BEGIN
            GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE,
                @errno = MYSQL_ERRNO,
                @text = MESSAGE_TEXT;
            CALL db_log_error(@errno,
                              'app_log_event',
                              @text,
                              @sqlstate);
        END;

    INSERT INTO api.platform_user_events (
        user_id,
        user_event_type,
        user_event_status,
        user_event_notes
    ) VALUES (
        p_user_id,
        p_user_event_type,
        p_user_event_status,
        p_user_event_notes
    );
END;

