create
    definer = root@`%` function get_notification_log_last_sent_at(
                                                                 p_email varchar(200),
                                                                 p_notification_type varchar(200),
                                                                 p_notification_category varchar(200),
                                                                 p_notification_sub_category varchar(200) ) returns datetime
BEGIN
    DECLARE v_datetime datetime;
    
    IF api.api_is_blank( p_email ) OR api.api_is_blank( p_notification_type ) OR
       api.api_is_blank( p_notification_category ) THEN
        RETURN NULL;
    END IF;
    
    IF api.api_is_blank( p_notification_sub_category ) THEN
        SET p_notification_sub_category = '%';
    END IF;
    
    SELECT
        MAX( notification_sent_at )
    INTO v_datetime
    FROM
        api.api_notification_logs
    WHERE
          destination_address = p_email
      AND notification_type LIKE p_notification_type
      AND notification_category LIKE p_notification_category
      AND (p_notification_sub_category = '%' OR notification_sub_category LIKE p_notification_sub_category);
    
    RETURN v_datetime;
END;

