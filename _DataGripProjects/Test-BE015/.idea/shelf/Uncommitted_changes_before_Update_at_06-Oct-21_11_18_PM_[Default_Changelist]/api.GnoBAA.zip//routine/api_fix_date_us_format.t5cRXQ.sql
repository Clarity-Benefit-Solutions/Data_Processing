create
    definer = root@`%` function api_fix_date_us_format( value varchar(200) ) returns date
BEGIN
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION BEGIN
        GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
        CALL api.db_log_error( @errno , 'api_fix_date_us_format' , @text , @sqlstate );
        RETURN NULL;
    END;
    
    IF api.api_is_blank( value ) OR value = '<NULL>' THEN
        RETURN NULL;
    END IF;
    
    SET value = REPLACE( value , '-' , '/' );
    IF POSITION( '/' IN value ) > 4 THEN
        RETURN api.api_fix_date( value );
    END IF;
    
    RETURN CAST(
            CONCAT( SUBSTR( value , 7 , 4 ) , '-' , SUBSTR( value , 1 , 2 ) , '-' , SUBSTR( value , 4 , 2 ) ) AS date );

END;

