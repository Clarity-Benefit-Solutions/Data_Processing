create
    definer = root@`%` procedure cobra_continuation_change_contact(
                                                                  IN p_attempt_type varchar(200),
                                                                  IN p_org_contact_email varchar(200),
                                                                  IN p_client_id int,
                                                                  IN p_contact_email varchar(200),
                                                                  IN p_first_name varchar(200),
                                                                  IN p_last_name varchar(200),
                                                                  IN p_mobile_number varchar(200),
                                                                  IN p_company_name varchar(200) )
full_proc:

BEGIN
    DECLARE v_matched_row_id int;
    DECLARE v_matched_row_ids text;
    DECLARE v_internal_messages text;
    DECLARE v_error_message text;
    
    DECLARE v_status varchar(200);
    
    DECLARE v_row_id int;
    DECLARE v_updated_rows int;
    
    DECLARE v_employer_id varchar(50);
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN
        GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
        
        IF api.api_is_blank( v_status ) THEN
            SET v_status = 'FAILED';
        ELSE
            SET v_status = CONCAT( 'FAILED' , ': ' , v_status );
        END IF;
        SET v_matched_row_id = 0;
        SET v_error_message = @text;
        
        SELECT
            p_attempt_type
          , p_org_contact_email
          , p_client_id
          , v_status
          , v_row_id
          , v_updated_rows
          , v_error_message
          , v_matched_row_id
          , v_matched_row_ids
          , v_internal_messages
          , p_first_name
          , p_last_name
          , p_mobile_number
          , p_company_name;
        
        
        
    END;
    
    
    IF api_is_blank( p_org_contact_email ) || api_is_blank( p_client_id ) || api_is_blank( p_contact_email ) ||
       api_is_blank( p_first_name ) || api_is_blank( p_last_name ) || api_is_blank( p_mobile_number ) ||
       api_is_blank( p_company_name ) THEN
        CALL db_throw_error( 50001 , 'cobra_continuation_change_contact' ,
                             'FIELD_IS_BLANK: All fields must be passed' );
    END IF;
    
    SET p_org_contact_email = api.api_fix_email( p_org_contact_email );
    SET p_client_id = api.api_nz_int( p_client_id , 0 );
    SET p_contact_email = api.api_fix_email( p_contact_email );
    SET p_mobile_number = api.api_fix_phone_number( p_mobile_number );
    
    SET v_matched_row_id = 0;
    SET v_matched_row_ids = '';
    SET v_internal_messages = '';
    
    
    CALL api.db_log_message( 'cobra_continuation_change_contact' ,
                             CONCAT( 'Processing user for '
                                 , ' p_org_email: ' , api.api_nz( p_org_contact_email , '' )
                                 , ' p_client_id: ' , api.api_nz( p_client_id , '' )
                                 , ' p_email: ' , api.api_nz( p_contact_email , '' )
                                 , ' p_first_name: ' , api.api_nz( p_first_name , '' )
                                 , ' p_last_name: ' , api.api_nz( p_last_name , '' )
                                 , ' p_company_name: ' , api.api_nz( p_company_name , '' )
                                 , ' p_mobile_number: ' , api.api_nz( p_mobile_number , '' )
                                 ) , 'WARN' );
    
    
    SELECT
        employerid
    INTO v_employer_id
    FROM
        api.cobra_continuation
    WHERE
        clientid = p_client_id
    LIMIT 1;
    
    SET v_status = CONCAT( 'NO_MATCH: Could not get EmployerID for  ClientID: ' , p_client_id );
    IF api.api_is_blank( v_employer_id ) THEN
        CALL db_throw_error( 50001 , 'cobra_continuation_change_contact' ,
                             v_status
            );
    END IF;
    
    
    SELECT
        row_id
    INTO v_row_id
    FROM
        sf.sf_contacts
    WHERE
          clientcode = v_employer_id
      AND email = p_contact_email;
    
    IF api.api_nz_int( v_row_id , 0 ) = 0 THEN
        SET v_status = CONCAT( 'NO_MATCH: NO record in Salesforce Contacts found for ClientID: ' , p_client_id ,
                               ' EmployerID: ' , v_employer_id , '  Email: ' , p_contact_email );
        CALL db_throw_error( 50001 , 'cobra_continuation_change_contact' ,
                             v_status
            );
    END IF;
    
    SET v_internal_messages =
            CONCAT( v_internal_messages , 'cobra_continuation_change_contact: ' , 'Matched existing SF RowID: ' ,
                    v_row_id , ' for ClientID: ' , p_client_id ,
                    ' EmployerID: ' , v_employer_id , '  Email: ' , p_contact_email
                , CHAR( 13 ) );
    
    CALL api.db_log_message( 'cobra_continuation_change_contact' ,
                             v_internal_messages , 'WARN' );
    
    
    UPDATE api.cobra_continuation_contacts
    SET
        status             = 'Resent Invite',
        contact_email      =p_contact_email,
        contact_first_name =p_first_name,
        contact_last_name  = p_last_name,
        contact_phone      =p_mobile_number,
        organization_name  =p_company_name
    WHERE
          contact_email = p_org_contact_email
      AND clientid = p_client_id
      AND contact_is_cobra_contact = 1
    LIMIT 1;
    
    SELECT
        ROW_COUNT( )
    INTO v_updated_rows;
    
    IF api.api_nz_int( v_updated_rows , 0 ) = 0 THEN
        SET v_status = CONCAT( 'NO_UPDATE: ' , 'Zero Rows were updated for for ClientID: ' , p_client_id
            , ' and Org Email: ' , p_org_contact_email , 'Salesforce Contact was found RowID: ' ,
                               v_row_id ,
                               ' EmployerID: ' , v_employer_id );
        CALL db_throw_error( 50001 , 'cobra_continuation_change_contact' ,
                             v_status
            );
    END IF;
    
    
    SET v_matched_row_id = api.api_nz_int( v_matched_row_id , 0 );
    
    SET v_status = 'SUCCESS';
    
    SELECT
        p_attempt_type
      , p_org_contact_email
      , p_client_id
      , v_status
      , v_row_id
      , v_updated_rows
      , v_error_message
      , v_matched_row_id
      , v_matched_row_ids
      , v_internal_messages
      , p_first_name
      , p_last_name
      , p_mobile_number
      , p_company_name;
    
    LEAVE full_proc;

END;

