create
    definer = root@`%` procedure upsert_en_platform_user(
                                                        IN p_user_name varchar(200),
                                                        IN p_email varchar(200),
                                                        IN p_first_name varchar(200),
                                                        IN p_last_name varchar(200),
                                                        IN p_mobile_number varchar(200),
                                                        IN p_ssn varchar(200),
                                                        IN p_en_employee_id varchar(200),
                                                        IN p_dob varchar(50),
                                                        IN p_en_is_active int,
                                                        IN p_en_is_employee int,
                                                        IN p_en_is_manager int,
                                                        IN p_en_is_tpa_user int,
                                                        IN p_en_row_id int,
                                                        IN p_en_employer_id varchar(200),
                                                        IN p_zip varchar(50),
                                                        IN p_is_used_for_registration varchar(200) )
full_proc:
BEGIN
    DECLARE v_count varchar(50) DEFAULT NULL;
    DECLARE v_user_id int DEFAULT NULL;
    DECLARE v_user_id2 int DEFAULT NULL;
    DECLARE v_is_locked int DEFAULT NULL;
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN
        GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
        CALL db_log_error( @errno , 'upsert_en_platform_user' , @text , @sqlstate );
    END;
    
    SET p_email = api.api_fix_email( p_email );
    SET p_user_name = api.api_fix_email( p_user_name );
    SET p_ssn = api.api_fix_email( p_ssn );
    SET p_en_employee_id = api.api_fix_email( p_en_employee_id );
    SET p_mobile_number = api.api_fix_phone_number( p_mobile_number );
    SET p_dob = api.api_fix_date( p_dob );
    SET p_zip = api.api_fix_zip( p_zip );
    
    IF api.api_is_blank( p_email ) OR api.api_is_blank( p_user_name ) THEN
        CALL api.db_log_message( 'upsert_en_platform_user' ,
                                 CONCAT( 'Not Inserting record as either email or username is blank ' ,
                                         'Import First Name: ' , api.api_nz( p_first_name , '' ) , ' AND Last Name: ' ,
                                         api.api_nz( p_last_name , '' ) ) , 'WARN' );
        
        LEAVE full_proc;
    END IF;
    
    
    
    SELECT
        COUNT( * )
      , user_id
      , CASE
            WHEN is_verified THEN 1
            ELSE 0
        END
    INTO v_count, v_user_id, v_is_locked
    FROM
        api.platform_users
    WHERE
        (email = p_email);
    
    SET v_user_id = api.api_nz_int( v_user_id , 0 );
    SET v_is_locked = api.api_nz_int( v_is_locked , 0 );
    
    CALL api.db_log_message( 'upsert_en_platform_user' ,
                             CONCAT( v_count , ' Records found for EMAIL: ' , api.api_nz( p_email , '' ) ) ,
                             'WARN' );
    
    
    
    IF (api.api_nz_int( p_en_is_manager , 0 ) = 0 AND api.api_nz_int( p_en_is_tpa_user , 0 ) = 0) THEN
        
        
        IF NOT p_is_used_for_registration THEN
            
            IF api.api_is_blank( p_ssn ) THEN
                CALL api.db_log_message( 'upsert_en_platform_user' ,
                                         CONCAT(
                                                 'EXITING as Participant and not p_is_used_for_registration and SSN is blank ' ,
                                                 api.api_nz( p_email , '' ) ) , ', ' , api.api_nz( p_ssn , '' ) ,
                                         'WARN' );
                
                LEAVE full_proc;
            END IF;
            
            
            SELECT
                user_id
            INTO v_user_id2
            FROM
                api.platform_users
            WHERE
                  (email = p_email)
              AND (api.api_fix_ssn( ssn ) = api.api_fix_ssn( p_ssn ));
            
            
            IF NOT api.api_cbool( v_user_id2 ) THEN
                CALL api.db_log_message( 'upsert_en_platform_user' ,
                                         CONCAT(
                                                 'EXITING as Participant and not p_is_used_for_registration and no match for Email and SSN ' ,
                                                 api.api_nz( p_email , '' ) , ', ' , api.api_nz( p_ssn , '' ) ) ,
                                         'WARN' );
                
                LEAVE full_proc;
            END IF;
            
            
            CALL api.db_log_message( 'upsert_en_platform_user' ,
                                     CONCAT( v_count ,
                                             ' Records found for  EMAIL and SSN though Participant and not p_is_used_for_registration and not verified: ' ,
                                             api.api_nz( p_email , '' ) , ', ' , api.api_nz( p_ssn , '' ) ) ,
                                     'WARN' );
            
            
            UPDATE en.en_employees
            SET
                is_used_for_registration =1
            WHERE
                ROW_ID = p_en_row_id;
            
            
            SET v_user_id = v_user_id2;
        
        END IF;
    END IF;
    
    IF api.api_cbool( v_user_id ) THEN
        CALL api.db_log_message( 'upsert_en_platform_user' ,
                                 CONCAT( 'UPDATING existing ' , v_count , ' records for EMAIL: ' ,
                                         api.api_nz( p_email , '' ) ) , 'WARN' );
        
        UPDATE api.platform_users
        SET
            user_name         = api.api_if_true_else( v_is_locked , user_name , api.api_nz( p_user_name , user_name ) )
          , first_name        = api.api_if_true_else( v_is_locked , first_name ,
                                                      api.api_nz( p_first_name , first_name ) )
          , last_name         = api.api_if_true_else( v_is_locked , last_name , api.api_nz( p_last_name , last_name ) )
          , email             = api.api_if_true_else( v_is_locked , email , api.api_nz( p_email , email ) )
          , mobile_number     = api.api_if_true_else( v_is_locked , mobile_number ,
                                                      api.api_nz( p_mobile_number , mobile_number ) )
          , ssn               = api.api_if_true_else( v_is_locked , ssn , api.api_nz( p_ssn , ssn ) )
          , dob               = api.api_if_true_else( v_is_locked , dob , api.api_nz( p_dob , dob ) )
          , employee_id       = api.api_if_true_else( v_is_locked , employee_id ,
                                                      api.api_nz( p_en_employee_id , employee_id ) )
          , en_employee_id    = api.api_nz( p_en_employee_id , en_employee_id )
          , en_employer_id    = api.api_nz( p_en_employer_id , en_employer_id )
          , en_dob            = api.api_nz( p_dob , en_dob )
          , en_ssn            = api.api_nz( p_ssn , en_ssn )
          , en_email          = api.api_nz( p_email , en_email )
          , en_user_is_active = api_cbool( api.api_nz( p_en_is_active , en_user_is_active ) )
          , en_is_employee    = api_cbool( api.api_nz( p_en_is_employee , en_is_employee ) )
          , en_is_manager= api_cbool( api.api_nz( p_en_is_manager , en_is_manager ) )
          , en_is_tpa_user= api_cbool( api.api_nz( p_en_is_tpa_user , en_is_tpa_user ) )
          , en_row_id= api.api_nz( p_en_row_id , en_row_id )
          , zip               = api.api_nz( p_zip , zip )
          , en_zip            = api.api_nz( p_zip , en_zip )
          , last_updated_from = 'upsert_en_platform_user'
        WHERE
            (email = p_email);
        
        LEAVE
            full_proc;
    END
        IF;
    
    CALL api.db_log_message( 'upsert_en_platform_user' ,
                             CONCAT( 'UPSERTING record for Import First Name: ' , api.api_nz( p_first_name , '' ) ,
                                     ' AND Last Name: ' , api.api_nz( p_last_name , '' ) ) , 'WARN' );
    
    INSERT INTO api.platform_users(
                                    user_name
                                  , first_name
                                  , last_name
                                  , email
                                  , mobile_number
                                  , en_dob
                                  , dob
                                  , ssn
                                  , employee_id
                                  , en_user_is_active
                                  , en_employer_id
                                  , en_ssn
                                  , en_email
                                  , en_is_employee
                                  , en_is_manager
                                  , en_is_tpa_user
                                  , en_row_id
                                  , last_updated_from
                                  , zip
                                  , en_zip
    )
    VALUES (
               p_user_name
           ,   p_first_name
           ,   p_last_name
           ,   p_email
           ,   p_mobile_number
           ,   p_dob
           ,   p_dob
           ,   p_ssn
           ,   p_en_employee_id
           ,   api_cbool( p_en_is_active )
           ,   p_en_employer_id
           ,   p_ssn
           ,   p_email
           ,   api_cbool( p_en_is_employee )
           ,   api_cbool( p_en_is_manager )
           ,   api_cbool( p_en_is_tpa_user )
           ,   p_en_row_id
           ,   'upsert_en_platform_user'
           ,   p_zip
           ,   p_zip
           )
    
    ON DUPLICATE KEY UPDATE
                         user_name         = api.api_if_true_else( v_is_locked , user_name ,
                                                                   api.api_nz( p_user_name , user_name ) )
                       , first_name        = api.api_if_true_else( v_is_locked , first_name ,
                                                                   api.api_nz( p_first_name , first_name ) )
                       , last_name         = api.api_if_true_else( v_is_locked , last_name ,
                                                                   api.api_nz( p_last_name , last_name ) )
                       , email             = api.api_if_true_else( v_is_locked , email , api.api_nz( p_email , email ) )
                       , mobile_number     = api.api_if_true_else( v_is_locked , mobile_number ,
                                                                   api.api_nz( p_mobile_number , mobile_number ) )
                       , ssn               = api.api_if_true_else( v_is_locked , ssn , api.api_nz( p_ssn , ssn ) )
                       , dob               = api.api_if_true_else( v_is_locked , dob , api.api_nz( p_dob , dob ) )
                       , employee_id       = api.api_if_true_else( v_is_locked , employee_id ,
                                                                   api.api_nz( p_en_employee_id , employee_id ) )
                       , en_employee_id    = api.api_nz( p_en_employee_id , en_employee_id )
                       , en_employer_id    = api.api_nz( p_en_employer_id , en_employer_id )
                       , en_dob            = api.api_nz( p_dob , en_dob )
                       , en_ssn            = api.api_nz( p_ssn , en_ssn )
                       , en_email          = api.api_nz( p_email , en_email )
                       , en_user_is_active = api_cbool( api.api_nz( p_en_is_active , en_user_is_active ) )
                       , en_is_employee    = api_cbool( api.api_nz( p_en_is_employee , en_is_employee ) )
                       , en_is_manager= api_cbool( api.api_nz( p_en_is_manager , en_is_manager ) )
                       , en_is_tpa_user= api_cbool( api.api_nz( p_en_is_tpa_user , en_is_tpa_user ) )
                       , en_row_id= api.api_nz( p_en_row_id , en_row_id )
                       , zip               = api.api_nz( p_zip , zip )
                       , en_zip            = api.api_nz( p_zip , en_zip )
                       , last_updated_from = 'upsert_en_platform_user';

END;

