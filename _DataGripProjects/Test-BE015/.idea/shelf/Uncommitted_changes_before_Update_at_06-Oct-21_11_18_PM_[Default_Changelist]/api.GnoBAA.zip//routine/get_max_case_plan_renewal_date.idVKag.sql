create
    definer = admin@`%` function get_max_case_plan_renewal_date(
                                                               p_case_id varchar(50),
                                                               p_plan_sub_type varchar(50) ) returns datetime
BEGIN

    DECLARE v_date datetime DEFAULT NULL;

    IF p_plan_sub_type = 'COBRA' THEN
        SELECT max(plan_year_renewal_date) INTO v_date FROM api.api_case_plans_cobra WHERE case_id = p_case_id;
    ELSEIF p_plan_sub_type = 'CONSUMER_BENEFIT' THEN
        SELECT date_add(max(plan_year_end_date), INTERVAL 1 DAY)
        INTO v_date
        FROM api.api_case_plans_cons_ben
        WHERE case_id = p_case_id;
    ELSE
        CALL api.db_throw_error(50001, 'get_max_case_plan_renewal_date', concat('Invalid Case Sub Type ', p_plan_sub_type));
    END IF;

    RETURN v_date;

END;

