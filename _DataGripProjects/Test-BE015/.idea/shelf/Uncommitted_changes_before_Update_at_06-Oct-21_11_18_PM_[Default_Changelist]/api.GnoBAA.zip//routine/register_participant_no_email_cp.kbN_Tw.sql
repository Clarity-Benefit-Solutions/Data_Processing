create
    definer = root@`%` procedure register_participant_no_email_cp(
                                                                 IN p_attempt_type varchar(200),
                                                                 IN p_invite_token varchar(200),
                                                                 INOUT p_email varchar(200),
                                                                 IN p_first_name varchar(200),
                                                                 IN p_last_name varchar(200),
                                                                 IN p_mobile_number varchar(200),
                                                                 IN p_ssn varchar(200),
                                                                 IN p_employer_id varchar(200),
                                                                 IN p_employee_id varchar(200),
                                                                 IN p_dob varchar(200),
                                                                 IN p_zip varchar(200),
                                                                 IN p_card_number varchar(200),
                                                                 IN p_ignore_email_mismatch int,
                                                                 INOUT v_matched int,
                                                                 INOUT v_matched_row_ids text,
                                                                 INOUT v_internal_messages text,
                                                                 INOUT v_user_messages text,
                                                                 INOUT v_status varchar(200),
                                                                 INOUT v_email_status longtext )
full_proc:

BEGIN
    DECLARE v_count int DEFAULT NULL;
    DECLARE v_row_id int DEFAULT NULL;
    
    DECLARE v_matched_score int;
    DECLARE v_message text;
    DECLARE v_matched_cardnumber int;
    DECLARE v_matched_ssn int;
    DECLARE v_matched_employeeid int;
    DECLARE v_matched_employer_id int;
    DECLARE v_matched_dob int;
    DECLARE v_matched_zip int;
    DECLARE v_matched_email int;
    DECLARE v_email varchar(200);
    DECLARE v_has_email_mismatch int DEFAULT 0;
    DECLARE v_is_used_for_registration int;
    DECLARE v_is_active int;
    DECLARE v_orderseq int;
    
    
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN
        GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
        CALL db_throw_error( 50001 , 'register_participant_no_email_cp' , @text );
    END;
    
    
    SET p_email = api.api_fix_email( p_email );
    SET p_mobile_number = api.api_fix_phone_number( p_mobile_number );
    SET p_ssn = api.api_fix_ssn( p_ssn );
    SET p_dob = api.api_fix_date( p_dob );
    
    SET v_matched_row_ids = api.api_nz( v_matched_row_ids , '' );
    SET v_internal_messages = api.api_nz( v_internal_messages , '' );
    SET v_user_messages = api.api_nz( v_user_messages , '' );
    SET v_status = api.api_nz( v_status , '' );
    SET v_email_status = api.api_nz( v_email_status , '' );
    
    CALL api.db_log_message( 'register_participant_no_email_cp' ,
                             CONCAT( 'Processing user for '
                                 , ' p_attempt_type: ' , api.api_nz( p_attempt_type , '' ) , ' p_email: ' ,
                                     api.api_nz( p_email , '' )
                                 , ' p_first_name: ' , api.api_nz( p_first_name , '' )
                                 , ' p_last_name: ' , api.api_nz( p_last_name , '' )
                                 , ' p_ssn: ' , api.api_nz( p_ssn , '' )
                                 , ' p_employee_id: ' , api.api_nz( p_employee_id , '' )
                                 , ' p_employer_id: ' , api.api_nz( p_employer_id , '' )
                                 , ' p_dob: ' , api.api_nz( p_dob , '' )
                                 , ' p_zip: ' , api.api_nz( p_zip , '' )
                                 , ' p_card_number: ' , api.api_nz( p_card_number , '' )
                                 , ' p_ignore_email_mismatch: ' , api.api_nz( p_ignore_email_mismatch , '' )
                                 , ' p_mobile_number: ' , api.api_nz( p_mobile_number , '' )
                                 ) , 'WARN' );
    
    
    IF api.api_is_blank( p_email ) AND p_attempt_type IN ('REGISTRATION') THEN
        CALL db_throw_error( 50001 , 'register_participant_no_email_cp' ,
                             'EMAIL_IS_BLANK: Email MUST NOT be blank' );
    END IF;
    
    
    SELECT
        is_used_for_registration
      , is_active
      , orderseq
      , t.row_id
      , t.email
      , (t.is_active * 1 +
         t.matched_cardnumber + t.matched_email + t.matched_ssn + t.matched_zip + t.matched_employeeid +
         t.matched_employer_id +
         t.matched_dob) matched_score
      , t.matched_cardnumber
      , t.matched_ssn
      , t.matched_employeeid
      , t.matched_employer_id
      , t.matched_dob
      , t.matched_zip
      , t.matched_email
    INTO v_is_used_for_registration
        , v_is_active
        , v_orderseq
        , v_row_id
        , v_email
        , v_matched_score
        ,v_matched_cardnumber
        , v_matched_ssn
        , v_matched_employeeid
        , v_matched_employer_id
        , v_matched_dob
        , v_matched_zip
        , v_matched_email
    
    FROM
        (
            SELECT
                                                                 is_used_for_registration
              ,
                
                
                                                                 en.en_is_active_status( loginstatus )
                                                                     is_active
              ,                                                  orderseq
              ,                                                  CASE
                                                                     WHEN NOT api.api_is_blank( email ) AND email = p_email
                                                                         THEN 1
                                                                     ELSE 0
                                                                 END matched_email
              
              , 
                                                                 0 matched_cardnumber
              ,                                                  (CASE
                                                                      WHEN NOT api.api_is_blank( p_ssn ) AND
                                                                           (ssn = p_ssn OR
                                                                            matched_ssn_emp_id_last = RIGHT( p_ssn , 4 ))
                                                                          THEN 1
                                                                      ELSE 0
                                                                  END)
                                                                     matched_ssn
              ,                                                  (CASE
                                                                      WHEN NOT api.api_is_blank( p_zip ) AND
                                                                           (matched_zip = p_zip) THEN 1
                                                                      ELSE 0
                                                                  END)
                                                                     matched_zip
              ,                           0
                                                                     matched_employeeid
              ,  0 matched_employer_id
              ,                                                  (CASE
                                                                      WHEN NOT api.api_is_blank( p_dob ) AND
                                                                           (dob = p_dob)
                                                                          THEN 1
                                                                      ELSE 0
                                                                  END) matched_dob
              ,                                                  row_id
              ,                                                  email
              ,                                                  registrationdate
            
            FROM
                cp.cp_all_sso_users
            WHERE
                


                
                
                
                (
                    
                        (NOT api.api_is_blank( p_ssn ) AND
                         (ssn = p_ssn OR
                          matched_ssn_emp_id_last = RIGHT( p_ssn , 4 ))
                            )
                        
                        
                        
                        
                        
                        
                        OR (NOT api.api_is_blank( p_dob ) AND
                            (dob = p_dob))
                        OR (NOT api.api_is_blank( p_zip ) AND
                            (matched_zip = p_zip))
                    )
        
        ) t
    
    ORDER BY
        (t.is_active * 1 +
         t.matched_cardnumber + t.matched_email + t.matched_ssn + t.matched_zip + t.matched_employeeid +
         t.matched_employer_id +
         t.matched_dob)
        DESC
      , t.registrationdate DESC
    LIMIT 1;
    
    
    
    
    
    
    
    
    
    
    SET v_row_id = api.api_nz_int( v_row_id , 0 );
    SET v_matched_score = api.api_nz_int( v_matched_score , 0 );
    
    
    IF v_is_active THEN
        SET v_matched_score = v_matched_score - v_is_active * 1;
    END IF;
    
    
    SET v_message = CONCAT( 'CP: Match Details '
        , ' For p_attempt_type: ' , p_attempt_type
        , ' For p_email: ' , p_email
        , ' Row ID: ' , api.api_nz( v_row_id , '' )
        , ' Score: ' , api.api_nz( v_matched_score , '' )
        , ' Email: ' , api.api_nz( v_matched_email , '' )
        , ' DOB: ' , api.api_nz( v_matched_dob , '' )
        , ' SSN: ' , api.api_nz( v_matched_ssn , '' )
        , ' ZIP: ' , api.api_nz( v_matched_zip , '' )
        , ' Card No: ' , api.api_nz( v_matched_cardnumber , '' )
        , ' Employer Id: ' , api.api_nz( v_matched_employer_id , '' )
        , ' Employee ID: ' , api.api_nz( v_matched_employeeid , '' )
        );
    CALL api.db_log_message( 'register_participant_no_email_cp' , v_message , 'WARN' );
    SET v_internal_messages = CONCAT( v_internal_messages , v_message ,
                                      CHAR( 13 ) );
    
    
    IF v_matched_score < 3 THEN
        
        CALL api.db_log_message( 'register_participant_no_email_cp' ,
                                 CONCAT( 'NOT Matched record ' , v_row_id
                                     , ' For p_attempt_type: ' , p_attempt_type
                                     , ' For p_email: ' , p_email
                                     , ' match count: ' , v_matched_score
                                     ) , 'WARN' );
        
        SET v_matched_row_ids =
                CONCAT( v_matched_row_ids , 'NOT Matched COBRAPoint. Match Count: ' , v_matched_score ,
                        CHAR( 13 ) );
        SET v_internal_messages =
                CONCAT( v_internal_messages , 'NOT Matched COBRAPoint. Match Count: ' , v_matched_score ,
                        CHAR( 13 ) );
        
        LEAVE full_proc;
    
    ELSE
        
        IF p_attempt_type NOT IN ('REGISTRATION') THEN
            SET p_email = v_email;
        END IF;
        
        
        CALL api.db_log_message( 'register_participant_no_email_cp' ,
                                 CONCAT( 'Matched record ' , v_row_id
                                     , ' For p_attempt_type: ' , p_attempt_type
                                     , ' For p_email: ' , p_email
                                     , ' match count: ' , v_matched_score
                                     ) , 'WARN' );
        
        
        SET v_matched_row_ids =
                CONCAT( v_matched_row_ids , 'Matched COBRAPoint Row ID: ' , v_row_id , CHAR( 13 ) );
        
        SET v_internal_messages =
                CONCAT( v_internal_messages , 'Matched COBRAPoint. Match Count: ' , v_matched_score , CHAR( 13 ) );
        
        IF api.api_is_blank( v_email ) THEN
            SET v_internal_messages =
                    CONCAT( v_internal_messages , 'COBRAPoint: Existing email address was blank' , CHAR( 13 ) );
            
            SET v_email_status =
                    CONCAT( v_email_status , 'EMAIL_BLANK_ON_PLATFORM: ' , 'COBRAPoint email is blank' );
            
            
            
            
            
            
            
            
        
        ELSEIF v_email <> p_email THEN
            IF p_attempt_type IN ('REGISTRATION') THEN
                SET v_internal_messages =
                        CONCAT( v_internal_messages ,
                                'EMAIL_DIFFERENT_ON_PLATFORM: COBRAPoint: Existing email address was different ' ,
                                v_email ,
                                CHAR( 13 ) );
                
                
                SET v_email_status =
                        CONCAT( v_email_status , 'EMAIL_DIFFERENT_ON_PLATFORM: ' , 'COBRAPoint email is: ' , v_email ,
                                CHAR( 13 ) );
                
                SET v_user_messages =
                        CONCAT(  'EMAIL_DIFFERENT_ON_PLATFORM: ' , 
                                                      'The email you provided does not match the records we have on file.' ,
                                                      CHAR( 13 ) );
            
            END IF;
        END IF;
        
        
        IF NOT v_has_email_mismatch OR p_ignore_email_mismatch THEN
            IF p_attempt_type IN ('REGISTRATION') THEN
                
                
                UPDATE cp.cp_all_sso_users
                SET
                    email                    = p_email,
                    is_used_for_registration = 1
                WHERE
                    row_id = v_row_id
                 ;
                
                
                
                
                
                
                
                
                
                CALL api.upsert_all_cp_platform_users_2( p_email , v_orderseq );
            END IF;
            
            SET v_matched = 1;
        END IF;
        
        
        LEAVE full_proc;
    END IF;
    
    LEAVE full_proc;

END;

