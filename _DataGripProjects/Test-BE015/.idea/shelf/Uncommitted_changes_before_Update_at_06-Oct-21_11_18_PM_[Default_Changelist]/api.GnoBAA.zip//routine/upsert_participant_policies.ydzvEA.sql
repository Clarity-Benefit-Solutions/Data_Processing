create
    definer = root@`%` procedure upsert_participant_policies(
                                                            IN p_row_id int,
                                                            IN p_tpa_policy_holder_id int,
                                                            IN p_tpa_employee_id int,
                                                            IN p_login_needs_correction int,
                                                            IN p_login_problem varchar(50),
                                                            IN p_payer_id int,
                                                            IN p_payer_name varchar(50),
                                                            IN p_payer_retriever varchar(50),
                                                            IN p_payer_short_name varchar(50),
                                                            IN p_payer_supports_realtime_verification int,
                                                            IN p_payer_website_home_url varchar(50),
                                                            IN p_username varchar(50) )
BEGIN
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN
        GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
        SET @text = CONCAT( @text , CONCAT( '
Called With Params: ' , ', row_id: ' , api.api_nz( `p_row_id` , '' ) , ', tpa_policy_holder_id: ' ,
                                            api.api_nz( `p_tpa_policy_holder_id` , '' ) , ', tpa_employee_id: ' ,
                                            api.api_nz( `p_tpa_employee_id` , '' ) , ', login_needs_correction: ' ,
                                            api.api_nz( `p_login_needs_correction` , '' ) , ', login_problem: ' ,
                                            api.api_nz( `p_login_problem` , '' ) , ', payer_id: ' ,
                                            api.api_nz( `p_payer_id` , '' ) , ', payer_name: ' ,
                                            api.api_nz( `p_payer_name` , '' ) , ', payer_retriever: ' ,
                                            api.api_nz( `p_payer_retriever` , '' ) , ', payer_short_name: ' ,
                                            api.api_nz( `p_payer_short_name` , '' ) ,
                                            ', payer_supports_realtime_verification: ' ,
                                            api.api_nz( `p_payer_supports_realtime_verification` , '' ) ,
                                            ', payer_website_home_url: ' ,
                                            api.api_nz( `p_payer_website_home_url` , '' ) , ', username: ' ,
                                            api.api_nz( `p_username` , '' ) ) );
        CALL api.db_throw_error( @errno , 'upsert_participant_policies' , @text );
    END;
    
    CALL api.db_log_message( 'upsert_participant_policies' ,
                             CONCAT( 'Called With Params: ' , ', row_id: ' , api.api_nz( `p_row_id` , '' ) ,
                                     ', tpa_policy_holder_id: ' , api.api_nz( `p_tpa_policy_holder_id` , '' ) ,
                                     ', tpa_employee_id: ' , api.api_nz( `p_tpa_employee_id` , '' ) ,
                                     ', login_needs_correction: ' , api.api_nz( `p_login_needs_correction` , '' ) ,
                                     ', login_problem: ' , api.api_nz( `p_login_problem` , '' ) , ', payer_id: ' ,
                                     api.api_nz( `p_payer_id` , '' ) , ', payer_name: ' ,
                                     api.api_nz( `p_payer_name` , '' ) , ', payer_retriever: ' ,
                                     api.api_nz( `p_payer_retriever` , '' ) , ', payer_short_name: ' ,
                                     api.api_nz( `p_payer_short_name` , '' ) ,
                                     ', payer_supports_realtime_verification: ' ,
                                     api.api_nz( `p_payer_supports_realtime_verification` , '' ) ,
                                     ', payer_website_home_url: ' , api.api_nz( `p_payer_website_home_url` , '' ) ,
                                     ', username: ' , api.api_nz( `p_username` , '' ) ) , 'WARN' );
    
    INSERT INTO `misc`.`participant_policies` (
                                              `row_id`,
                                              `tpa_policy_holder_id`,
                                              `tpa_employee_id`,
                                              `login_needs_correction`,
                                              `login_problem`,
                                              `payer_id`,
                                              `payer_name`,
                                              `payer_retriever`,
                                              `payer_short_name`,
                                              `payer_supports_realtime_verification`,
                                              `payer_website_home_url`,
                                              `username`
    )
    
    VALUES (
           `p_row_id`,
           `p_tpa_policy_holder_id`,
           `p_tpa_employee_id`,
           `p_login_needs_correction`,
           `p_login_problem`,
           `p_payer_id`,
           `p_payer_name`,
           `p_payer_retriever`,
           `p_payer_short_name`,
           `p_payer_supports_realtime_verification`,
           `p_payer_website_home_url`,
           `p_username`
           )
    
    ON DUPLICATE KEY UPDATE
                         `row_id`                               = api.api_nz_int( `p_row_id` , `row_id` ),
                         `tpa_policy_holder_id`                 = api.api_nz_int( `p_tpa_policy_holder_id` , `tpa_policy_holder_id` ),
                         `tpa_employee_id`                      = api.api_nz_int( `p_tpa_employee_id` , `tpa_employee_id` ),
                         `login_needs_correction`               = api.api_nz_int( `p_login_needs_correction` , `login_needs_correction` ),
                         `login_problem`                        = api.api_nz( `p_login_problem` , `login_problem` ),
                         `payer_id`                             = api.api_nz_int( `p_payer_id` , `payer_id` ),
                         `payer_name`                           = api.api_nz( `p_payer_name` , `payer_name` ),
                         `payer_retriever`                      = api.api_nz( `p_payer_retriever` , `payer_retriever` ),
                         `payer_short_name`                     = api.api_nz( `p_payer_short_name` , `payer_short_name` ),
                         `payer_supports_realtime_verification` = api.api_nz_int(
                                 `p_payer_supports_realtime_verification` , `payer_supports_realtime_verification` ),
                         `payer_website_home_url`               = api.api_nz( `p_payer_website_home_url` , `payer_website_home_url` ),
                         `username`                             = api.api_nz( `p_username` , `username` );

END;

