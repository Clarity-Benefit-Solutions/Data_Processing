create
    definer = root@`%` procedure util_generate_audit_sql_for_table(
                                                                  IN dbname varchar(100),
                                                                  IN tablename varchar(100) )
BEGIN
    
    SELECT
        dbname
      , table_data.audit_table
      , table_data.audit_table_prv
      , concat( "DROP TABLE IF EXISTS `" , dbname , "`.`" , table_data.audit_table_prv , "`;\r" , "RENAME TABLE `" ,
                dbname , "`.`" , table_data.audit_table , "` to `" , dbname , "`.`" , table_data.audit_table_prv ,
                "` ;\r" , "DROP TABLE IF EXISTS `" , dbname , "`.`" , table_data.audit_table , "`;\r" ,
                "CREATE TABLE `" , dbname , "`.`" , table_data.audit_table , "`\r" , "(\r" ,
                "  `auditAction` ENUM ('INSERT', 'UPDATE', 'DELETE'),\r" ,
                "  `auditTimestamp` timestamp DEFAULT CURRENT_TIMESTAMP,\r" , "  `auditId` INT(14) AUTO_INCREMENT," ,
                column_defs , ",\r" "  PRIMARY KEY (`auditId`),\r" , "  INDEX (`auditTimestamp`)\r" , ")\r" ,
                "  ENGINE = MyISAM;\r\r" ,
                concat( 'INSERT INTO `' , dbname , '`.`' , table_data.audit_table , '` ' , '(' ,
                        api.util_get_column_list_for_table( dbname , table_data.audit_table ) , ') ' , "\r" ,
                        'SELECT ' , api.util_get_column_list_for_table( dbname , table_data.audit_table ) , ' FROM `' ,
                        dbname , '`.`' , table_data.audit_table_prv , '` ;' ) , "\r\r\r" ,
                concat( 'DROP table `' , dbname , '`.`' , table_data.audit_table_prv , '` ;' ) , "\r\r\r" ,
                " DROP TRIGGER IF EXISTS `" , dbname , "`.`" , table_data.insert_trigger , "`;
                     \r" , "CREATE TRIGGER `" , dbname , "`.`" , table_data.insert_trigger , "`\r" ,
                "  AFTER INSERT ON `" , dbname , "`.`" , table_data.db_table , "`\r" , "  FOR EACH ROW INSERT INTO `" ,
                dbname , "`.`" , table_data.audit_table , "`\r" , "     (`auditAction`," , table_data.column_names ,
                ")\r" , "  VALUES\r" , "     ('INSERT'," , table_data.newcolumn_names , ");
                     \r\r" , "DROP TRIGGER IF EXISTS `" , dbname , "`.`" , table_data.update_trigger , "`;
                     \r" , "CREATE TRIGGER `" , dbname , "`.`" , table_data.update_trigger , "`\r" ,
                "  AFTER UPDATE ON `" , dbname , "`.`" , table_data.db_table , "`\r" , "  FOR EACH ROW INSERT INTO `" ,
                dbname , "`.`" , table_data.audit_table , "`\r" , "     (`auditAction`," , table_data.column_names ,
                ")\r" , "  VALUES\r" , "     ('UPDATE'," , table_data.newcolumn_names , ");
                     \r\r" , "DROP TRIGGER IF EXISTS `" , dbname , "`.`" , table_data.delete_trigger , "`;
                     \r" , "CREATE TRIGGER `" , dbname , "`.`" , table_data.delete_trigger , "`\r" ,
                "  AFTER DELETE ON `" , dbname , "`.`" , table_data.db_table , "`\r" , "  FOR EACH ROW INSERT INTO `" ,
                dbname , "`.`" , table_data.audit_table , "`\r" , "     (`auditAction`," , table_data.column_names ,
                ")\r" , "  VALUES\r" , "     ('DELETE'," , table_data.oldcolumn_names , ");
                     \r\r" )
    FROM
        (
            
            SELECT
                table_order_key
              , table_name db_table
              , concat( table_name , "_audit" ) audit_table
              , concat( "tmp_prv_" , table_name , "_audit" ) audit_table_prv
              , concat( "au_audit_" , table_name , "_inserts" ) insert_trigger
              , concat( "au_audit_" , table_name , "_updates" ) update_trigger
              , concat( "au_audit_" , table_name , "_deletes" ) delete_trigger
              , group_concat( "\r  `" , column_name , "` " , column_type ORDER BY column_order_key ) column_defs
              , group_concat( "`" , column_name , "`" ORDER BY column_order_key ) column_names
              , group_concat( "NEW.`" , column_name , "`" ORDER BY column_order_key ) newcolumn_names
              , group_concat( "OLD.`" , column_name , "`" ORDER BY column_order_key ) oldcolumn_names
            FROM
                (
                    
                    SELECT
                        information_schema.tables.table_name table_name
                      , information_schema.columns.column_name column_name
                      , information_schema.columns.column_type column_type
                      , information_schema.tables.create_time table_order_key
                      , information_schema.columns.ordinal_position column_order_key
                    FROM
                        information_schema.tables
                            JOIN information_schema.columns
                                 ON information_schema.tables.table_name = information_schema.columns.table_name
                    WHERE
                          information_schema.tables.table_schema = dbname
                      AND information_schema.columns.table_schema = dbname
                      AND information_schema.tables.table_name NOT LIKE "audit\_%"
                ) table_column_ordering_info
            WHERE
                table_name = tablename
            GROUP BY
                table_name
        ) table_data
    ORDER BY
        table_order_key;
END;

