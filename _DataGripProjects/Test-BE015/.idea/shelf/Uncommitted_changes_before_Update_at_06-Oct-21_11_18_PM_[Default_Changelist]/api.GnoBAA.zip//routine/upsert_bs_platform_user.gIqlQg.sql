create
    definer = root@`%` procedure upsert_bs_platform_user(
                                                        IN p_user_name varchar(200),
                                                        IN p_email varchar(200),
                                                        IN p_first_name varchar(200),
                                                        IN p_last_name varchar(200),
                                                        IN p_mobile_number varchar(200),
                                                        IN p_ssn varchar(200),
                                                        IN p_bs_user_id varchar(200),
                                                        IN p_bs_import_user_id varchar(200),
                                                        IN p_bs_user_name varchar(200),
                                                        IN p_bs_employee_id varchar(200),
                                                        IN p_bs_work_email varchar(200),
                                                        IN p_bs_payroll_id varchar(200),
                                                        IN p_dob varchar(50),
                                                        IN p_bs_is_active int,
                                                        IN p_bs_is_employee int,
                                                        IN p_bs_is_manager int,
                                                        IN p_bs_is_topdog int,
                                                        IN p_bs_abbrev_url varchar(200),
                                                        IN p_bs_row_id int,
                                                        IN p_bs_employer_id varchar(200),
                                                        IN p_zip varchar(50),
                                                        IN p_is_used_for_registration varchar(200) )
full_proc:
BEGIN
    DECLARE v_count varchar(50) DEFAULT NULL;
    DECLARE v_user_id int DEFAULT NULL;
    DECLARE v_user_id2 int DEFAULT NULL;
    DECLARE v_is_locked int DEFAULT NULL;
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN
        GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
        CALL db_log_error( @errno , 'upsert_bs_platform_user' , @text , @sqlstate );
    END;
    
    SET p_email = api.api_fix_email( p_email );
    SET p_user_name = api.api_fix_email( p_user_name );
    SET p_ssn = api.api_fix_email( p_ssn );
    SET p_bs_employee_id = api.api_fix_email( p_bs_employee_id );
    SET p_mobile_number = api.api_fix_phone_number( p_mobile_number );
    SET p_dob = api.api_fix_date( p_dob );
    SET p_zip = api.api_fix_zip( p_zip );
    
    IF api.api_is_blank( p_user_name ) OR api.api_is_blank( p_email ) THEN
        CALL api.db_log_message( 'upsert_bs_platform_user' ,
                                 CONCAT( 'Not Inserting record as either email or username is blank ' ,
                                         'Import User ID: ' , api.api_nz( p_bs_import_user_id , '' ) ,
                                         ' AND UserName: ' , api.api_nz( p_bs_user_name , '' ) ) , 'WARN' );
        
        LEAVE full_proc;
    END IF;
    
    
    
    SELECT
        COUNT( * )
      , user_id
      , CASE
            WHEN is_verified THEN 1
            ELSE 0
        END
    INTO v_count, v_user_id, v_is_locked
    FROM
        api.platform_users
    WHERE
        (email = p_email);
    
    SET v_user_id = api.api_nz_int( v_user_id , 0 );
    SET v_is_locked = api.api_nz_int( v_is_locked , 0 );
    
    CALL api.db_log_message( 'upsert_bs_platform_user' ,
                             CONCAT( v_count , ' Records found for EMAIL: ' , api.api_nz( p_email , '' ) ) ,
                             'WARN' );
    
    
    IF (api.api_nz_int( p_bs_is_manager , 0 ) = 0 AND api.api_nz_int( p_bs_is_topdog , 0 ) = 0) THEN
        
        
        IF NOT p_is_used_for_registration THEN
            
            IF api.api_is_blank( p_ssn ) THEN
                CALL api.db_log_message( 'upsert_bs_platform_user' ,
                                         CONCAT(
                                                 'EXITING as Participant and not p_is_used_for_registration and SSN is blank ' ,
                                                 api.api_nz( p_email , '' ) ) , ', ' , api.api_nz( p_ssn , '' ) ,
                                         'WARN' );
                
                LEAVE full_proc;
            END IF;
            
            
            SELECT
                user_id
            INTO v_user_id2
            FROM
                api.platform_users
            WHERE
                  (email = p_email)
              AND (api.api_fix_ssn( ssn ) = api.api_fix_ssn( p_ssn ));
            
            
            IF NOT api.api_cbool( v_user_id2 ) THEN
                CALL api.db_log_message( 'upsert_bs_platform_user' ,
                                         CONCAT(
                                                 'EXITING as Participant and not p_is_used_for_registration and no match for Email and SSN ' ,
                                                 api.api_nz( p_email , '' ) , ', ' , api.api_nz( p_ssn , '' ) ) ,
                                         'WARN' );
                
                LEAVE full_proc;
            END IF;
            
            
            CALL api.db_log_message( 'upsert_bs_platform_user' ,
                                     CONCAT( v_count ,
                                             ' Records found for  EMAIL and SSN though Participant and not p_is_used_for_registration and not verified: ' ,
                                             api.api_nz( p_email , '' ) , ', ' , api.api_nz( p_ssn , '' ) ) ,
                                     'WARN' );
            
            
            UPDATE bs.bs_employees
            SET
                is_used_for_registration =1
            WHERE
                ROW_ID = p_bs_row_id;
            
            
            SET v_user_id = v_user_id2;
        
        END IF;
    END IF;
    
    IF api.api_cbool( v_user_id ) THEN
        CALL api.db_log_message( 'upsert_bs_platform_user' ,
                                 CONCAT( 'UPDATING existing ' , v_count , ' records for EMAIL: ' ,
                                         api.api_nz( p_email , '' ) ) , 'WARN' );
        
        UPDATE api.platform_users
        SET
            user_name         = api.api_if_true_else( v_is_locked , user_name , api.api_nz( p_user_name , user_name ) )
          , first_name        = api.api_if_true_else( v_is_locked , first_name ,
                                                      api.api_nz( p_first_name , first_name ) )
          , last_name         = api.api_if_true_else( v_is_locked , last_name , api.api_nz( p_last_name , last_name ) )
          , email             = api.api_if_true_else( v_is_locked , email , api.api_nz( p_email , email ) )
          , mobile_number     = api.api_if_true_else( v_is_locked , mobile_number ,
                                                      api.api_nz( p_mobile_number , mobile_number ) )
          , ssn               = api.api_if_true_else( v_is_locked , ssn , api.api_nz( p_ssn , ssn ) )
          , dob               = api.api_if_true_else( v_is_locked , dob , api.api_nz( p_dob , dob ) )
          , employee_id       = api.api_if_true_else( v_is_locked , employee_id ,
                                                      api.api_nz( p_bs_employee_id , employee_id ) )
          , bs_user_id        = api.api_nz( p_bs_user_id , bs_user_id )
          , bs_import_user_id = api.api_nz( p_bs_import_user_id , bs_import_user_id )
          , bs_user_name      = api.api_nz( p_bs_user_name , bs_user_name )
          , bs_payroll_id     = api.api_nz( p_bs_payroll_id , bs_payroll_id )
          , bs_dob            = api.api_nz( p_dob , bs_dob )
          , bs_ssn            = api.api_nz( p_ssn , bs_ssn )
          , bs_email          = api.api_nz( p_email , bs_email )
          , bs_user_is_active = api_cbool( api.api_nz( p_bs_is_active , bs_user_is_active ) )
          , bs_employer_id= api.api_nz( p_bs_employer_id , bs_employer_id )
          , bs_is_employee    = api_cbool( api.api_nz( p_bs_is_employee , bs_is_employee ) )
          , bs_is_manager= api_cbool( api.api_nz( p_bs_is_manager , bs_is_manager ) )
          , bs_is_topdog= api_cbool( api.api_nz( p_bs_is_topdog , bs_is_topdog ) )
          , bs_abbrev_url= (api_nz( p_bs_abbrev_url , bs_abbrev_url ))
          , bs_row_id= api.api_nz( p_bs_row_id , bs_row_id )
          , zip               = api.api_nz( p_zip , zip )
          , bs_zip            = api.api_nz( p_zip , bs_zip )
          , last_updated_from = 'upsert_bs_platform_user'
        WHERE
            (email = p_email);
        
        LEAVE full_proc;
    END IF;
    
    CALL api.db_log_message( 'upsert_bs_platform_user' ,
                             CONCAT( 'UPSERTING record for Import User ID: ' , api.api_nz( p_bs_import_user_id , '' ) ,
                                     ' AND Email: ' , api.api_nz( p_email , '' ) ) , 'WARN' );
    
    INSERT INTO api.platform_users(
                                    user_name
                                  , first_name
                                  , last_name
                                  , email
                                  , mobile_number
                                  , bs_user_id
                                  , bs_import_user_id
                                  , bs_user_name
                                  , bs_work_email
                                  , bs_payroll_id
                                  , bs_dob
                                  , dob
                                  , ssn
                                  , employee_id
                                  , bs_user_is_active
                                  , bs_employer_id
                                  , bs_ssn
                                  , bs_email
                                  , bs_is_employee
                                  , bs_is_manager
                                  , bs_is_topdog
                                  , bs_abbrev_url
                                  , bs_row_id
                                  , last_updated_from
                                  , zip
                                  , bs_zip
    )
    VALUES (
               p_user_name
           ,   p_first_name
           ,   p_last_name
           ,   p_email
           ,   p_mobile_number
           ,   p_bs_user_id
           ,   p_bs_import_user_id
           ,   p_bs_user_name
           ,   p_bs_work_email
           ,   p_bs_payroll_id
           ,   p_dob
           ,   p_dob
           ,   p_ssn
           ,   p_bs_employee_id
           ,   api_cbool( p_bs_is_active )
           ,   p_bs_employer_id
           ,   p_ssn
           ,   p_email
           ,   api_cbool( p_bs_is_employee )
           ,   api_cbool( p_bs_is_manager )
           ,   api_cbool( p_bs_is_topdog )
           ,   p_bs_abbrev_url
           ,   p_bs_row_id
           ,   'upsert_bs_platform_user'
           ,   p_zip
           ,   p_zip
           )
    
    ON DUPLICATE KEY UPDATE
                         user_name         = api.api_if_true_else( v_is_locked , user_name ,
                                                                   api.api_nz( p_user_name , user_name ) )
                       , first_name        = api.api_if_true_else( v_is_locked , first_name ,
                                                                   api.api_nz( p_first_name , first_name ) )
                       , last_name         = api.api_if_true_else( v_is_locked , last_name ,
                                                                   api.api_nz( p_last_name , last_name ) )
                       , email             = api.api_if_true_else( v_is_locked , email , api.api_nz( p_email , email ) )
                       , mobile_number     = api.api_if_true_else( v_is_locked , mobile_number ,
                                                                   api.api_nz( p_mobile_number , mobile_number ) )
                       , ssn               = api.api_if_true_else( v_is_locked , ssn , api.api_nz( p_ssn , ssn ) )
                       , dob               = api.api_if_true_else( v_is_locked , dob , api.api_nz( p_dob , dob ) )
                       , employee_id       = api.api_if_true_else( v_is_locked , employee_id ,
                                                                   api.api_nz( p_bs_employee_id , employee_id ) )
                       , bs_user_id        = api.api_nz( p_bs_user_id , bs_user_id )
                       , bs_import_user_id = api.api_nz( p_bs_import_user_id , bs_import_user_id )
                       , bs_user_name      = api.api_nz( p_bs_user_name , bs_user_name )
                       , bs_payroll_id     = api.api_nz( p_bs_payroll_id , bs_payroll_id )
                       , bs_dob            = api.api_nz( p_dob , bs_dob )
                       , bs_ssn            = api.api_nz( p_ssn , bs_ssn )
                       , bs_email          = api.api_nz( p_email , bs_email )
                       , bs_user_is_active = api_cbool( api.api_nz( p_bs_is_active , bs_user_is_active ) )
                       , bs_employer_id= api.api_nz( p_bs_employer_id , bs_employer_id )
                       , bs_is_employee    = api_cbool( api.api_nz( p_bs_is_employee , bs_is_employee ) )
                       , bs_is_manager= api_cbool( api.api_nz( p_bs_is_manager , bs_is_manager ) )
                       , bs_is_topdog= api_cbool( api.api_nz( p_bs_is_topdog , bs_is_topdog ) )
                       , bs_abbrev_url= (api_nz( p_bs_abbrev_url , bs_abbrev_url ))
                       , bs_row_id= api.api_nz( p_bs_row_id , bs_row_id )
                       , zip               = api.api_nz( p_zip , zip )
                       , bs_zip            = api.api_nz( p_zip , bs_zip )
                       , last_updated_from = 'upsert_bs_platform_user';

END;

