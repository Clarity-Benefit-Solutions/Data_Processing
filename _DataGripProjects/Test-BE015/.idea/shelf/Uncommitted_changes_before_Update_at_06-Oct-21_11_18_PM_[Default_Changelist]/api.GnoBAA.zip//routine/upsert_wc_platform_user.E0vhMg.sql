CREATE
    DEFINER = root@`%` PROCEDURE upsert_wc_platform_user(
                                                        IN p_user_name varchar(200),
                                                        IN p_email varchar(200),
                                                        IN p_first_name varchar(200),
                                                        IN p_last_name varchar(200),
                                                        IN p_mobile_number varchar(200),
                                                        IN p_ssn varchar(200),
                                                        IN p_wca_employer_id varchar(200),
                                                        IN p_wca_tpa_id varchar(200),
                                                        IN p_wca_client_user_id varchar(200),
                                                        IN p_wca_data_partner_id varchar(200),
                                                        IN p_wcp_tpa_id varchar(200),
                                                        IN p_wcp_employer_id varchar(200),
                                                        IN p_wcp_employee_id varchar(200),
                                                        IN p_dob varchar(200),
                                                        IN p_wc_card_number varchar(200),
                                                        IN p_wca_is_active int,
                                                        IN p_wcp_is_active int,
                                                        IN p_wca_row_id int,
                                                        IN p_wcp_row_id int,
                                                        IN p_wca_user_type varchar(50),
                                                        IN p_zip varchar(50) )
full_proc:

BEGIN
    DECLARE v_count varchar(50) DEFAULT NULL;
    DECLARE v_user_id varchar(50) DEFAULT NULL;
    DECLARE v_is_locked varchar(5) DEFAULT NULL;
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN
        GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
        CALL db_log_error( @errno , 'upsert_wc_sso_user' , @text , @sqlstate );
    END;
    
    SET p_email = api.api_fix_email( p_email );
    SET p_user_name = api.api_fix_email( p_user_name );
    SET p_mobile_number = api.api_fix_phone_number( p_mobile_number );
    SET p_ssn = api.api_fix_email( p_ssn );
    
    SET p_dob = api.api_fix_date( p_dob );
    SET p_zip = api.api_fix_zip( p_zip );
    
    IF api.api_is_blank( p_email ) AND api.api_is_blank( p_user_name ) THEN
        CALL api.db_log_message( 'upsert_wc_platform_user' ,
                                 CONCAT( 'Not Inserting record as username, email is blank ' , 'ClientUserId: ' ,
                                         api_nz( p_wca_client_user_id , '' ) , ' EmployeeID: ' ,
                                         api_nz( p_wcp_employee_id , '' ) ) , 'WARN' );
        
        LEAVE full_proc;
    END IF;
    IF api.api_is_blank( p_wca_client_user_id ) AND api.api_is_blank( p_wcp_employee_id ) THEN
        CALL api.db_log_error( 50001 , 'upsert_wc_platform_user' , CONCAT(
                'Not Inserting record as p_wca_client_user_id, p_wcp_employee_id are all blank ' , 'ClientUserId: ' ,
                api_nz( p_wca_client_user_id , '' ) , ' EmployeeID: ' , api_nz( p_wcp_employee_id , '' ) ) , 'WARN' );
        
        LEAVE full_proc;
    END IF;
    
    IF !api.api_is_blank( p_email ) THEN
        
        SELECT
            count( * )
          , user_id
          , CASE
                WHEN is_verified OR is_ready_for_sso_processing THEN 1
                ELSE 0
            END
        INTO v_count, v_user_id, v_is_locked
        FROM
            api.platform_users
        WHERE
            (email <=> p_email);
        
        SET v_user_id = api.api_nz( v_user_id , '' );
        
        CALL api.db_log_message( 'upsert_wc_platform_user' ,
                                 CONCAT( v_count , ' Records found for EMAIL: ' , api.api_nz( p_email , '' ) ) ,
                                 'WARN' );
        IF api.api_cbool( v_user_id ) THEN
            CALL api.db_log_message( 'upsert_wc_platform_user' ,
                                     CONCAT( 'UPDATING existing ' , v_count , ' records for EMAIL: ' ,
                                             api.api_nz( p_email , '' ) ) , 'WARN' );
            
            UPDATE api.platform_users
            SET
                user_name           = api_if_true_else( v_is_locked , user_name , api_nz( p_user_name , user_name ) )
              , first_name          = api_if_true_else( v_is_locked , first_name , api_nz( p_first_name , first_name ) )
              , last_name           = api_if_true_else( v_is_locked , last_name , api_nz( p_last_name , last_name ) )
              , email               = api_if_true_else( v_is_locked , email , api_nz( p_email , email ) )
              , mobile_number       = api_if_true_else( v_is_locked , mobile_number ,
                                                        api_nz( p_mobile_number , mobile_number ) )
              , ssn                 = api_if_true_else( v_is_locked , ssn , api_nz( p_ssn , ssn ) )
              , dob                 = api_if_true_else( v_is_locked , dob , api_nz( p_dob , dob ) )
              , employee_id         = api_if_true_else( v_is_locked , employee_id ,
                                                        api_nz( p_wcp_employee_id , employee_id ) )
              , wca_employer_id     = api_nz( p_wca_employer_id , wca_employer_id )
              , wca_tpa_id          = api_nz( p_wca_tpa_id , wca_tpa_id )
              , wca_client_user_id  = api_nz( p_wca_client_user_id , wca_client_user_id )
              , wca_data_partner_id = api_nz( p_wca_data_partner_id , wca_data_partner_id )
              , wcp_employer_id     = api_nz( p_wcp_employer_id , wcp_employer_id )
              , wcp_tpa_id          = api_nz( p_wcp_tpa_id , wcp_tpa_id )
              , wcp_employee_id     = api_nz( p_wcp_employee_id , wcp_employee_id )
              , wc_dob              = api_nz( p_dob , wc_dob )
              , wc_card_number      = api_nz( p_wc_card_number , wc_card_number )
              , wca_user_is_active  = api_nz( p_wca_is_active , wca_user_is_active )
              , wcp_user_is_active  = api_nz( p_wcp_is_active , wcp_user_is_active )
              , wc_ssn              = api_nz( p_ssn , wc_ssn )
              , wc_email            = api_nz( p_email , wc_email )
              , wca_row_id= ifnull( p_wca_row_id , wca_row_id )
              , wcp_row_id= ifnull( p_wcp_row_id , wcp_row_id )
              , wca_user_type       = p_wca_user_type
              , zip                 = api_nz( p_zip , zip )
              , wc_zip              = api_nz( p_zip , wc_zip )
              , last_updated_from   = 'upsert_wc_platform_user'
            
            WHERE
                (email <=> p_email);
            
            LEAVE full_proc;
        END IF;
    END IF;
    
    CALL api.db_log_message( 'upsert_wc_platform_user' ,
                             CONCAT( 'UPSERTING record WCA UserID: ' , api.api_nz( p_wca_client_user_id , '' ) ,
                                     ' AND WCP EmployeeID: ' , api.api_nz( p_wcp_employee_id , '' ) ) , 'WARN' );
    
    INSERT INTO api.platform_users(
                                    user_name
                                  , first_name
                                  , last_name
                                  , email
                                  , mobile_number
                                  , wca_employer_id
                                  , wca_tpa_id
                                  , wca_client_user_id
                                  , wca_data_partner_id
                                  , wcp_employer_id
                                  , wcp_tpa_id
                                  , wcp_employee_id
                                  , wc_dob
                                  , dob
                                  , ssn
                                  , employee_id
                                  , wc_card_number
                                  , wca_user_is_active
                                  , wcp_user_is_active
                                  , wc_ssn
                                  , wc_email
                                  , wca_row_id
                                  , wcp_row_id
                                  , last_updated_from
                                  , wca_user_type
                                  , zip
                                  , wc_zip
    )
    VALUES (
               p_user_name
           ,   p_first_name
           ,   p_last_name
           ,   p_email
           ,   p_mobile_number
           ,   p_wca_employer_id
           ,   p_wca_tpa_id
           ,   p_wca_client_user_id
           ,   p_wca_data_partner_id
           ,   p_wcp_employer_id
           ,   p_wcp_tpa_id
           ,   p_wcp_employee_id
           ,   p_dob
           ,   p_dob
           ,   p_ssn
           ,   p_wcp_employee_id
           ,   p_wc_card_number
           ,   p_wca_is_active
           ,   p_wcp_is_active
           ,   p_ssn
           ,   p_email
           ,   p_wca_row_id
           ,   p_wcp_row_id
           ,   'upsert_wc_platform_user'
           ,   p_wca_user_type
           ,   p_zip
           ,   p_zip
           )
    
    ON DUPLICATE KEY UPDATE
                         user_name           = api_if_true_else( v_is_locked , user_name ,
                                                                 api_nz( p_user_name , user_name ) )
                       , first_name          = api_if_true_else( v_is_locked , first_name ,
                                                                 api_nz( p_first_name , first_name ) )
                       , last_name           = api_if_true_else( v_is_locked , last_name ,
                                                                 api_nz( p_last_name , last_name ) )
                       , email               = api_if_true_else( v_is_locked , email , api_nz( p_email , email ) )
                       , mobile_number       = api_if_true_else( v_is_locked , mobile_number ,
                                                                 api_nz( p_mobile_number , mobile_number ) )
                       , ssn                 = api_if_true_else( v_is_locked , ssn , api_nz( p_ssn , ssn ) )
                       , dob                 = api_if_true_else( v_is_locked , dob , api_nz( p_dob , dob ) )
                       , employee_id         = api_if_true_else( v_is_locked , employee_id ,
                                                                 api_nz( p_wcp_employee_id , employee_id ) )
                       , wca_employer_id     = api_nz( p_wca_employer_id , wca_employer_id )
                       , wca_tpa_id          = api_nz( p_wca_tpa_id , wca_tpa_id )
                       , wca_client_user_id  = api_nz( p_wca_client_user_id , wca_client_user_id )
                       , wca_data_partner_id = api_nz( p_wca_data_partner_id , wca_data_partner_id )
                       , wcp_employer_id     = api_nz( p_wcp_employer_id , wcp_employer_id )
                       , wcp_tpa_id          = api_nz( p_wcp_tpa_id , wcp_tpa_id )
                       , wcp_employee_id     = api_nz( p_wcp_employee_id , wcp_employee_id )
                       , wc_dob              = api_nz( p_dob , wc_dob )
                       , wc_card_number      = api_nz( p_wc_card_number , wc_card_number )
                       , wca_user_is_active  = api_nz( p_wca_is_active , wca_user_is_active )
                       , wcp_user_is_active  = api_nz( p_wcp_is_active , wcp_user_is_active )
                       , wc_ssn              = api_nz( p_ssn , wc_ssn )
                       , wc_email            = api_nz( p_email , wc_email )
                       , wca_row_id= ifnull( p_wca_row_id , wca_row_id )
                       , wcp_row_id= ifnull( p_wcp_row_id , wcp_row_id )
                       , wca_user_type= ifnull( p_wca_user_type , wca_user_type )
                       , zip                 = api_nz( p_zip , zip )
                       , wc_zip              = api_nz( p_zip , wc_zip )
                       , last_updated_from   = 'upsert_wc_platform_user';
END;

