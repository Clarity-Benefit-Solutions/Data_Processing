create
    definer = root@`%` procedure upsert_all_cp_platform_users_2(
                                                               IN p_email varchar(200),
                                                               IN p_order_seq_no int )
full_proc:

BEGIN
    DECLARE v_email varchar(200);
    DECLARE v_is_active int;
    DECLARE v_user_type varchar(200);
    DECLARE v_row_id varchar(200);
    DECLARE v_is_used_for_registration varchar(200);
    DECLARE v_orderseq varchar(200);
    DECLARE v_entitytype varchar(200);
    DECLARE v_memberid varchar(200);
    DECLARE v_brokerid varchar(200);
    DECLARE v_clientcontactid varchar(200);
    DECLARE v_clientid varchar(200);
    DECLARE v_clientdivisionid varchar(200);
    DECLARE v_organizationname varchar(200);
    DECLARE v_divisionname varchar(200);
    DECLARE v_individualidentifier varchar(200);
    DECLARE v_contacttype varchar(200);
    DECLARE v_salutation varchar(200);
    DECLARE v_firstname varchar(200);
    DECLARE v_lastname varchar(200);
    DECLARE v_dob varchar(200);
    DECLARE v_title varchar(200);
    DECLARE v_department varchar(200);
    DECLARE v_phone varchar(200);
    DECLARE v_phone2 varchar(200);
    DECLARE v_city varchar(200);
    DECLARE v_state varchar(200);
    DECLARE v_postalcode varchar(200);
    DECLARE v_country varchar(200);
    DECLARE v_active varchar(200);
    DECLARE v_loginstatus varchar(200);
    DECLARE v_registrationcode varchar(200);
    DECLARE v_registrationdate varchar(200);
    DECLARE v_userdisplayname varchar(200);
    DECLARE v_allowsso varchar(200);
    DECLARE v_ssoidentifier varchar(200);
    DECLARE v_userid varchar(200);
    DECLARE v_ssn varchar(200);
    DECLARE v_employeeid varchar(200);
    DECLARE v_qualeventdate varchar(200);
    DECLARE v_is_broker_user_active int;
    DECLARE v_is_client_user_active int;
    DECLARE v_is_tpa_user_active int;
    DECLARE v_is_member_user_active int;
    
    DECLARE v_finished int;
    
    
    DECLARE v_values_cursor CURSOR FOR SELECT
                                           t.is_used_for_registration
                                         , t.email
                                         , t.is_active
                                         , t.user_type
                                         , t.row_id
                                         , t.orderseq
                                         , t.entitytype
                                         , t.memberid
                                         , t.brokerid
                                         , t.clientcontactid
                                         , t.clientid
                                         , t.clientdivisionid
                                         , t.organizationname
                                         , t.divisionname
                                         , t.individualidentifier
                                         , t.contacttype
                                         , t.salutation
                                         , t.firstname
                                         , t.lastname
                                         , t.title
                                         , t.department
                                         , t.phone
                                         , t.phone2
                                         , t.city
                                         , t.state
                                         , t.postalcode
                                         , t.country
                                         , t.active
                                         , t.loginstatus
                                         , t.registrationcode
                                         , t.registrationdate
                                         , t.userdisplayname
                                         , t.allowsso
                                         , t.ssoidentifier
                                         , t.userid
                                         , t.ssn
                                         , t.employeeid
                                         , t.dob
                                         , t.qualeventdate
                                         , CASE
                                               WHEN is_active AND t.user_type LIKE '%BROKER%' THEN 1
                                               ELSE 0
                                           END is_broker_user_active
                                         , CASE
                                               WHEN is_active AND t.user_type LIKE '%CLIENT%' THEN 1
                                               ELSE 0
                                           END is_client_user_active
                                         , CASE
                                               WHEN is_active AND t.user_type LIKE '%TPA%' THEN 1
                                               ELSE 0
                                           END is_tpa_user_active
                                         , CASE
                                               WHEN is_active AND (t.user_type LIKE '%QB%' OR t.user_type LIKE '%SPM%')
                                                   THEN 1
                                               ELSE 0
                                           END is_member_user_active
                                       FROM
                                           cp.vw_cp_all_sso_users t
                                       WHERE
                                             email = p_email
                                         AND t.orderseq = p_order_seq_no
                                       ORDER BY
                                           
                                           email
                                         , t.is_active DESC
                                         , t.user_type DESC
                                         , t.registrationdate DESC
                                       LIMIT 1
    
    
    
    ;
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND BEGIN
        SET v_finished = 1;
    END;
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN
        GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
        CALL db_throw_error( @errno , 'upsert_all_cp_platform_users_2' , @text );
    END;
    
    SET @@max_sp_recursion_depth = 12;
    
    OPEN v_values_cursor;
    
    getvalues
        :
    LOOP
        FETCH v_values_cursor INTO v_is_used_for_registration, v_email , v_is_active , v_user_type , v_row_id , v_orderseq , v_entitytype , v_memberid , v_brokerid , v_clientcontactid , v_clientid , v_clientdivisionid , v_organizationname, v_divisionname, v_individualidentifier , v_contacttype , v_salutation , v_firstname , v_lastname , v_title , v_department , v_phone , v_phone2 , v_city , v_state , v_postalcode , v_country , v_active , v_loginstatus , v_registrationcode , v_registrationdate , v_userdisplayname , v_allowsso , v_ssoidentifier , v_userid , v_ssn , v_employeeid, v_dob, v_qualeventdate, v_is_broker_user_active, v_is_client_user_active, v_is_tpa_user_active, v_is_member_user_active;
        
        IF v_finished = 1 THEN
            LEAVE getvalues;
        END IF;
        
        IF !api.api_is_blank( v_email ) THEN
            CALL api.db_log_message( 'upsert_all_cp_platform_users_2' ,
                                     CONCAT( 'Processing CP contact for email: ' , p_email , ' orderseq: ' ,
                                             p_order_seq_no ,
                                             ' using record with row_id  ' , v_row_id , ' and user_type ' ,
                                             v_user_type ) , 'WARN' );
            
            IF FALSE THEN
                SET v_is_active = '2';
            END IF;
            
            CALL api.upsert_cp_platform_user( v_email , v_email , v_firstname , v_lastname , NULL , v_title , v_phone ,
                                              v_ssn , v_employeeid , v_clientid , v_brokerid , v_clientcontactid ,
                                              v_ssoidentifier , api.cp_get_default_customer_id( ) , v_entitytype ,
                                              v_userid , v_memberid , v_allowsso , v_dob , v_is_tpa_user_active ,
                                              v_is_member_user_active , v_row_id , v_is_client_user_active ,
                                              v_is_broker_user_active , v_organizationname , v_divisionname ,
                                              v_contacttype , v_registrationcode , v_registrationdate , v_postalcode , v_qualeventdate,
                                              v_is_used_for_registration );
        END IF;
    END LOOP getvalues;
END;

