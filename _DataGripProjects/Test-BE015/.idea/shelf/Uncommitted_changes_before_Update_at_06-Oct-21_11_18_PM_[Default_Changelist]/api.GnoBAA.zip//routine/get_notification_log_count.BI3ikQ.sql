create
    definer = root@`%` function get_notification_log_count(
                                                          p_email varchar(200),
                                                          p_notification_type varchar(200),
                                                          p_notification_category varchar(200),
                                                          p_notification_sub_category varchar(200) ) returns int
BEGIN
    DECLARE v_count int(11);
    
    IF api.api_is_blank( p_email ) OR api.api_is_blank( p_notification_type ) OR
       api.api_is_blank( p_notification_category ) THEN
        RETURN 0;
    END IF;
    
    IF api.api_is_blank( p_notification_sub_category ) THEN
        SET p_notification_sub_category = '%';
    END IF;
    
    SELECT
        COUNT( * )
    INTO v_count
    FROM
        api.api_notification_logs
    WHERE
          destination_address = p_email
      AND notification_type LIKE p_notification_type
      AND notification_category LIKE p_notification_category
      AND (p_notification_sub_category = '%' OR notification_sub_category LIKE p_notification_sub_category);
    
    RETURN api.api_nz_int( v_count , 0 );
END;

