create
    definer = admin@`%` function util_generate_upsert_sql_nz_string( p_column_type varchar(100) ) returns varchar(100)
BEGIN
    IF instr( p_column_type , 'float' ) > 0 OR instr( p_column_type , 'double' ) > 0 THEN
        RETURN 'api.api_nz_float';
    ELSEIF instr( p_column_type , 'int' ) > 0 OR instr( p_column_type , 'bool' ) > 0 THEN
        RETURN 'api.api_nz_int';
    ELSEIF instr( p_column_type , 'date' ) > 0 THEN
        RETURN 'api.api_nz_date';
    ELSE
        RETURN 'api.api_nz';
    END IF;

END;

