create
    definer = root@`%` procedure upsert_bt_platform_user(
                                                        IN p_user_name varchar(200),
                                                        IN p_email varchar(200),
                                                        IN p_bt_row_id int,
                                                        IN p_bt_is_active int,
                                                        IN p_bt_user_type varchar(200) )
full_proc:
BEGIN
    DECLARE v_count varchar(50) DEFAULT NULL;
    DECLARE v_user_id varchar(50) DEFAULT NULL;
    DECLARE v_is_locked varchar(5) DEFAULT NULL;
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN
        GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
        CALL db_log_error( @errno , 'upsert_bt_platform_user' , @text , @sqlstate );
    END;
    
    SET p_email = api.api_fix_email( p_email );
    SET p_user_name = api.api_fix_email( p_user_name );
    
    IF api.api_is_blank( p_user_name ) OR api.api_is_blank( p_email ) THEN
        CALL api.db_log_message( 'upsert_bt_platform_user' ,
                                 CONCAT( 'Not Inserting record as either email or username is blank ' , 'Row ID: ' ,
                                         api.api_nz( p_bt_row_id , '' ) ) , 'WARN' );
        
        LEAVE full_proc;
    END IF;
    
    IF !api.api_is_blank( p_email ) THEN
        
        SELECT
            COUNT( * )
          , user_id
          , CASE
                WHEN is_verified OR is_ready_for_sso_processing THEN 1
                ELSE 0
            END
        INTO v_count, v_user_id, v_is_locked
        FROM
            api.platform_users
        WHERE
            (email = p_email);
        
        SET v_user_id = api.api_nz( v_user_id , '' );
        
        CALL api.db_log_message( 'upsert_bt_platform_user' ,
                                 CONCAT( v_count , ' Records found for EMAIL: ' , api.api_nz( p_email , '' ) ) ,
                                 'WARN' );
        IF api.api_cbool( v_user_id ) THEN
            CALL api.db_log_message( 'upsert_bt_platform_user' ,
                                     CONCAT( 'UPDATING existing ' , v_count , ' records for EMAIL: ' ,
                                             api.api_nz( p_email , '' ) ) , 'WARN' );
            
            UPDATE api.platform_users
            SET
                user_name         = api_if_true_else( v_is_locked , user_name , api_nz( p_user_name , user_name ) )
              
              , email             = api_if_true_else( v_is_locked , email , api_nz( p_email , email ) )
              , bt_user_is_active = api_cint( api_nz( p_bt_is_active , bt_user_is_active ) )
              , bt_row_id= api_nz( p_bt_row_id , bt_row_id )
              , bt_user_type= api_nz( p_bt_user_type , bt_user_type )
              , last_updated_from = 'upsert_bt_platform_user'
            WHERE
                (email = p_email);
            
            LEAVE full_proc;
        END IF;
    END IF;
    
    CALL api.db_log_message( 'upsert_bt_platform_user' ,
                             CONCAT( 'UPSERTING record for Email: ' , api.api_nz( p_email , '' ) ) , 'WARN' );
    
    INSERT INTO api.platform_users(
                                    user_name
    
                                  , email
                                  , bt_user_is_active
                                  , bt_user_type
                                  , bt_row_id
                                  , last_updated_from
    )
    VALUES (
               p_user_name
    
           ,   p_email
           ,   api_cint( p_bt_is_active )
           ,   p_bt_user_type
           ,   p_bt_row_id
           ,   'upsert_bt_platform_user'
           )
    
    ON DUPLICATE KEY UPDATE
                         user_name         = api_if_true_else( v_is_locked , user_name ,
                                                               api_nz( p_user_name , user_name ) )
      
                       , email             = api_if_true_else( v_is_locked , email , api_nz( p_email , email ) )
       
                       , bt_user_is_active = api_cint( api_nz( p_bt_is_active , bt_user_is_active ) )
                       , bt_row_id= api_nz( p_bt_row_id , bt_row_id )
                       , bt_user_type= api_nz( p_bt_user_type , bt_user_type )
                       , last_updated_from = 'upsert_bt_platform_user';

END;

