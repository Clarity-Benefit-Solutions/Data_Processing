create
    definer = admin@`%` function api_fix_date( value varchar(200) ) returns date
BEGIN
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
        BEGIN
            GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE, @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
            CALL api.db_log_error( @errno , 'api_fix_date' , @text , @sqlstate );
            return null;
        END;
    
    if api.api_is_blank( value ) or value = '<NULL>' THEN
        return null;
    end if;
    
    set value = replace( value , '-' , '/' );
    if position( '/' in value ) < 5 then
        return api.api_fix_date_us_format( value );
    end if;
    return cast( value as date );

END;

