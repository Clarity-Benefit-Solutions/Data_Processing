create
    definer = root@`%` procedure temp_fix_api_cases_data_2(
                                                          IN p_case_id varchar(100),
                                                          IN p_audit_id int )
BEGIN

    DECLARE v_is_ready_for_processing varchar(200);
    DECLARE v_case_status varchar(200);
    DECLARE v_form_initial_summary longtext;
    DECLARE v_form_user_sumbission longtext;
    DECLARE v_form_final_summary longtext;
    DECLARE v_is_used_for_testing longtext;
    DECLARE v_case_id varchar(200) DEFAULT NULL;
    DECLARE v_audit_id int(11);
    SELECT DISTINCT case_id
                  , auditid
                  , is_ready_for_processing
                  , case_status
                  , form_initial_summary
                  , form_user_sumbission
                  , form_final_summary
                  , is_used_for_testing
    INTO v_case_id,
        v_audit_id ,
        v_is_ready_for_processing
        , v_case_status
        , v_form_initial_summary
        , v_form_user_sumbission
        , v_form_final_summary
        , v_is_used_for_testing
    FROM api.api_cases_audit
    WHERE case_id = p_case_id
      AND auditId = p_audit_id;

    IF !api.api_is_blank( v_case_id ) AND !api.api_is_blank( v_audit_id ) THEN
        CALL api.db_log_message( 'temp_fix_api_cases_data_2',
                                 CONCAT(
                                         'Update Case: ',
                                         v_case_id,
                                         ' with data from AuditId: ',
                                         v_audit_id,
                                         ' is_ready_for_processing = ', v_is_ready_for_processing
                                     , ' case_status             = ', v_case_status
                                     , ' is_used_for_testing     =', v_is_used_for_testing
                                     ), 'WARN' );

        UPDATE api.api_cases
        SET is_ready_for_processing =v_is_ready_for_processing
          , case_status             = v_case_status
          , form_initial_summary    = v_form_initial_summary
          , form_user_sumbission    = v_form_user_sumbission
          , form_final_summary      = v_form_final_summary
          , is_used_for_testing     =v_is_used_for_testing
        WHERE case_id = v_case_id;
    ELSE
        CALL api.db_log_message( 'temp_fix_api_cases_data_2',
                                 CONCAT(
                                         'Failed to Get Audit And  Case ID for Case: ',
                                         p_case_id,
                                         ' with data from AuditId: ',
                                         p_audit_id
                                     ), 'ERROR' );
    END IF;
END;

