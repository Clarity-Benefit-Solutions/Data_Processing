create
    definer = root@`%` function temp_get_last_submitted_on_cc_from_audit( p_cobra_continuation_id varchar(50) ) returns datetime
BEGIN
    
    DECLARE v_id int(11);
    DECLARE v_ret datetime;
    
    SELECT
        MAX( auditId )
    INTO
        v_id
    FROM
        cobra_continuation_audit
    WHERE
          cobra_continuation_audit.cobra_continuation_id = p_cobra_continuation_id
      AND auditAction = 'UPDATE'
      AND submitted_on IS NOT NULL
    and submitted_on < '2021-05-10 08:43:21';
    
    SELECT
        submitted_on
    INTO v_ret
    FROM
        cobra_continuation_audit
    WHERE
        auditId = v_id;
    
    RETURN v_ret;
END;

