create
    definer = root@`%` function api_split_str(
                                             value varchar(255),
                                             delim varchar(12),
                                             pos int ) returns varchar(255)
BEGIN
    IF POSITION( delim IN value ) <= 0 THEN
        RETURN value;
    END IF;
    RETURN REPLACE( SUBSTRING( SUBSTRING_INDEX( value , delim , pos ) ,
                               LENGTH( SUBSTRING_INDEX( value , delim , pos - 1 ) ) + 1 ) ,
                    delim , '' );
END;

