create
    definer = root@`%` function api_nz2( value text ) returns text
BEGIN
    IF ifnull(
               value
           , '') = ''
    THEN
        RETURN '';
        
    ELSEIF ifnull(
                   value
               , '') = '<NULL>' THEN
        RETURN NULL;
    ELSE
        RETURN value;
    END IF;
END;

