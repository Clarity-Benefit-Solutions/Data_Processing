create definer = root@`%` trigger au_audit_cobra_continuation_deletes
    after delete
    on cobra_continuation
    for each row
    INSERT INTO `api`.`cobra_continuation_audit`
                 (
                 `auditAction`,
                 `cobra_continuation_id`,
                 `status`,
                 `continuation_type`,
                 `memberid`,
                 `brokerid`,
                 `clientid`,
                 `employerid`,
                 `clientname`,
                 `salutation`,
                 `firstname`,
                 `lastname`,
                 `email`,
                 `ssn`,
                 `dob`,
                 `phone`,
                 `cobra_event_date`,
                 `cobra_last_day_of_coverage`,
                 `event_type`,
                 `ae_2021_is_eligible`,
                 `submitted_on`,
                 `submitted_by`,
                 `uploaded_on`,
                 `created_at`,
                 `created_by`,
                 `updated_at`,
                 `updated_by`
                 )
                 VALUES (
                        'DELETE',
                        OLD.`cobra_continuation_id`,
                        OLD.`status`,
                        OLD.`continuation_type`,
                        OLD.`memberid`,
                        OLD.`brokerid`,
                        OLD.`clientid`,
                        OLD.`employerid`,
                        OLD.`clientname`,
                        OLD.`salutation`,
                        OLD.`firstname`,
                        OLD.`lastname`,
                        OLD.`email`,
                        OLD.`ssn`,
                        OLD.`dob`,
                        OLD.`phone`,
                        OLD.`cobra_event_date`,
                        OLD.`cobra_last_day_of_coverage`,
                        OLD.`event_type`,
                        OLD.`ae_2021_is_eligible`,
                        OLD.`submitted_on`,
                        OLD.`submitted_by`,
                        OLD.`uploaded_on`,
                        OLD.`created_at`,
                        OLD.`created_by`,
                        OLD.`updated_at`,
                        OLD.`updated_by`
                        );

