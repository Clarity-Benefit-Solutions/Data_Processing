create definer = admin@`%` trigger au_audit_api_import_deletes
    after delete
    on api_import
    for each row
    INSERT INTO `api`.`api_import_audit`
                 (`auditAction`,`import_id`,`uploaded_by_user_id`,`file`,`file_orignal_name`,`file_converted_name`,`file_size`,`file_mime_type`,`created_at`,`updated_at`,`created_by`,`updated_by`)
                 VALUES
                 ('DELETE',OLD.`import_id`,OLD.`uploaded_by_user_id`,OLD.`file`,OLD.`file_orignal_name`,OLD.`file_converted_name`,OLD.`file_size`,OLD.`file_mime_type`,OLD.`created_at`,OLD.`updated_at`,OLD.`created_by`,OLD.`updated_by`);

