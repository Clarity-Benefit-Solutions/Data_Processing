create definer = admin@`%` trigger util_bi_api_case_plan_cobra_coverage_new_set_id
    before insert
    on api_case_plan_cobra_coverage
    for each row
BEGIN
    IF api.api_is_blank(new.case_plan_coverage_id) THEN
        SET new.case_plan_coverage_id = api.api_uuid();
    END IF;
END;

