create definer = admin@`%` trigger util_bi_platform_users_new_prod_set_updated_at_and_by
    before insert
    on platform_users
    for each row
BEGIN
    SET new.created_at = CURRENT_TIMESTAMP;
    SET new.created_by = current_user;
    SET new.updated_at = CURRENT_TIMESTAMP;
    SET new.updated_by = current_user;
END;

