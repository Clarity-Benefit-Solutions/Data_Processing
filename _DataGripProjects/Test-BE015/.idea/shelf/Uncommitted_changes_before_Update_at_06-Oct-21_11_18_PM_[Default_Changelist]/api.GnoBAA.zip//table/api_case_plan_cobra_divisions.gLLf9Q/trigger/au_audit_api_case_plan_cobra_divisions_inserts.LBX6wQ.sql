create definer = admin@`%` trigger au_audit_api_case_plan_cobra_divisions_inserts
    after insert
    on api_case_plan_cobra_divisions
    for each row
    INSERT INTO `api`.`api_case_plan_cobra_divisions_audit`
                 (`auditAction`, `case_plan_division_id`, `case_plan_id`, `status`, `version_no`, `division_sort_order`,
                  `division_name`, `created_at`, `created_by`, `updated_at`, `updated_by`)
                 VALUES ('INSERT', NEW.`case_plan_division_id`, NEW.`case_plan_id`, NEW.`status`, NEW.`version_no`,
                         NEW.`division_sort_order`, NEW.`division_name`, NEW.`created_at`, NEW.`created_by`,
                         NEW.`updated_at`, NEW.`updated_by`);

