create definer = root@`%` trigger util_bi_api_case_contacts_new_set_id
    before insert
    on api_case_contacts
    for each row
BEGIN
    IF api.api_is_blank(new.case_contact_id) THEN
        SET new.case_contact_id = api.api_uuid();
    END IF;

    
    SET new.contact_email_org = new.contact_email;
END;

