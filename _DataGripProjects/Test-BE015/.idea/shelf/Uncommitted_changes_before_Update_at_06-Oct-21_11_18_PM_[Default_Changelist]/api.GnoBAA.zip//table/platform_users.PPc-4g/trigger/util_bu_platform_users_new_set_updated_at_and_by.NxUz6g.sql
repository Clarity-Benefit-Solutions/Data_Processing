create definer = root@`%` trigger util_bu_platform_users_new_set_updated_at_and_by
    before update
    on platform_users
    for each row
BEGIN
    
    IF old.user_synced_to_mini_orange <> new.user_synced_to_mini_orange THEN
        SET new.updated_at = old.updated_at;
        SET new.updated_by = old.updated_by;
    ELSE
        SET new.updated_at = CURRENT_TIMESTAMP;
        SET new.updated_by = current_user;
        SET new.user_synced_to_mini_orange = 0;
    END IF;
END;

