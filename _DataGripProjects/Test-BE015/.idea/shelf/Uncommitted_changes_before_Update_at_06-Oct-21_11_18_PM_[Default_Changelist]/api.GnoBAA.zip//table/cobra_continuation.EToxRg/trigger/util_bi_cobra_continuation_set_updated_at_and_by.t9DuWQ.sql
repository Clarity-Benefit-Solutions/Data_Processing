create definer = root@`%` trigger util_bi_cobra_continuation_set_updated_at_and_by
    before insert
    on cobra_continuation
    for each row
BEGIN
    IF api.api_is_blank( new.cobra_continuation_id ) THEN
        SET new.cobra_continuation_id = api_uuid( );
    END IF;
    
    SET new.created_at = CURRENT_TIMESTAMP;
    SET new.created_by = CURRENT_USER;
    SET new.updated_at = CURRENT_TIMESTAMP;
    SET new.updated_by = CURRENT_USER;
END;

