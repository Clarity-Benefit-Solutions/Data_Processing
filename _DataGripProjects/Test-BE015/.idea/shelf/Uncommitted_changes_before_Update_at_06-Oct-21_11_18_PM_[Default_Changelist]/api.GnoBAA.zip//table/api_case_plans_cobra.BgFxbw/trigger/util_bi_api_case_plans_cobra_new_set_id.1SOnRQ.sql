create definer = admin@`%` trigger util_bi_api_case_plans_cobra_new_set_id
    before insert
    on api_case_plans_cobra
    for each row
BEGIN
    IF api.api_is_blank(new.case_plan_id) THEN
        SET new.case_plan_id = api.api_uuid();
    END IF;
END;

