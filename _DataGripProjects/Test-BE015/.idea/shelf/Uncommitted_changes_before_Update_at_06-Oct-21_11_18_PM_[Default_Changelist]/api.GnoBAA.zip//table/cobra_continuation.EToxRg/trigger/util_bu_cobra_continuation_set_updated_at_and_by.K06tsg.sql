create definer = root@`%` trigger util_bu_cobra_continuation_set_updated_at_and_by
    before update
    on cobra_continuation
    for each row
BEGIN
    SET new.updated_at = CURRENT_TIMESTAMP;
    SET new.updated_by = CURRENT_USER;
END;

