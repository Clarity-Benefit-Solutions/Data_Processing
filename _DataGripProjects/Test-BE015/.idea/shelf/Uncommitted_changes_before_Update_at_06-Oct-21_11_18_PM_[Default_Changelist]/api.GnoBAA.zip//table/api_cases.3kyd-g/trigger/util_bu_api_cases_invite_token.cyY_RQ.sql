create definer = root@`%` trigger util_bu_api_cases_invite_token
    before update
    on api_cases
    for each row
BEGIN
    DECLARE v_portalPath varchar(100);
    DECLARE v_invite_token varchar(100);
    
    IF api.api_is_blank( new.form_invite_token ) OR new.form_invite_token <= '0' THEN
        SET v_invite_token = api.api_uuid( );
        SET new.form_invite_token = v_invite_token;
    ELSE
        SET v_invite_token = new.form_invite_token;
    END IF;
    
    SET v_portalPath = 'https://portal.claritybenefitsolutions.com';
    
    IF new.case_type = 'Renewal' THEN
        IF new.case_sub_type = 'CONSUMER_BENEFIT' THEN
            SET v_portalPath = CONCAT( v_portalPath , '/renewals/consumer-benefits/step-1?token=' );
        ELSEIF new.case_sub_type = 'COBRA' THEN
            SET v_portalPath = CONCAT( v_portalPath , '/renewals/cobra-benefits/step-1?token=' );
        ELSE
            SET v_portalPath = CONCAT( v_portalPath , '/case/?token=' );
        END IF;
    ELSE
        SET v_portalPath = CONCAT( v_portalPath , '/case/?token=' );
    END IF;
    
    SET new.portal_case_edit_url = CONCAT( v_portalPath , v_invite_token );

END;

