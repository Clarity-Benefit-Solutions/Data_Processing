create definer = admin@`%` trigger bd_api_cases_new_NO_deletes
    before delete
    on api_cases
    for each row
BEGIN
   
END;

