create definer = root@`%` trigger util_bu_platform_user_events_new_set_updated_at_and_by
    before update
    on platform_user_events
    for each row
BEGIN
    SET new.updated_at = CURRENT_TIMESTAMP;
    SET new.updated_by = current_user;
END;

