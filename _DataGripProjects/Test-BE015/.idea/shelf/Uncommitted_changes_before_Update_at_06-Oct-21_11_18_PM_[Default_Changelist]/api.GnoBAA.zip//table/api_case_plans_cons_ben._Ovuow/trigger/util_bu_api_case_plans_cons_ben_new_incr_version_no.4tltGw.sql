create definer = admin@`%` trigger util_bu_api_case_plans_cons_ben_new_incr_version_no
    before update
    on api_case_plans_cons_ben
    for each row
BEGIN
    
    IF api.api_nz(new.status, '') <> api.api_nz(old.status, '') THEN
        SET new.version_no = api.api_nz(new.version_no, 0) + 1;
    END IF;
END;

