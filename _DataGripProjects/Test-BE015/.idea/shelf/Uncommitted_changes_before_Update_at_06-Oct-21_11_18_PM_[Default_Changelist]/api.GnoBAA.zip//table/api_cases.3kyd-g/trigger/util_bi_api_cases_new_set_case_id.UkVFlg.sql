create definer = root@`%` trigger util_bi_api_cases_new_set_case_id
    before insert
    on api_cases
    for each row
BEGIN
    IF api.api_is_blank(new.case_id) THEN
        SET new.case_id = api.api_uuid();
    END IF;

    if api.api_is_blank(new.legal_business_name) then
        set new.legal_business_name = new.employer_name;
    end if;
END;

