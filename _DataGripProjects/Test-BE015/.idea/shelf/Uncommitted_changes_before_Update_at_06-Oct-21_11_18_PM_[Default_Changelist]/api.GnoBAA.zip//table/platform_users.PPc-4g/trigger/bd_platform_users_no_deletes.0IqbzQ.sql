create definer = root@`%` trigger bd_platform_users_no_deletes
    before delete
    on platform_users
    for each row
BEGIN
    CALL api.db_throw_error( 50001 , 'api.bd_platform_users_new_NO_deletes' ,
                             'Cannot delete records from api.platform_users_new' );
END;

