create definer = root@`%` view vw_platform_users_base
as
    select
        `api`.`platform_users`.`user_name` `user_name`
      , `api`.`platform_users`.`email` `email`
      , `api`.`platform_users`.`user_id` `user_id`
      , `api`.`platform_users`.`first_name` `first_name`
      , `api`.`platform_users`.`last_name` `last_name`
      , `api`.`platform_users`.`is_invalid` `is_invalid`
      , `api`.`platform_users`.`is_ready_for_sso_processing` `is_ready_for_sso_processing`
      , `api`.`platform_users`.`invited_as_user_type` `invited_as_user_type`
      , case
            when !`api_is_blank`( `api`.`platform_users`.`cp_user_id` ) and
                 `api_cbool`( `api`.`platform_users`.`cp_tpa_user_is_active` ) then 1
            else 0
        end `is_cp_tpa_admin`
      , case
            when `api`.`platform_users`.`cp_broker_id` > '0' and
                 `api_cbool`( `api`.`platform_users`.`cp_broker_user_is_active` ) then 1
            else 0
        end `is_cp_broker`
      , case
            when `api`.`platform_users`.`cp_client_contact_id` > '0' and
                 `api_cbool`( `api`.`platform_users`.`cp_client_user_is_active` ) then 1
            else 0
        end `is_cp_client`
      , case
            when `api`.`platform_users`.`cp_member_id` > '0' and
                 `api_cbool`( `api`.`platform_users`.`cp_member_user_is_active` ) then 1
            else 0
        end `is_cp_particpant`
      , case
            when `api`.`platform_users`.`wca_user_type` like '%TPA%' or
                 `api_is_blank`( `api`.`platform_users`.`wca_employer_id` ) and `api_cbool`(
                             `api`.`platform_users`.`wca_user_is_active` <> 0 and
                             !`api_is_blank`( `api`.`platform_users`.`wca_client_user_id` ) ) then 1
            else 0
        end `is_wc_tpa_admin`
      , case
            when `api`.`platform_users`.`wca_user_type` like '%BROKER%' and
                 `api_cbool`( `api`.`platform_users`.`wca_user_is_active` ) and
                 !`api_is_blank`( `api`.`platform_users`.`wca_client_user_id` ) then 1
            else 0
        end `is_wc_broker`
      , case
            when (!`api_is_blank`( `api`.`platform_users`.`wca_client_user_id` ) or
                  `api`.`platform_users`.`wca_user_type` like '%CLIENT%') and
                 `api_cbool`( `api`.`platform_users`.`wca_user_is_active` ) and
                 !`api_is_blank`( `api`.`platform_users`.`wca_client_user_id` ) then 1
            else 0
        end `is_wc_client`
      , case
            when !`api_is_blank`( `api`.`platform_users`.`wcp_employee_id` ) and
                 `api_cbool`( `api`.`platform_users`.`wcp_user_is_active` ) then 1
            else 0
        end `is_wc_particpant`
      , case
            when `api_cbool`( `api`.`platform_users`.`bs_is_topdog` ) and
                 `api_cbool`( `api`.`platform_users`.`bs_user_is_active` ) then 1
            else 0
        end `is_bs_tpa_admin`
      , case
            when `api_cbool`( `api`.`platform_users`.`bs_is_topdog` ) and
                 `api_cbool`( `api`.`platform_users`.`bs_user_is_active` ) then 1
            else 0
        end `is_bs_broker`
      , case
            when (`api_cbool`( `api`.`platform_users`.`bs_is_manager` ) or
                  `api_cbool`( `api`.`platform_users`.`bs_is_topdog` )) and
                 `api_cbool`( `api`.`platform_users`.`bs_user_is_active` ) then 1
            else 0
        end `is_bs_client`
      , case
            when `api_cbool`( `api`.`platform_users`.`bs_is_employee` ) and
                 `api_cbool`( `api`.`platform_users`.`bs_user_is_active` ) then 1
            else 0
        end `is_bs_particpant`
      , case
            when `api_cbool`( `api`.`platform_users`.`en_is_tpa_user` ) and
                 `api_cbool`( `api`.`platform_users`.`en_user_is_active` ) then 1
            else 0
        end `is_en_tpa_admin`
      , case
            when `api_cbool`( `api`.`platform_users`.`en_is_manager` ) and
                 `api_cbool`( `api`.`platform_users`.`en_user_is_active` ) then 1
            else 0
        end `is_en_broker`
      , case
            when `api_cbool`( `api`.`platform_users`.`en_is_manager` ) and
                 `api_cbool`( `api`.`platform_users`.`en_user_is_active` ) then 1
            else 0
        end `is_en_client`
      , case
            when `api_cbool`( `api`.`platform_users`.`en_is_employee` ) and
                 `api_cbool`( `api`.`platform_users`.`en_user_is_active` ) then 1
            else 0
        end `is_en_particpant`
      , case
            when `api_cbool`( 0 ) and `api_cbool`( `api`.`platform_users`.`sf_user_is_active` ) then 1
            else 0
        end `is_sf_tpa_admin`
      , case
            when `api_cbool`( `api`.`platform_users`.`sf_is_broker` ) and
                 `api_cbool`( `api`.`platform_users`.`sf_user_is_active` ) then 1
            else 0
        end `is_sf_broker`
      , case
            when `api_cbool`( `api`.`platform_users`.`sf_is_client` ) and
                 `api_cbool`( `api`.`platform_users`.`sf_user_is_active` ) then 1
            else 0
        end `is_sf_client`
      , case
            when `api_cbool`( `api`.`platform_users`.`sf_is_employee` ) and
                 `api_cbool`( `api`.`platform_users`.`sf_user_is_active` ) then 1
            else 0
        end `is_sf_particpant`
      , case
            when `api_cbool`( `api`.`platform_users`.`ts_user_is_active` ) then 1
            else 0
        end `is_ts_particpant`
      , `api`.`platform_users`.`bt_user_is_active` `is_bt_user`
      , `api`.`platform_users`.`rto_user_is_active` `is_rto_user`
      , `api`.`platform_users`.`bt_user_is_active` `bt_user_is_active`
      , `api`.`platform_users`.`rto_user_is_active` `rto_user_is_active`
      , `api`.`platform_users`.`bt_user_type` `bt_user_type`
      , `api`.`platform_users`.`rto_user_type` `rto_user_type`
      , `api`.`platform_users`.`alternate_email` `alternate_email`
      , `api`.`platform_users`.`title` `title`
      , `api`.`platform_users`.`mobile_number` `mobile_number`
      , `api`.`platform_users`.`ssn` `ssn`
      , `api`.`platform_users`.`dob` `dob`
      , `api`.`platform_users`.`zip` `zip`
      , `api`.`platform_users`.`employee_id` `employee_id`
      , `api`.`platform_users`.`invite_token` `invite_token`
      , `api`.`platform_users`.`last_invite_token_sent_date` `last_invite_token_sent_date`
      , `api`.`platform_users`.`is_invited` `is_invited`
      , `api`.`platform_users`.`is_verified` `is_verified`
      , `api`.`platform_users`.`cp_client_id` `cp_client_id`
      , `api`.`platform_users`.`cp_broker_id` `cp_broker_id`
      , `api`.`platform_users`.`cp_client_contact_id` `cp_client_contact_id`
      , `api`.`platform_users`.`cp_sso_identifier` `cp_sso_identifier`
      , `api`.`platform_users`.`cp_customer_id` `cp_customer_id`
      , `api`.`platform_users`.`cp_entity_type` `cp_entity_type`
      , `api`.`platform_users`.`cp_user_id` `cp_user_id`
      , `api`.`platform_users`.`cp_tpa_user_is_active` `cp_tpa_user_is_active`
      , `api`.`platform_users`.`cp_broker_user_is_active` `cp_broker_user_is_active`
      , `api`.`platform_users`.`cp_client_user_is_active` `cp_client_user_is_active`
      , `api`.`platform_users`.`cp_member_id` `cp_member_id`
      , `api`.`platform_users`.`cp_member_user_is_active` `cp_member_user_is_active`
      , `api`.`platform_users`.`cp_allow_sso` `cp_allow_sso`
      , `api`.`platform_users`.`cp_ssn` `cp_ssn`
      , `api`.`platform_users`.`cp_email` `cp_email`
      , `api`.`platform_users`.`cp_dob` `cp_dob`
      , `api`.`platform_users`.`cp_zip` `cp_zip`
      , `api`.`platform_users`.`wc_card_number` `wc_card_number`
      , `api`.`platform_users`.`wc_dob` `wc_dob`
      , `api`.`platform_users`.`wc_ssn` `wc_ssn`
      , `api`.`platform_users`.`wc_zip` `wc_zip`
      , `api`.`platform_users`.`wc_email` `wc_email`
      , `api`.`platform_users`.`wca_tpa_id` `wca_tpa_id`
      , `api`.`platform_users`.`wca_employer_id` `wca_employer_id`
      , `api`.`platform_users`.`wca_data_partner_id` `wca_data_partner_id`
      , `api`.`platform_users`.`wca_client_user_id` `wca_client_user_id`
      , `api`.`platform_users`.`wca_user_is_active` `wca_user_is_active`
      , `api`.`platform_users`.`wcp_tpa_id` `wcp_tpa_id`
      , `api`.`platform_users`.`wcp_employer_id` `wcp_employer_id`
      , `api`.`platform_users`.`wcp_employee_id` `wcp_employee_id`
      , `api`.`platform_users`.`wcp_user_is_active` `wcp_user_is_active`
      , `api`.`platform_users`.`wcp_employer_name` `wcp_employer_name`
      , `api`.`platform_users`.`bs_user_id` `bs_user_id`
      , `api`.`platform_users`.`bs_import_user_id` `bs_import_user_id`
      , `api`.`platform_users`.`bs_user_name` `bs_user_name`
      , `api`.`platform_users`.`bs_user_is_active` `bs_user_is_active`
      , `api`.`platform_users`.`bs_dob` `bs_dob`
      , `api`.`platform_users`.`bs_work_email` `bs_work_email`
      , `api`.`platform_users`.`bs_payroll_id` `bs_payroll_id`
      , `api`.`platform_users`.`bs_abbrev_url` `bs_abbrev_url`
      , `api`.`platform_users`.`bs_ssn` `bs_ssn`
      , `api`.`platform_users`.`bs_zip` `bs_zip`
      , `api`.`platform_users`.`bs_email` `bs_email`
      , `api`.`platform_users`.`bs_employer_id` `bs_employer_id`
      , `api`.`platform_users`.`bs_is_employee` `bs_is_employee`
      , `api`.`platform_users`.`bs_is_manager` `bs_is_manager`
      , `api`.`platform_users`.`bs_is_topdog` `bs_is_topdog`
      , `api`.`platform_users`.`en_email` `en_email`
      , `api`.`platform_users`.`en_ssn` `en_ssn`
      , `api`.`platform_users`.`en_dob` `en_dob`
      , `api`.`platform_users`.`en_zip` `en_zip`
      , `api`.`platform_users`.`en_user_is_active` `en_user_is_active`
      , `api`.`platform_users`.`en_is_employee` `en_is_employee`
      , `api`.`platform_users`.`en_is_manager` `en_is_manager`
      , `api`.`platform_users`.`en_is_tpa_user` `en_is_tpa_user`
      , `api`.`platform_users`.`sf_email` `sf_email`
      , `api`.`platform_users`.`sf_row_id` `sf_row_id`
      , `api`.`platform_users`.`sf_employer_id` `sf_employer_id`
      , `api`.`platform_users`.`sf_dob` `sf_dob`
      , `api`.`platform_users`.`sf_ssn` `sf_ssn`
      , `api`.`platform_users`.`sf_user_is_active` `sf_user_is_active`
      , `api`.`platform_users`.`sf_is_employee` `sf_is_employee`
      , `api`.`platform_users`.`sf_is_client` `sf_is_client`
      , `api`.`platform_users`.`sf_is_broker` `sf_is_broker`
      , `api`.`platform_users`.`created_at` `created_at`
      , `api`.`platform_users`.`created_by` `created_by`
      , `api`.`platform_users`.`updated_at` `updated_at`
      , `api`.`platform_users`.`updated_by` `updated_by`
      , `api`.`platform_users`.`user_synced_to_mini_orange` `user_synced_to_mini_orange`
      , `api`.`platform_users`.`cp_contact_registration_code` `cp_contact_registration_code`
      , `api`.`platform_users`.`cp_contact_registration_date` `cp_contact_registration_date`
      , `api`.`platform_users`.`ts_row_id` `ts_row_id`
      , `api`.`platform_users`.`ts_employer_key` `ts_employer_key`
      , `api`.`platform_users`.`ts_employer_name` `ts_employer_name`
      , `api`.`platform_users`.`ts_employee_key` `ts_employee_key`
      , `api`.`platform_users`.`ts_email` `ts_email`
      , `api`.`platform_users`.`ts_first_name` `ts_first_name`
      , `api`.`platform_users`.`ts_last_name` `ts_last_name`
      , `api`.`platform_users`.`ts_phone` `ts_phone`
      , `api`.`platform_users`.`ts_ssn` `ts_ssn`
      , `api`.`platform_users`.`ts_user_is_active` `ts_user_is_active`
      , `api`.`platform_users`.`if_user_is_active` `if_user_is_active`
      , `api`.`platform_users`.`if_unique_id` `if_unique_id`
      , `api`.`platform_users`.`if_reward_amount` `if_reward_amount`
    from
        `api`.`platform_users`;

