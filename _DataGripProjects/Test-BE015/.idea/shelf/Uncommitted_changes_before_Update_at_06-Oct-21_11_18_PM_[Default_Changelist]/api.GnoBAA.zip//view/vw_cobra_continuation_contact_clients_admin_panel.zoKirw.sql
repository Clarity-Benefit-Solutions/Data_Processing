create definer = root@`%` view vw_cobra_continuation_contact_clients_admin_panel
as
    select
        `vw_cobra_continuation_contact_clients`.`contact_id` `contact_id`
      , `vw_cobra_continuation_contact_clients`.`organization_name` `organization_name`
      , `vw_cobra_continuation_contact_clients`.`contact_first_name` `contact_first_name`
      , `vw_cobra_continuation_contact_clients`.`contact_last_name` `contact_last_name`
      , `vw_cobra_continuation_contact_clients`.`contact_email` `contact_email`
      , `vw_cobra_continuation_contact_clients`.`contact_type` `contact_type`
      , `vw_cobra_continuation_contact_clients`.`contact_sub_type` `contact_sub_type`
      , `vw_cobra_continuation_contact_clients`.`contact_phone` `contact_phone`
      , `vw_cobra_continuation_contact_clients`.`contact_is_cobra_contact` `contact_is_cobra_contact`
      , `vw_cobra_continuation_contact_clients`.`status` `status`
      , `vw_cobra_continuation_contact_clients`.`clientid` `clientid`
      , `vw_cobra_continuation_contact_clients`.`clientname` `clientname`
      , `vw_cobra_continuation_contact_clients`.`org_contact_email` `org_contact_email`
      , `vw_cobra_continuation_contact_clients`.`require_addtn_attestation_from_qbs` `require_addtn_attestation_from_qbs`
      , `vw_cobra_continuation_contact_clients`.`require_addtn_attestation_from_qbs_sub_on` `require_addtn_attestation_from_qbs_sub_on`
      , `vw_cobra_continuation_contact_clients`.`count_pending_rollover` `count_pending_rollover`
      , `vw_cobra_continuation_contact_clients`.`count_submitted_rollover` `count_submitted_rollover`
      , `vw_cobra_continuation_contact_clients`.`count_pending_ongoing` `count_pending_ongoing`
      , `vw_cobra_continuation_contact_clients`.`count_submitted_ongoing` `count_submitted_ongoing`
      , `vw_cobra_continuation_contact_clients`.`total_count` `total_count`
      , `vw_cobra_continuation_contact_clients`.`reminder_count` `reminder_count`
      , `vw_cobra_continuation_contact_clients`.`last_reminder_date` `last_reminder_date`
      , `vw_cobra_continuation_contact_clients`.`last_reminder_ongoing_date` `last_reminder_ongoing_date`
      , `vw_cobra_continuation_contact_clients`.`reminder_count_attestation` `reminder_count_attestation`
      , `vw_cobra_continuation_contact_clients`.`last_reminder_date_attestation` `last_reminder_date_attestation`
    from
        `api`.`vw_cobra_continuation_contact_clients`;

