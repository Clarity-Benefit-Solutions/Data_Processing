create definer = admin@`%` view vw_util_sql_for_for_created_updated_cols
as
    select
        `c`.`TABLE_SCHEMA` `table_schema`
      , `c`.`TABLE_NAME` `table_name`
      , `util_get_sql_for_created_updated_cols`( concat( `c`.`TABLE_SCHEMA` , '.' , `c`.`TABLE_NAME` ) ,
                                                 `c`.`TABLE_SCHEMA` ) `util_get_sql_for_created_updated_cols`
    from
        `information_schema`.`tables` `c`
    where
          `c`.`TABLE_TYPE` = 'BASE TABLE'
      and `c`.`TABLE_SCHEMA` not in ('performance_schema', 'information_schema', 'mysql');

