create definer = admin@`%` view vw_sso_platform_wc
as
    select
        case
            when `t`.`row_id` = `api`.`sso_get_record_for_wc`( `t`.`email` ) then 1
            else 0
        end `is_sso_record`
      , `t`.`email` `email`
      , `t`.`is_active` `is_active`
      , `t`.`user_type` `user_type`
      , `t`.`tpa_id` `tpa_id`
      , `t`.`user_id` `user_id`
      , `t`.`profile_name` `profile_name`
      , `t`.`middle_initial` `middle_initial`
      , `t`.`name_prefix` `name_prefix`
      , `t`.`phone` `phone`
      , `t`.`row_id` `row_id`
      , `t`.`employer_id` `employer_id`
      , `t`.`first_name` `first_name`
      , `t`.`last_name` `last_name`
      , `t`.`allow_get_current_sessions` `allow_get_current_sessions`
      , `t`.`allow_to_uplod_a_payroll_file` `allow_to_uplod_a_payroll_file`
      , `t`.`status` `status`
      , `t`.`created_at` `created_at`
      , `t`.`created_by` `created_by`
      , `t`.`updated_at` `updated_at`
      , `t`.`updated_by` `updated_by`
    from
        `wc`.`vw_wc_employer_users` `t`;

