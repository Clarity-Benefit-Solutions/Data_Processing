create definer = root@`%` view vw_if_participant_alert
as
    select
        `api`.`vw_platform_sso_users`.`user_name` `user_name`
      , `api`.`vw_platform_sso_users`.`email` `email`
      , `api`.`vw_platform_sso_users`.`user_id` `user_id`
      , `api`.`vw_platform_sso_users`.`first_name` `first_name`
      , `api`.`vw_platform_sso_users`.`last_name` `last_name`
      , `api`.`vw_platform_sso_users`.`ssn` `ssn`
      , `api`.`vw_platform_sso_users`.`is_ready_for_sso_processing` `is_ready_for_sso_processing`
      , `api`.`vw_platform_sso_users`.`is_invalid` `is_invalid`
      , `api`.`vw_platform_sso_users`.`is_active` `is_active`
      , `api`.`vw_platform_sso_users`.`alternate_email` `alternate_email`
      , `api`.`vw_platform_sso_users`.`title` `title`
      , `api`.`vw_platform_sso_users`.`mobile_number` `mobile_number`
      , `api`.`vw_platform_sso_users`.`dob` `dob`
      , `api`.`vw_platform_sso_users`.`zip` `zip`
      , `api`.`vw_platform_sso_users`.`employee_id` `employee_id`
      , `api`.`vw_platform_sso_users`.`invite_token` `invite_token`
      , `api`.`vw_platform_sso_users`.`last_invite_token_sent_date` `last_invite_token_sent_date`
      , `api`.`vw_platform_sso_users`.`is_invited` `is_invited`
      , `api`.`vw_platform_sso_users`.`is_verified` `is_verified`
      , `api`.`vw_platform_sso_users`.`if_user_is_active` `if_user_is_active`
      , `api`.`vw_platform_sso_users`.`if_unique_id` `if_unique_id`
      , `api`.`vw_platform_sso_users`.`if_reward_amount` `if_reward_amount`
      , `api`.`vw_platform_sso_users`.`wcp_employer_name` `wcp_employer_name`
      , `api`.`get_notification_log_count`( `api`.`vw_platform_sso_users`.`email` , 'alert' , 'if_part_1' ,
                                            '%' ) `warning_notification_log_count`
      , `api`.`get_notification_log_last_sent_at`( `api`.`vw_platform_sso_users`.`email` , 'alert' , 'if_part_1' ,
                                                   '%' ) `warning_notification_log_last_sent_at`
      , `api`.`get_notification_log_count`( `api`.`vw_platform_sso_users`.`email` , 'alert' , 'if_part_unregistered' ,
                                            '%' ) `unregistered_notification_log_count`
      , `api`.`get_notification_log_last_sent_at`( `api`.`vw_platform_sso_users`.`email` , 'alert' ,
                                                   'if_part_unregistered' ,
                                                   '%' ) `unregistered_notification_log_last_sent_at`
    from
        `api`.`vw_platform_sso_users`
    where
          `api`.`vw_platform_sso_users`.`is_particpant` = 1
      and `api`.`vw_platform_sso_users`.`if_user_is_active` = 2
    order by
        `api`.`vw_platform_sso_users`.`email`;

