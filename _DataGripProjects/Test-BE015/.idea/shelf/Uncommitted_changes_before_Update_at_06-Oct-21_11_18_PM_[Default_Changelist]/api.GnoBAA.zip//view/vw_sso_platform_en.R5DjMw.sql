create definer = admin@`%` view vw_sso_platform_en
as
    select
        `t`.`email` `email`
      , case
            when `t`.`row_id` = `api`.`sso_get_record_for_en`( `t`.`email` ) then 1
            else 0
        end `is_sso_record`
      , `t`.`is_active` `is_active`
      , `t`.`user_type` `user_type`
      , `t`.`row_id` `row_id`
      , `t`.`companyidentifier` `companyidentifier`
      , `t`.`firstname` `firstname`
      , `t`.`lastname` `lastname`
      , `t`.`ssn` `ssn`
      , `t`.`employeeid` `employeeid`
      , `t`.`employeestatus` `employeestatus`
      , `t`.`address1` `address1`
      , `t`.`address2` `address2`
      , `t`.`city` `city`
      , `t`.`state` `state`
      , `t`.`zip` `zip`
      , `t`.`phone` `phone`
      , `t`.`dob` `dob`
      , `t`.`terminationdate` `terminationdate`
      , `t`.`enparticipant` `enparticipant`
      , `t`.`created_at` `created_at`
      , `t`.`created_by` `created_by`
      , `t`.`updated_at` `updated_at`
      , `t`.`updated_by` `updated_by`
    from
        `en`.`vw_en_employees` `t`;

