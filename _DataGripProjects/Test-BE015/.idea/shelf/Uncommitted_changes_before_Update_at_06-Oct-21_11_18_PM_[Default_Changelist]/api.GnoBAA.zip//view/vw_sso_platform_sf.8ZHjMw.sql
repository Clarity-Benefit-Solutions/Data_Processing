create definer = admin@`%` view vw_sso_platform_sf
as
    select
        case
            when `t`.`row_id` = `api`.`sso_get_record_for_sf`( `t`.`email` ) then 1
            else 0
        end `is_sso_record`
      , `t`.`email` `email`
      , `t`.`is_active` `is_active`
      , `t`.`user_type` `user_type`
      , `t`.`row_id` `row_id`
      , `t`.`entitytype` `entitytype`
      , `t`.`clientcode` `clientcode`
      , `t`.`clientname` `clientname`
      , `t`.`fullname` `fullname`
      , `t`.`ssn` `ssn`
      , `t`.`contactid` `contactid`
      , `t`.`contactstatus` `contactstatus`
      , `t`.`is_in_wc` `is_in_wc`
      , `t`.`is_in_cp` `is_in_cp`
      , `t`.`is_in_bs` `is_in_bs`
      , `t`.`is_in_en` `is_in_en`
      , `t`.`phone` `phone`
      , `t`.`employeeid` `employeeid`
      , `t`.`isprimarycontact` `isprimarycontact`
      , `t`.`created_at` `created_at`
      , `t`.`created_by` `created_by`
      , `t`.`updated_at` `updated_at`
      , `t`.`updated_by` `updated_by`
    from
        `sf`.`vw_sf_contacts` `t`;

