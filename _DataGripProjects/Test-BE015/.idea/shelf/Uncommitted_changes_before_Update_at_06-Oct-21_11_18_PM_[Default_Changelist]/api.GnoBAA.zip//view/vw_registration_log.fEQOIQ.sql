create definer = root@`%` view vw_registration_log
as
    select
        `api`.`registration_log`.`row_id` `row_id`
      , `api`.`registration_log`.`attempt_type` `attempt_type`
      , `api`.`registration_log`.`status` `status`
      , `api`.`registration_log`.`email_status` `email_status`
      , `api`.`registration_log`.`invite_token` `invite_token`
      , `api`.`registration_log`.`email` `email`
      , `api`.`registration_log`.`first_name` `first_name`
      , `api`.`registration_log`.`last_name` `last_name`
      , `api`.`registration_log`.`mobile_number` `mobile_number`
      , `api`.`registration_log`.`ssn` `ssn`
      , `api`.`registration_log`.`employer_id` `employer_id`
      , `api`.`registration_log`.`employee_id` `employee_id`
      , `api`.`registration_log`.`dob` `dob`
      , `api`.`registration_log`.`zip` `zip`
      , `api`.`registration_log`.`card_number` `card_number`
      , replace( `api`.`registration_log`.`matched_user_id` , char( 13 ) , '<br>' ) `matched_user_id`
      , replace( `api`.`registration_log`.`matched_row_ids` , char( 13 ) , '<br>' ) `matched_row_ids`
      , replace( `api`.`registration_log`.`internal_messages` , char( 13 ) , '<br>' ) `internal_messages`
      , replace( `api`.`registration_log`.`user_messages` , char( 13 ) , '<br>' ) `user_messages`
      , `api`.`registration_log`.`created_at` `created_at`
      , `api`.`registration_log`.`created_by` `created_by`
      , `api`.`registration_log`.`updated_at` `updated_at`
      , `api`.`registration_log`.`updated_by` `updated_by`
      , replace( `api`.`registration_log`.`error_message` , char( 13 ) , '<br>' ) `error_message`
      , `api`.`registration_log`.`ignore_email_mismatch` `ignore_email_mismatch`
    from
        `api`.`registration_log`
    order by
        `api`.`registration_log`.`email`
      , `api`.`registration_log`.`created_at` desc;

