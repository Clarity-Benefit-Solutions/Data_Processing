create definer = admin@`%` view vw_api_case_plans_all
as
    select
        `t`.`main_plan_type` `main_plan_type`
      , `t`.`case_plan_id` `case_plan_id`
      , `t`.`case_id` `case_id`
      , `t`.`status` `status`
      , `t`.`version_no` `version_no`
      , `t`.`plan_type` `plan_type`
      , `t`.`plan_name` `plan_name`
      , `t`.`plan_sub_type` `plan_sub_type`
      , `t`.`plan_order` `plan_order`
      , `t`.`plan_year_start_date` `plan_year_start_date`
      , `t`.`plan_year_end_date` `plan_year_end_date`
      , `t`.`plan_year_renewal_date` `plan_year_renewal_date`
      , `t`.`plan_should_terminate` `plan_should_terminate`
      , `t`.`plan_year_termination_date` `plan_year_termination_date`
      , `t`.`plan_is_new` `plan_is_new`
      , `t`.`plan_should_auto_renew` `plan_should_auto_renew`
      , `t`.`created_at` `created_at`
      , `t`.`created_by` `created_by`
      , `t`.`updated_at` `updated_at`
      , `t`.`updated_by` `updated_by`
    from
        (
            select
                'CONSUMER_BENEFIT' `main_plan_type`
              , `api`.`api_case_plans_cobra`.`case_plan_id` `case_plan_id`
              , `api`.`api_case_plans_cobra`.`case_id` `case_id`
              , `api`.`api_case_plans_cobra`.`status` `status`
              , `api`.`api_case_plans_cobra`.`version_no` `version_no`
              , `api`.`api_case_plans_cobra`.`plan_type` `plan_type`
              , `api`.`api_case_plans_cobra`.`plan_name` `plan_name`
              , `api`.`api_case_plans_cobra`.`plan_sub_type` `plan_sub_type`
              , `api`.`api_case_plans_cobra`.`plan_order` `plan_order`
              , `api`.`api_case_plans_cobra`.`plan_year_start_date` `plan_year_start_date`
              , `api`.`api_case_plans_cobra`.`plan_year_end_date` `plan_year_end_date`
              , `api`.`api_case_plans_cobra`.`plan_year_renewal_date` `plan_year_renewal_date`
              , `api`.`api_case_plans_cobra`.`plan_should_terminate` `plan_should_terminate`
              , `api`.`api_case_plans_cobra`.`plan_year_termination_date` `plan_year_termination_date`
              , `api`.`api_case_plans_cobra`.`plan_is_new` `plan_is_new`
              , NULL `plan_should_auto_renew`
              , `api`.`api_case_plans_cobra`.`created_at` `created_at`
              , `api`.`api_case_plans_cobra`.`created_by` `created_by`
              , `api`.`api_case_plans_cobra`.`updated_at` `updated_at`
              , `api`.`api_case_plans_cobra`.`updated_by` `updated_by`
            from
                `api`.`api_case_plans_cobra`
            union all
            select
                'COBRA' `main_plan_type`
              , `api`.`api_case_plans_cons_ben`.`case_plan_id` `case_plan_id`
              , `api`.`api_case_plans_cons_ben`.`case_id` `case_id`
              , `api`.`api_case_plans_cons_ben`.`status` `status`
              , `api`.`api_case_plans_cons_ben`.`version_no` `version_no`
              , `api`.`api_case_plans_cons_ben`.`plan_type` `plan_type`
              , `api`.`api_case_plans_cons_ben`.`plan_sub_type` `plan_sub_type`
              , `api`.`api_case_plans_cons_ben`.`plan_name` `plan_name`
              , `api`.`api_case_plans_cons_ben`.`plan_order` `plan_order`
              , `api`.`api_case_plans_cons_ben`.`plan_year_start_date` `plan_year_start_date`
              , `api`.`api_case_plans_cons_ben`.`plan_year_end_date` `plan_year_end_date`
              , `api`.`api_case_plans_cons_ben`.`plan_year_renewal_date` `plan_year_renewal_date`
              , 0 `0`
              , NULL `NULL`
              , NULL `NULL`
              , `api`.`api_case_plans_cons_ben`.`plan_should_auto_renew` `plan_should_auto_renew`
              , `api`.`api_case_plans_cons_ben`.`created_at` `created_at`
              , `api`.`api_case_plans_cons_ben`.`created_by` `created_by`
              , `api`.`api_case_plans_cons_ben`.`updated_at` `updated_at`
              , `api`.`api_case_plans_cons_ben`.`updated_by` `updated_by`
            from
                `api`.`api_case_plans_cons_ben`
        ) `t`
    order by
        `t`.`case_id`
      , `t`.`main_plan_type`
      , `t`.`plan_order`
      , `t`.`plan_type`;

