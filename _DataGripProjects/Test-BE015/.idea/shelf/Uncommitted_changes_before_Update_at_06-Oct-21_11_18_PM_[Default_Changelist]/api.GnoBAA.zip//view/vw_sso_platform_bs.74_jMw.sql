create definer = admin@`%` view vw_sso_platform_bs
as
    select
        `t`.`eeemail` `eeemail`
      , case
            when `t`.`row_id` = `api`.`sso_get_record_for_bs`( `t`.`eeemail` ) then 1
            else 0
        end `is_sso_record`
      , `t`.`is_active` `is_active`
      , `t`.`user_type` `user_type`
      , `t`.`row_id` `row_id`
      , `t`.`eeclientbencode` `eeclientbencode`
      , `t`.`eedivision` `eedivision`
      , `t`.`eefirstname` `eefirstname`
      , `t`.`eelastname` `eelastname`
      , `t`.`eeemployeeid` `eeemployeeid`
      , `t`.`eessn` `eessn`
      , `t`.`eestatus` `eestatus`
      , `t`.`eeaddress1` `eeaddress1`
      , `t`.`eeaddress2` `eeaddress2`
      , `t`.`eecity` `eecity`
      , `t`.`eestate` `eestate`
      , `t`.`eezip` `eezip`
      , `t`.`eehomephone` `eehomephone`
      , `t`.`eedob` `eedob`
      , `t`.`eebswiftparticipant` `eebswiftparticipant`
      , `t`.`eealternateid` `eealternateid`
      , `t`.`eeimportuserid` `eeimportuserid`
      , `t`.`eepayrollid` `eepayrollid`
      , `t`.`eeuserroles` `eeuserroles`
      , `t`.`eeuserid` `eeuserid`
      , `t`.`eeusername` `eeusername`
      , `t`.`eeisemployee` `eeisemployee`
      , `t`.`eeismanager` `eeismanager`
      , `t`.`eeistopdog` `eeistopdog`
      , `t`.`abbrevurl` `abbrevurl`
      , `t`.`created_at` `created_at`
      , `t`.`created_by` `created_by`
      , `t`.`updated_at` `updated_at`
      , `t`.`updated_by` `updated_by`
    from
        `bs`.`vw_bs_employees` `t`;

