create definer = root@`%` view vw_cases_forms
as
    select
        `a`.`case_id` `case_id`
      , `a`.`employer_name` `employer_name`
      , `api`.`get_sf_case_owner_fullname`( `a`.`sf_case_owner_user_id` ) `sf_case_owner_fullname`
      , substr( `a`.`last_rollout_error` , 1 , 150 ) `last_rollout_error`
      , `a`.`employer_id` `employer_id`
      , `a`.`case_type` `case_type`
      , `a`.`case_sub_type` `case_sub_type`
      , `a`.`form_invite_token` `form_invite_token`
      , `a`.`wizard_curr_step_no` `wizard_curr_step_no`
      , `a`.`form_curr_page_no` `form_curr_page_no`
      , `a`.`sf_case_id` `sf_case_id`
      , `a`.`is_ready_for_processing` `is_ready_for_processing`
      , `a`.`is_used_for_testing` `is_used_for_testing`
      , `a`.`sf_case_owner_user_id` `sf_case_owner_user_id`
      , `a`.`case_status` `status`
      , case
            when `a`.`case_status` like 'Client Notified%' then 'Start'
            when `a`.`case_status` like 'In Progress%' then 'Resume'
            else 'View'
        end `lable`
      , case
            when `a`.`case_status` in
                 ('New', 'Contact Changed', 'Contact Changed: Task Created', 'Ready For Entry', 'Closed',
                  'Cancelled: Hidden') then 0
            else 1
        end `is_visible_to_client`
      , case
            when `a`.`case_status` like 'Client Notified%' then 'Not Started'
            else `api`.`api_fix_case_status_for_user_display`( `a`.`case_status` )
        end `case_status`
      , case
            when `a`.`case_status` like 'New%' or `a`.`case_status` like 'Ready For Entry%' then 'Waiting'
            when `a`.`case_status` like 'Cancelled%' then 'Cancelled'
            else 'Rolled Out'
        end `major_case_status`
      , concat( 'https://portal.test.claritybenefitsolutions.com' , '/forms/caa/?token=' ,
                `a`.`form_invite_token` ) `url`
      , min( `b`.`contact_first_name` ) `contact_first_name`
      , min( `b`.`contact_last_name` ) `contact_last_name`
      , min( `b`.`contact_email` ) `contact_email`
      , min( `b`.`contact_email` ) `email_sent_to`
      , min( `b`.`contact_phone` ) `contact_phone`
      , `api`.`get_case_status_history`( `a`.`form_invite_token` , 1 ) `current_status_time`
      , `api`.`get_case_notification_history`( `a`.`case_id` , 1 , 'email' , 'Renewal Portal' ,
                                               `a`.`case_sub_type` ) `last_outreach_at`
      , '2021-02-26' `renewal_date`
      , case
            when `a`.`case_sub_type` = 'Covid2021Info'
                then 'Optional Provisions in Consolidated Appropriations Act, 2021'
            else `a`.`case_sub_type`
        end `products`
      , `api`.`get_cases_forms_covide2021infofieldvalue`( `a`.`form_invite_token` , '%intro%' ) `valueofapproveall`
      , `api`.`get_cases_forms_covide2021infofieldvalue`( `a`.`form_invite_token` , '%carryover%' ) `valueofcarryover`
      , `api`.`get_cases_forms_covide2021infofieldvalue`( `a`.`form_invite_token` ,
                                                          '%grace_period%' ) `valueofgraceperiod`
      , `api`.`get_cases_forms_covide2021infofieldvalue`( `a`.`form_invite_token` ,
                                                          '%co_gp%' ) `valueofcarryoverandgpdenial`
      , `api`.`get_cases_forms_covide2021infofieldvalue`( `a`.`form_invite_token` , '%relife%' ) `valueoftemprelief`
      , `api`.`get_cases_forms_covide2021infofieldvalue`( `a`.`form_invite_token` ,
                                                          '%reimbursement%' ) `valueofspenddown`
      , `api`.`get_cases_forms_covide2021infofieldvalue`( `a`.`form_invite_token` , '%election%' ) `valueofelection`
    from
        (`api`.`api_cases` `a`
            join `api`.`api_case_contacts` `b` on (`b`.`case_id` = `a`.`case_id`))
    where
          `a`.`case_type` = 'Forms'
      and case
              when `a`.`case_sub_type` = 'Covid2021Info' then `b`.`contact_is_cons_ben_contact` = 1
              else `b`.`contact_is_cobra_contact` = 1 or `b`.`contact_is_cons_ben_contact` = 1
          end
    group by
        `a`.`case_id`
      , `a`.`employer_name`
      , `a`.`employer_id`
      , `a`.`case_sub_type`
      , `a`.`form_invite_token`
      , `a`.`wizard_curr_step_no`
      , `a`.`form_curr_page_no`
      , `a`.`sf_case_id`
      , `a`.`case_status`
    order by
        `a`.`employer_name`;

