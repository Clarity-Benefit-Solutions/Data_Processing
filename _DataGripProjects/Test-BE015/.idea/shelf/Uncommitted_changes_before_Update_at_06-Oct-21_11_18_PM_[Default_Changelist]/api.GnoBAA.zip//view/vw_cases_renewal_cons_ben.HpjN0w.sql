create definer = root@`%` view vw_cases_renewal_cons_ben
as
    select
        `a`.`case_id` `case_id`
      , `a`.`employer_name` `employer_name`
      , `a`.`employer_id` `employer_id`
      , `a`.`case_sub_type` `case_sub_type`
      , `api`.`get_sf_case_owner_fullname`( `a`.`sf_case_owner_user_id` ) `sf_case_owner_fullname`
      , `a`.`is_ready_for_processing` `is_ready_for_processing`
      , substr( `a`.`last_rollout_error` , 1 , 150 ) `last_rollout_error`
      , `a`.`form_invite_token` `form_invite_token`
      , `a`.`wizard_curr_step_no` `wizard_curr_step_no`
      , `a`.`form_curr_page_no` `form_curr_page_no`
      , `a`.`sf_case_id` `sf_case_id`
      , group_concat( distinct case
                                   when `c`.`plan_name` <> '' or `c`.`plan_name` <> NULL then `c`.`plan_name`
                                   else case
                                            when `c`.`plan_sub_type` <> '' or `c`.`plan_sub_type` <> NULL
                                                then `c`.`plan_sub_type`
                                            else `c`.`plan_type`
                                        end
                               end order by `c`.`plan_name` ASC , `c`.`plan_sub_type` ASC , `c`.`plan_name` ASC
                      separator ', ' ) `plan_type`
      , min( `c`.`plan_year_renewal_date` ) `renewal_date`
      , 'View' `lable`
      , `a`.`case_status` `case_status`
      , case
            when `a`.`case_status` like 'New%' or `a`.`case_status` like 'Ready For Entry%' then 'Waiting'
            when `a`.`case_status` like 'Cancelled%' then 'Cancelled'
            else 'Rolled Out'
        end `major_case_status`
      , concat( 'https://portal.test.claritybenefitsolutions.com' , '/renewals/' , case
                                                                                       when `a`.`case_sub_type` = 'CONSUMER_BENEFIT'
                                                                                           then 'cb'
                                                                                       else 'cobra'
                                                                                   end , '/step-' , 1 , '/?token=' ,
                `a`.`form_invite_token` , '&show_summary=1&frm_page=' , case
                                                                            when `a`.`form_curr_page_no` < 1 then 1
                                                                            else `a`.`form_curr_page_no`
                                                                        end ) `url`
      , min( `b`.`contact_first_name` ) `contact_first_name`
      , min( `b`.`contact_last_name` ) `contact_last_name`
      , min( `b`.`contact_email` ) `contact_email`
      , min( `b`.`contact_phone` ) `contact_phone`
      , `api`.`get_case_status_history`( `a`.`form_invite_token` , 1 ) `current_status_time`
      , `api`.`get_case_notification_history`( `a`.`case_id` , 1 , 'email' , 'Renewal Portal' ,
                                               `a`.`case_sub_type` ) `last_outreach_at`
    from
        ((`api`.`api_cases` `a` join `api`.`api_case_contacts` `b` on (`b`.`case_id` = `a`.`case_id`))
            join `api`.`api_case_plans_cons_ben` `c` on (`c`.`case_id` = `a`.`case_id`))
    where
          `a`.`case_type` = 'Renewal'
      and `a`.`case_sub_type` = 'CONSUMER_BENEFIT'
      and `c`.`plan_name` not like '%ROL%'
      and `c`.`plan_sub_type` not like '%ROL%'
      and `c`.`plan_type` not like '%ROL%'
      and `b`.`contact_is_cons_ben_contact` = 1
    group by
        `a`.`case_id`
      , `a`.`employer_name`
      , `a`.`employer_id`
      , `a`.`case_sub_type`
      , `a`.`form_invite_token`
      , `a`.`wizard_curr_step_no`
      , `a`.`form_curr_page_no`
      , `a`.`sf_case_id`
      , `c`.`plan_year_renewal_date`
      , `a`.`case_status`
    order by
        `c`.`plan_year_renewal_date`
      , `a`.`employer_name`;

