create definer = admin@`%` view vw_temp_case_plan_cobra__coverage_data
as
    select
        `c`.`case_id` `case_id`
      , `c`.`employer_name` `employer_name`
      , `p`.`case_plan_id` `case_plan_id`
      , `p`.`status` `status`
      , `p`.`plan_type` `plan_type`
      , `p`.`plan_name` `plan_name`
      , `p`.`plan_sub_type` `plan_sub_type`
      , `p`.`plan_order` `plan_order`
      , `p`.`ben_term_type` `ben_term_type`
      , `v`.`case_plan_coverage_id` `case_plan_coverage_id`
      , `v`.`plan_coverage_level` `plan_coverage_level`
      , `v`.`plan_coverage_level_is_new` `plan_coverage_level_is_new`
      , `v`.`plan_coverage_level_order` `plan_coverage_level_order`
      , `v`.`pct_100_rate_for_coverage_level` `pct_100_rate_for_coverage_level`
      , `v`.`new_pct_100_rate_for_coverage_level` `new_pct_100_rate_for_coverage_level`
    from
        ((`api`.`api_cases` `c` join `api`.`api_case_plans_cobra` `p` on (`c`.`case_id` = `p`.`case_id`))
            join `api`.`api_case_plan_cobra_coverage` `v` on (`p`.`case_plan_id` = `v`.`case_plan_id`))
    order by
        `c`.`employer_name`
      , `c`.`case_id`
      , `p`.`plan_type`
      , `p`.`plan_sub_type`
      , `p`.`plan_name`
      , `v`.`plan_coverage_level`;

