create definer = root@`%` view vw_client_participant_plans
as
    select
        `c`.`email` `email`
      , `p`.`email` `pemail`
      , `c`.`isprimarycontact` `isprimarycontact`
      , `c`.`is_in_en` `is_in_en`
      , `c`.`is_in_bs` `is_in_bs`
      , `c`.`is_in_cp` `is_in_cp`
      , `c`.`is_in_wc` `is_in_wc`
      , `pl`.`row_id` `row_id`
      , `pl`.`recordid` `recordid`
      , `pl`.`tpaid` `tpaid`
      , `pl`.`employerid` `employerid`
      , `pl`.`employeeid` `employeeid`
      , `p`.`employeessn` `employeessn`
      , `p`.`birthdate` `birthdate`
      , `p`.`addressline1` `addressline1`
      , `p`.`addressline2` `addressline2`
      , `p`.`city` `city`
      , `p`.`state` `state`
      , `p`.`zip` `zip`
      , `p`.`country` `country`
      , `p`.`phone` `phone`
      , `pl`.`firstname` `firstname`
      , `pl`.`lastname` `lastname`
      , `pl`.`plandesc` `plandesc`
      , `pl`.`plancode` `plancode`
      , `pl`.`alegusacctstatus` `alegusacctstatus`
      , `pl`.`planstart` `planstart`
      , `pl`.`planend` `planend`
      , `pl`.`annualelection` `annualelection`
      , `pl`.`overrideelection` `overrideelection`
      , `pl`.`employeeppd` `employeeppd`
      , `pl`.`employerppd` `employerppd`
      , `pl`.`eligibilitydate` `eligibilitydate`
      , `pl`.`dummy1` `dummy1`
      , `pl`.`created_at` `created_at`
      , `pl`.`created_by` `created_by`
      , `pl`.`updated_at` `updated_at`
      , `pl`.`updated_by` `updated_by`
    from
        ((`sf`.`sf_contacts` `c` join `wc`.`wc_participants` `p` on (`c`.`clientcode` = `p`.`employerid`))
            join `wc`.`wc_participant_plans` `pl`
                 on (`p`.`employeeid` = `pl`.`employeeid` and `p`.`employerid` = `pl`.`employerid`))
    where
          `c`.`isprimarycontact` = 1
      and `pl`.`planstart` <= sysdate( )
      and `pl`.`planend` >= sysdate( )
    order by
        `c`.`email`
      , `pl`.`employerid`
      , `pl`.`plancode`
      , `pl`.`plandesc`
      , `pl`.`planstart`;

