create definer = root@`%` view vw_find_form_entry_duplicates
as
    select
        `portal`.`cl_frm_items`.`id` `id`
      , `portal`.`cl_frm_items`.`name` `name`
      , `portal`.`cl_frm_items`.`is_duplicated` `is_duplicated`
      , `portal`.`cl_frm_items`.`item_key` `item_key`
      , `portal`.`cl_frm_items`.`form_id` `form_id`
      , `portal`.`cl_frm_items`.`created_at` `created_at`
      , `portal`.`cl_frm_items`.`is_draft` `is_draft`
      , `portal`.`cl_frm_items`.`user_id` `user_id`
      , `portal`.`cl_frm_items`.`parent_item_id` `parent_item_id`
      , `portal`.`cl_frm_items`.`updated_at` `updated_at`
    from
        `portal`.`cl_frm_items`
    where
            `portal`.`cl_frm_items`.`name` in (
                                                  select
                                                      `portal`.`cl_frm_items`.`name`
                                                  from
                                                      `portal`.`cl_frm_items`
                                                  where
                                                        `portal`.`cl_frm_items`.`form_id` = 61
                                                    and (octet_length( `portal`.`cl_frm_items`.`item_key` ) = 32 or
                                                         (octet_length( `portal`.`cl_frm_items`.`item_key` ) < 32 or
                                                          octet_length( `portal`.`cl_frm_items`.`item_key` ) > 32) and
                                                         `portal`.`cl_frm_items`.`created_at` >= '2020-12-18')
                                                    and `portal`.`cl_frm_items`.`is_duplicated` = 0
                                                  group by
                                                      `portal`.`cl_frm_items`.`name`
                                                  having
                                                      count( 0 ) > 1
                                                  order by
                                                      `portal`.`cl_frm_items`.`name`
                                              )
      and   (`portal`.`cl_frm_items`.`parent_item_id` is null or `portal`.`cl_frm_items`.`parent_item_id` = 0)
      and   `portal`.`cl_frm_items`.`is_duplicated` = 0
      and   (octet_length( `portal`.`cl_frm_items`.`item_key` ) <= 32 or
             octet_length( `portal`.`cl_frm_items`.`item_key` ) > 32)
      and   `portal`.`cl_frm_items`.`form_id` = 61
      and   !`api`.`api_is_blank`( `portal`.`cl_frm_items`.`name` )
    order by
        `portal`.`cl_frm_items`.`name`
      , `portal`.`cl_frm_items`.`created_at` desc;

