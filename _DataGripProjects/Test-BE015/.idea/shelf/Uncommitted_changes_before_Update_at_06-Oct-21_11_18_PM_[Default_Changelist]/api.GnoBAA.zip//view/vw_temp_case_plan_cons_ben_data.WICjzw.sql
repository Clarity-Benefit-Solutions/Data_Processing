create definer = admin@`%` view vw_temp_case_plan_cons_ben_data
as
    select
        `c`.`case_id` `case_id`
      , `c`.`employer_name` `employer_name`
      , `p`.`case_plan_id` `case_plan_id`
      , `p`.`status` `status`
      , `p`.`plan_type` `plan_type`
      , `p`.`plan_sub_type` `plan_sub_type`
      , `p`.`plan_name` `plan_name`
      , `p`.`plan_order` `plan_order`
      , `p`.`plan_year_start_date` `plan_year_start_date`
      , `p`.`plan_year_end_date` `plan_year_end_date`
      , `p`.`plan_year_renewal_date` `plan_year_renewal_date`
      , `p`.`min_annual_election_amount` `min_annual_election_amount`
      , `p`.`max_annual_election_amount` `max_annual_election_amount`
      , `p`.`employer_contribution_amount` `employer_contribution_amount`
      , `p`.`employee_contribution_amounts` `employee_contribution_amounts`
      , `p`.`employee_child_contribution_amounts` `employee_child_contribution_amounts`
      , `p`.`employee_spouse_contribution_amounts` `employee_spouse_contribution_amounts`
      , `p`.`family_contribution_amounts` `family_contribution_amounts`
      , `p`.`runout_period` `runout_period`
      , `p`.`runout_period_terminated_employees` `runout_period_terminated_employees`
      , `p`.`add_limited_purpose` `add_limited_purpose`
      , `p`.`recommended_feature` `recommended_feature`
      , `p`.`remove_grace_period` `remove_grace_period`
      , `p`.`add_grace_period` `add_grace_period`
      , `p`.`add_clarity_convenience_card` `add_clarity_convenience_card`
      , `p`.`contribution_amounts` `contribution_amounts`
      , `p`.`who_will_pay_first` `who_will_pay_first`
      , `p`.`participant_responsible_pay_eligible_expenses` `participant_responsible_pay_eligible_expenses`
      , `p`.`funding_frequency` `funding_frequency`
      , `p`.`eligible_expense_categories` `eligible_expense_categories`
      , `p`.`will_the_HRA_reimburse_same_expenses_as_current_plan_year` `will_the_HRA_reimburse_same_expenses_as_current_plan_year`
      , `p`.`HRA_reimburse_same_expenses_as_current_plan_year_if_no` `HRA_reimburse_same_expenses_as_current_plan_year_if_no`
      , `p`.`HRA_participant_responsible_pay_eligible_expenses_if_yes` `HRA_participant_responsible_pay_eligible_expenses_if_yes`
      , `p`.`max_annual_election_amount_is_changed` `max_annual_election_amount_is_changed`
      , `p`.`carry_over_features` `carry_over_features`
      , `p`.`additional_plan_details` `additional_plan_details`
      , `p`.`runout_period_terminated_employees_end_date` `runout_period_terminated_employees_end_date`
      , `p`.`plan_should_auto_renew` `plan_should_auto_renew`
    from
        (`api`.`api_cases` `c`
            join `api`.`api_case_plans_cons_ben` `p` on (`c`.`case_id` = `p`.`case_id`))
    order by
        `c`.`employer_name`
      , `c`.`case_id`
      , `p`.`plan_type`
      , `p`.`plan_sub_type`;

