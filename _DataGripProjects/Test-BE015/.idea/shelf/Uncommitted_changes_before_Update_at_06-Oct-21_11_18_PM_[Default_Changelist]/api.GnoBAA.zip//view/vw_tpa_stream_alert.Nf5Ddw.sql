create definer = root@`%` view vw_tpa_stream_alert
as
    select
        `vw_platform_sso_users`.`user_name` `user_name`
      , `vw_platform_sso_users`.`email` `email`
      , `vw_platform_sso_users`.`user_id` `user_id`
      , `vw_platform_sso_users`.`first_name` `first_name`
      , `vw_platform_sso_users`.`last_name` `last_name`
      , `vw_platform_sso_users`.`ssn` `ssn`
      , `vw_platform_sso_users`.`is_ready_for_sso_processing` `is_ready_for_sso_processing`
      , `vw_platform_sso_users`.`is_invalid` `is_invalid`
      , `vw_platform_sso_users`.`is_active` `is_active`
      , `vw_platform_sso_users`.`alternate_email` `alternate_email`
      , `vw_platform_sso_users`.`title` `title`
      , `vw_platform_sso_users`.`mobile_number` `mobile_number`
      , `vw_platform_sso_users`.`dob` `dob`
      , `vw_platform_sso_users`.`zip` `zip`
      , `vw_platform_sso_users`.`employee_id` `employee_id`
      , `vw_platform_sso_users`.`invite_token` `invite_token`
      , `vw_platform_sso_users`.`last_invite_token_sent_date` `last_invite_token_sent_date`
      , `vw_platform_sso_users`.`is_invited` `is_invited`
      , `vw_platform_sso_users`.`is_verified` `is_verified`
      , `vw_platform_sso_users`.`ts_row_id` `ts_row_id`
      , `vw_platform_sso_users`.`ts_employer_key` `ts_employer_key`
      , `vw_platform_sso_users`.`ts_employer_name` `ts_employer_name`
      , `vw_platform_sso_users`.`ts_employee_key` `ts_employee_key`
      , `vw_platform_sso_users`.`ts_email` `ts_email`
      , `vw_platform_sso_users`.`ts_first_name` `ts_first_name`
      , `vw_platform_sso_users`.`ts_last_name` `ts_last_name`
      , `vw_platform_sso_users`.`ts_phone` `ts_phone`
      , `vw_platform_sso_users`.`ts_ssn` `ts_ssn`
      , `vw_platform_sso_users`.`ts_user_is_active` `ts_user_is_active`
      , `misc`.`ts_get_participant_platforms`( `vw_platform_sso_users`.`ts_row_id` ,
                                               'registered' ) `ts_platforms_registered`
      , `misc`.`ts_get_participant_platforms`( `vw_platform_sso_users`.`ts_row_id` ,
                                               'invalid' ) `ts_platforms_disconnected`
      , `api`.`get_notification_log_count`( `vw_platform_sso_users`.`email` , 'alert' , 'ts_sdk_1' ,
                                            '%' ) `warning_notification_log_count`
      , `api`.`get_notification_log_last_sent_at`( `vw_platform_sso_users`.`email` , 'alert' , 'ts_sdk_1' ,
                                                   '%' ) `warning_notification_log_last_sent_at`
      , `api`.`get_notification_log_count`( `vw_platform_sso_users`.`email` , 'alert' , 'tpastream_disconnected' ,
                                            '%' ) `disconnected_notification_log_count`
      , `api`.`get_notification_log_last_sent_at`( `vw_platform_sso_users`.`email` , 'alert' ,
                                                   'tpastream_disconnected' ,
                                                   '%' ) `disconnected_notification_log_last_sent_at`
      , `api`.`get_notification_log_count`( `vw_platform_sso_users`.`email` , 'alert' , 'tpastream_unregistered' ,
                                            '%' ) `unregistered_notification_log_count`
      , `api`.`get_notification_log_last_sent_at`( `vw_platform_sso_users`.`email` , 'alert' ,
                                                   'tpastream_unregistered' ,
                                                   '%' ) `unregistered_notification_log_last_sent_at`
    from
        `api`.`vw_platform_sso_users`
    where
          `vw_platform_sso_users`.`is_particpant` = 1
      and `vw_platform_sso_users`.`is_verified` = 1
      and `vw_platform_sso_users`.`ts_user_is_active` in (2, 3)
    order by
        `vw_platform_sso_users`.`email`;

