create definer = root@`%` view vw_cases_renewal_cons_ben_entered_values
as
    select
        `a`.`case_id` `case_id`
      , `a`.`employer_name` `employer_name`
      , `a`.`employer_id` `employer_id`
      , `a`.`case_sub_type` `case_sub_type`
      , `api`.`get_sf_case_owner_fullname`( `a`.`sf_case_owner_user_id` ) `sf_case_owner_fullname`
      , `a`.`is_ready_for_processing` `is_ready_for_processing`
      , substr( `a`.`last_rollout_error` , 1 , 150 ) `last_rollout_error`
      , `a`.`form_invite_token` `form_invite_token`
      , `a`.`case_status` `case_status`
      , case
            when `a`.`case_status` like 'New%' or `a`.`case_status` like 'Ready For Entry%' then 'Waiting'
            when `a`.`case_status` like 'Cancelled%' then 'Cancelled'
            else 'Rolled Out'
        end `major_case_status`
      , `portal`.`get_values_for_form_key`( `a`.`form_invite_token` , 0 , NULL , NULL , 'healthcare' ,
                                            1 ) `valuesof_carriers_healthcare`
      , `portal`.`get_values_for_form_key`( `a`.`form_invite_token` , 0 , NULL , NULL , 'pcvdo71f0845ede' ,
                                            1 ) `valuesof_carriers_dental`
      , `portal`.`get_values_for_form_key`( `a`.`form_invite_token` , 0 , NULL , NULL , '97rmg7999b9b9f8' ,
                                            1 ) `valuesof_carriers_vision`
    from
        `api`.`api_cases` `a`
    where
          `a`.`case_type` = 'Renewal'
      and `a`.`case_sub_type` = 'CONSUMER_BENEFIT'
    order by
        `a`.`employer_name`;

