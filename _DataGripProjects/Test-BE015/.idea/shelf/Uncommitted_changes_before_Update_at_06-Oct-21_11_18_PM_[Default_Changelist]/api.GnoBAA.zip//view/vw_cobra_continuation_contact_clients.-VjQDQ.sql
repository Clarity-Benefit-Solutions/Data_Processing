create definer = root@`%` view vw_cobra_continuation_contact_clients
as
    select
        `t`.`contact_id` `contact_id`
      , `t`.`organization_name` `organization_name`
      , `t`.`contact_first_name` `contact_first_name`
      , `t`.`contact_last_name` `contact_last_name`
      , `t`.`contact_email` `contact_email`
      , `t`.`contact_type` `contact_type`
      , `t`.`contact_sub_type` `contact_sub_type`
      , `t`.`contact_phone` `contact_phone`
      , `t`.`contact_is_cobra_contact` `contact_is_cobra_contact`
      , `t`.`status` `status`
      , `t`.`clientid` `clientid`
      , `t`.`clientname` `clientname`
      , `t`.`org_contact_email` `org_contact_email`
      , `t`.`require_addtn_attestation_from_qbs` `require_addtn_attestation_from_qbs`
      , `t`.`require_addtn_attestation_from_qbs_sub_on` `require_addtn_attestation_from_qbs_sub_on`
      , `t`.`count_pending_rollover` `count_pending_rollover`
      , `t`.`count_submitted_rollover` `count_submitted_rollover`
      , `t`.`count_pending_ongoing` `count_pending_ongoing`
      , `t`.`count_submitted_ongoing` `count_submitted_ongoing`
      , `t`.`count_pending_rollover` + `t`.`count_submitted_rollover` + `t`.`count_pending_ongoing` +
        `t`.`count_submitted_ongoing` `total_count`
      , `t`.`reminder_count` `reminder_count`
      , `t`.`last_reminder_date` `last_reminder_date`
      , `t`.`last_reminder_ongoing_date` `last_reminder_ongoing_date`
      , `t`.`reminder_count_attestation` `reminder_count_attestation`
      , `t`.`last_reminder_date_attestation` `last_reminder_date_attestation`
    from
        (
            select
                `cc`.`contact_id` `contact_id`
              , `cc`.`organization_name` `organization_name`
              , `cc`.`contact_first_name` `contact_first_name`
              , `cc`.`contact_last_name` `contact_last_name`
              , `cc`.`contact_email` `contact_email`
              , `cc`.`contact_phone` `contact_phone`
              , `cc`.`contact_type` `contact_type`
              , `cc`.`contact_sub_type` `contact_sub_type`
              , `cc`.`contact_is_cobra_contact` `contact_is_cobra_contact`
              , `cc`.`status` `status`
              , `cc`.`clientid` `clientid`
              , `cc`.`clientname` `clientname`
              , `cc`.`org_contact_email` `org_contact_email`
              , `cc`.`require_addtn_attestation_from_qbs` `require_addtn_attestation_from_qbs`
              , `cc`.`require_addtn_attestation_from_qbs_sub_on` `require_addtn_attestation_from_qbs_sub_on`
              , `api`.`get_cobra_continutation_counts`( `cc`.`clientid` , 0 , 'ROLLOVER' ) `count_pending_rollover`
              , `api`.`get_cobra_continutation_counts`( `cc`.`clientid` , 1 , 'ROLLOVER' ) `count_submitted_rollover`
              , `api`.`get_cobra_continutation_counts`( `cc`.`clientid` , 0 , 'ONGOING' ) `count_pending_ongoing`
              , `api`.`get_cobra_continutation_counts`( `cc`.`clientid` , 1 , 'ONGOING' ) `count_submitted_ongoing`
              , `api`.`get_notification_log_count`( `cc`.`contact_email` , 'email' , 'cobra_continuation' ,
                                                    '%' ) `reminder_count`
              , `api`.`get_notification_log_last_sent_at`( `cc`.`contact_email` , 'email' , 'cobra_continuation' ,
                                                           '%' ) `last_reminder_date`
              , `api`.`get_notification_log_last_sent_at`( `cc`.`contact_email` , 'email' ,
                                                           'cobra_continuation_ongoing' ,
                                                           '%' ) `last_reminder_ongoing_date`
              , `api`.`get_notification_log_count`( `cc`.`contact_email` , 'email' , 'cobra_continuation_attestation' ,
                                                    '%' ) `reminder_count_attestation`
              , `api`.`get_notification_log_last_sent_at`( `cc`.`contact_email` , 'email' ,
                                                           'cobra_continuation_attestation' ,
                                                           '%' ) `last_reminder_date_attestation`
            from
                `api`.`cobra_continuation_contacts` `cc`
            where
                  `cc`.`contact_is_cobra_contact` = 1
              and `cc`.`clientname` <> 'ZZ No QBS For This Client'
            group by
                `cc`.`contact_id`
              , `cc`.`organization_name`
              , `cc`.`contact_first_name`
              , `cc`.`contact_last_name`
              , `cc`.`contact_email`
              , `cc`.`contact_phone`
              , `cc`.`contact_type`
              , `cc`.`contact_sub_type`
              , `cc`.`contact_is_cobra_contact`
              , `cc`.`status`
              , `cc`.`clientid`
              , `cc`.`clientname`
              , `cc`.`org_contact_email`
              , `cc`.`require_addtn_attestation_from_qbs`
              , `cc`.`require_addtn_attestation_from_qbs_sub_on`
        ) `t`;

