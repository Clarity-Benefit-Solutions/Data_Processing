CREATE DEFINER = admin@`%` VIEW vw_wc_employer_users AS
    SELECT
        `wc`.`wc_employer_users`.`email`                                AS `email`
      , `wc`.`wc_is_active_status`( `wc`.`wc_employer_users`.`status` ) AS `is_active`
      , CASE
            WHEN `api`.`api_is_blank`( `wc`.`wc_employer_users`.`employer_id` ) THEN CASE
                                                                                         WHEN `wc`.`wc_employer_users`.`profile_name` IN
                                                                                              ( 'Clarity Admin Master', 'Clarity Employee Role' )
                                                                                             THEN '3 TPA'
                                                                                         WHEN `wc`.`wc_employer_users`.`profile_name` IN
                                                                                              ( 'Broker Portal Standard', 'Group Broker Profile' )
                                                                                             THEN '2 BROKER'
                                                                                         WHEN `wc`.`wc_employer_users`.`profile_name` IN ( 'Y', 'N' )
                                                                                             THEN '000 INVALID'
                                                                                         ELSE '2 BROKER' END
            ELSE '1 CLIENT' END                                         AS `user_type`
      , `wc`.`wc_employer_users`.`tpa_id`                               AS `tpa_id`
      , `wc`.`wc_employer_users`.`user_id`                              AS `user_id`
      , `wc`.`wc_employer_users`.`profile_name`                         AS `profile_name`
      , `wc`.`wc_employer_users`.`middle_initial`                       AS `middle_initial`
      , `wc`.`wc_employer_users`.`name_prefix`                          AS `name_prefix`
      , `wc`.`wc_employer_users`.`phone`                                AS `phone`
      , `wc`.`wc_employer_users`.`row_id`                               AS `row_id`
      , `wc`.`wc_employer_users`.`employer_id`                          AS `employer_id`
      , `wc`.`wc_employer_users`.`first_name`                           AS `first_name`
      , `wc`.`wc_employer_users`.`last_name`                            AS `last_name`
      , `wc`.`wc_employer_users`.`allow_get_current_sessions`           AS `allow_get_current_sessions`
      , `wc`.`wc_employer_users`.`allow_to_uplod_a_payroll_file`        AS `allow_to_uplod_a_payroll_file`
      , `wc`.`wc_employer_users`.`status`                               AS `status`
      , `wc`.`wc_employer_users`.`created_at`                           AS `created_at`
      , `wc`.`wc_employer_users`.`created_by`                           AS `created_by`
      , `wc`.`wc_employer_users`.`updated_at`                           AS `updated_at`
      , `wc`.`wc_employer_users`.`updated_by`                           AS `updated_by`
    FROM
        `wc`.`wc_employer_users`;

