CREATE
    DEFINER = admin@`%` PROCEDURE upsert_wc_employer_users(IN employer_id varchar(200), IN first_name varchar(200)
, IN last_name varchar(200), IN allow_get_current_sessions varchar(200), IN allow_to_uplod_a_payroll_file varchar(200)
, IN email varchar(200), IN middle_initial varchar(200), IN name_prefix varchar(200), IN phone varchar(200)
, IN profile_name varchar(200), IN status varchar(200), IN tpa_id varchar(200), IN user_id varchar(200))
BEGIN

    CALL api.db_show_message(
            'upsert_wc_employer_users'
        , concat(
                    ' Processing Employer User '
                , employer_id
                , ', '
                , first_name
                , ', '
                , user_id ) );

    INSERT
    INTO
        wc.wc_employer_users(
                              employer_id
                            , first_name
                            , last_name
                            , allow_get_current_sessions
                            , allow_to_uplod_a_payroll_file
                            , email
                            , middle_initial
                            , name_prefix
                            , phone
                            , profile_name
                            , status
                            , tpa_id
                            , user_id
    )
    VALUES
    (
        employer_id
    ,   first_name
    ,   last_name
    ,   allow_get_current_sessions
    ,   allow_to_uplod_a_payroll_file
    ,   email
    ,   middle_initial
    ,   name_prefix
    ,   phone
    ,   profile_name
    ,   status
    ,   tpa_id
    ,   user_id
    )
    ON DUPLICATE KEY UPDATE
                         employer_id                   = employer_id
                       , first_name                    = first_name
                       , last_name                     = last_name
                       , allow_get_current_sessions    =
                             allow_get_current_sessions
                       , allow_to_uplod_a_payroll_file =
                             allow_to_uplod_a_payroll_file
                       , email                         = email
                       , middle_initial                = middle_initial
                       , name_prefix                   = name_prefix
                       , phone                         = phone
                       , profile_name                  = profile_name
                       , status                        = status
                       , tpa_id                        = tpa_id;
END;

