CREATE
    DEFINER = admin@`%` PROCEDURE truncate_wc_all_employers_users_participants(IN dummy int(1))
BEGIN

    CALL api.db_show_message( 'truncate_wc_employees_employers', 'STARTING' );

    TRUNCATE TABLE wc.wc_employer_users;
    TRUNCATE TABLE wc.wc_employer_plans;
    TRUNCATE TABLE wc.wc_employers;
    TRUNCATE TABLE wc.wc_participants;


    CALL api.db_show_message( 'truncate_wc_employees_employers', 'FINISHED' );


END;

