CREATE
    DEFINER = admin@`%` PROCEDURE upsert_wc_employers(IN employer_id varchar(200), IN employer_name varchar(200)
, IN active_first_use varchar(200), IN bucket_split varchar(200), IN city varchar(200), IN email_address varchar(200)
, IN copay_auto_renew varchar(200), IN employer_status varchar(200), IN recurring_expense_auto_renew varchar(200)
, IN state varchar(200), IN tpa_id varchar(200))
BEGIN

    CALL api.db_show_message(
            'upsert_wc_employers'
        , concat(
                    ' Processing Employer '
                , employer_id
                , ', '
                , employer_name ) );

    INSERT
    INTO
        wc.wc_employers(
                         employer_id
                       , employer_name
                       , active_first_use
                       , bucket_split
                       , city
                       , email_address
                       , copay_auto_renew
                       , employer_status
                       , recurring_expense_auto_renew
                       , state
                       , tpa_id
    )
    VALUES
    (
        employer_id
    ,   employer_name
    ,   active_first_use
    ,   bucket_split
    ,   city
    ,   email_address
    ,   copay_auto_renew
    ,   employer_status
    ,   recurring_expense_auto_renew
    ,   state
    ,   tpa_id
    )
    ON DUPLICATE KEY UPDATE
                         employer_name                = employer_name
                       , active_first_use             = active_first_use
                       , bucket_split                 = bucket_split
                       , city                         = city
                       , email_address                = email_address
                       , copay_auto_renew             = copay_auto_renew
                       , employer_status              = employer_status
                       , recurring_expense_auto_renew =
                             recurring_expense_auto_renew
                       , state                        = state
                       , tpa_id                       = tpa_id;
END;

